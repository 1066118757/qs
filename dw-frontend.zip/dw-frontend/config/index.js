// see http://vuejs-templates.github.io/webpack for documentation.
var path = require('path');
var proxyPath, proxyPath2;

//proxyPath = 'http://192.168.55.121:80';
proxyPath = 'http://192.168.55.115:18083';
//proxyPath = 'http://192.168.101.50:18083';
// proxyPath='http://192.168.111.80:8080';
// proxyPath="http://192.168.111.116:18083";
// proxyPath="http://192.168.101.53:18083";

proxyPath2 = 'http://192.168.55.115:9000';
// proxyPath2 = "http://192.168.101.22:9000";//欧治成

module.exports = {
  build: {
    env: require('./prod.env'),
    index: path.resolve(__dirname, '../dist/index.html'),
    assetsRoot: path.resolve(__dirname, '../dist/'),
    assetsSubDirectory: './static',
    assetsPublicPath: './',
    productionSourceMap: true,
    // Gzip off by default as many popular static hosts such as
    // Surge or Netlify already gzip all static assets for you.
    // Before setting to `true`, make sure to:
    // npm install --save-dev compression-webpack-plugin
    productionGzip: false,
    productionGzipExtensions: ['js', 'css'],
    // Run the build command with an extra argument to
    // View the bundle analyzer report after build finishes:
    // `npm run build --report`
    // Set to `true` or `false` to always turn it on or off
    bundleAnalyzerReport: process.env.npm_config_report
  },
  dev: {
    env: require('./dev.env'),
    port: 1234,
    autoOpenBrowser: true,
    assetsSubDirectory: 'static',
    assetsPublicPath: '/',
    proxyTable: {
      '/v1': {
        target: proxyPath,
        changeOrigin: true
      },
      '/rest': {
        target: proxyPath2,
        changeOrigin: true
      }
    },
    // CSS Sourcemaps off by default because relative paths are "buggy"
    // with this option, according to the CSS-Loader README
    // (https://github.com/webpack/css-loader#sourcemaps)
    // In our experience, they generally work as expected,
    // just be aware of this issue when enabling this option.
    cssSourceMap: false
  }
}
