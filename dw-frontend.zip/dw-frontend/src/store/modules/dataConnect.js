/**
 * 数据引接模块的 状态
 * */
// initial state
const state = {
    sourceType: [{
            src: "Mysql.png",
            text: "MySQL",
            key: 601
        },
        {
            src: "Oracle.png",
            text: "Oracle",
            key: 602
        },
        {
            src: "Sqlserver.png",
            text: "Sql Server",
            key: 603
        },
        {
            src: "infobright.png",
            text: "infobright",
            key: 604
        },
        {
            src: "Postgras.png",
            text: "Postgre sql",
            key: 605
        },
        {
            src: "Phoenix.png",
            text: "Phoenix",
            key: 606
        },
        {
            src: "mongodb.png",
            text: "mongodb",
            key: 607
        },
        {
            src: "Web Service.png",
            text: "Web Service",
            key: 608
        },
        {
            src: "hive.png",
            text: "hive",
            key: 613
        },
    ],
    fileType: [{
            src: "excel.png",
            text: "Excel",
            key: 609,
            reg: /\.(xls|xlsx)$/,
            desc: "请选择Excel类型的文件！"
        },
        {
            src: "txt.png",
            text: "Txt",
            key: 610,
            reg: /\.txt$/,
            desc: "请选择Txt类型的文件！"
        },
        {
            src: "CSV.png",
            text: "CSV",
            key: 611,
            reg: /\.csv$/,
            desc: "请选择Csv类型的文件！"
        },
        {
            src: "xml.png",
            text: "Xml",
            key: 612,
            reg: /\.xml$/,
            desc: "请选择Xml类型的文件！"
        },
    ],
    priority: [{
            key: "高",
            value: 1
        },
        {
            key: "中",
            value: 2
        },
        {
            key: "低",
            value: 3
        }
    ],
    time: 0,
    syntaxHighlight(json, flag) {
        /**
         * json必须是对象，不能是字符串
         * */
        if (flag) return '<span class="key">根据当前请求字段得到的响应为：<span class="boolean">' + json + '</span>，不符合字段解析要求（它应该为一个对象或者数组）</span>';
        if (typeof json != 'string') {
            json = JSON.stringify(json, undefined, 2);
        }
        json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function(match) {
            var cls = 'number';
            if (/^"/.test(match)) {
                if (/:$/.test(match)) {
                    cls = 'key';
                } else {
                    cls = 'string';
                }
            } else if (/true|false/.test(match)) {
                cls = 'boolean';
            } else if (/null/.test(match)) {
                cls = 'null';
            }
            return '<span class="' + cls + '">' + match + '</span>';
        });
    }
};

// getters
const getters = {

    }
    // mutations
const mutations = {

}

// actions
const actions = {

}

export default {
    // namespaced: true,
    state,
    getters,
    actions,
    mutations
}
export { state }