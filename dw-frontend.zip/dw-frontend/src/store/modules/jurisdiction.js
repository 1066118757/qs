/**
 * 权限管理
 * */
// initial state
const state = {
//页面是否合法（404）
  legal:true,
  menuArray:[]
};

// getters
const getters = {

}
// mutations
const mutations = {
  setLegal(c,v){c.legal = v},
  setMenuArray(c,v){c.menuArray = v},
}

// actions
const actions = {

}

export default {
  // namespaced: true,
  state,
  getters,
  actions,
  mutations
}
export {state}
