/**
 * 元数据模块的 状态
 * */
// initial state
const state = {
  metaType:[{text:"数据结构",key:201},{text:"数据字典",key:202}],
  metaItemType:[{text:"文本",key:301},{text:"数值",key:302}],
}

// getters
const getters = {
  minTableColumns(state){
    let num = state.screenHeight - 727;
    return num >= 0 ? Math.floor(num / 40 + 10): 10;
  }
}
// mutations
const mutations = {

}

// actions
const actions = {

}

export default {
  // namespaced: true,
  state,
  getters,
  actions,
  mutations
}
