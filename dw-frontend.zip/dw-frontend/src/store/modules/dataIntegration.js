/**
 * 数据整合模块的 状态
 * */
// initial state
const state = {
  scriptType:[
    {
      text:"java",
      key:901
    },
    {
      text:"python",
      key:902
    },
    {
      text:"R",
      key:903
    },
  ],
  ruleType:[
    {
      text:"更新值",
      key:801
    },
    {
      text:"数据清洗",
      key:802
    },
    {
      text:"数据筛选",
      key:803
    },
    {
      text:"列操作",
      key:804
    },
    {
      text:"其他",
      key:805
    },
    {
      text:"自定义",
      key:806
    },
  ],
  paramType:[
    {
      text:"String",
      key:1301
    },
    {
      text:"Bigdecimal",
      key:1302
    },
    {
      text:"Integer",
      key:1303
    },
    {
      text:"Short",
      key:1304
    },
    {
      text:"Boolean",
      key:1305
    },
  ],
  paramGetType:[
    {
      text:"下拉框（列）",
      key:1200
    },
    {
      text:"下拉框（列多选）",
      key:1201
    },
    {
      text:"输入框",
      key:1202
    },
    {
      text:"输入框(输入多值)",
      key:1203
    },
    {
      text:"数字输入框",
      key:1204
    },
    {
      text:"下拉框",
      key:1205,
      list:[]
    },
    {
      text:"下拉多选框",
      key:1206,
      list:[]
    },
    {
      text:"开关选择(是或否)",
      key:1207
    },
	  {
		  text:"数据字典选择",
		  key:1208
	  },

  ]
};

// getters
const getters = {

}
// mutations
const mutations = {

}

// actions
const actions = {

}

export default {
  // namespaced: true,
  state,
  getters,
  actions,
  mutations
}
export {state}
