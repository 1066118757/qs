// export const minTableColumns = state => {
//   let num = state.screenHeight - 727;
//   return num >= 0 ? Math.floor(num / 40 + 10): 10;
// }
export const demo = ()=>{}
