import Vue from 'vue'
import Vuex from 'vuex'
import * as getters from './getters'
import connect from './modules/dataConnect'
import integration from './modules/dataIntegration'
import meta from './modules/metaData'
import qx from './modules/jurisdiction'
import createLogger from './plugins/logger'
import {ISDEV as debug} from '@/config/constant'

Vue.use(Vuex);
export default new Vuex.Store({
  state:{
    //logo and company name
    company:{},
    //屏幕高度
    screenHeight:Math.max(window.innerHeight,727),
    //面包屑
    crumbs:[],
    //验证输出长度用的
    validateLength(num){
      if(num === undefined)return (r,v,c)=>{
        if(!v)c("该项为必填项");
        else c();
      };
      return (r,v,c)=>{
        if(!v)c("该项为必填项");
        else if(v.length>num)c("最多可输入"+num+"个字符");
        else c();
      }
    },
    validatorPhone(r,v,c){
      if(!/^1[3|4|5|8|7][0-9]\d{8}$/.test(v))c("手机号格式错误");
      else c();
    },
    validatorEmail(r,v,c){
      if(!/^[0-9A-Za-z][\.-_0-9A-Za-z]*@[0-9A-Za-z]+(\.[0-9A-Za-z]+)+$/.test(v))c("邮箱格式错误");
      else c();
    },
    //设置table高度用
    setTableHeight(num,isMin){
      if(isMin)return {minHeight:this.screenHeight - num + 'px'};
      return {height:this.screenHeight - num + 'px'};
    }
  },
  mutations:{
    setScreenHeight(c,v){c.screenHeight = Math.max(v,727);},//再啷个也要有727的高度
    setCrumbs(c,v){c.crumbs = v},
    setCompany(c,v){c.company = v},
    setCrumbsThemeName(c,v){if(c.crumbs[0])c.crumbs[0].text = v},
  },
  // actions,
  getters,
  modules: {
    meta,
    connect,
    integration,
    qx,//权限
  },
  strict: debug,
  plugins: debug ? [createLogger()] : []
})
