import Vue from 'vue';
import Router from 'vue-router';

import metaData from './metaData';
// import dataAnalysisMining from './dataAnalysisMining';
import dataIntegration from './dataIntegration';
import dataStorage from './dataStorage';
import dataConnect from './dataConnect';
import audit from './audit';
import user from './user';
import eml from './eml';
import dataDesensitization from './dataDesensitization';
import test from './test';
// import systemTask from './systemTask';
import App from '@/components/App';
import menu from '@/components/common/menu';
import login from '@/components/other/login';
import noFound from "cmpts/common/noFound"
import beforeEnter from "@/config/beforeEnter"
Vue.use(Router);
//路由在这里配置，以后文件多了，还可以拆分然后在合并
let childrens = [].concat(metaData,test,dataConnect,dataIntegration,dataStorage,dataDesensitization,audit,user,eml);//这个变量要用在menu组件中
//  dataAnalysisMining,systemTask
let routes = [
  {
    path: '/',
    name: 'app',
    components:{
      default:App,
      menu:menu
    },
    meta: {
      name: "app"
    },
    // redirect:{name:"login"},
    children: childrens,
    beforeEnter
  },
  {
    path: '/login',
    name: 'login',
    component:login
  },
  {
    path: '*',
    name: 'noFound',
    component:noFound
  }
];

let router = new Router({
  //mode: 'history',
  routes
});
export default router;
export {childrens};


