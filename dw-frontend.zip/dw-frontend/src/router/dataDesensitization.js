
import Index from 'cmpts/dataDesensitization/index'

export default [
  {
    path:'/data_desensitization',
    name:'dataDesensitization',
    component:Index,
    meta: {
      name:"数据脱敏",
      title:"数据脱敏"
    },
    children:[]
  }
];
