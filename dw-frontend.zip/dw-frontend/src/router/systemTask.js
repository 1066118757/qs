import Index from "cmpts/systemTask/index"
export default [
  {
    path:'/system_task',
    name:'systemTask',
    component:Index,
    meta: {
      name:"系统任务",
      title:"系统任务系统"
    },
    children:[]
  }
];
