import Index from "cmpts/dataIntegration/index"
import ruleList from "cmpts/dataIntegration/rule_list"
import taskList from "cmpts/dataIntegration/task_list"
import sub_menu from "cmpts/dataIntegration/sub_menu"
import workItem from "cmpts/dataIntegration/work_details"
import algorithmList from "cmpts/dataIntegration/algorithm_list"

// algorithm_list
import taskDetail from "cmpts/dataIntegration/task_details"
import jobDetail from "cmpts/dataIntegration/job_detail"
import JoinTable from 'cmpts/dataIntegration/joinTable'
import Main from "cmpts/common/main"
import crumbs from "cmpts/common/crumbs"
import taskListArithmetic from "cmpts/dataIntegration/task_list_arithmetic"
export default [{
    path: '/data_integration',
    name: 'dataIntegration',
    components: {
        default: Main,
        sub_menu: sub_menu,
        crumbs: crumbs
    },
    props: { crumbs: { route: { name: "数据整合", path: '/data_integration' } } },
    meta: {
        name: "数据整合",
        title: "数据整合系统"
    },
    redirect: { name: 'integrationWorkTable' },
    children: [{
            path: "work-table",
            name: "integrationWorkTable",
            component: Index,
        },
        {
            path: "work-table/work-details",
            name: "integrationWorkDetails",
            component: workItem,
        },
        {
            path: "task-list",
            name: "integrationTaskList",
            component: taskList
        },
        {
            path: "task-list/task-detail",
            name: "integrationTaskDetail",
            component: taskDetail,
        },
        {
          path: "task-list-arithmetic/job-detail",
          name: "jobDetail",
          component: jobDetail,
        },
        {
          path: "task-list-arithmetic",
          name: "integrationTaskListArithmetic",
          component: taskListArithmetic
        },
        {
            path: "rule-list",
            name: "integrationRuleList",
            component: ruleList
        },
        {
            path: "algorithm-list",
            name: "integrationAlgorithmList",
            component: algorithmList
        },
        {
            path: 'join/table',
            name: 'joinTable',
            component: JoinTable
        }
    ]
}];
