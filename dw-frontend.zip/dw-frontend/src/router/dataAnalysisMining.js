import Index from "cmpts/dataAnalysisMining/index"
export default [
  {
    path:'/data_analysis_mining',
    name:'dataAnalysisMining',
    component:Index,
    meta: {
      name:"数据分析挖掘",
      title:"数据分析挖掘系统"
    },
    children:[]
  }
];
