import work_list from "cmpts/metaData/work_list"
import TaskItem from "cmpts/metaData/task_list"
import sub_menu from "cmpts/metaData/sub_menu"
import AddMeta from "cmpts/metaData/add_work"
import Details from "cmpts/metaData/item_details"
import crumbs from "cmpts/common/crumbs"
import Main from "cmpts/common/main"
import monitoring from "cmpts/metaData/monitoring"

export default [
  {
    path:'/meta_data',
    name:'metaData',
    components:{
      default:Main,
      sub_menu:sub_menu,
      crumbs:crumbs
    },
    props: {crumbs:{route:{name:"元数据",path:"/meta_data"}}},
    meta: {
      name:"元数据",
      title:"元数据管理系统"
    },
    children:[
      {
        path:"work_list",
        name:"metaWorkList",
        component:work_list
      },
      {
        path:"item_details",
        name:"metaItemDetails",
        component:Details
      },
      {
        path:"add_work",
        name:"metaAddWork",
        component:AddMeta
      },
      {
        path:"task_list",
        name:"metaTaskList",
        component:TaskItem
      },
      {
        path:"task_details",
        name:"metaTaskDetails",
        component:work_list
      },
      {
        path:"monitoring",
        name:"monitoring",
        component:monitoring
      }
    ]
  }
];
