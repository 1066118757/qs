import Index from "cmpts/eml/index"
import sub_menu from "cmpts/eml/sub_menu"

import Main from "cmpts/common/main"
import crumbs from "cmpts/common/crumbs"

export default [{
    path: '/eml',
    name: 'eml',
    components: {
        default: Main,
        sub_menu: sub_menu,
        crumbs: crumbs
    },
    props: { crumbs: { route: { name: "eml", path: '/eml' } } },
    meta: {
        name: "eml",
        title: "eml"
    },
    redirect: { name: 'emlIndex' },
    children: [{
            path: "work-table",
            name: "emlIndex",
            component: Index,
        }
    ]
}];
