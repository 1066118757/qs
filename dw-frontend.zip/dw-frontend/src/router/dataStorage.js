
import sub_menu from 'cmpts/dataStorage/sub_menu'
import crumbs from 'cmpts/common/crumbs'
import Main from 'cmpts/common/main'
import Source from 'cmpts/dataStorage/source'
import SourceTableList from 'cmpts/dataStorage/source_table_list'
import SourceTableDetail from 'cmpts/dataStorage/source_table_detail'
import SourceTableAaaData from 'cmpts/dataStorage/source_table_add_data'
import SourceTableShare from 'cmpts/dataStorage/source_table_share'
import Img from 'cmpts/dataStorage/img'
import Video from 'cmpts/dataStorage/video'
import OtherFile from 'cmpts/dataStorage/otherFile'
import RestFull from 'cmpts/dataStorage/restFull'
export default [
  {
    path: '/data_storage',
    name: 'dataStorage',
    components:{
      default:Main,
      sub_menu:sub_menu,
      crumbs:crumbs
    },
    //props: {crumbs: {route: {name: '数据存储', path: '/data_storage'}}},
    meta: {
      name: '数据存储',
      title: '数据存储系统'
    },
    redirect: {name: 'storageSource'},
    children: [
      {
        path: 'source',
        name: 'storageSource',
        component: Source
      },
      {
        path: 'source/source_table_list',
        name: 'source_table_list',
        component: SourceTableList
      },
      {
        path: 'source/source_table_detail',
        name: 'source_table_detail',
        component: SourceTableDetail
      },
      {
        path: 'source/source_table_add_data',
        name: 'source_table_add_data',
        component: SourceTableAaaData
      },
      {
        path: 'source/source_table_share',
        name: 'source_table_share',
        component: SourceTableShare
      },
      {
        path: 'img',
        name: 'storageImg',
        component: Img
      },
      {
        path: 'video',
        name: 'storageVideo',
        component: Video
      },
      {
        path: 'otherFile',
        name: 'otherFile',
        component: OtherFile
      },
      {
        path: 'restFull',
        name: 'restFull',
        component: RestFull
      }
    ]
  }
];
