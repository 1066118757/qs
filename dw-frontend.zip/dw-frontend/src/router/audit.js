
import auditList from "cmpts/audit/list"
export default [
  {
    path:'/audit',
    name:'audit',
    component:auditList,
    meta: {
      name:"数据审计",
      title:"数据审计"
    }
  }
];
