
import userList from "cmpts/user/list"

import crumbs from "cmpts/common/crumbs"
export default [
  {
    path:'/user',
    name:'user',
    component:userList,
    meta: {
      name:"用户管理",
      title:"用户管理"
    }
  }
];
