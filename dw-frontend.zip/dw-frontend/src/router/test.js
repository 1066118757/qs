
import Index from 'cmpts/test/index'

export default [
  {
    path:'/test',
    name:'test',
    component:Index,
    meta: {
      name:"数据目录",
      title:"数据目录"
    },
    children:[]
  }
];
