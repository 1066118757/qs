import Index from "cmpts/dataConnect/source"
import Statistics from "cmpts/dataConnect/statistics"
import Etl from "cmpts/dataConnect/etl"
import sub_menu from "cmpts/dataConnect/sub_menu"
import Add from "cmpts/dataConnect/add"
import AddEtl from "cmpts/dataConnect/addEtl"
import AddEtlFromFile from "cmpts/dataConnect/addEtlFromFile"
import addEtlForWebService from "cmpts/dataConnect/addEtlForWebService"
import DatabaseTransference from "cmpts/dataConnect/database_transference"
import crumbs from "cmpts/common/crumbs"
import Main from "cmpts/common/main"
export default [
  {
    path:'/data_connect',
    name:'dataConnect',
    components:{
      default:Main,
      sub_menu:sub_menu,
      crumbs:crumbs
    },
    props: {crumbs:{route:{name:"数据引接",path:"/data_connect"}}},
    meta: {
      name:"数据引接",
      title:"数据引接系统"
    },
    redirect:{name:"source"},
    children:[
      {
        path:"source",
        name:"source",
        component:Index
      },
      {
        path:"source/add",
        name:"addSource",
        component:Add,
      },
      {
        path:"source/statistics",
        name:"statisticsSource",
        component:Statistics,
      },
      {
        path:"etl",
        name:"etl",
        component:Etl
      },
      {
        path:"etl/statistics",
        name:"statisticsEtl",
        component:Statistics,
      },
      {
        path:"etl/addEtl",
        name:"addEtl",
        component:AddEtl,
      },
      {
        path:"etl/addEtlForWebService",
        name:"addEtlForWebService",
        component:addEtlForWebService,
      },
      {
        path:"etl/addEtlFromFile",
        name:"addEtlFromFile",
        component:AddEtlFromFile,
      },
      {
        path:"etl/database_transference",
        name:"databaseTransference",
        component:DatabaseTransference,
      },
    ]
  }
];
