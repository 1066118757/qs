function formatterMetaItemType(Vue) {
  Vue.filter("formatterMetaItemType", formatter);
}
function formatterMetaType(Vue) {
  Vue.filter("formatterMetaType", formatter2);
}
function formatter(value) {
  switch (value) {
    case 301:
      return "文本";
    case 302:
      return "数值";
    default:
      return value;
  }
}
function formatter2(value) {
  switch (value) {
    case 201:
      return "数据结构";
    case 202:
      return "数据字典";
    default:
      return value;
  }
}


export {formatterMetaItemType as default};
export {formatterMetaType};

