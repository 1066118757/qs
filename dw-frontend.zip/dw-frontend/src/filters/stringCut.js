function stringCut(Vue) {
  Vue.filter("stringCut", stringCutFn);
}

function stringCutFn(str, fmt) {
  let newStr=str;
  if(str&&str.length>fmt){
    newStr=str.slice(0,fmt)+"..."
  }
  return newStr;
}


export {stringCut as default, stringCutFn};
