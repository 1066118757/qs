import {state} from "@/store/modules/dataConnect"
function formatterNumber(Vue) {
  Vue.filter("formatterSyncType", formatter);
}

function formatter(value) {
  switch (value){
    case 1:
      return "进行中";
    case 2:
      return "同步成功";
    case 3:
      return "同步失败";
  }
}
export {formatterNumber as default};

