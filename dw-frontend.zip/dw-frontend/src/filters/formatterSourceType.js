import {state} from "@/store/modules/dataConnect"
function formatterNumber(Vue) {
  Vue.filter("formatterSourceType", formatter);
}

function formatter(value) {
  let o = state.sourceType.find(l=>l.key === value) || state.fileType.find(l=>l.key === value);
  if(o)return o.text;
  return value
}
export {formatterNumber as default};

