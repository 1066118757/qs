import {state} from "@/store/modules/dataConnect"
function formatterNumber(Vue) {
  Vue.filter("formatterPriority", formatter);
}

function formatter(v) {
  let obj = state.priority.find(({value})=>value === v);
  return obj?obj.key:v;
}
export {formatterNumber as default};

