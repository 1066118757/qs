/**
 * Created by zhaowei on 2017/12/20.
 */
import server from '@/config/server'

let oldServer = server('/rest/:params1/:params2/:params3/:params4/:params5/:analyzeMapInfoUuid', {}, {

	sparksqlDict: {
		method: 'GET',
		params: {
			params1: 'hbase',
			params2: 'sparksql',
			params3: 'dict'
		}
	},
	add: {
		method: 'POST',
		params: {
			params1: 'view',
			params2: 'add'
		}
	},
	preview: {
		method: 'POST',
		params: {
			params1: 'view',
			params2: 'preview'
		}
	},
	getAnalyzeTableColumns: {
		method: 'GET',
		params: {
			params1: 'analyze',
			analyzeMapInfoUuid: 'analyzeMapInfoUuid'
		}
	},
	pageTables: {
		method: 'get',
		params: {
			params2: 'analyze',
			params3: 'table',
			params4: 'pageList'
		}
	},
	getServerAddressConf: {
		method: 'get',
		params: {
			params1: 'getServerAddressConf'
		}
	},
	gettabledatas: {
		method: 'post',
		params: {
			params1: 'calcolumn',
			params2: 'gettabledatas',
		}
	},
	sparksqlQuery: {
		method: 'post',
		params: {
			params1: 'hbase',
			params2: 'sparksql',
			params3: 'query'
		}
	},
	exportTableData: {
		method: 'get',
		params: {
			params1: 'hbase',
			params2: 'sparksql',
			params3: 'exportTableData',
		}
	},
	clearRuleDelete: {
		method: 'get',
		params: {
			params1: 'clearRule',
			params2: 'delete',
		}
	},
	executeSql: {
		method: 'post',
		params: {
			params1: 'hbase',
			params2: 'sparksql',
			params3: 'executeSql'
		}
	},
	getToken: {
		method: 'get',
		params: {
			params1: 'oauth2',
			params2: 'access_token',
		}
	},
	me: {
		method: 'get',
		params: {
			params1: 'oauth2',
			params2: 'me',
		}
	},
	getListUser: {
		method: 'get',
		params: {
			params1: 'oauth2',
			params2: 'listUser',
		}
	},
	createUserAnalyzeTables: {
		method: 'post',
		params: {
			params1: 'hbase',
			params2: 'sparksql',
			params3: 'createUserAnalyzeTables',
		}
	},
	addUser: {
		method: 'POST',
		params: {
			params1: 'oauth2',
			params2: 'addUser',
		}
	},
	updateUser: {
		method: 'POST',
		params: {
			params1: 'oauth2',
			params2: 'updateUser',
		}
	},
	deleteUser: {
		method: 'DELETE',
		params: {
			params1: 'oauth2',
			params2: 'deleteUser',
		}
	},
	tablesCount: {
		method: 'post',
		params: {
			params1: 'hbase',
			params2: 'sparksql',
			params3: 'tables',
			params4: 'count',
		}
	},
	tableUsersChecked: {
		method: 'get',
		params: {
			params1: 'role',
			params2: 'table',
			params3: 'users',
		}
	},
	executeCountSql: {
		method: 'post',
		params: {
			params1: 'hbase',
			params2: 'sparksql',
			params3: 'executeCountSql',
		}
	}
});
export default oldServer
