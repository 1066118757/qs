import server from '@/config/server'
let integrationServer = server('/v1/:params1/:params2/:params3/:params4/:params5', {}, {
  // mataItem
  addAlls: {
    method: 'post',
    params: {
      params1: 'metaItem',
      params2: 'addAlls'
    }
  },
  metaTableList: {
    method: 'post',
    params: {
      params1: 'metaItem',
      params2: 'list',
      params3: 1,
      params4: 10000,
    }
  },
  metaTableDetail: {
    method: 'post',
    params: {
      params1: 'metaItemDetail',
      params2: 'list',
      params3: 1,
      params4: 10000,
    }
  },
  // clearRecord
  clearRecordList: {
    method: 'post',
    params: {
      params1: 'clearRecord',
      params2: 'list',
    }
  },
  clearRecordAdd: {
    method: 'post',
    params: {
      params1: 'clearRecord',
      params2: 'add',
    }
  },
  clearRecordDelete: {
    method: 'get',
    params: {
      params1: 'clearRecord',
      params2: 'delete',
    }
  },
  clearRecordDetailById: {
    method: 'get',
    params: {
      params1: 'clearRecord',
      params2: 'detailById',
    }
  },
  clearRecordUpdate: {
    method: 'post',
    params: {
      params1: 'clearRecord',
      params2: 'update',
    }
  },

  // clearRule
  clearRuleList: {
    method: 'post',
    params: {
      params1: 'clearRule',
      params2: 'list',
    }
  },
  clearRuleAdd: {
    method: 'post',
    params: {
      params1: 'clearRule',
      params2: 'add',
    }
  },
  clearRuleDelete: {
    method: 'get',
    params: {
      params1: 'clearRule',
      params2: 'delete',
    }
  },
  clearRuleUpdate: {
    method: 'post',
    params: {
      params1: 'clearRule',
      params2: 'update',
    }
  },
  // Task
  clearTaskList: {
    method: 'post',
    params: {
      params1: 'clearTask',
      params2: 'list',
    }
  },
  clearTaskAdd: {
    method: 'post',
    params: {
      params1: 'clearTask',
      params2: 'add',
    }
  },
  clearTaskDelete: {
    method: 'get',
    params: {
      params1: 'clearTask',
      params2: 'delete',
    }
  },
  clearTaskUpdate: {
    method: 'post',
    params: {
      params1: 'clearTask',
      params2: 'update',
    }
  },
  clearTaskDetail: {
    method: 'get',
    params: {
      params1: 'clearTask',
      params2: 'detailById',
    }
  },
  clearResultPreview: {
    method: 'post',
    params: {
      params1: 'clearRecord',
      params2: 'clearResultPreview',
    }
  },
  getRedisData: {
    method: 'get',
    params: {
      params1: 'clearRecord',
      params2: 'getRedisData',
    }
  },
  clearTaskLogList: {
    method: 'post',
    params: {
      params1: 'clearTaskLog',
      params2: 'list',
    }
  },
  nowExecute: {
    method: 'get',
    params: {
      params1: 'clearTask',
      params2: 'nowExecute',
    }
  }
});
export default integrationServer
