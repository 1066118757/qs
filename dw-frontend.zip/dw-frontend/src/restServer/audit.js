import server from '@/config/server'
let auditServer = server('/v1/:params1/:params2/:params3/:params4/:params5',{},{
  listLog:{
    method:'post',
    params:{
      params1:'operate',
      params2:'listLog',
    }
  },
  actionList:{
    method:'post',
    params:{
      params1:'operate',
      params2:'list',
    }
  },
});
export default auditServer
