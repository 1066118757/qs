/**
 * Created by zhaowei on 2017/12/20.
 */
import server from '@/config/server'
let otherServer = server('/rest/:params1/:params2/:params3/:params4/:params5', {}, {
  jobQueryPage: {
    method: 'post',
    params: {
      params1: 'sparkJobDeploy',
      params2: 'queryPage'
    }
  },
  jobAdd: {
    method: 'post',
    params: {
      params1: 'sparkJobDeploy',
      params2: 'add'
    }
  },
  jobDelete: {
    method: 'post',
    params: {
      params1: 'sparkJobDeploy',
      params2: 'delete',
    }
  },
  jobUpdate: {
    method: 'post',
    params: {
      params1: 'sparkJobDeploy',
      params2: 'update',
    }
  },
  jobFindById: {
    method: 'get',
    params: {
      params1: 'sparkJobDeploy',
      params2: 'findById',
    }
  },
  jobExecute: {
    method: 'put',
    params: {
      params1: 'sparkJobDeploy',
      params2: 'execute',
    }
  },
  getBatchState: {
    method: 'get',
    params: {
      params1: 'datamining',
      params2: 'getBatchState',
    }
  },
  getBatchLog: {
    method: 'get',
    params: {
      params1: 'datamining',
      params2: 'getBatchLog',
    }
  },
  getBatchState: {
    method: 'get',
    params: {
      params1: 'datamining',
      params2: 'getBatchState',
    }
  },
  getSparkJobList: {
    method: 'post',
    params: {
      params1: 'sparkjob',
      params2: 'getSparkJobList',
    }
  },

  deleteSparkJob: {
    method: 'delete',
    params: {
      params1: 'sparkjob',
      params2: 'delete',
    }
  },
  updateSparkJob: {
    method: 'post',
    params: {
      params1: 'sparkjob',
      params2: 'update',
    }
  },
  createSparkJob: {
    method: 'post',
    params: {
      params1: 'sparkjob',
      params2: 'create',
    }
  },
  uploadJobFiles: {
    method: 'post',
    params: {
      params1: 'datamining',
      params2: 'uploadJobFiles',
    }
  }

});
export default otherServer

