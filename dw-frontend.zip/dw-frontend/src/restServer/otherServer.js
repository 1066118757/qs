/**
 * Created by zhaowei on 2017/12/20.
 */
import server from '@/config/server'
let otherServer = server('/v1/:params1/:params2/:params3/:params4/:params5',{},{

  dictList:{
    method:'post',
    params:{
      params1:'dict',
      params2:'list',
    }
  },
  getCurrentInfo:{
    method:'get',
    params:{
      params1:'version',
      params2:'getCurrentInfo',
    }
  }

});
export default otherServer

