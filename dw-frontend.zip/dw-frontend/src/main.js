//最开始进入项目之前需要做的一些事情（比如：兼容性之类的）
import beforeCreate from "./config/beforeCreate"

//vue 全家桶+iView
import Vue from 'vue'
import router from './router'
import iView from 'iview'
import store from './store'
import '@/config/prototype'
//样式
import '@/assets/css/default.less'
import "@/assets/css/common.less"


//配置config
import componentConfig from './config/component'
// filter
import filter from './config/filter'
//关掉初始化时的2个console，烦死了
Vue.config.productionTip = false;
Vue.config.devtools = false;
beforeCreate(()=>{
  //根实例
  let vm =new Vue({
    router,
    store
  });
  window.onresize = (()=>{
    store.commit("setScreenHeight",Math.max(window.innerHeight,727));
  });
//安装插件/config
  Vue.use(componentConfig);
  Vue.use(filter);
  Vue.use(iView);
  window.Vue = Vue;
//挂载到html
  vm.$mount('#app');
});
