<template>
  <div class="audit_list">
    <v-Header text="数据源列表">
    </v-Header>
    <p class="search_wrapper">
      <span>用户账号</span>
      <Input style="width: 100px;" v-model="form.operatorName" placeholder="用户名"></Input>
      <span>开始时间</span>
       <DatePicker type="date" @on-change="s" format="yyyy-MM-dd" placeholder="Select date" style="width: 200px"></DatePicker>
      <span>结束时间</span>
       <DatePicker type="date" @on-change="e" format="yyyy-MM-dd" placeholder="Select date" style="width: 200px"></DatePicker>
      <span>用户行为</span>
      <Select v-model="form.actionId" style="width:300px" filterable clearable>
          <Option v-for="item in actionList" :value="item.id" :key="item.id">{{ item.actionDesc }}</Option>
      </Select>
      <span>执行结果</span>
      <Select v-model="form.result" style="width:150px" clearable>
        <Option :value="0">成功</Option>
        <Option :value="-1">失败</Option>
      </Select>
      <span>是否为系统操作</span>
      <Select v-model="form.flag" style="width:150px" >
        <Option value="null">全部</Option>
        <Option :value="1">是</Option>
        <Option :value="0">否</Option>
      </Select>

      <Button type="ghost" @click="search()">查询</Button>
    </p>
    <div class="table" :style="$store.state.setTableHeight(327)">
      <table>
        <thead>
          <tr>
            <th>序号</th>
            <th>用户ID</th>
            <th>用户类型</th>
            <th>用户账号</th>
            <th>操作表</th>
            <th>操作时间</th>
            <th>用户行为</th>
            <th>执行结果</th>
          </tr>
        </thead>
        <tbody>
          <tr v-show="!data.length">
            <td colspan="9" style="text-align: center">没有数据</td>
          </tr>
          <tr v-for="(item,index) in data" :key="item.name">
            <td v-text="index+1"></td>
            <td v-text="item.operatorName"></td>
            <td>{{item.operatorType|userType}}</td>
            <td v-text="item.operatorAccount"></td>
            <td v-text="item.operateTable"></td>
            <td>{{item.operateTime|date}}</td>
            <td>{{item.actionDesc}}</td>
            <td>
                <span :class="item.result==0?'success':'fail'">
                  {{item.result==0?'成功':'失败'}}
                </span>
            </td>
          </tr>
        </tbody>
      </table>
      <Spin fix v-show="loading"></Spin>
    </div>
    <Page
      :total="total"
      :current ="current"
      show-elevator
      show-total
      :page-size="minPageSize"
      placement="top"
      @on-change="pageChange"
      style="margin-top:10px;"
    ></Page>
  </div>
</template>
<script>
  import auditServer from "rs/audit"
  export default {
    props:{
    },
    data() {
      return {
        modal:false,
        updateText:"",
        affirm:false,
        affirm2:false,
        delItem:"",
        jyItem:{},
        total:0,
        current:1,
        data:[],
        form:{
          operateTimeStart:null,
          operateTimeEnd:null,
          actionId:undefined,
          result:undefined,
          operatorName:null,
          flag:null
        },
        loading:false,
        actionList:[],
        isSearch:false,
      }
    },
    created() {
      this.init();
      auditServer.actionList({data:{},params:{params3:1,params4:9999}},({data,errorCode})=>{
        this.loading = false;
        if(!errorCode){
          this.actionList = data.pageData;
        }
        else{
          this.$Notice.error({title:"提示",desc:"用户行为筛选列表获取失败！"})
        }
      });
    },
    directives: {

    },
    computed: {
      minPageSize(){
        return Math.max(Math.floor((this.$store.state.screenHeight - 377)/41),10);
      }
    },
    filters: {

      userType(type){
        let  userTypeList=[
          {
            name:'管理员',
            type:'admin',
          },
          {
            name:'集群操作员',
            type:'operator',
          },
          {
            name:'数据分析员',
            type:'analyzer',
          },
          {
            name:'数据处理员',
            type:'personal_trial',
          }
        ];
        for(let o of userTypeList){
          if(o.type==type)return o.name;
        }
      }
    },
    methods: {
      search(){
        this.isSearch = true;
        this.current = 1;
        this.init();
      },
      pageChange (current){
        this.current = current;
        this.init();
      },
      init(){
        let data ={};
        if(this.isSearch){
          data = this.form;
          if(data.operateTimeStart&&data.operateTimeEnd&&data.operateTimeStart>data.operateTimeEnd){
            this.$Notice.error({title:"操作无效",desc:"查询时间范围有误！"})
            return;
          }
          if(data.flags=='null') data.flags=null;
        }
        auditServer.listLog({data:data,params:{params3:this.current,params4:this.minPageSize}},({data,errorCode})=>{
          this.loading = false;
          if(!errorCode){
            data.pageData.forEach(l=>l.testLoading = false);
            this.data = data.pageData;
            this.total = data.totalCount;
          }
        });
      },
      s(d){
        let data = new Date(d)
        this.form.operateTimeStart = data.getTime();
      },
      e(d){
        let data = new Date(d)
        let t = data.getTime();
        this.form.operateTimeEnd = t+86399999;
      }
    }
  };
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
  .audit_list{
      margin: 20px;
      padding: 30px;
      border-radius: 10px;
      background-color: #fff;
    .search_wrapper{
      margin-bottom: 30px;
      font-size: 12px;
      span{
        margin-left:30px;
        margin-right: 10px;
        &:nth-of-type(1){
          margin-left:0;
        }
      }
    }
    .table{
      .success{
        display: inline-block;
        width:40px;
        height:20px;
        line-height: 20px;
        text-align: center;
        border-radius: 10px ;
        background:rgba(41,188,110,1);
        color:#fff;
      }
      .fail{
        display: inline-block;
        width:40px;
        height:20px;
        line-height: 20px;
        text-align: center;
        border-radius: 10px ;
        background:rgba(234,65,36,1);
        color:#fff;
      }
    }
  }
</style>
