<template>
  <div class="loginBox" v-if="!$route.query.token">
    <div class="login-con">
      <div class="titleCon">
        <img :src="'/v1/file/download/'+logo" style="max-width: 100%">
      </div>
      <Form autocomplete="on">
        <FormItem prop="user">
          <Input icon="android-person" type="text"  @on-focus="onFocus" v-model="username" placeholder="用户名"></Input>
        </FormItem>
        <FormItem prop="password">
          <Input icon="android-lock" type="password" @on-focus="onFocus" @on-keyup.13="enter($event)" v-model="password" placeholder="密码"></Input>
        </FormItem>
          <Button class="loginBtn" :loading="loginText=='登录中'" style="height:48px;width: 100%;background:#1693f7;border: none"  v-text="loginText" type="primary" @click="loginGo"></Button>
      </Form>
      <p class="login-tip" v-text="err"></p>
     </div>
    </div>
  </div>
</template>

<script>
import oldServer from "rs/oldServer";
import otherServer from "rs/otherServer";
export default {
  props: {},
  data() {
    return {
      logo: "",
      username: "",
      password: "",
      loginText: "登录",
      err: ""
    };
  },
  created() {
    if (this.$route.query.token) {
      this.logined();
    }
    this.getCurrentInfo();
  },
  directives: {},
  computed: {},
  filters: {},
  methods: {
    getCurrentInfo() {
      otherServer.getCurrentInfo({}, response => {
        if (response.errorCode == 0) {
          var logos = JSON.parse(response.data.logo);
          var logo = logos.length == 2 ? logos[1].url : logos[0].url;
          this.session.set("logo", logo);
          this.logo = logos[0].url;
        }
      });
    },
    logined() {
      this.session.del("userName");
      this.session.set("access_token", this.$route.query.token);
      setTimeout(() => {
        this.goPage();
      }, 500);
    },
    onFocus: function() {
      this.err = "";
    },
    enter() {
      this.loginGo();
    },
    goPage() {
      if (this.session.get("access_token")) {
        oldServer.me(
          {},
          user => {
            let userName = user.loginAccount;
            this.session.set("guid", user.guid);
            this.session.set("scope", user.scope);
            this.session.set("userName", userName);
            this.session.set("version", user.version);
            this.session.set("loginName", this.username);
            this.session.set("loginP", btoa(this.password));
            this.$router.push({ name: "app" });
          },
          err => {
            this.loginText = "登 录";
            this.err = "获取用户信息失败";
          }
        );
      } else {
        setTimeout(() => {
          this.goPage();
        }, 400);
      }
    },
    loginGo() {
      this.session.del("access_token");
      if (!this.username || !this.password) {
        this.err = "请填写用户名和密码";
        return;
      }
      this.loginText = "登录中";
      let json1 = {
        username: this.username,
        password: btoa(this.password)
      };
      let jwt = btoa(JSON.stringify(json1));
      let json3 = {
        grant_type: "password",
        jwt: jwt
      };
      oldServer.getToken(
        { params: json3 },
        data => {
          this.session.del("userName");
          this.session.del("access_token");
          this.session.set("access_token", data.access_token);
          this.session.set("scope", data.scope);

          let prot = window.location.port;
          let splitKey = "/#/";
          switch (data.scope) {
            case "analyzer":
              window.location.href =
                window.location.href.split(splitKey)[0] +
                "/bi/#/login?token=" +
                data.access_token;
              break;
            case "operator":
              window.location.href =
                window.location.href.split(splitKey)[0] +
                "/aio/#/login?token=" +
                data.access_token;
              break;
            default:
              setTimeout(() => {
                this.goPage();
              }, 2500);
          }
        },
        err => {
          this.loginText = "登 录";
          if (err.response.data.error == "invalid_grant") {
            this.err = "用户名和密码错误,请重新输入";
          } else {
            this.err = "后端错误";
          }
        }
      );
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang='less' type="text/less">
.loginBox {
  width: 100%;
  height: 100%;
  background: #003263;
  position: relative;
  .login-con {
    position: absolute;
    top: 10%;
    left: 50%;
    margin-left: -200px;
    width: 340px;
    .titleCon {
      padding-top: 30px;
      text-align: center;
      margin-bottom: 30px;
    }
    .ivu-input {
      height: 48px;
      background: none;
      padding-left: 30px;
      color: white;
    }
    .ivu-input-icon {
      left: 0;
      color: white;
      line-height: 48px;
    }
    .loginBtn {
      font-size: 14px;
    }
  }
  .login-tip {
    font-size: 10px;
    margin-top: 20px;
    text-align: center;
    color: #ff4236;
  }
}
</style>
