/**
* Created by zhaowei on 2017/12/25.
*/

<template>
  <div class="ivu-layout" :style="{height:$store.state.screenHeight - 60 + 'px'}">
    <div class="ivu-layout-content">
      <Row class="title_box">
        <Col span="12">
        <span class="h1">用户列表</span>
        </Col>
        <Col span="12" style="text-align: right">
        <Input style="width: 300px;" v-model="keyWords" placeholder="根据用户名查询,请输入关键字..."></Input>
        <!--<Button disabled type="ghost">查询</Button>-->
        <Button
            type="primary"
            :disabled='tabActive==1||tabActive.json=="all"'
            shape="circle"
            icon="ios-plus-empty"
            @click="openModal()"
            style="float: right">添加新用户
        </Button>
        </Col>
      </Row>
      <Tabs type="card" @on-click="v=>tab(v)">
        <TabPane v-for="(item,index) in list" :key="index" :label="item.name">
          <div class="table">
            <table>
              <thead>
              <tr>
                <th>序号</th>
                <th>用户名</th>
                <th>用户类型</th>
                <th>用户账户</th>
                <th>用户ID</th>
                <th>操作</th>
              </tr>
              </thead>
              <tbody>
              <tr v-for="(obj,$index) in searchData[index]">
                <td v-text="$index"></td>
                <td v-text="obj.firstName">11</td>
                <td v-text="obj.scope">11</td>
                <td v-text="obj.loginAccount">11</td>
                <td v-text="obj.guid">11</td>
                <td>
                  <!--<a class="upload" @click="update(item)">下载密匙</a>-->
                  <a class="upload" @click="openModal(obj)">修改信息</a>
                  <a class="upload" @click="deleteUser(obj)">删除</a>
                </td>
              </tr>
              </tbody>
            </table>
          </div>
          <Page style="margin-top:10px;" :current="item.current" :total="item.total"
                @on-change="v=>getData(item,item.json,v)" show-total show-elevator></Page>
        </TabPane>
      </Tabs>
    </div>
    <Modal
        v-model="addRuleModal"
        :mask-closable="false"
        :title="title"
        width="600"
        class="no_footer">
      <div style="text-align:center; margin-top:20px; margin-bottom:50px;">
        <Form style="text-align:left;width: 400px;margin: 0 auto" :rules="ruleInline"
              :model="formItem"  ref="formItem"
              :label-width="80">
          <FormItem label="账户" prop="loginAccount">
            <Input :disabled="modelStatus=='upload'" v-model="formItem.loginAccount"
                   placeholder="请输入Email..."></Input>
          </FormItem>
          <FormItem label="姓名" prop="firstName">
            <Input v-model="formItem.firstName" placeholder="请输入姓名..."></Input>
          </FormItem>
          <!--<FormItem label="名">-->
          <!--<Input v-model="formItem.lastName" placeholder="请输入名..."></Input>-->
          <!--</FormItem>-->
          <FormItem label="密码" prop="password">
            <Input type="password" v-model="formItem.password" @on-change="pwdChange" placeholder="请输入密码..."></Input>
          </FormItem>
          <FormItem label="权限" prop="scope">
            <Input disabled v-model="formItem.scope"></Input>
          </FormItem>
        </Form>
        <Button type="ghost" style="width: 130px" @click="addRuleModal = false">取消</Button>
        <Button type="primary" style="width: 130px" @click="addRuleModalSubmit" :loading="loading.modalBtn">提交</Button>
      </div>
    </Modal>
  </div>
</template>

<script>
	import oldServer from "rs/oldServer"

	export default {
		name: 'list',
		data() {
			return {
				total: 0,
				data: '',
				activeItem: '',
				tabActive: 1,
				name: '',
				addRuleModal: false,
				title: '添加用户',
				keyWords: '',
				modelStatus: '',
				pwdStatus: false,
				current: 1,
				loading: {
					modalBtn: false,
				},
				formItem: {},
				ruleInline: {
					loginAccount:[
						{ required: true, message: 'Please fill in the user name', trigger: 'blur' }
          ],
					firstName:[
						{ required: true, message: 'Please fill in the user name', trigger: 'blur' }
          ],
					password:[
						{ required: true, message: 'Please fill in the user name', trigger: 'blur' }
          ],
					scope:[
						{ required: true, message: 'Please fill in the user name', trigger: 'blur' }
          ]
        },
				list: [
					{
						current: 1,
						name: '全部',
						json: 'all',
						total: 0,
						data: ''
					},
					{
						current: 1,
						name: '管理员',
						json: 'admin',
						total: 0,
						data: '',
					},
					{
						current: 1,
						name: '集群操作员',
						json: 'operator',
						total: 0,
						data: ''
					},
					{
						current: 1,
						name: '数据分析员',
						json: 'analyzer',
						total: 0,
						data: ''
					},
					{
						current: 1,
						name: '数据处理员',
						json: 'personal_trial',
						total: 0,
						data: ''
					},
					{
						current: 1,
						name: '算法管理员',
						json: 'cas_admin',
						total: 0,
						data: ''
					},
					{
						current: 1,
						name: '算法处理员',
						json: 'cas_personal_trial',
						total: 0,
						data: ''
					}
				]
			}
		},
		computed: {
			searchData: function () {
				var keyWords = this.keyWords;
				return this.list.map(({data}) => {
					if (!keyWords) {
						return data
					}
					return data.filter(function ({firstName, lastName}) {
						return (firstName + lastName).toLowerCase().indexOf(keyWords) != -1
					})
				})
			}
		},
		created() {
			this.list.forEach((item, i) => {
				this.getData(item, item.json, 1)
			});
		},
		methods: {
			tab(v) {
				this.list.forEach((item, i) => {
					if (v == i) {
						this.tabActive = item;
					}
				});
			},
			getData(item, param, num) {
				item.current = num
				let json = {
					params3: param,
					params4: num - 1,
					params5: 10
				};
				oldServer.getListUser({data: {name: this.name}, params: json}, (data) => {
					item.data = data.data;
					item.total = data.totalItems;
				})
			},
			openModal(item) {
				this.pwdStatus = false;
				this.addRuleModal = true;
				if (item) {
					this.modelStatus = 'upload';
					this.formItem = item;
				} else {
					this.modelStatus = 'add';
					this.formItem = {
						accountType: 1,
						loginAccount: '',
						firstName: '',
						lastName: '',
						password: '',
						scope: this.tabActive.json
					}
				}
			},
			pwdChange() {
				this.pwdStatus = true
			},
			addRuleModalSubmit(e) {
				if(e&&e.preventDefault)e.preventDefault();
				if (this.modelStatus == 'add') {
					this.formItem.resetPsw = false;
					this.formItem.password = btoa(this.formItem.password);
					let json = this.formItem;
					oldServer.addUser({data: json}, (data) => {
						this.addRuleModal = false;
						this.tabActive.current = 1;
						this.getData(this.tabActive, this.tabActive.json, 1);
						this.$Message.success('添加成功');
					}, (err) => {
						this.$Message.error(err.response.data);
					})
				} else {
					let json2 = {
						firstName: this.formItem.firstName,
						lastName: this.formItem.lastName,
						loginAccount: this.formItem.loginAccount,
						resetPsw: false,
						scope: this.formItem.scope
					};
					if (this.pwdStatus) {
						json2.resetPsw = true;
						json2.againPwd = this.formItem.password;
						json2.password = btoa(this.formItem.password);
					}
					oldServer.updateUser({data: json2}, (data) => {
						this.addRuleModal = false;
						this.tabActive.current = 1;
						this.getData(this.tabActive, this.tabActive.json, 1);
						this.$Message.success('修改成功');
					}, (err) => {
						this.$Message.error(err.response.data);
					})
				}
			},
			deleteUser(item) {
				oldServer.deleteUser({params: {params3: item.loginAccount}}, (data) => {
					this.tabActive.current = 1;
					this.getData(this.tabActive, this.tabActive.json, 1);
					this.$Message.success('删除成功');
				}, (err) => {
					this.$Message.error(err.response.data);
				})
			}
		}
	}
</script>

<style scoped rel="stylesheet/less" type="text/less">
  .ivu-layout {
    padding: 20px;
  }

  .ivu-layout-content {
    width: 100%;
    height: 100%;
    padding: 20px;
    background: white;
  }
</style>
