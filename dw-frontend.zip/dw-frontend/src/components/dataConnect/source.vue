<template>
  <div class="source_container">
    <v-Header text="数据源列表">
      <Button
        type="primary"
        shape="circle"
        icon="ios-plus-empty"
        @click="modal = true"
        style="float: right">添加数据源</Button>
    </v-Header>
    <p class="search_wrapper">
      <span>类型</span>
      <Select v-model="form.type" style="width:150px" clearable>
        <Option v-for="item in $store.state.connect.sourceType" :value="item.key" :key="item.key">{{ item.text }}</Option>
      </Select>
      <span>状态</span>
      <Select v-model="form.state" style="width:150px" clearable>
        <Option :value="1">启用</Option>
        <Option :value="2">禁用</Option>
      </Select>
      <span>数据源名称</span>
      <Input v-model="form.name" placeholder="输入数据源名称进行模糊查询" style="width:200px;margin-right: 30px"/>
      <Button type="ghost" @click="init()">查询</Button>
    </p>
    <div style="position: relative" :style="$store.state.setTableHeight(328)">
      <div class="table" style="height: 100%;">
        <table>
          <thead>
          <tr>
            <th>序号</th>
            <th>名称</th>
            <th>类型</th>
            <th>创建用户</th>
            <th>概述</th>
            <th>创建时间</th>
            <th>状态</th>
            <th>最近测试连接情况</th>
            <th>操作</th>
          </tr>
          </thead>
          <tbody>
          <tr v-show="!data.length">
            <td colspan="9" style="text-align: center">没有数据</td>
          </tr>
          <tr v-for="(item,index) in data" :key="index">
            <td v-text="index + 1"></td>
            <td v-text="item.name"></td>
            <td>{{item.type|formatterSourceType}}</td>
            <td v-text="item.createUserName"></td>
            <td v-text="item.remark"></td>
            <td v-text="item.createTime"></td>
            <td>
              <Button :type="item.state===1?'success':'error'" shape="circle" style="min-width:40px;padding:0">{{item.state===1?"启用":"禁用"}}</Button>
            </td>
            <td v-text="item.latestConnectLog"></td>
            <td class="last">
              <div class="action_wrapper gorgeous">
                <Button type="text" @click="test(item)" :loading="item.testLoading" :class="{disabled:item.type === 608}">测试
                </Button><span @click="update(item)">编辑
              </span><span @click='jyItem = item;affirm2 = true;updateText = item.state===1?"禁用":"启用"'>{{item.state===1?"禁用":"启用"}}
              </span><span @click="delItem = item.id;affirm = true">删除
              </span><router-link :to="{name:'statisticsSource',query:{id:item.id}}" tag="span">历史统计</router-link>
              </div>
            </td>
          </tr>
          </tbody>
        </table>
      </div>
      <Spin fix v-show="loading"></Spin>
    </div>
    <Page
      :total="total"
      show-elevator
      show-total
      :page-size="minPageSize"
      placement="top"
      @on-change="init"
      style="margin-top:10px;"
    ></Page>
    <v-modal-source-type :modal.sync="modal" @checked="checked"></v-modal-source-type>
    <v-affirm :model.sync="affirm" :del="true" @click="del"></v-affirm>
    <v-affirm :model.sync="affirm2" @click="updateInfo" :color="updateText==='启用'?'#19be6b':''">
      <span slot="title">{{updateText+"确认"}}</span>
      <p v-text='"是否要"+updateText+"当前数据源？"'></p>
    </v-affirm>
  </div>
</template>
<script>
  import connectServer from "rs/connect"
  export default {
    props:{
    },
    data() {
      return {
        modal:false,
        updateText:"",
        affirm:false,
        affirm2:false,
        delItem:"",
        jyItem:{},
        total:0,
        data:[],
        form:{
          name:undefined,
          state:undefined,
          type:undefined
        },
        loading:false,
      }
    },
    created() {
      /**
       * 处理面包屑
       * */
      this.$store.commit('setCrumbs',[
        {text:"数据源管理",query:{},name:"source"},
      ]);
      this.init();
    },
    directives: {

    },
    computed: {
      minPageSize(){
        return Math.max(Math.floor((this.$store.state.screenHeight - 377)/41),10);
      }
    },
    filters: {
    },
    methods: {
      init(num){
        this.loading = true;
        let {name,state,type} = this.form;
        let data = {
          name:name||undefined,
          state:state||undefined,
          type:type||undefined
        };
        connectServer.sourceList({data:data,params:{params3:num||1,params4:this.minPageSize}},({data,errorCode})=>{
          this.loading = false;
          if(!errorCode){
            data.pageData.forEach(l=>l.testLoading = false);
            this.data = data.pageData;
            this.total = data.totalCount;
          }
        });
      },
      checked(type){
        this.$router.push({name:"addSource",query:{type:type}});
      },
      test(item){
        if(item.type === 608){
          this.$Notice.warning({title:"警告",desc:"Web Service 类型数据源不支持测试操作"});
          return;
        }
        item.testLoading = true;
        connectServer.test({data:{
          dataSourceId:item.id,
          type:item.type
        }},({errorCode,msg})=>{
          item.testLoading = false;
          if(errorCode)this.$Notice.error({title:"连接失败！",desc:msg});
          else this.$Notice.success({title:"连接成功！"});
          item.latestConnectLog = errorCode?"连接失败":"连接成功";
        });
      },
      //禁用or启用
      updateInfo(e){
	      if(e&&e.preventDefault) e.preventDefault();
        let item = this.jyItem,flag = item.state === 1;
        let num = flag?2:1;
        connectServer.updateInfo({data:{id:item.id,state:num}},({errorCode,msg})=>{
          this.affirm2 = false;
          if(!errorCode){
            this.jyItem.state = num;
            this.$Notice.success({title:"操作成功！"});
            return
          }
          this.$Notice.error({title:"操作失败！",desc:msg});
        });
      },
      update({id,type}){
        this.$router.push({name:"addSource",query:{id,type:type}});
      },
      del(e){
	      if(e&&e.preventDefault) e.preventDefault();
        connectServer.delSource({params:{id:this.delItem}},({errorCode,msg})=>{
          this.affirm = false;
          if(!errorCode){
            this.$Notice.success({title:"删除成功！"});
            this.init();
            return
          }
          this.$Notice.error({title:"删除失败！",desc:msg});
        });
      },
    }
  };
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
  .source_container{
    .header{
      margin-bottom: 20px;
    }
    .search_wrapper{
      margin-bottom: 30px;
      font-size: 12px;
      span{
        margin-left:30px;
        margin-right: 10px;
        &:nth-of-type(1){
          margin-left:0;
        }
      }
    }
    td.last{
      min-width: 250px;
      .action_wrapper{
        font-size: 12px;
        width: 250px;
        button{
          font:inherit;
        }
      }
    }
  }
</style>
