<template>
  <!--这是.vue文件模板~-->
  <div class="main">
    <header style="padding-right: 75px;">数据源信息</header>
    <Form :model="form" :label-width="80" :rules="rules" ref="form" style="width:520px;margin: 0 auto;">
      <FormItem label="数据源名称" prop="name" style="white-space: nowrap">
        <Input v-model="form.name" placeholder="请输入数据源名称" style="width: 280px" @on-change="form.latestConnectLog = ''"/>
        <!--<span style="color:#7D7F85;margin-left: 10px;">仅支持mysql5.5,mysql5.6</span>-->
      </FormItem>
      <FormItem label="服务器" prop="serve" style="display: inline-block">
        <Input v-model="form.serve" placeholder="服务器地址" style="width: 280px" @on-change="form.latestConnectLog = ''"/>
        <span>:</span>
      </FormItem>
      <FormItem prop="port" style="display: inline-block" class="no_label">
        <Input v-model="form.port" placeholder="port" style="width: 80px" @on-change="form.latestConnectLog = ''"/>
      </FormItem>
      <FormItem label="数据库名" prop="sourceName" v-if="!isHBase">
        <Input v-model="form.sourceName" placeholder="请输入数据库名称" style="width: 280px" @on-change="form.latestConnectLog = ''"/>
      </FormItem>
      <FormItem label="用户名" prop="user">
        <Input v-model="form.user" placeholder="请输入用户名称" style="width: 280px" @on-change="form.latestConnectLog = ''"/>
      </FormItem>
      <FormItem label="密码" prop="psd">
        <Input v-model="form.psd" placeholder="请输入密码" style="width: 280px" @on-change="form.latestConnectLog = ''" type="password"/>
      </FormItem>
      <FormItem label="描述" prop="remark">
        <Input v-model="form.remark" type="textarea" :rows="4" style="width: 280px;"/>
      </FormItem>
      <FormItem label="数据库类型" prop="type">
        <Select v-model="form.type" placeholder="请选择数据库类型" style="width: 280px" disabled  @on-change="form.latestConnectLog = ''">
          <Option v-for="item in $store.state.connect.sourceType" :value="item.key" :key="item.key">{{ item.text }}</Option>
        </Select>
      </FormItem>
      <FormItem label="数据库状态" prop="state">
        <RadioGroup v-model="form.state" style="display: block">
          <Radio :label="1">启用</Radio>
          <Radio :label="2">禁用</Radio>
        </RadioGroup>
      </FormItem>
      <FormItem label="测试连接" prop="latestConnectLog">
        <Button type="ghost" @click="test" :loading="btnLoading">测试连接</Button>
        <span style="margin-left: 10px" v-text="form.latestConnectLog" :style="{color:form.latestConnectLog==='连接成功'?'#19be6b':'#ed3f14'}"></span>
      </FormItem>
      <FormItem>
        <Button type="primary" style="width: 280px" @click="save" :loading="loading">保存</Button>
      </FormItem>
    </Form>
  </div>
</template>

<script>
import connectServer from "rs/connect"
import {Base64} from "js-base64"
export default {
	data() {
    const validateNumber = (r,v,c)=>{
      if(!v)c("该项为必填项");
      else if(!/^[0-9]+$/.test(v))c("端口号为数字");
      else if(v>65535)c("端口号无效");
      else c();
    };
    const validateForTest = (r,v,c)=>{
      if(this.isTest){c();return;}
      if(!v)c("请先测试连接是否可行");
      else if(v !== "连接成功") c("测试连接通过后才能提交保存");
      else c();
    };
    let validateLength = this.$store.state.validateLength;
    return {
      btnLoading:false,
      loading:false,
      form:{
        isHBase:false,
        type:+this.$route.query.type,
        state:1,
        name:"",
        latestConnectLog:"",
        serve:"",
        port:"80",
        sourceName:"",
        isTest:false,
        user:"",
        psd:"",
        remark:"",
        createUser:this.session.get("userName"),
      },
      rules:{
        name:{validator: validateLength(30), trigger: 'blur'},
        serve:{validator: validateLength(100), trigger: 'blur'},
        remark:{validator: validateLength(100), trigger: 'blur'},
        port:{validator: validateNumber, trigger: 'blur'},
        sourceName:{validator: validateLength(100), trigger: 'blur'},
        user:{validator: validateLength(30), trigger: 'blur'},
        psd:{validator: validateLength(30), trigger: 'blur'},
        latestConnectLog:{validator: validateForTest}
      },
    }
	},
	created() {
    let id = this.$route.query.id;
    this.isHBase = +this.$route.query.type === 606;
    if(id){
      connectServer.findById({params:{id}},({errorCode,data})=>{
        if(!errorCode){
          let form = this.form,{type,state,name,confs,remark,createUser} = data;
          form.type = type;form.state = state;form.name = name;form.remark = remark;form.createUser = createUser;
          confs.forEach(l=>{
            switch (l.key){
              case "服务器":
                form.serve = l.value;break;
              case "端口号":
                form.port = l.value;break;
              case "数据库名":
                form.sourceName = l.value;break;
              case "用户名":
                form.user = l.value;break;
              case "密码":
                form.psd = Base64.decode(l.value);break;
            }
          });
        }
      });
    }
	},
	directives: {

	},
	computed: {

	},
	filters: {
	},
	methods: {
    test(){
      this.isTest =true;
      this.$refs.form.validate(f=>{
        this.isTest =false;
        if(f){
          let {name,serve,port,sourceName,user,psd,type} = this.form;
          this.btnLoading = true;
          connectServer.test({data:{
            dataSourceName:name,
            databaseName:this.isHBase?undefined:sourceName,
            userName:user,
            password:Base64.encode(psd),
            port:port,
            type:+type,
            url:serve,
          }},({errorCode,msg})=>{
            this.btnLoading = false;
            this.form.latestConnectLog = errorCode?"连接失败":"连接成功";
            if(errorCode){
              this.$Notice.error({title:"连接失败",desc:msg});
            }
          });
        }
      });
    },
    save(){
      this.$refs.form.validateField("latestConnectLog",f=>{
        if(!f){
          this.loading = true;
          let query = this.$route.query;
          let id = query.id;
          let server = id?"updateSource":"addSource";
          let {type,state,name,latestConnectLog,serve,port,sourceName,user,psd,remark,createUser} = this.form,data = {type,state,name,latestConnectLog,id,remark,createUser};
          data.confs = [
            {
              key:"服务器",
              type:701,
              value:serve
            },
            {
              key:"端口号",
              type:701,
              value:port
            },
            {
              key:"数据库名",
              type:701,
              value:sourceName
            },
            {
              key:"用户名",
              type:701,
              value:user
            },
            {
              key:"密码",
              type:701,
              value:Base64.encode(psd)
            },
          ];
          connectServer[server]({data:data},({errorCode})=>{
            this.loading = false;
            if(errorCode){
              this.$Notice.error({title:"操作失败！"});return
            }
            this.$Notice.success({title:"操作成功！"});
            if(query.from)this.$router.push({name:query.from,query:{type:query.type}});
            else this.$router.push({name:"source"});
          });
        }
      });
    }
	}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
  header{
    text-align: center;
    font-size: 18px;
    color: #4A4B50;
    font-weight: 600;
    padding-top: 28px;
    padding-bottom: 28px;
  }
</style>
