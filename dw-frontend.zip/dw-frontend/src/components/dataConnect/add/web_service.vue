<template>
  <!--这是.vue文件模板~-->
  <div class="main">
    <header style="padding-right: 75px">数据源信息</header>
    <Form :model="form" :label-width="80" :rules="rules" ref="form" style="width:510px;margin: 0 auto;">
      <FormItem label="数据源名称" prop="name">
        <Input v-model="form.name" placeholder="请输入数据源名称" style="width: 280px"/>
      </FormItem>
      <FormItem label="服务器" prop="server">
        <Input v-model="form.server" placeholder="服务器地址" style="width: 280px"/>
      </FormItem>
      <FormItem label="描述" prop="remark">
        <Input v-model="form.remark" type="textarea" :rows="4" style="width: 280px;"/>
      </FormItem>
      <FormItem label="数据库状态" prop="state">
        <RadioGroup v-model="form.state">
          <Radio :label="1">启用</Radio>
          <Radio :label="2">禁用</Radio>
        </RadioGroup>
      </FormItem>
      <FormItem>
        <Button type="primary" style="width: 280px" @click="save" :loading="loading">保存</Button>
      </FormItem>
    </Form>
  </div>
</template>

<script>
  import connectServer from "rs/connect"
  export default {
    props:{
    },
    data() {
      let validateLength = this.$store.state.validateLength;
      return {
        loading:false,
        form:{
          name:"",
          state:1,
          remark:"",
          type:608,
          server:""
        },
        rules:{
          name:{validator: validateLength(30), trigger: 'blur'},
          server:{validator: validateLength(300), trigger: 'blur'},
          remark:{validator: validateLength(100), trigger: 'blur'},
        },
      }
    },
    created() {
      let id = this.$route.query.id;
      if(id){
        connectServer.findById({params:{id}},({errorCode,data})=>{
          if(!errorCode){
            let form = this.form,{type,state,name,remark,confs} = data;
            form.type = type;form.state = state;form.name = name;form.remark = remark;
            confs.forEach(l=>{
              switch (l.key){
                case "服务器":
                  form.server = l.value;break;
              }
            });
          }
        });
      }
    },
    directives: {

    },
    computed: {

    },
    filters: {
    },
    methods: {
      save(){
        this.$refs.form.validate(f=>{
          if(f){
            this.loading = true;
            let query = this.$route.query;
            let id = query.id;
            let serverName = id?"updateSource":"addSource";
            let {type,state,name,server,remark} = this.form,data = {type,state,name,remark,id};
            data.confs = [
              {
                key:"服务器",
                type:701,
                value:server
              }
            ];
            connectServer[serverName]({data:data},({errorCode})=>{
              this.loading = false;
              if(errorCode){
                this.$Notice.error({title:"操作失败！"});return
              }
              this.$Notice.success({title:"操作成功！"});
              if(query.from)this.$router.push({name:query.from,query:{type:query.type}});
              else this.$router.push({name:"source"});
            });
          }
        });
      }
    }
  };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
  header{
    text-align: center;
    font-size: 18px;
    color: #4A4B50;
    font-weight: 600;
    padding-top: 28px;
    padding-bottom: 28px;
  }
</style>
