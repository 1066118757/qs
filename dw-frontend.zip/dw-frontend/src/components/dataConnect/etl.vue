<template>
  <div class="etl_container">
    <v-Header text="引接任务列表">
      <div style="float: right">
        <Button
            type="ghost"
            shape="circle"
            icon="ios-plus-empty"
            @click="modal3 = true;fileList=[]"
            style="margin-right:20px">论文数据导入
        </Button>
        <Button
            type="ghost"
            shape="circle"
            icon="ios-plus-empty"
            @click="modal2 = true"
            style="margin-right:20px">文件数据导入
        </Button><!--<Button
          type="ghost"
          shape="circle"
          icon="ios-plus-empty"
          @click="modal = true;isDBT = true;"
          style="margin-right:20px">数据库迁移
        </Button>-->
        <Button
            type="primary"
            shape="circle"
            icon="ios-plus-empty"
            @click="modal = true;isDBT = false;">添加引接任务
        </Button>
      </div>
    </v-Header>
    <p class="search_wrapper">
      <span>类型</span>
      <Select v-model="form.dataSourceType" style="width:90px" placeholder="选择类型" clearable>
        <Option v-for="item in $store.state.connect.sourceType" :value="item.key" :key="item.key">{{ item.text }}
        </Option>
      </Select>
      <span>状态</span>
      <Select v-model="form.state" style="width:90px" placeholder="启用/禁用" clearable>
        <Option :value="1">启用</Option>
        <Option :value="2">禁用</Option>
      </Select>
      <span>最近同步</span>
      <Select v-model="form.latestScheduleState" style="width:90px" placeholder="成功/失败" clearable>
        <Option :value="1">进行中</Option>
        <Option :value="2">成功</Option>
        <Option :value="3">失败</Option>
      </Select>
      <span>名称</span>
      <Input v-model="form.name" style="width:70px;"/>
      <span>创建者</span>
      <Input v-model="form.createUserName" style="width:70px;"/>
      <span>数据源</span>
      <Input v-model="form.dataSourceName" style="width:70px;margin-right: 20px"/>
      <Button type="ghost" @click="init()">查询</Button>
    </p>
    <div style="position: relative" :style="$store.state.setTableHeight(328)">
      <div class="table" style="height: 100%;">
        <table>
          <thead>
          <tr>
            <th>序号</th>
            <th>引接任务名称</th>
            <th>数据源名称</th>
            <th>数据源类型</th>
            <th>创建用户</th>
            <th>概述</th>
            <th>创建时间</th>
            <th>状态</th>
            <th>最近同步情况</th>
            <th>操作</th>
          </tr>
          </thead>
          <tbody>
          <tr v-show="!data.length">
            <td colspan="10" style="text-align: center">没有数据</td>
          </tr>
          <tr v-for="(item,index) in data" :key="index">
            <td v-text="index + 1"></td>
            <td v-text="item.name" @click="showDetails(item.id)" class="name"></td>
            <td>{{item.dataSourceDetailVo.name}}</td>
            <td>{{item.dataSourceDetailVo.type | formatterSourceType}}</td>
            <td v-text="item.createUserName"></td>
            <td v-text="item.dataSourceDetailVo.remark"></td>
            <td v-text="item.createTime"></td>
            <td>
              <Button :type="item.state===1?'success':'error'" shape="circle" style="min-width:40px;padding:0">
                {{item.state===1?"启用":"禁用"}}
              </Button>
            </td>
            <td :style="{color:color(item.latestScheduleState)}">{{item.latestScheduleState | formatterSyncType }}</td>
            <td class="last">
              <div class="action_wrapper gorgeous" style="font-size: 12px">
                <Button type="text" @click="test(item)" :loading="item.yjLoading" style="padding: 4px 10px 8px;;"
                        :class="{disabled:item.disabled}">引接
                </Button>
                <span @click="update(item)" :class="{disabled:item.disabled}">编辑
              </span><span @click='changeState(item)' :class="{disabled:item.latestScheduleState === 1}">{{item.state===1?"禁用":"启用"}}
              </span><span @click="delItem = item.id;affirm = true">删除
              </span>
                <router-link :to="{name:'statisticsEtl',query:{id:item.id}}" tag="span">历史统计</router-link>
              </div>
            </td>
          </tr>
          </tbody>
        </table>
      </div>
      <Spin fix v-show="loading"></Spin>
    </div>
    <Page
        :total="total"
        show-elevator
        show-total
        :page-size="minPageSize"
        placement="top"
        @on-change="init"
        style="margin-top:10px;"
    ></Page>
    <v-modal-source-type :modal.sync="modal" @checked="checked" :showWS="!isDBT"></v-modal-source-type>
    <v-modal-file-type :modal.sync="modal2" @checked="checked2"></v-modal-file-type>
    <v-affirm :model.sync="affirm" :del="true" @click="del"></v-affirm>
    <v-affirm :model.sync="affirm2" @click="updateInfo" :color="updateText==='启用'?'#19be6b':''">
      <span slot="title">{{updateText+"确认"}}</span>
      <p v-text='"是否要"+updateText+"当前引接任务？"'></p>
    </v-affirm>
    <Modal v-model="detailsModal" class="no_footer" :width="600" title="引接任务详情">
      <div style="margin: 0 auto;width: 440px;line-height: 28px">
        <div style="float: left;width:220px">
          <p class="overflow" v-for="(item,index) in details.etl" :key="index">
            <span class="name" v-text="item.key+':'"></span>
            <span class="value" v-text="item.value" :title="item.value"></span>
          </p>
        </div>
        <div style="float: left;width:220px">
          <p class="overflow" style="width:220px" v-for="(item,index) in details.source" :key="index">
            <span class="name" v-text="item.key+':'"></span>
            <span class="value" v-text="item.value" :title="item.value"></span>
          </p>
        </div>
        <p class="overflow" style="clear: both;">
          <span>最新同步状态:</span>
          <span v-text="details.last" :title="details.last"></span>
        </p>
      </div>
    </Modal>
    <Modal v-model="modal3" class="fileBox no_footer" :width="700" title="论文数据导入">
      <div>
        <div class="lwItem">
          <p class="p">
            <span>选择论文来源</span>
            <i>文件编码格式必须为UTF-8</i>
          </p>
          <RadioGroup v-model="lwObj.format">
            <Radio label="CNKI">
              <span>CNKI</span>
            </Radio>
            <Radio label="EI">
              <span>EI</span>
            </Radio>
            <Radio label="ISI">
              <span>ISI</span>
            </Radio>
            <Radio label="SCI">
              <span>SCI</span>
            </Radio>
            <Radio label="DW">
              <span>DW</span>
            </Radio>
            <Radio label="PUBM">
              <span>PUBM</span>
            </Radio>
            <Radio label="CSCD">
              <span>CSCD</span>
            </Radio>

          </RadioGroup>
        </div>
        <div class="lwItem">
          <p class="p">
            <span>选择表</span>
          </p>
          <div>
            <Select v-model="lwObj.tableName" style="width:200px">
              <Option v-for="item in tableList" :value="item.name"
                      :key="item.name">{{ item.name }}
              </Option>
            </Select>
            <Button @click="modal4 = true" type="dashed">新建表</Button>
          </div>
        </div>
        <div class="lwItem">
          <p class="p">
            <span>上传文件</span>
          </p>
          <ul class=" clearfix">
            <li v-for="item,i in fileList">
              <div class="del">
                <Button @click="delFile(i)" type="ghost" shape="circle" icon="trash-a"></Button>
              </div>
              <span>
                {{item.name}}
              </span>
              <!--<p>{{item.size/1000}}kb</p>-->
            </li>
            <li>
              <Upload
                  multiple
                  action=""
                  style="margin:0 auto 18px;width: 80px;color: #4AB9FF;text-align: center"
                  :before-upload="beforeUpload"
                  :show-upload-list="false"
              >
                <div style="text-align: center;cursor: pointer">
                  <p>
                    <Icon type="ios-plus-outline" size="50"></Icon>
                  </p>
                  <p style="font-size: 14px;">添加文件</p>
                </div>
              </Upload>
            </li>
          </ul>
        </div>
        <div style="text-align: center; padding: 30px 0;">
          <Button :disabled="fileUpLoading" type="primary" @click="upFile()">保存</Button>
          <Button type="ghost" @click="modal3=false" style="margin-left: 8px">取消</Button>
        </div>
      </div>
    </Modal>
    <Modal v-model="modal4" class="no_footer" :width="700" title="新建表">
      <div style="width: 400px; margin: 0 auto;">
        <Form :model="newTable" ref="newTable" :rules="newTableValidate"
              :label-width="80">
          <FormItem label="储存分区" prop="themeItemId">
            <Select v-model="newTable.themeItemId">
              <Option v-for="item in themeList" :value="item['themeItemListVos'][0].id"
                      :key="item['themeItemListVos'][0].id">{{ item.name }}
              </Option>
            </Select>
          </FormItem>
          <FormItem label="表名" prop="name">
            <Input v-model="newTable.name" placeholder="请输入"></Input>
          </FormItem>
          <FormItem label="数据类型" prop="type">
            <Select v-model="newTable.type" placeholder="请选择元数据类型">
              <Option :value="201">数据结构</Option>
              <Option :value="202">数据字典</Option>
            </Select>
          </FormItem>
          <FormItem label="描述" prop="purpose">
            <Input v-model="newTable.purpose" type="textarea" :rows="4"
                   placeholder="请输入"></Input>
          </FormItem>
          <FormItem style="text-align: center;">
            <Button type="primary" @click="saveTable()">保存</Button>
            <Button @click="modal4=false" type="ghost" style="margin-left: 8px">取消</Button>
          </FormItem>

        </Form>
      </div>

    </Modal>
  </div>
</template>
<script>
/**
 * 1.进行中的引接任务 不允许操作它的状态（启用/禁用）；
 * 2.进行中/禁用/文件类型的引接任务 这三种情况任意一个存在时（此时disabled = true） 不能引接 和 编辑；
 * */
import connectServer from "rs/connect";
import metaServer from "rs/meta";

export default {
  props: {},
  data() {
    return {
      fileUpLoading: false,
      fileList: [],
      tableList: [],
      themeList: [],
      newTableValidate: {
        name: [{ required: true, message: "不能为空", trigger: "blur" }],
        themeItemId: [
          {
            type: "number",
            required: true,
            message: "不能为空",
            trigger: "change"
          }
        ],
        type: [
          {
            type: "number",
            required: true,
            message: "不能为空",
            trigger: "change"
          }
        ],
        purpose: [{ required: true, message: "不能为空", trigger: "blur" }]
      },
      newTable: {
        name: null,
        themeItemId: null,
        type: null,
        purpose: null
      },
      modal4: false,
      lwObj: {
        format: "CNKI",
        tableName: null
      },
      fileType: {
        reg: /\.(eln|txt)$/,
        desc: "请选择.eln .txt文件！"
      },
      modal3: false,
      isDBT: false, //是否是通过点击数据库迁移来打开source-type-modal的
      details: {},
      detailsModal: false,
      modal: false,
      modal2: false,
      updateText: "",
      affirm: false,
      affirm2: false,
      delItem: "",
      jyItem: {},
      total: 0,
      data: [],
      form: {
        name: undefined,
        createUserName: undefined,
        dataSourceName: undefined,
        state: undefined,
        latestScheduleState: undefined,
        dataSourceType: undefined
      },
      loading: false
    };
  },
  created() {
    /**
     * 处理面包屑
     * */
    this.$store.commit("setCrumbs", [
      { text: "引接任务管理", query: {}, name: "etl" }
    ]);
    this.init();
    this.getTableList();
    this.getThemeList();
  },
  directives: {},
  computed: {
    minPageSize() {
      return Math.max(
        Math.floor((this.$store.state.screenHeight - 377) / 41),
        10
      );
    }
  },
  filters: {},
  methods: {
    delFile(i) {
      this.fileList.splice(i, 1);
    },
    upFile() {
      this.fileUpLoading = true;
      if (!this.fileList.length) {
        this.$Message.error("请选择至少一个文件");
        return;
      }
      if (!this.lwObj.tableName) {
        this.$Message.error("请选择表");
        return;
      }

      let formData = new FormData();
      this.fileList.forEach(item => {
        formData.append(item.name, item);
      });
      metaServer.literatureImport(
        { data: formData, params: this.lwObj },
        ({ data, errorCode, msg }) => {
          this.fileUpLoading = false;
          if (errorCode) {
            this.$Notice.error({ title: "上传失败", desc: "文件格式不正确！" });
            return;
          }
          this.modal3 = false;
          let table = {};
          this.tableList.forEach(hi => {
            if (hi.name == this.lwObj.tableName) {
              table = hi;
            }
          });
          this.$router.push({
            name: "source_table_detail",
            query: {
              id: table.id,
              name: table.name,
              pId: table.themeItemId,
              pName: "分区"
            }
          });
          this.$Notice.success({ title: "上传成功", desc: msg });
        }
      );
    },
    beforeUpload(file) {
      let fileType = this.fileType;
      if (!fileType.reg.test(file.name)) {
        this.$Notice.error({ title: "操作失败", desc: fileType.desc });
        return false;
      }
      let key = false;
      this.fileList.forEach(item => {
        if (item.name == file.name) {
          key = true;
        }
      });
      if (!key) {
        this.fileList.push(file);
      } else {
        this.$Notice.error({
          title: "重复选择文件",
          desc: file.name + "已经选中"
        });
      }
      return false;
    },
    saveTable() {
      this.$refs["newTable"].validate(valid => {
        if (valid) {
          metaServer.addTableISI({ data: this.newTable }, data => {
            if (data.errorCode == 0) {
              this.modal4 = false;
              this.getTableList(this.newTable.name);
              this.$refs["newTable"].resetFields();
            } else {
              this.$Message.error(data.data);
            }
          });
        } else {
          this.$Message.error("验证失败");
        }
      });
    },
    getThemeList() {
      metaServer.getThemeList({ params: { from: 1 } }, ({ data }) => {
        this.themeList = data;
      });
    },
    getTableList(name) {
      metaServer.getMetaItemList(
        {
          params: { params3: 1, params4: 10000 },
          data: {
            sourceType: 1504
          }
        },
        ({ data }) => {
          this.tableList = data.pageData;
          if (name) {
            this.lwObj.tableName = name;
          } else if (this.tableList.length) {
            this.lwObj.tableName = this.tableList[0].name;
          } else {
            //this.$Message.error('没有表，请新建表');
          }
        }
      );
    },
    changeState(item) {
      if (item.latestScheduleState === 1) {
        this.$Notice.warning({
          title: "警告",
          desc: "引接任务尚在进行中，请稍后再操作"
        });
        return;
      }
      this.jyItem = item;
      this.affirm2 = true;
      this.updateText = item.state === 1 ? "禁用" : "启用";
    },
    showDetails(id) {
      this.detailsModal = true;
      connectServer.jobFindById({ params: { id } }, ({ data, errorCode }) => {
        if (errorCode) return;
        let {
          distTable,
          name,
          priority,
          state,
          syncStrategy,
          dependenceVO,
          latestScheduleState,
          importMode,
          latestScheduleTime,
          confs,
          latestScheduleLog,
          dataSourceDetailVo
        } = data;
        let sourceTable = confs.find(({ key }) => key === "来源表");
        let details = {};
        details.last =
          latestScheduleTime +
          " " +
          (latestScheduleLog ? latestScheduleLog : "");
        details.etl = [
          {
            key: "etl名称",
            value: name
          },
          {
            key: "来源表",
            value: sourceTable ? sourceTable.value : "无"
          },
          {
            key: "目标表",
            value: distTable
          },
          {
            key: "导入模式",
            value: importMode === 1 ? "覆盖" : "更新"
          },
          {
            key: "同步策略",
            value: syncStrategy === 1 ? "定时" : "频率"
          },
          {
            key: "优先级",
            value: Vue.filter("formatterPriority")(priority)
          },
          {
            key: "状态",
            value: state === 1 ? "启用" : "禁用"
          },
          {
            key: "同步结果",
            value: Vue.filter("formatterSyncType")(latestScheduleState)
          }
        ];
        details.source = [
          {
            key: "数据源名称",
            value: dataSourceDetailVo.name
          },
          {
            key: "数据源类型",
            value: Vue.filter("formatterSourceType")(dataSourceDetailVo.type)
          },
          {
            key: "数据源是否启用",
            value: dataSourceDetailVo.state === 1 ? "启用" : "禁用"
          },
          {
            key: "依赖任务",
            value:
              dependenceVO &&
              dependenceVO.etlJobs &&
              dependenceVO.etlJobs.length
                ? dependenceVO.etlJobs[0].name
                : ""
          },
          ...dataSourceDetailVo.confs.filter(l => l.key !== "密码")
        ];
        this.details = details;
      });
    },
    color(type) {
      switch (type) {
        case 1:
          return "#ff9900";
        case 2:
          return "#19be6b";
        case 3:
          return "#ed3f14";
      }
    },
    init(num) {
      this.loading = true;
      let form = this.form,
        data = {};
      for (let i in this.form) {
        if (form[i]) data[i] = form[i];
      }
      connectServer.jobFind(
        {
          data: data,
          params: { params3: num || 1, params4: this.minPageSize }
        },
        ({ data, errorCode }) => {
          this.loading = false;
          if (!errorCode) {
            data.pageData.forEach(l => {
              l.yjLoading = false;
              l.disabled =
                l.latestScheduleState === 1 ||
                [609, 610, 611, 612].includes(l.dataSourceDetailVo.type) ||
                l.state === 2;
            });
            this.data = data.pageData;
            this.total = data.totalCount;
          }
        }
      );
    },
    checked(type) {
      if (this.isDBT) {
        this.$router.push({
          name: "databaseTransference",
          query: { type: type }
        });
      } else if (type === 608) {
        this.$router.push({ name: "addEtlForWebService" });
      } else this.$router.push({ name: "addEtl", query: { type: type } });
    },
    checked2(type) {
      this.$router.push({ name: "addEtlFromFile", query: { type: type } });
    },
    test(item) {
      if (item.state === 2) {
        this.$Notice.warning({ title: "警告", desc: "引接任务已被禁用" });
        return;
      }
      if (item.latestScheduleState === 1) {
        this.$Notice.warning({ title: "警告", desc: "引接任务已在进行中" });
        return;
      }
      if ([609, 610, 611, 612].includes(item.dataSourceDetailVo.type)) {
        this.$Notice.warning({
          title: "警告",
          desc: "文件类型的引接任务不能进行手动引接操作"
        });
        return;
      }
      item.yjLoading = true;
      item.latestScheduleState = 1;
      item.disabled = true;
      connectServer.jobPromptlyRun(
        { params: { id: item.id } },
        ({ errorCode, msg }) => {
          item.yjLoading = false;
          if (!errorCode) {
            this.$Notice.success({
              title: "引接成功！",
              desc: "请稍后刷新页面查看本次同步结果"
            });
            return;
					}
					item.latestScheduleState=3;
          this.$Notice.error({ title: "引接失败！", desc: msg });
        }
      );
    },
    //禁用or启用
    updateInfo(e) {
      if (e && e.preventDefault) e.preventDefault();
      let item = this.jyItem,
        flag = item.state === 1;
      let num = flag ? 2 : 1;
      connectServer.jobUpdateInfo(
        { data: { id: item.id, state: num } },
        ({ errorCode, msg }) => {
          this.affirm2 = false;
          if (!errorCode) {
            this.jyItem.state = num;
            this.jyItem.disabled = flag;
            this.$Notice.success({ title: "操作成功！" });
            return;
          }
          this.$Notice.error({ title: "操作失败！", desc: msg });
        }
      );
    },
    update({ id, state, latestScheduleState, dataSourceDetailVo: { type } }) {
      if (state === 2) {
        this.$Notice.warning({
          title: "警告",
          desc: "被禁用的引接任务不允许编辑"
        });
        return;
      }
      if (latestScheduleState === 1) {
        this.$Notice.warning({
          title: "警告",
          desc: "进行中的引接任务不允许编辑"
        });
        return;
      }
      if ([609, 610, 611, 612].includes(type)) {
        this.$Notice.warning({
          title: "警告",
          desc: "文件类型的引接任务不允许编辑"
        });
        return;
      }
      if (type === 608) {
        this.$router.push({ name: "addEtlForWebService", query: { id } });
      } else this.$router.push({ name: "addEtl", query: { id, type: type } });
    },
    del(e) {
      if (e && e.preventDefault) e.preventDefault();
      connectServer.jobDel(
        { params: { id: this.delItem } },
        ({ errorCode, msg }) => {
          this.affirm = false;
          if (!errorCode) {
            this.$Notice.success({ title: "删除成功！" });
            this.init();
            return;
          }
          this.$Notice.error({ title: "删除失败！", desc: msg });
        }
      );
    }
  }
};
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
.etl_container {
  .header {
    margin-bottom: 20px;
  }
  .name {
    cursor: pointer;
    &:hover {
      color: @primary-color;
      text-decoration: underline;
    }
  }
  .search_wrapper {
    margin-bottom: 30px;
    font-size: 12px;
    span {
      margin-left: 20px;
      margin-right: 10px;
      &:nth-of-type(1) {
        margin-left: 0;
      }
    }
  }
  .table tr th,
  .table tr td {
    padding-right: 0;
  }
  td.last {
    min-width: 250px;
    .action_wrapper {
      font-size: 12px;
      width: 250px;
      button {
        font: inherit;
      }
    }
  }
}

.fileBox {
  .lwItem {
    > div,
    > ul {
      margin-bottom: 30px;
      padding-left: 20px;
    }
    > ul {
      li {
        float: left;
        width: 100px;
        height: 100px;
        margin-left: 10px;
        overflow: hidden;
        border: 1px solid #ededed;
        padding: 10px;
        position: relative;
        margin-bottom: 10px;
        > span {
          word-wrap: break-word;
          display: block;
          width: 100%;
          height: 100%;
          overflow: hidden;
        }
        .del {
          position: absolute;
          width: 100%;
          height: 100%;
          background: rgba(0, 0, 0, 0.5);
          text-align: center;
          line-height: 100px;
          left: 0;
          top: 0;
          color: #fff;
          display: none;
          .ivu-btn-circle {
            width: 32px;
            min-width: 32px;
          }
          /deep/ .ivu-icon {
            color: #fff;
          }
        }
        &:hover .del {
          display: block;
        }
      }
    }
  }
  p {
    padding: 0 0 10px;
    font-size: 16px;
    i {
      font-size: 14px;
    }
  }
}
</style>
