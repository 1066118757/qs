<template>
  <!--这是.vue文件模板~-->
  <div class="add_etl_container">
    <v-steps :data="steps" :step="step"></v-steps>
    <keep-alive>
      <Form
        :model="form"
        :label-width="90"
        :rules="rules.first"
        ref="form1"
        style="width:370px;margin: 30px auto 0;"
        v-if="step === 1">
        <FormItem label="引接任务名称" prop="name">
          <Input v-model="form.name" placeholder="请输入引接任务名称" style="width: 280px"/>
        </FormItem>
        <FormItem label="数据源名称" prop="dataSourceId">
          <Select v-model="form.dataSourceId" placeholder="请选择数据源" style="width: 280px" @on-change="sourceChange" :disabled="disabled">
            <Option v-for="(o,i) in sourceList" :key="i" :value="o.id">{{o.name}}</Option>
          </Select>
        </FormItem>
        <div style="position: relative" v-if="sourceDetails">
          <Spin fix v-show="sourceDetailsLoading"></Spin>
          <FormItem label="数据库名称" class="no_bottom">
            <span class="bind" v-text="sourceDetails.sourceName" :title="sourceDetails.sourceName"></span>
          </FormItem>
          <FormItem label="服务器地址" class="no_bottom">
            <span class="bind"
                  v-text="sourceDetails.server + ':' + sourceDetails.port"
                  v-show="sourceDetails.server"
                  :title="sourceDetails.server + ':' + sourceDetails.port"></span>
          </FormItem>
          <FormItem label="用户名" class="no_bottom">
            <span class="bind" v-text="sourceDetails.user" :title="sourceDetails.user"></span>
          </FormItem>
          <FormItem label="数据库类型" class="no_bottom">
            <span class="bind">{{sourceDetails.type | formatterSourceType}}</span>
          </FormItem>
          <FormItem label="测试连接" class="no_bottom">
            <span class="bind" v-text="sourceDetails.latestConnectLog"></span>
          </FormItem>
        </div>
      </Form>
      <Form
        :model="form"
        :label-width="80"
        :rules="rules.second"
        ref="form2"
        style="width:360px;margin: 30px auto 0;"
        v-else-if="step === 2">
        <FormItem label="来源表" prop="sourceTable">
          <Select v-model="form.sourceTable" placeholder="请选择数据源表" style="width: 280px" :disabled="disabled">
            <Option v-for="(item,index) in sourceTableList" :key="index" :value="item.tableName">{{item.tableName}}</Option>
          </Select>
        </FormItem>
        <FormItem label="目标表" style="margin-bottom:0">
          <RadioGroup v-model="form.distTableSource" @on-change="radioGroupChange" :disabled="disabled">
            <Radio :label="1" :disabled="disabled">新建目标表</Radio>
            <Radio :label="2" :disabled="disabled">已有目标表</Radio>
          </RadioGroup>
          <template v-if=" form.distTableSource === 1">
            <FormItem :label-width="60" class="form_item" prop="distTable">
              <span slot="label">表&emsp;&emsp;单</span>
              <Input v-model="form.distTable" placeholder="请输入目标表名" style="width: 100%" :disabled="disabled"/>
            </FormItem>
            <FormItem label="逻辑分区" :label-width="60" class="form_item" prop="logicPartitionId">
              <Select v-model="form.themeId" placeholder="选择逻辑分区" style="width: 106px;margin-right: 8px" :disabled="disabled" @on-change="setSubLogicList">
                <Option v-for="item in logicList" :key="item.id" :value="item.id">{{item.name}}</Option>
              </Select><Select v-model="form.logicPartitionId" placeholder="选择元数据" style="width: 106px" :disabled="disabled ||!form.themeId">
                <Option v-for="item in subLogicList" :key="item.id" :value="item.id">{{item.name}}</Option>
              </Select>
            </FormItem>
          </template>
          <template v-else>
            <FormItem class="form_item" prop="distTable" :label-width="60">
              <span slot="label">表&emsp;&emsp;单</span>
              <Select v-model="form.distTable" placeholder="请选择目标表名" style="width: 100%" :disabled="disabled">
                <Option v-for="(item,index) in distTableList" :key="index" :value="item.tableName">{{item.tableName}}</Option>
              </Select>
            </FormItem>
          </template>
        </FormItem>
        <FormItem label="表数据类型" class="form_item" prop="metaDataType">
          <Select v-model="form.metaDataType" placeholder="请选择表数据类型" style="width: 100%" :disabled="disabled">
            <Option :value="201">数据结构</Option>
            <Option :value="202">数据字典</Option>
          </Select>
        </FormItem>
        <FormItem label="导入模式" prop="importMode">
          <RadioGroup v-model="form.importMode">
            <Radio :label="1" :disabled="disabled">覆盖</Radio>
            <Radio :label="2" :disabled="disabled">更新</Radio>
          </RadioGroup>
        </FormItem>
        <FormItem label="同步策略">
          <FormItem :label-width="60" class="form_item" prop="ds">
            <Radio slot="label" v-model="form.syncStrategy" :true-value="1" :false-value="2" @on-change="syncStrategyChange">定时</Radio>
            <DatePicker v-model="date" type="datetime" placeholder="选择时间" style="width: 100%" :disabled="form.syncStrategy !== 1" @on-change="d=>form.ds = d" :options="options"></DatePicker>
          </FormItem>
          <FormItem :label-width="60" class="form_item" prop="pl">
            <Radio slot="label" v-model="form.syncStrategy" :true-value="2" :false-value="1" @on-change="syncStrategyChange">频率</Radio>
            <v-frequency v-model="form.pl" :disabled="form.syncStrategy !== 2"></v-frequency>
          </FormItem>
        </FormItem>
        <FormItem label="任务优先级" prop="priority">
          <Select v-model="form.priority" placeholder="请选择任务优先级" style="width: 280px">
            <Option :value="item.value" v-for="item in $store.state.connect.priority" :key="item.value">{{item.key}}</Option>
          </Select>
        </FormItem>
      </Form>
      <Form
        :model="form"
        :label-width="60"
        :rules="rules.third"
        ref="form3"
        style="width:360px;margin: 30px auto 0;"
        v-else-if="step === 3">
        <FormItem :label-width="360">
          <p slot="label" style="text-align: left">请选择消息提醒机制，并设置相关提醒账号</p>
        </FormItem>
        <FormItem label="短信提醒" prop="name" style="margin-bottom: 0">
          <RadioGroup v-model="form.dx" style="margin-top: -5px">
            <Radio :label="1">启用</Radio>
            <Radio :label="2">关闭</Radio>
          </RadioGroup>
          <FormItem class="form_item" label="提醒账号" v-if="form.dx === 1" prop="dxAccount">
            <Input v-model="form.dxAccount" style="width: 214px"/>
          </FormItem>
        </FormItem>
        <FormItem label="邮箱提醒" prop="name" style="margin-bottom: 0">
          <RadioGroup v-model="form.yj" style="margin-top: -5px">
            <Radio :label="1">启用</Radio>
            <Radio :label="2">关闭</Radio>
          </RadioGroup>
          <FormItem class="form_item" label="提醒账号" v-if="form.yj === 1" prop="yjAccount">
            <Input v-model="form.yjAccount" style="width: 214px"/>
          </FormItem>
        </FormItem>
      </Form>
      <div
        style="width:360px;margin: 30px auto 0;"
        v-else-if="step === 4">
        <vFieldMap :from="sourceFiledList" :to="distFiledList" :value="fileMapList" @change="array=>fileMapList = array"  :disabled="disabled"></vFieldMap>
      </div>
      <div v-else class="last_container">
        <v-done>
          <p>恭喜你操作成功！</p>
          <p><span v-text="djs" class="num" style="margin-right: 4px"></span>秒后将会返回<router-link :to="{name:'etl'}" class="link" @click.native="_clearInterval(intervalId)">引接任务列表</router-link></p>
        </v-done>
      </div>
    </keep-alive>
    <footer v-if="step !== 5">
      <p v-if="step === 4&&(fileMapList.length !== distFiledList.length)" style="text-align: center;color: #ed3f14;font-size: 12px;padding-bottom: 8px">目标表的每个字段都需要有对应的来源表字段与之匹配！</p>
      <Button type="ghost" @click="prev(step)" v-text="step === 1?'新增数据源':'上一步'"></Button>
      <Button type="primary" @click="next(step)" :loading="btnLoading">下一步</Button>
    </footer>
  </div>
</template>
<script>
  import connectServer from "rs/connect"
  import vFrequency from "cmpts/common/frequency"
  import vFieldMap from "cmpts/common/fieldMap"
  import vDone from "cmpts/common/done"
export default {
  props:{
  },
	data() {
    let validateLength = this.$store.state.validateLength;
    let blur = { validator: validateLength(), trigger: 'blur' };
    let change = { validator: validateLength(), trigger: 'change' };
    const validator = (str,num)=>{
      return (r,v,c)=>{
        if((this.form[str] === num)&&!v)c("该项为必填项");
        else c();
      }
    };
    const validatorDate = (r,v,c)=>{
      if(this.form.syncStrategy === 1){
        if(!v)c("该项为必填项");
        else if(Date.parse(v)<Date.now())c("所选时间小于当前时间");
        else c();
      }
      else c();
    }
    return {
      modal:true,
      disabled:false,//编辑时，如果latestScheduleState为真，则有些项目不可以编辑
      djs:5,//倒计时
      step:1,
      steps:["连接配置","任务配置","消息设置","字段映射","结束"],
      date:"",
      form:{
        id:undefined,
        name:"",
        dataSourceId:"",
        sourceTable:"",
        distTable:"",
        distTableSource:1,
        logicPartitionId:"",
        metaDataType:201,
        themeId:"",
        importMode:1,
        syncStrategy:1,
        ds:"",//定时
        pl:"",//频率
        priority:1,
        dx:2,//短信提醒是否开启
        dxAccount:"",//短信提醒账号
        yj:2,//邮箱提醒是否开启
        yjAccount:"",//邮箱提醒账号

      },
      fileMapList:[],//字段映射array
      rules:{
        first:{
          name:blur,
          dataSourceId:change,
        },
        second:{
          sourceTable:change,
          distTable:[change,blur],
          logicPartitionId:{ validator: validator("distTableSource",1), trigger: 'change' },
          ds:{ validator: validatorDate, trigger: 'change' },
          priority:change,
        },
        third:{
          dxAccount:[{ validator: validator("dx",1), trigger: 'blur' },{validator: this.$store.state.validatorPhone, trigger: 'blur' }],
          yjAccount:[{ validator: validator("yj",1), trigger: 'blur' },{validator: this.$store.state.validatorEmail, trigger: 'blur' }],
        },
      },
      sourceTableList:[],//来源表list
      distTableList:[],//目标表list
      logicList:[],//逻辑分区list
      subLogicList:[],//逻辑分区list
      sourceList:[],//数据源list
      sourceFiledList:[],//来源表字段list
      distFiledList:[],//目标表字段list
      sourceDetails:undefined,//选择数据源明细展示
      sourceDetailsLoading:false,//明细加载loading
      btnLoading:false,//下一步loading
      options:{
        disabledDate (date) {
          return date && date.valueOf() < Date.now() - 86400000;
        }
      },
      //编辑/old-value
      edit:{
        sourceId:undefined,
        sourceTableName:undefined,
        distTableName:undefined,
      },
    }
	},
	created() {
    /**
     * 处理面包屑
     * */
    let query = this.$route.query;
    this.$store.commit('setCrumbs',[
      {text:"引接任务管理",query:{},name:"etl"},
      {text:query.id?"编辑引接任务":"添加引接任务",query:query,name:"addEtl"},
    ]);
    //获取sourceList
    connectServer.sourceList({data:{state:1,type:query.type},params:{params3:1,params4:999}},({data,errorCode})=>{
      if(!errorCode){
        this.sourceList = data.pageData;
      }
    });
    let id = query.id;
    id&&connectServer.jobFindById({params:{id}},({data,errorCode})=>{
      if(errorCode)return;
      let {confs,name,dataSourceId,distTable,distTableSource,logicPartitionId,syncStrategy,importMode,priority,id,latestScheduleState} = data;
      this.disabled = !!latestScheduleState;
      let form = this.form,edit = this.edit;
      form.name = name;
      form.id = id;
      form.dataSourceId = edit.sourceId = dataSourceId;
      form.distTable = edit.distTableName = distTable;
      form.distTableSource = distTableSource;
      form.logicPartitionId = logicPartitionId;
      form.syncStrategy = syncStrategy;
      form.importMode = importMode;
      form.priority = priority;
      confs.forEach(({key,type,value})=>{
        switch (type){
          case 702:
            switch (key){
              case "频率":
                form.pl = JSON.parse(value);
                break;
              case "定时":
                this.date = +value;
                form.ds = Vue.filter("date")(+value);
                break;
              case "来源表":
                form.sourceTable = value;
                edit.sourceTableName = value;
                break;
              case "表数据类型":
                form.metaDataType = +value;
                break;
              case "themeId":
                form.themeId = +value;
                break;
            }
            break;
          case 703:
            switch (key){
              case "短信提醒":
                form.dxAccount = value;
                form.dx = 1;
                break;
              case "邮箱提醒":
                form.yjAccount = value;
                form.yj = 1;
                break;
            }
            break;
          case 704:
            switch (key){
              case "字段映射":
                this.fileMapList = JSON.parse(value);
                break;
            }
            break;
        }
      });
      //sourceTable?
    });
  },
	directives: {

	},
	computed: {

	},
  components:{vFrequency,vFieldMap,vDone},
	filters: {
	},
	methods: {
    setSubLogicList(v,flag){
      let o = this.logicList.find(l=>l.id === v);
      if(o)this.subLogicList = o.themeItemListVos.map(({id,name})=>({id,name}));
      if(!flag)this.form.logicPartitionId = this.subLogicList[1].id;
    },
    syncStrategyChange(v){
      if(v === 2)this.$refs.form2.validateField("ds");
    },
    _clearInterval(id){clearInterval(id)},
    sourceChange(id){
      this.sourceDetailsLoading = true;
      connectServer.findById({params:{id}},({errorCode,data})=>{
        this.sourceDetailsLoading = false;
        if(!errorCode){
          let form = {},{type,latestConnectLog,remark,confs} = data;
          form.type = type;form.remark = remark; form.latestConnectLog = latestConnectLog;
          confs.forEach(l=>{
            switch (l.key){
              case "服务器":
                form.server = l.value;break;
              case "端口号":
                form.port = l.value;break;
              case "数据库名":
                form.sourceName = l.value;break;
              case "用户名":
                form.user = l.value;break;
              case "描述":
                form.remark = l.value;break;
            }
          });
          this.sourceDetails = form;
        }
      });
    },
    prev(num){
      let edit = this.edit,form = this.form;
      switch(num){
        case 1:
          this.$router.push({name:"addSource",query:{type:this.$route.query.type,from:"addEtl"}});break;
        case 2:
          edit.sourceId = form.dataSourceId;
          this.step --;break;
        case 4:
          edit.sourceTableName = form.sourceTable;
          edit.distTableName = form.distTable;
          this.step --;break;
        default:
          this.step --;break;
      }
    },
    next(num){
      switch(num){
        case 1:
          this.getSourceTableList();
          this.radioGroupChange(this.form.distTableSource,true);
          break;
        case 2:
          this.$refs.form2.validate(f=>f&&this.step ++);
          break;
        case 3:
          this.$refs.form3.validate(f=>{
            if(f){
              this.getSourceField();
            }
          });
          break;
        case 4:
          if(this.fileMapList.length === this.distFiledList.length)this.submit();
      }
    },
    //获取来源表
    getSourceTableList(){
      this.$refs.form1.validate(f=>{
        if(f){
          let form = this.form;
          let dataSourceId = form.dataSourceId;
          this.btnLoading = true;
          connectServer.queryTableName({data:{dataSourceId}},({data})=>{
            this.btnLoading = false;
            this.step ++;
            this.sourceTableList = data;
            let {sourceId,sourceTableName} = this.edit;
            if(dataSourceId === sourceId)form.sourceTable = sourceTableName;
            else form.sourceTable = "";
          });
        }
      });
    },
    //获取目标表
    getDistTableList(){
      connectServer.queryDistTableName({data:{}},({data})=>{
        this.distTableList = data;
      });
    },
    //获取来源表字段（根据情况获取目标表字段list）
    getSourceField(){
      this.btnLoading = true;
      let {sourceTable:tableName,dataSourceId,distTable} = this.form;
      let {sourceId,sourceTableName,distTableName} = this.edit;
      if(!((dataSourceId === sourceId)&&(sourceTableName === tableName)&&(distTable === distTableName)))this.fileMapList = [];
      connectServer.queryTableFilelds({data:{tableName,dataSourceId}},({data,errorCode})=>{
        if(!errorCode)this.sourceFiledList = data[0].fields;
        if(this.form.distTableSource === 1){this.distFiledList = this.sourceFiledList;this.step ++;this.btnLoading = false;}
        else this.getDistField();
      });
    },
    //获取目标表字段
    getDistField(){
      connectServer.queryDistTableFilelds({params:{tableName:this.form.distTable}},({data,errorCode})=>{
        this.btnLoading = false;
        this.step ++;
        if(!errorCode)this.distFiledList = data[0].fields;
      });
    },
    //获取逻辑分区列表
    getLogicList(){
      connectServer.listMenuAlls({},({data,errorCode})=>{
        if(!errorCode)this.logicList = data;
        let id = this.form.themeId;
        if(id)this.setSubLogicList(id,true);
      });
    },
    //新建目标表和已有目标表切换时
    radioGroupChange(flag,b){
      if(!b)this.form.distTable = "";
      switch (flag){
        case 1:
          !this.logicList.length&&this.getLogicList();
          break;
        case 2:
          !this.distTableList.length&&this.getDistTableList();
          break;
      }
    },
    //提交
    submit(){
      this.btnLoading = true;
      let confs = [],dataSourceAddVo = {type:+this.$route.query.type};
      let {name,dataSourceId,sourceTable,distTable,distTableSource,logicPartitionId,importMode,syncStrategy,priority,ds,pl,dx,yj,dxAccount,yjAccount,id,metaDataType,themeId} = this.form;
      let data = {name,dataSourceId,distTable,distTableSource,importMode,syncStrategy,priority,dataSourceAddVo,id};
      if(distTableSource === 1){
        data.logicPartitionId = logicPartitionId;
        confs.push({key:"themeId",type:702,value:themeId});
      }

      confs.push({key:"来源表",type:702,value:sourceTable});
      confs.push({key:"表数据类型",type:702,value:metaDataType});
      confs.push({key:"themeId",type:702,value:themeId});

      if(syncStrategy === 1)confs.push({key:"定时",type:702,value:Date.parse(ds)});
      else confs.push({key:"频率",type:702,value:JSON.stringify(pl)});

      if(dx === 1)confs.push({key:"短信提醒",type:703,value:dxAccount});
      if(yj === 1)confs.push({key:"邮箱提醒",type:703,value:yjAccount});

      confs.push({key:"字段映射",type:704,value:JSON.stringify(this.fileMapList)});

      data.confs = confs;
      let server = id?"jobUpdate":"jobAdd";
      connectServer[server]({data:data},({errorCode,msg})=>{
        this.btnLoading = false;
        if(!errorCode){
          this.step = 5;
          this.intervalId = setInterval(()=>{
            this.djs --;
            if(this.djs)return;
            clearInterval(this.intervalId);
            this.djs = 5;
            this.$router.push({name:"etl"});
          },1000);
          return
        }
        this.$Notice.error({title:"操作失败",desc:msg});
      });
    },
	}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
  .add_etl_container{
  }
  .ivu-form .bind{
    max-width: 100%;
    display: inline-block;
    overflow: hidden; text-overflow: ellipsis; white-space: nowrap
  }
  .last_container{
    margin-top: 100px;
    p{
      .num,.link{
        color: @primary-color;
      }
    }
  }
  footer{
    padding-top:30px;
    text-align: center;
    .ivu-btn{
      width: 130px;
      line-height:28px;
    }
  }
</style>
<style lang='less'>
  .ivu-form-item .form_item.ivu-form-item{
    margin-bottom: 24px;
    .ivu-form-item-content{
      margin-left:60px!important;
    }
  }
  .add_etl_container{
    .ivu-form-item .ivu-form-item-label{
      line-height: 12px;
      height: 34px;
      overflow: hidden;
    }
  }
</style>
