<template>
  <!--这是.vue文件模板~-->
  <Form :model="form" :label-width="80" :rules="rules" ref="form" style="width:600px;margin: 0 auto;" class="add_web_service_container">
    <FormItem label="URL" prop="url">
      <Input v-model="form.url" placeholder="服务器地址" style="width: 280px" :disabled="disabled"/>
    </FormItem>
    <FormItem label="请求方式">
      <RadioGroup v-model="form.method" style="vertical-align: top;margin-top: -2px">
        <Radio label="get" :disabled="disabled">GET</Radio>
        <Radio label="post" :disabled="disabled">POST</Radio>
      </RadioGroup>
    </FormItem>
    <FormItem label="Header" prop="saveHeader">
      <Input type="textarea" v-model="form.saveHeader" :rows="5" :disabled="disabled"/>
    </FormItem>
    <FormItem label="Body" prop="saveBody">
      <Input type="textarea" v-model="form.saveBody" :rows="5" :disabled="disabled"/>
    </FormItem>
    <FormItem label="发送请求" prop="requested">
      <Button type="ghost" @click="test" :loading="btnLoading">发送请求</Button>
    </FormItem>
    <FormItem label="响应" prop="responsed">
      <RadioGroup v-model="form.type" style="vertical-align: top;margin-top: -2px">
        <Radio :label="1">原始</Radio>
        <Radio :label="2">JSON</Radio>
      </RadioGroup>
      <pre v-html="form.type===1?responseData:responseDataForHtml" style="max-height: 300px;width: 100%;min-height: 100px;"></pre>
    </FormItem>
  </Form>
</template>

<script>
  import connectServer from "rs/connect"
  export default {
    props:{
      source:{
        type:Object,
      },
      disabled:{
        type:Boolean,
        default:false
      }
    },
    data() {
      let validateLength = this.$store.state.validateLength;
      const validateReq = (r,v,c)=>{
        if(this.isBtn){c();return}
        let {responsed} = this.form;
        if(responsed === 1)c("请先发送请求获取响应结果");
        else c();
      };
      const validateRes = (r,v,c)=>{
        if(this.isBtn){c();return}
        let {responsed} = this.form;
        switch (responsed){
          case 2:
            c("响应错误，请检查请求参数是否正确");break;
          case 3:
            c("响应值为空");break;
          case 4:
            c("响应值不符合字段解析要求");break;
          case 5:
            c();break;
          default:
            c();break;
        }
      };
      const validateJson = (str)=>{
        return (r,v,c)=>{
          if(v){
            try {
              this.form[str] = JSON.stringify(JSON.parse(v),undefined,4);
              c();
            } catch ({message}){
              c(message)
            }
            return
          }
          c();
        }
      };
      return {
        loading:false,
        contentType:undefined,
        btnLoading:false,
        isBtn:false,//表示是否是点击btn时的一个标记
        form:{
          type:1,
          url:"",
          method:"get",
          requested:"",
          responsed:1,//1 未发送请求 ；2 请求报错 ；3 请求data为空 4 响应格式不对 5 响应合法
          saveHeader:"",
          saveBody:"",
        },
        responseData:"",
        responseDataForHtml:"",
        syntaxHighlight:this.$store.state.connect.syntaxHighlight,
        rules:{
          url:{validator: validateLength(300), trigger: 'blur'},
          requested:{validator: validateReq},
          responsed:{validator: validateRes},
          saveHeader:{validator: validateJson("saveHeader"), trigger: 'blur'},
          saveBody:{validator: validateJson("saveBody"), trigger: 'blur'},
        },
      }
    },
    created() {
      let source = this.source;
      if(source.method){
        let {url,method,header,body} = source;
        let form = this.form;
        form.url = url;
        form.method = method;
        form.saveHeader = header;
        form.saveBody = body;
      }
    },
    mounted(){
    },
    watch:{
    },
    computed:{
    },
    methods: {
      validate(){
        let req = false,confs;
        this.$refs.form.validateField("requested",f=>{
          req = !f;
          if(req)this.$refs.form.validateField("responsed",f=>req = !f);
        });
        if(req){
          let {url,method,saveBody,saveHeader} = this.form;
          confs = [
            {
              key:"URL",
              type:702,
              value:url
            },
            {
              key:"请求方式",
              type:702,
              value:method
            },
            {
              key:"body",
              type:702,
              value:saveBody
            },
            {
              key:"headers",
              type:702,
              value:saveHeader
            },
            {
              key:"RespContentType",
              type:702,
              value:this.contentType
            },
          ];
        }
        return {
          flag:req,
          data:req?JSON.parse(this.responseData):"",
          html:this.responseDataForHtml,
          confs
        };
      },
      test(){
        this.isBtn = true;
        this.$refs.form.validate(f=>{
          this.isBtn = false;
          if(f){
            let form = this.form;
            let {url,method,saveHeader,saveBody} = form;
            this.btnLoading = true;
            connectServer.test({data:{
              headers:saveHeader,
              body:saveBody,
              requestUrl:url,
              requestMethod:method,
              type:608
            }},({errorCode,msg,data:{data,contentType}})=>{
              this.btnLoading = false;
              this.responseData = this.responseDataForHtml =this.contentType = undefined;
              if(errorCode){
                this.$Notice.error({title:"响应出错",desc:msg});
                form.responsed = 2;
                return;
              }
              if(!data){
                this.$Notice.error({title:"响应出错",desc:"响应值为空"});
                form.responsed = 3;
                return;
              }
              let obj = JSON.parse(data),isArray = obj instanceof Array,isObj = obj instanceof Object;
              if(isArray || !isObj){
                let txt = "根据当前请求字段得到的响应为" + obj + "不符合字段解析要求（它应该为一个对象或者数组）";
                this.$Notice.error({title:"响应出错",desc:txt});
                this.responseDataForHtml = this.syntaxHighlight(obj,true);
                this.responseData = txt;
                form.responsed = 4;
                return;
              }
              form.responsed = 5;
              this.$Notice.success({title:"响应成功"});
              this.responseData = data;
              this.contentType = contentType;
              this.responseDataForHtml = this.syntaxHighlight(obj);
            });
          }
        });
      },
    }
  };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang='less'>
  .add_web_service_container{
    padding-top: 28px;
    .ul{
      position: relative;
      border: 1px solid #F0F0F0;
      border-bottom: none;
      .clearfix{
        border-bottom:1px solid #F0F0F0;
        &.first{
          background-color: #F9FAFC;
          .ivu-icon{
            position: absolute;
            color: @primary-color;
            right:-24px;
            top:6px;
            cursor: pointer;
          }
        }
        >div{
          float: left;
          height: 33px;
          >span{
            padding-left: 10px;
            width: 100%;
            display: inline-block;
          }
          >span,.ivu-input-wrapper{
            vertical-align: top;
          }
          &:nth-of-type(1){
            width:188px;
            border-right: 1px solid #F0F0F0;
          }
          &:nth-of-type(2){
            width:280px;
          }
          &:nth-of-type(3){
            border-left: 1px solid #F0F0F0;
            width:50px;
            text-align: center;
          }
          &.action_wrapper{
            .ivu-icon{
              padding: 4px;
              font-size: 16px;
              color: #c4d6e6;
              cursor: pointer;
            }
          }
        }
      }
    }
  }
</style>
