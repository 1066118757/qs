<template>
  <!--这是.vue文件模板~-->
  <div class="add_etl_from_file_container">
    <v-steps :data="steps" :step="step"></v-steps>
    <keep-alive>
      <div class="upload_container" style="width: 520px;margin: 0 auto;" v-if="step === 1">
          <Upload
            action="//jsonplaceholder.typicode.com/posts/"
            style="margin: 37px auto 18px;width: 80px;color: #4AB9FF;text-align: center"
            :before-upload="beforeUpload"
            :show-upload-list="false"
            >
            <div style="text-align: center;cursor: pointer">
              <p>
                <Icon type="ios-plus-outline" size="50"></Icon>
              </p>
              <p>上传文件</p>
            </div>
          </Upload>
          <p style="margin-bottom: 6px">已选取的文件列表</p>
          <div class="table" style="border-left: 1px solid #F0F0F0;border-right: 1px solid #F0F0F0;">
            <table>
              <thead>
              <tr>
                <td>序号</td>
                <td>文件名</td>
                <td>操作</td>
              </tr>
              </thead>
              <tbody>
              <tr v-show="!fileList.length">
                <td colspan="3" style="text-align: center">还没有选择文件！</td>
              </tr>
              <tr v-for="(item,index) in fileList" :key="index">
                <td v-text="index + 1"></td>
                <td v-text="item.name"></td>
                <td><Button type="text" @click="fileList.splice(index,1)" style="padding-left: 0">删除</Button></td>
              </tr>
              </tbody>
            </table>
          </div>
        </div>
      <Form
        :model="form"
        :label-width="90"
        :rules="rules"
        ref="form"
        style="width:370px;margin: 30px auto 0;"
        v-else-if="step === 2">
        <FormItem label="引接任务名称" prop="name">
          <Input v-model="form.name" placeholder="请输入引接任务名称" style="width: 280px"/>
        </FormItem>
        <FormItem label="目标表" style="margin-bottom:0">
          <RadioGroup v-model="form.distTableSource" @on-change="radioGroupChange">
            <Radio :label="1">新建目标表</Radio>
            <Radio :label="2">已有目标表</Radio>
          </RadioGroup>
          <template v-if=" form.distTableSource === 1">
            <FormItem :label-width="60" class="form_item" prop="distTable">
              <span slot="label">表&emsp;&emsp;单</span>
              <Input v-model="form.distTable" placeholder="请输入目标表名" style="width: 100%"/>
            </FormItem>
            <FormItem label="逻辑分区" :label-width="60" class="form_item" prop="logicPartitionId">
              <Select v-model="form.themeId" placeholder="选择逻辑分区" style="width: 106px;margin-right: 8px" :disabled="disabled" @on-change="setSubLogicList">
                <Option v-for="item in logicList" :key="item.id" :value="item.id">{{item.name}}</Option>
              </Select><Select v-model="form.logicPartitionId" placeholder="选择元数据" style="width: 106px" :disabled="disabled ||!form.themeId">
              <Option v-for="item in subLogicList" :key="item.id" :value="item.id" >{{item.name}}</Option>
            </Select>
            </FormItem>
          </template>
          <template v-else>
            <FormItem class="form_item" prop="distTable" :label-width="60">
              <span slot="label">表&emsp;&emsp;单</span>
              <Select v-model="form.distTable" placeholder="请选择目标表名" style="width: 100%">
                <Option v-for="(item,index) in distTableList" :key="index" :value="item.tableName">{{item.tableName}}</Option>
              </Select>
            </FormItem>
          </template>
        </FormItem>
        <FormItem label="表数据类型" prop="metaDataType">
          <Select v-model="form.metaDataType" placeholder="请选择表数据类型" style="width: 100%" :disabled="disabled">
            <Option :value="201">数据结构</Option>
            <Option :value="202">数据字典</Option>
          </Select>
        </FormItem>
        <FormItem label="导入模式" prop="importMode">
          <RadioGroup v-model="form.importMode">
            <Radio :label="1">覆盖</Radio>
            <Radio :label="2">更新</Radio>
          </RadioGroup>
        </FormItem>
      </Form>
      <div
        style="width:360px;margin: 30px auto 0;"
        v-else-if="step === 3">
        <vFieldMap :from="sourceTableFiledList" :to="distFiledList" :value="fileMapList" @change="array=>fileMapList = array"></vFieldMap>
      </div>
      <div v-else class="last_container">
        <v-done>
          <p>恭喜你操作成功！</p>
          <p><span v-text="djs" class="num" style="margin-right: 4px"></span>秒后将会返回<router-link :to="{name:'etl'}" class="link" @click.native="_clearInterval(intervalId)">引接任务列表</router-link></p>
        </v-done>
      </div>
    </keep-alive>
    <footer v-if="step !== 4">
      <p v-if="step === 3&&(fileMapList.length !== distFiledList.length)" style="text-align: center;color: #ed3f14;font-size: 12px;padding-bottom: 8px">目标表的每个字段都需要有对应的来源表字段与之匹配！</p>
      <Button type="ghost" @click="prev(step)" v-text="step === 1?'返回':'上一步'"></Button>
      <Button type="primary" @click="next(step)" :loading="btnLoading">下一步</Button>
    </footer>
  </div>
</template>

<script>
  import vFieldMap from "cmpts/common/fieldMap"
  import vDone from "cmpts/common/done"
  import connectServer from "rs/connect"
  export default {
    props:{
    },
    data() {
      let validateLength = this.$store.state.validateLength;
      let blur = { validator: validateLength(), trigger: 'blur' };
      let change = { validator: validateLength(), trigger: 'change' };
      const validator = (str,num)=>{
        return (r,v,c)=>{
          if((this.form[str] === num)&&!v)c("该项为必填项");
          else c();
        }
      };
      return {
        disabled:false,
        step:1,
        steps:["选取文件","任务配置","字段映射","结束"],
        fileMapList:[],
        btnLoading:false,
        fileType:undefined,
        fileList:[],
        sourceTableFiledList:[],
        distFiledList:[],
        distTableList:[],
        logicList:[],
        subLogicList:[],
        djs:5,
        form:{
          name:"",
          redisKey:"",
          distTable:"",
          distTableSource:1,
          themeId:"",
          metaDataType:201,
          logicPartitionId:undefined,
          importMode:1
        },
        rules:{
          distTable:[change,blur],
          name:blur,
          logicPartitionId:{ validator: validator("distTableSource",1), trigger: 'change' },
        },
      }
    },
    created() {
      /**
       * 处理面包屑
       * */
      let query = this.$route.query;
      this.$store.commit('setCrumbs',[
        {text:"引接任务管理",query:{},name:"etl"},
        {text:query.id?"编辑引接任务":"添加引接任务",query:query,name:"addEtlFromFile"},
      ]);
      //文件类型判定
      let type = this.$store.state.connect.fileType.find(l=>l.key === +this.$route.query.type);
      if(!type)this.$Notice.error({title:"文件类型错误",desc:"暂不支持该类型文件"});
      this.fileType = type
    },
    directives: {

    },
    computed: {

    },
    components:{vFieldMap,vDone},
    filters: {
    },
    methods: {
      setSubLogicList(v,flag){
        this.subLogicList = this.logicList.find(l=>l.id === v).themeItemListVos.map(({id,name})=>({id,name}));
        if(!flag)this.form.logicPartitionId = this.subLogicList[1].id;
      },
      //获取目标表字段
      getDistField(){
        let form = this.form;
        if(form.distTableSource === 1){
          this.distFiledList = this.sourceTableFiledList;
          this.step ++;
          return;
        }
        this.btnLoading = true;
        connectServer.queryDistTableFilelds({params:{tableName:form.distTable}},({data,errorCode})=>{
          this.btnLoading = false;
          this.step ++;
          if(!errorCode)this.distFiledList = data[0].fields;
        });
      },
      //获取目标表
      getDistTableList(){
        connectServer.queryDistTableName({data:{}},({data})=>{
          this.distTableList = data;
        });
      },
      //新建目标表和已有目标表切换时
      radioGroupChange(flag,b){
        if(!b)this.form.distTable = "";
        switch (flag){
          case 1:
            !this.logicList.length&&this.getLogicList();
            break;
          case 2:
            !this.distTableList.length&&this.getDistTableList();
            break;
        }
      },
      //获取逻辑分区列表
      getLogicList(){
        connectServer.listMenuAlls({},({data,errorCode})=>{
          if(!errorCode)this.logicList = data;
          let id = this.form.themeId;
          if(id)this.setSubLogicList(id,true);
        });
      },
      prev(num){
        switch (num){
          case 1:
            this.$router.go(-1);break;
          default:
            this.step --;break;
        }
      },
      next(num){
        switch (num){
          case 1:
            this.upload();break;
          case 2:
            this.$refs.form.validate(f=>{if(f)this.getDistField()});break;
          case 3:
            if(this.fileMapList.length === this.distFiledList.length)this.submit();break;
        }
      },
      submit(){
        this.btnLoading = true;
        let confs = [],dataSourceAddVo = {type:+this.$route.query.type};
        let {redisKey,distTable,distTableSource,logicPartitionId,importMode,name,metaDataType} = this.form;
        let data = {redisKey,distTable,distTableSource,importMode,dataSourceAddVo,name};
        if(distTableSource === 1)data.logicPartitionId = logicPartitionId;
        confs.push({key:"字段映射",type:704,value:JSON.stringify(this.fileMapList)});
        confs.push({key:"表数据类型",type:702,value:metaDataType});
        data.confs = confs;
//        let server = id?"jobUpdate":"jobAdd";
        connectServer.jobAdd({data:data},({errorCode,msg})=>{
          this.btnLoading = false;
          if(!errorCode){
            this.step = 4;
            this.intervalId = setInterval(()=>{
              this.djs --;
              if(this.djs)return;
              clearInterval(this.intervalId);
              this.djs = 5;
              this.$router.push({name:"etl"});
            },1000);
            return;
          }
          this.$Notice.error({title:"操作失败",desc:msg});
        });
      },
      _clearInterval(id){clearInterval(id)},
      beforeUpload(file){
        let fileType = this.fileType;
        if(!fileType.reg.test(file.name)){
          this.$Notice.error({title:"操作失败",desc:fileType.desc});
          return false;
        }
        //查重
        let checkRepeat = (nm,num)=>{
          let last = nm.lastIndexOf(".");
          let name = nm.slice(0,last);
          let type = nm.slice(last);
          let rpt = num?"(" + num + ")":"";
          let newName = name + rpt + type;
          let flag = this.fileList.find(l=>l.name === newName);
          if(flag)return checkRepeat(nm,num + 1);
          else return newName;
        };
        let obj = {file};
        obj.name = checkRepeat(file.name,0);
        this.fileList.push(obj);
        return false;
      },
      upload(){
        let fileList = this.fileList;
        if(!fileList.length){
          this.$Notice.error({title:"请选择要上传文件！"});
          return;
        }
        let formData = new FormData();
        fileList.forEach(l=>{
          formData.append(l.name,l.file);
        });
        this.btnLoading = true;
        connectServer.jobDownload({data:formData},({data,errorCode,msg})=>{
          this.btnLoading = false;
          if(errorCode){
            this.$Notice.error({title:"上传失败",desc:msg});
            return;
          }
          this.$Notice.success({title:"上传成功",desc:msg});
          this.step ++;
          this.form.redisKey = data.dataKey;
          this.sourceTableFiledList = data.header.map(l=>({fieldName:l}));
          this.radioGroupChange(1,true);
        });
      },
    }
  };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang='less'>
  .add_etl_from_file_container{
    .last_container{
      margin-top: 100px;
      p{
        .num,.link{
          color: @primary-color;
        }
      }
    }
    .form_item.ivu-form-item{
      margin-bottom: 24px;
      .ivu-form-item-content{
        margin-left:60px!important;
      }
    }
    footer{
      padding-top:30px;
      text-align: center;
      .ivu-btn{
        width: 130px;
        line-height:28px;
      }
    }
    .table{
      td{
        font-size: 12px;
      }
    }
  }
</style>
