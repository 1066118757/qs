<template>
  <!--这是.vue文件模板~-->
  <div class="history_statistics_container">
    <v-header :text="isEtl?'引接任务统计':'数据源引接统计'"></v-header>
    <p class="search_wrapper">
      <span>同步状态</span>
      <Select style="width: 150px" v-model="scheduleState" clearable>
        <Option :value="1">进行中</Option>
        <Option :value="2">成功</Option>
        <Option :value="3">失败</Option>
      </Select>
      <span>引接任务名称</span>
      <Input placeholder="输入任务名称进行模糊搜索" style="width: 180px" v-model="jobName"/>
      <span>同步时间</span>
      <DatePicker type="datetimerange" :options="options" placeholder="选择查询同步时间区间" style="width: 326px;margin-right: 30px" :editable="false" @on-change="dateChange"></DatePicker>
      <Button type="ghost" @click="init()">查询</Button>
    </p>
    <div class="card_container">
      <div class="card_wrapper" v-for="item in cardData" :style="item.style">
        <p class="title" v-text="item.name"></p>
        <div class="main">
          <p>
            <span class="key">同步总次数:</span>
            <span class="value" v-text="item.totalTime"></span>
          </p>
          <p>
            <span class="key">同步成功率:</span>
            <span class="value" v-text="((s)=>(Math.floor(s) === s ? s : s.toFixed(2)))(100 - item.failPercent) + '%'"></span>
          </p>
          <p>
            <span class="key">同步失败率:</span>
            <span class="value" v-text="item.failPercent + '%'"></span>
          </p>
          <p>
            <span class="key">同步数据量总数:</span>
            <span class="value" v-text="item.totalDataCount"></span>
          </p>
        </div>
      </div>
    </div>
    <div class="table" :style="$store.state.setTableHeight(517)">
      <table>
        <thead>
        <tr>
          <th>序号</th>
          <th>名称</th>
          <th>数据源</th>
          <th>创建用户</th>
          <th>状态</th>
          <th>引接开始时间</th>
          <th>引接时间</th>
          <th>引接数据量</th>
          <th>引接执行结果</th>
        </tr>
        </thead>
        <tbody>
        <tr v-show="!data.length">
          <td colspan="9" style="text-align: center">没有数据</td>
        </tr>
        <tr v-for="(item,index) in data" :key="item.name">
          <td v-text="index + 1"></td>
          <td v-text="item.name"></td>
          <td>{{item.dataSourceName}}</td>
          <td v-text="item.createUser"></td>
          <td>
            <Button :type="item.state===1?'success':'error'" shape="circle" style="min-width:40px;padding:0">{{item.state===1?"启用":"禁用"}}</Button>
          </td>
          <td v-text="item.scheduleStartTime"></td>
          <td v-text="item.scheduleEndTime"></td>
          <td v-text="item.successRows"></td>
          <td :style="{color:color(item.scheduleState)}">{{item.scheduleState | formatterSyncType }}</td>
        </tr>
        </tbody>
      </table>
      <Spin fix v-show="loading"></Spin>
    </div>
    <Page
      :total="total"
      show-elevator
      show-total
      :page-size="minPageSize"
      placement="top"
      @on-change="init"
      style="margin-top:10px;"
    ></Page>
  </div>
</template>

<script>
  import connectServer from "rs/connect"
export default {
  props:{
  },
	data() {
    return {
      isEtl:false,
      options:{
        disabledDate (date) {
          return date.valueOf()<1262275200000||date.valueOf()>Date.now();
        }
      },
      data:[],
      total:0,
      loading:false,
      startTime:"",
      endTime:"",
      jobName:"",
      scheduleState:"",
      cardData:[
        {
          name:"昨日同步结果",
          style:{backgroundImage:'url(./static/images/tbbg1.png)'},
          failPercent:0,
          totalDataCount:0,
          totalTime:0
        },
        {
          name:"上周同步结果",
          style:{backgroundImage:'url(./static/images/tbbg2.png)'},
          failPercent:0,
          totalDataCount:0,
          totalTime:0
        },
        {
          name:"当前同步结果",
          style:{backgroundImage:'url(./static/images/tbbg3.png)'},
          failPercent:0,
          totalDataCount:0,
          totalTime:0
        }
      ]
    }
	},
	created() {
    let route = this.$route,query = route.query;
    let flag = this.isEtl = route.name === "statisticsEtl";
    let crumb = {text:"数据源管理",query:{},name:"source"};
    if(flag){
      crumb = {text:"引接任务管理",query:{},name:"etl"};
    }
    this.$store.commit("setCrumbs",[
      crumb,
      {text:"历史统计",query:query,name:flag?"statisticsEtl":"statisticsSource"},
    ]);
    this.statisticsInfo();
	},
	directives: {

	},
	computed: {
    minPageSize(){
      return Math.max(Math.floor((this.$store.state.screenHeight - 567)/41),6);
    }
	},
	filters: {
	},
	methods: {
    color(type){
      switch (type){
        case 1:
          return "#ff9900";
        case 2:
          return "#19be6b";
        case 3:
          return "#ed3f14";
      }
    },
    dateChange(date){
      this.startTime = date[0];
      this.endTime = date[1];
    },
    init(num){
      let id = this.$route.query.id;
      let dataSourceId,jobId;
      this.isEtl?jobId = id:dataSourceId = id;
      let {startTime,endTime,jobName,scheduleState} = this.$data;
      let obj = {
        dataSourceId,
        jobId,
      };
      let form = Object.assign({},obj,{
        startTime:startTime||undefined,
        endTime:endTime||undefined,
        jobName:jobName||undefined,
        scheduleState:scheduleState||undefined
      });
      this.loading = true;
      connectServer.statisticsList({data:form,params:{params3:num||1,params4:this.minPageSize}},({data:{pageData,totalCount},errorCode})=>{
        this.loading = false;
        if(errorCode){this.$Notice.error({title:"获取列表失败！"});return}
        this.data = pageData;
        this.total = totalCount;
      });
      return form;
    },
    statisticsInfo(){
      let form = this.init();
      let now_string = Vue.filter("date")(Date.now(),"yyyy-MM-dd")+" 00:00:00";
      let now = Date.parse(now_string);
      let yesterday = Object.assign({},form,{
        startTime:Vue.filter("date")(now - 86400000,"yyyy-MM-dd hh:mm:ss"),
        endTime:now_string,
        jobName:undefined,
        scheduleState:undefined
      });
      let weekNow = (new Date()).getDay();
      let weekEnd = now - ((weekNow?weekNow:7)-1)*86400000;
      let weekStart = weekEnd - 7*86400000;
      let lastWeek = Object.assign({},form,{
        startTime:Vue.filter("date")(weekStart,"yyyy-MM-dd hh:mm:ss"),
        endTime:Vue.filter("date")(weekEnd,"yyyy-MM-dd hh:mm:ss"),
        jobName:undefined,
        scheduleState:undefined
      });
      Promise.all([connectServer.statisticsInfo({data:yesterday}),connectServer.statisticsInfo({data:lastWeek}),connectServer.statisticsInfo({data:form})]).then((array)=>{
        let data = this.cardData;
        this.cardData = array.map(({data:{totalTime,failTime,totalDataCount}},i)=>{
          let failPercent = 0;
          if(totalTime){
            let s = (failTime/totalTime)*100;
            failPercent = Math.floor(s) === s ? s : s.toFixed(2);
          }
          return Object.assign({},data[i],{totalTime,failPercent,totalDataCount});
        });
      });
    }
	}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
  .history_statistics_container{
    .search_wrapper{
      margin-bottom: 30px;
      font-size: 12px;
      span{
        margin-left:30px;
        margin-right: 10px;
        &:nth-of-type(1){
          margin-left:0;
        }
      }
    }
    .card_container{
      margin-bottom: 30px;
      color: #fff;
      font-size: 12px;
      text-align: center;
      .card_wrapper{
        width: 240px;
        height:150px;
        display: inline-block;
        margin-right: 20px;
        vertical-align: middle;
        &:last-child{
          margin-right: 0;
        }
        .title{
          line-height:30px;
          border-bottom: 1px solid #fff;
        }
        .main{
          text-align: left;
          line-height: 12px;
          padding-top: 20px;
          padding-left: 30px;
          p{
            margin-bottom: 8px;
            span{
              display: inline-block;
              vertical-align: middle;
              overflow: hidden; text-overflow: ellipsis; white-space: nowrap
            }
            .key{
              width: 132px;
            }
            .value{
              max-width:56px;
            }
          }
        }
      }
    }
  }
</style>
