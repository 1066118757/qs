<template>
  <div class="data_base_container">
    <v-header :text="$route.query.id?'编辑数据源':'添加数据源'"></v-header>
    <component :is="component"></component>
  </div>
</template>
<script>
  import Data_base from "./add/data_base"
  import Web_service from "./add/web_service"
  import store from "@/store"
export default {
    data(){
      return {
        component:Data_base,
      }
    },
    created(){
      let query = this.$route.query;
      store.commit("setCrumbs",[
        {text:"数据源管理",query:{},name:"source"},
        {text:query.id?"编辑数据源":"添加数据源",query:query,name:"addSource"},
      ]);
      if(query.type == 608)this.component = Web_service;
    }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
  .data_base_container{
    header{
      text-align: center;
      font-size: 18px;
      color: #4A4B50;
      font-weight: 600;
      padding-top: 28px;
      padding-bottom: 28px;
    }
  }
</style>
