<template>
  <div id="app_container">
    <router-view name="sub_menu"></router-view>
    <router-view name="crumbs"></router-view>
    <router-view></router-view>
  </div>
</template>
<script>
export default {
	name: 'app',
	data(){
    return {
    }
  },
	created() {
	},
	methods: {

	}
}
</script>
<style scoped lang='less'>
</style>
