<template>
  <div class="source_table_add_data">
    <v-steps :data="steps" :step="step"></v-steps>

    <div class="step" v-if="step==1" style="width:360px;margin: 30px auto;">
      <Form
        :model="form"
        :label-width="90"
        :rules="rules"
        ref="form"
        style="width:370px;margin: 30px auto 0;">
        <FormItem label="加载数据到" style="margin-bottom:0">
          <RadioGroup v-model="form.distTableSource" @on-change="radioGroupChange">
            <Radio :label="1">新建目标表</Radio>
            <Radio :label="2">已有目标表</Radio>
          </RadioGroup>
        </FormItem>
        <template v-if="form.distTableSource === 1">
          <FormItem class="form_item" prop="distTable">
            <span slot="label">表&emsp;&emsp;&emsp;名</span>
            <Input v-model="form.distTable" placeholder="请输入目标表名" style="width: 100%"/>
          </FormItem>
          <FormItem label="逻辑分区" v-if="shareFlag" class="form_item" prop="logicPartitionId">
            <Select v-model="form.themeId" placeholder="选择逻辑分区" style="width: 106px;margin-right: 8px"  @on-change="setSubLogicList">
              <Option v-for="item in logicList" :key="item.id" :value="item.id">{{item.name}}</Option>
            </Select><Select v-model="form.logicPartitionId" placeholder="选择元数据" style="width: 106px">
            <Option v-for="item in subLogicList" :key="item.id" :value="item.id">{{item.name}}</Option>
          </Select>
          </FormItem>
          <FormItem label="元数据类型" prop="metadataType">
            <Select v-model="form.metadataType" placeholder="请选择元数据类型" style="width: 100%" >
              <Option :value="201">数据结构</Option>
              <Option :value="202">数据字典</Option>
            </Select>
          </FormItem>
        </template>
        <template v-else>
          <FormItem class="form_item" prop="distTable" >
            <span slot="label">表&emsp;&emsp;&emsp;名</span>
            <Select v-model="form.distTable" placeholder="请选择目标表名" style="width: 100%">
              <Option v-if="distTableList.length==0" disabled :value="0">共享分区还没有表</Option>
              <Option v-if="shareFlag" v-for="(item,index) in distTableList" :key="index" :value="item.tableName">{{item.tableName}}</Option>
              <Option v-if="!shareFlag" v-for="(item,index) in distTableList" :key="index" :value="item.name">{{item.name}}</Option>
            </Select>
          </FormItem>
        </template>
      </Form>
      <div style="text-align:center;margin: 30px auto;">
          <!-- <Button type="ghost" style="width: 130px"  @click="">返回</Button> -->
          <Button type="primary" style="width: 130px" @click="foo"  :loading="loading.submitBtn"  >下一步</Button>
      </div>
    </div>
    <div class="step" v-if="step==2" style="width:380px;margin: 30px auto;">
       <vFieldMap v-if="form.distTableSource === 2" :from="sourceTableFiledList" :to="distFiledList" :value="fileMapList" @change="array=>fileMapList = array"></vFieldMap>

      <div  v-if="form.distTableSource === 1"  class="field_map_container clearfix">
        <div class="left">
          <p class="title">来源表</p>
          <p class="item" v-for="(f,i) in sourceTableFiledList" :key="i">
            <span class="name">字段名:</span>
            <span v-text="f.fieldName" :title="f.fieldName" class="overflow"></span>
          </p>
        </div>
        <div class="right">
          <p class="title">目标表</p>
          <p class="item" v-for="(f,i) in sourceTableFiledList" :key="i">
            <span class="name">是否加载:</span>
            <RadioGroup v-model="f.checked" v-if="showradio"  @on-change="showradio=!showradio;showradio=!showradio;">
                <Radio :label="1">
                    <span>是</span>
                </Radio>
                <Radio :label="0">
                    <span>否</span>
                </Radio>
            </RadioGroup>
          </p>
        </div>
      </div>
      <div style="text-align:center;margin: 30px auto;">
          <Button type="ghost" style="width: 130px"  @click="step--">上一步</Button>
          <Button type="primary" style="width: 130px" @click="getDataPreivew"  :loading="loading.submitBtn"  >下一步</Button>
      </div>
    </div>
    <div class="step" v-if="step==3">
      <div style="text-align:center; margin:15px 0 ;">
          <Button type="ghost" style="width: 130px"  @click="step--" :loading="loading.submitBtn">上一步</Button>
          <Button type="primary" style="width: 130px" @click="shareSubmit()" :loading="loading.submitBtn" >确定提交</Button>
      </div>
      <Table  v-if="step==3" class="tabBx" :height="height" :columns="columns" :data="dataList"></Table>
    </div>
    <div class="step" v-if="step==4" style="margin: 50px auto;">
      <v-done>
        <p>恭喜你操作成功！</p>
        <p><span v-text="djs" class="num" style="margin-right: 4px"></span>秒后将会返回<router-link :to="{name:'etl'}" class="link" @click.native="_clearInterval(intervalId)">数据表页面</router-link></p>
      </v-done>
      <div style="text-align:center;margin-top: 20px">
          <Button type="primary" style="width: 130px" @click="goBack" >立即返回</Button>
      </div>
    </div>
  </div>
</template>

<script>
import storageServer from "rs/storage";
import connectServer from "rs/connect"
import vFieldMap from "cmpts/common/fieldMap"
import oldServer from  "rs/oldServer"
import vDone from "cmpts/common/done"
  export default {
    name: 'source_table_add_data',
    data () {
      let validateLength = this.$store.state.validateLength;
      let blur = { validator: validateLength(), trigger: 'blur' };
      let change = { validator: validateLength(), trigger: 'change' };
      const validator = (str,num)=>{
        return (r,v,c)=>{
          if((this.form[str] === num)&&!v)c("该项为必填项");
          else c();
        }
      };
      return {
        height:9000,
        name: this.$route.query.name,
        sql:"",
        steps:['加载目标',"字段选择","数据预览","结束"],
        fileObj:{},
        step:1,
        djs:5,
        intervalId:'',
        shareFlag:true,
        loading:{
          submitBtn:false,
        },
        sourceTableFiledList:[],
        distFiledList:[],
        fileMapList:[],
        columns:[],
        dataList:[],
        noticeFlag:true,
        distTableList:[],
        logicList:[],
        subLogicList:[],
        form:{
          distTable:"",
          distTableSource:1,
          themeId:"",
          metadataType:201,
          logicPartitionId:undefined,
          importMode:1
        },
        rules:{
          distTable:[change,blur],
          name:blur,
          logicPartitionId:{ validator: validator("distTableSource",1), trigger: 'change' },
        },
        showradio:true,
      }
    },
    components:{vFieldMap,vDone},
    destroyed(){
      if(this.whileTime) clearTimeout(this.whileTime);
      this.$Notice.close("noticeFlag");
      
      if(this.intervalId)clearInterval(this.intervalId);
    },
    created() {
      /**
       * 处理面包屑
       * */
      let pName = this.$route.query.pName;
      let pId = this.$route.query.pId;
      let gName = this.$route.query.gName;
      let gId = this.$route.query.gId;
      let shareType = this.$route.query.type;
      if(this.$route.query.sql){
        this.sql = Base64.decode(this.$route.query.sql)
      }
      else{
        this.sql = 'select * from '+ pName;
      }
      this.$store.commit('setCrumbs', [
        {text: "数据管理", query: {}, name: "storageSource"},
        {text: gName, query: {name:gName,id:gId},name: "source_table_list"},
        {text: pName, query: {name:pName,id:pId,pName:gName,pId:gId},name: "source_table_detail"},
        {text: this.name, query: {}},
      ]);
      
      this.height=parseInt((this.$store.state.setTableHeight(330)).height.split("px")[0]);
      // this.getLogicList();
      if(shareType == "share"){
        this.shareFlag = false;
        this.steps[0] = "共享目标"
        this.form.themeId = 100;
        this.form.logicPartitionId = 1002;
      }
      else
        this.getLogicList();
      //初始化数据
    },
    methods: {
      _clearInterval(id){clearInterval(id)},
      
      //新建目标表和已有目标表切换时
      radioGroupChange(flag,b){
        if(!b)this.form.distTable = "";
        switch (flag){
          case 1:
            !this.logicList.length&&this.getLogicList();
            break;
          case 2:
            !this.distTableList.length&&this.getDistTableList();
            break;
        }
      },
      //获取逻辑分区列表
      getLogicList(){
        if(!this.shareFlag) return;
        connectServer.listMenuAlls({},({data,errorCode})=>{
          if(!errorCode)this.logicList = data;
          let id = this.form.themeId;
          if(id)this.setSubLogicList(id,true);
        });
      },
      // 改变logicSelect
      setSubLogicList(v,flag){
        this.subLogicList = this.logicList.find(l=>l.id === v).themeItemListVos.map(({id,name})=>({id,name}));
        if(!flag)this.form.logicPartitionId = this.subLogicList[0].id;
      },
      //获取目标表
      getDistTableList(){
        if(this.shareFlag){
          connectServer.queryDistTableName({data:{}},({data})=>{
            this.distTableList = data;
          });
        }
        else{
          storageServer.findItemList(
            { data:{themeId: 100}, params: { params3: 1, params4: 1000 } },
            ({ data, errorCode }) => {
              this.loading.list = false;
              if (!errorCode) {
                this.distTableList = data.pageData;
              }
            }
          );
        }
      },
      // 获取列名s
      foo() {
        this.$refs.form.validate(f=>{if(f)this.getCols()});
      },
      getCols() {
        let flag = false;
        
        if(this.form.distTableSource==1){
          storageServer.queryDistTableFilelds({
            params:{
            tableName:this.$route.query.pName
          }},({data,errorCode})=>{
            if(!errorCode){
              this.sourceTableFiledList = data[0].fields;
              for(let o of this.sourceTableFiledList){
                o.checked = 1
              }
              this.step = 2;
            }
            else{
              this.$Notice.error({desc:"获取页面数据失败"})
            }
          });
        }
        else{
          storageServer.queryDistTableFilelds({
            params:{
            tableName:this.form.distTable
          }},({data,errorCode})=>{
            if(!errorCode){
              this.distFiledList = data[0].fields;
              if(flag) this.step = 2;
              else  flag = true;
            }
            else{
              this.$Notice.error({desc:"获取页面数据失败"})
            }
          });
          storageServer.queryDistTableFilelds({
            params:{
            tableName:this.$route.query.pName
          }},({data,errorCode})=>{
            if(!errorCode){
              this.sourceTableFiledList = data[0].fields;
              if(flag) this.step = 2;
              else  flag = true;
            }
            else{
              this.$Notice.error({desc:"获取页面数据失败"})
            }
          });
        }
      },
      getDataPreivew(){
        this.columns = [];
        let sql = this.sql;
        if(this.form.distTableSource === 1){
          for(let o of this.sourceTableFiledList){
            if(o.checked === 1){
              this.fileMapList.push({
                  dist:o.fieldName,
                  source:o.fieldName,
                  distDataType:o.fieldType
              })
            }
          }
        }
        else if(this.fileMapList.length<this.distFiledList.length){
          this.$Notice.error({title:"违规操作",desc:"目标表字段映射不完整！"});
          return;
        }

        this.loading.submitBtn = true;
        oldServer.executeSql({
          data:{sql},params:{}
        },(data,errorCode)=>{
          if(!errorCode){
            // loading
            this.loading.submitBtn = false;
            // 表头
            let newHead=[];
            for(let i in this.fileMapList){
              let ob = {};
              let title = this.fileMapList[i].dist;
              let source = this.fileMapList[i].source;
              data.columnInfos.forEach((o,i)=>{
                if(o.columnName == source)
                  ob.render=(h, params) => {
                    return h('span', params.row[i]);
                  };
              });
              ob.width=150;
              ob.title= title;
              newHead.push(ob);
            }
            this.columns=newHead;

            // 内容
            let newData = []
            data.RowDataSet.forEach(arr=>{
              let json={};
              arr.forEach((item,i)=>{
                json[i]=item;
              });
              newData.push(json);
            });
            this.dataList = newData;
            // 步骤向前
            this.step++;
          }
        });

        // oldServer.sparksqlQuery({
        //   data:{
        //   limit:100,
        //   tableName:'default.'+this.$route.query.pName
        // },params:{}},(data,errorCode)=>{
        //   if(!errorCode){
        //     // loading
        //     this.loading.submitBtn = false;
        //     // 表头
        //     let newHead=[];
        //     for(let i in this.fileMapList){
        //       let ob = {};
        //       let title = this.fileMapList[i].dist;
        //       let source = this.fileMapList[i].source;
        //       data.columnInfos.forEach((o,i)=>{
        //         if(o.columnName == source)
        //           ob.render=(h, params) => {
        //             return h('span', params.row[i]);
        //           };
        //       });
        //       ob.title= title;
        //       newHead.push(ob);
        //     }
        //     this.columns=newHead;

        //     // 内容
        //     let newData = []
        //     data.RowDataSet.forEach(arr=>{
        //       let json={};
        //       arr.forEach((item,i)=>{
        //         json[i]=item;
        //       });
        //       newData.push(json);
        //     });
        //     this.dataList = newData;
        //     // 步骤向前
        //     this.step++;
        //   }
        // });
      },
      shareSubmit(){
        let data = {
          columnMappingVoList:this.fileMapList,
          srcTableName:this.$route.query.pName,
          distTableName:this.form.distTable,
          distTableSource :this.form.distTableSource,
          logicPartitionId :this.form.logicPartitionId,
          metadataType :this.form.metadataType,
          sql:this.sql
        }
        this.loading.submitBtn = true;
        storageServer.loadOrShare({data},({data,errorCode,msg})=>{
          // this.loading.submitBtn = false;
          if(errorCode){
            this.loading.submitBtn = false;
            this.$Notice.error({title:"提交失败",desc:msg});
            return;
          }
          this.whileResult(data);
        },(err)=>{
          this.$Notice.error({title:"网络异常",desc:"请刷新页面重试！"});
        });
      },
      whileResult(redisKey){
        storageServer.getResult({params:{redisKey}},({data,errorCode,msg})=>{
          if(errorCode==1000){
            if(this.noticeFlag){
              this.noticeFlag = false;
              this.$Notice.info({title:"waiting",desc:"数据正在载入，请稍等！",name:"noticeFlag",duration: 0});
            } 
            this.whileTime = setTimeout(()=>{
              this.whileResult(redisKey);
            },5000) 
            return
          }
          else if(errorCode==0){
            this.noticeFlag = true;
            this.$Notice.close("noticeFlag")
            this.loading.submitBtn = false;
            this.step ++;
            this.intervalId = setInterval(()=>{
              this.djs --;
              if(this.djs)return;
              clearInterval(this.intervalId);
              this.goBack()
              this.djs = 5;
            },1000);
          }
          else{
            this.noticeFlag = true;
            this.$Notice.close("noticeFlag")
            this.loading.submitBtn = false;
            this.$Modal.error({title:"操作失败",content:'发生错误：'+msg});
            return;
          }
        });
      },
      goBack(){
        let pName = this.$route.query.pName;
        let pId = this.$route.query.pId;
        let gName = this.$route.query.gName;
        let gId = this.$route.query.gId;
        this.$router.push({ query: {name:pName,id:pId,pName:gName,pId:gId},name: "source_table_detail"});
      }
    }
  }
</script>

<style lang='less'>
  @import "../../assets/css/variable.less";

  .source_table_add_data {
    height: 100%;
     position: relative;
    
    .tabBx{ height: 100%; overflow: hidden;
      // .ivu-table-wrapper{ border: none !important;}
      .ivu-table-header{ height: 50px !important;}
    }
    .h2{
      font-size:14px;
      color:rgba(74,75,80,1);
    }
    .cz{
      a{ margin: 0 4px; text-decoration: underline;}
    }
    .ivu-page{ position: absolute; bottom: 0; right: 0;}
    .step{
      .filed-list{
        margin:4px 0;
        padding: 4px 0;
        .filed-list-name{
          display: inline-block;
          width: 120px;
          padding-left: 4px;
          border-radius: 4px;
          line-height: 24px;
          border:1px solid #ccc;
          margin-right:10px;
        }
      }
    }
  .field_map_container{
    font-size: 12px;
    cursor: default;
    >div{
      width: 50%;
    }
    .left{
      float: left;
      padding-right: 20px;
    }
    .right{
      padding-left: 20px;
      float: left;
    }
    .ivu-select{
      width: 100px;
    }
    .item{
      height: 38px;
      line-height: 32px;
      padding-top: 3px;
      padding-bottom: 3px;
      .name{
        margin-right:8px;
      }
      .overflow{
        line-height: 30px;
        max-width:108px;
        display: inline-block;
        vertical-align: top;
      }
    }
    .title{
      text-align: center;
    }
  }
  }
</style>
