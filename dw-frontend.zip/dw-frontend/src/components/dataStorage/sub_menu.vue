<template>
  <div class="sub_menu_container_com" :style="{minHeight:$store.state.screenHeight - 60 + 'px'}">
    <h3>
      <Icon type="stats-bars" size="20" color="#7D7F85" style="float: left"></Icon>
      <span>数据存储系统</span>
    </h3>
    <router-link tag="p" :to="item.route" active-class="active" class="list_wrapper first" v-for="item in subMenu" :key="item.name">
      <Icon type="ios-paper-outline" size="18" color="#fff" style="float: left"></Icon>
      <span class="bind" v-text="item.name"></span>
    </router-link>
  </div>
</template>

<script>
  export default {
    props: {},
    data: function () {
      return {
        subMenu: [
          {
            name: "数据管理",
            route: {
              name: "storageSource"
            }
          },
          {
            name: "图片数据管理",
            route: {
              name: "storageImg"
            }
          },
          {
            name: "视频数据管理",
            route: {
              name: "storageVideo"
            }
          },
          {
            name: "其他文件",
            route: {
              name: "otherFile"
            }
          },
          // {
          //   name: "接口管理",
          //   route: {
          //     name: "restFull"
          //   }
          // },
        ]
      }
    },
    created() {

    },
    directives: {},
    computed: {},
    filters: {},
    methods: {}
  };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang='less'>

</style>
