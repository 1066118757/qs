<template>
  <div class="source_table_list">
    <Row class="title_box">
      <Col span="12">
        <span class="h1">{{name}}</span>
      </Col>
      <Col span="12" style="text-align: right">
        <Input v-model="keyWord.name" style="width: 200px;" placeholder="输入表名进行模糊查询"></Input>
        <Button type="ghost" @click="search">查询</Button>
        <!-- <Button type="ghost" shape="circle" icon="plus-round">新增数据</Button>
        <Button type="ghost" shape="circle" icon="plus-round">创建合表</Button> -->
      </Col>
    </Row>
    <Table stripe :columns="columns" :data="dataList"></Table>
    <Page
      :total="total"
      show-elevator
      show-total
      placement="top"
      @on-change="pageChange"
    ></Page>

    <Modal
      v-model="exportDataModal"
      title="选择加载目标地址"
      width="480"
      class="no_footer">
				<Form :label-width="80" :model="exportData">
						<FormItem label="分区名">
              <Select v-model="exportData.logicId" @on-change="logicIdChange">
                <Option v-for="(item,index) in LogicList" :value="item.id" :key="index">{{item.name}}</Option>
              </Select>
						</FormItem>
						<FormItem label="目标表名" >
              <Select v-model="exportData.tableName">
                <Option v-for="(item,index) in tableList" :value="item.name" :key="index">{{item.name}}</Option>
              </Select>
						</FormItem>

						<FormItem label="分区描述">
								<Input type="textarea"  placeholder="分区描述"></Input>
						</FormItem>
				</Form>
				<div style="text-align:center; margin-top:20px; margin-bottom:50px;">
          <Button type="ghost" style="width: 130px" @click="exportDataModal = false">取消</Button>
          <Button type="primary" style="width: 130px" @click="shareData()" >提交</Button>
				</div>
    </Modal>
  </div>
</template>

<script>
import storageServer from "rs/storage";
import oldServer from "rs/oldServer";
import { Base64 } from "js-base64";
export default {
  name: "source_table_list",
  data() {
    return {
      name: this.$route.query.name,
      exportDataModal: false,
      keyWord: {
        name: ""
      },
      total: 100,
      columns: [
        {
          width: 65,
          title: "序号",
          render: (h, params) => {
            return params.index + 1;
          }
        },
        {
          title: "数据表名",
          // width:200,
          render: (h, params) => {
            return [
              h(
                "a",
                {
                  on: {
                    click: () => {
                      this.goDetail(params.row);
                    }
                  }
                },
                params.row.name
              )
            ];
          }
        },
        {
          width: 140,
          title: "记录数",
          render: (h, params) => {
            // 如果在刷新中，置灰
            if (params.row.findCount === "") {
              return [
                h(
                  // "span",this.linesCount[params.row.name]||0
                  "span",
                  params.row.findCount
                ),
                h(
                  "a",
                  {
                    on: {
                      click: () => {
                        this.refresh(params.row.name);
                      }
                    },
                    style: {
                      float: "right",
                      "margin-top": "3px",
                      "font-size": "12px",
                      "line-height": "12px",
                      display: "inline-block",
                      border: "1px solid #999",
                      color: "#999",
                      padding: "1px 4px",
                      "border-radius": "6px"
                    }
                  },
                  "刷新"
                )
              ];
            } else
              // 正常状态
              return [
                h(
                  // "span",this.linesCount[params.row.name]||0
                  "span",
                  params.row.findCount
                ),
                h(
                  "a",
                  {
                    on: {
                      click: () => {
                        this.refresh(params.row.name);
                      }
                    },
                    style: {
                      float: "right",
                      "margin-top": "3px",
                      "font-size": "12px",
                      "line-height": "12px",
                      display: "inline-block",
                      border: "1px solid #57a3f3",
                      color: "#57a3f3",
                      padding: "1px 4px",
                      "border-radius": "6px"
                    }
                  },
                  "刷新"
                )
              ];
          }
        },
        {
          width: 100,
          title: "创建人",
          render: (h, params) => {
            return params.row.createUserName;
          }
        },
        {
          title: "创建时间",
          width: 180,
          render: (h, params) => {
            return Vue.filter("date")(params.row.createTime);
          }
        },
        {
          title: "概述",
          render(h, { row: { purpose } }) {
            let str =
              purpose.length > 15 ? purpose.substring(0, 15) + "..." : purpose;
            return h("Tooltip", { placement: "top" }, [
              h("span", str),
              h("div", { slot: "content" }, purpose)
            ]);
          }
        },
        {
          title: "操作",
          width: 200,
          className: "cz",
          render: (h, params) => {
            return [
              h(
                "a",
                {
                  on: {
                    click: () => {
                      this.goDetail(params.row);
                    }
                  }
                },
                "预览"
              ),
              // 暂时隐藏
              h(
                "a",
                {
                  on: {
                    click: () => {
                      this.exportTable(params.row.name);
                    }
                  }
                },
                "导出"
              ),
              h(
                "a",
                {
                  on: {
                    click: () => {
                      this.shareData(params.row);
                    }
                  }
                },
                "加载"
              ),
              // 隐藏
              // h(
              //   "a",
              //   {
              //     on: {
              //       click: () => {
              //         this.add(params.row);
              //       }
              //     }
              //   },
              //   "探索分析"
              // ),
              h(
                "a",
                {
                  on: {
                    click: () => {
                      this.shareData(params.row, "s");
                    }
                  }
                },
                "共享"
              )
              // 隐藏
              // h(
              //   "a",
              //   {
              //     on: {
              //       click: () => {
              //         this.add(params.row);
              //       }
              //     }
              //   },
              //   "清空"
              // )
            ];
          }
        }
      ],
      loading: {
        list: false
      },
      exportData: {
        logicId: "",
        tableName: ""
      },
      dataList: [],
      LogicList: [],
      tableList: [],
      sourceName: "",
      sourceId: "",
      linesCount: {}
    };
  },
  created() {
    /**
     * 处理面包屑
     * */
    this.$store.commit("setCrumbs", [
      { text: "数据管理", query: {}, name: "storageSource" },
      { text: this.name, query: {} }
    ]);
    this.getData();
  },
  methods: {
    pageChange(n) {
      this.getData(n);
    },
    // export(row){
    //   this.sourceName = row.name;
    //   this.sourceId = row.id;
    //   storageServer.findLogicList({data:{},params:{params3:1,params4:100}},({data,errorCode})=>{
    //     if(!errorCode){
    //       this.LogicList = data.pageData;
    //       this.exportDataModal = true;
    //     }
    //   });
    // },
    shareData(row, k) {
      let pName = row.name;
      let pId = this.sourceId;
      let gName = this.name;
      let gId = this.$route.query.id;
      let type = "share";
      if (k == "s")
        this.$router.push({
          name: "source_table_share",
          query: { name: "数据共享", type, pName, pId, gName, gId }
        });
      else
        this.$router.push({
          name: "source_table_share",
          query: { name: "数据加载", pName, pId, gName, gId }
        });
    },
    logicIdChange() {
      let data = {
        themeId: this.exportData.logicId
      };
      this.tableList = [];
      this.exportData.tableName = "";
      storageServer.findItemList(
        { data, params: { params3: 1, params4: 30 } },
        ({ data, errorCode }) => {
          if (!errorCode) {
            this.tableList = data.pageData;
            this.exportDataModal = true;
          }
        }
      );
    },
    search() {
      this.searchName = this.keyWord.name;
      this.getData();
    },
    exportTable(fileName) {
      oldServer.tablesCount(
        {
          params: {
            force: true
          },
          data: [fileName]
        },
        returnData => {
          let cum=parseInt(returnData[fileName])
          if (cum > 10000) {
            this.$Notice.error({
              title: "下载失败",
              desc: "数据量过大，下载请联系管理员"
            });
          } else if (cum > 0) {
            let sql = "select * from " + fileName+" limit 10000";
            window.open(
              "/rest/hbase/sparksql/exportTableData/" +
                fileName + "/" +Base64.encode(sql)
            );
          } else {
            this.$Notice.error({
              title: "下载失败",
              desc: "没有数据可以下载"
            });
          }
        }
      );
    },
    getData(num) {
      let data = {
        themeId: this.$route.query.id,
        name: this.searchName
      };
      this.loading.list = true;
      storageServer.findItemList(
        { data, params: { params3: num || 1, params4: 10 } },
        ({ data, errorCode }) => {
          this.loading.list = false;
          if (!errorCode) {
            this.total = data.totalCount;
            let tablenames = [];
            for (let o of data.pageData) {
              tablenames.push(o.name);
              o.findCount = 0;
            }
            this.getTableLines(tablenames);
            this.dataList = data.pageData;
          }
        }
      );
    },
    getTableLines(tablenames) {
      oldServer.tablesCount(
        {
          data: tablenames
        },
        returnData => {
          // this.linesCount = returnData;
          for (let o in returnData) {
            let name = o;
            let value = returnData[o];
            for (let it of this.dataList) {
              if (it.name == name) {
                it.findCount = value;
              }
            }
          }
        }
      );
    },
    refresh(name) {
      for (let it of this.dataList) {
        if (it.name == name) {
          it.findCount = "";
        }
      }
      oldServer.tablesCount(
        {
          params: {
            force: true
          },
          data: [name]
        },
        returnData => {
          // this.linesCount[name] = returnData[name];
          for (let it of this.dataList) {
            if (it.name == name) {
              it.findCount = returnData[name];
            }
          }
        }
      );
    },
    // findCount(name){
    //   return this.linesCount[name];
    // },
    goDetail(row) {
      this.$router.push({
        name: "source_table_detail",
        query: {
          id: row.id,
          name: row.name,
          pId: this.$route.query.id,
          pName: this.name
        }
      });
    }
  }
};
</script>

<style lang='less'>
@import "../../assets/css/variable.less";

.source_table_list {
  height: 100%;
  position: relative;
  .cz {
    a {
      margin: 0 4px;
      text-decoration: underline;
    }
  }
  .ivu-page {
    position: absolute;
    bottom: 0;
    right: 0;
  }
  .ivu-tooltip-inner {
    white-space: inherit;
  }
}
</style>
