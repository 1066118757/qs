<template>
  <div class="source_table_detail">
    <Row class="title_box">
      <Col span="12">
      <span class="h2">请输入标准SQL语句</span>
      </Col>
      <Col span="12">
      <Button type="info" style="float:right" shape="circle" @click="runSQL()">立即执行</Button>
      </Col>
      <Col span="24">
      <Input type="textarea" v-model='sqlString' style="margin:10px 0 0" :rows="2">
      </Input>
      </Col>
    </Row>
    <div style="margin-bottom:10px;">
      <Button type="ghost" icon="ios-plus-empty" @click="addModal">追加数据</Button>
      <Button type="ghost" icon="ios-upload-outline" @click="shareData">数据加载</Button>
      <Button type="ghost" icon="share" @click="shareData('s')">数据共享</Button>
      <Button type="ghost" icon="ios-download-outline" @click="exportTable()">数据导出</Button>
      <label style="float:right">显示返回前的<span style="color:#EA4124">50</span>条数据</label>
    </div>
    <Table class='tabBx' :height="height" stripe :columns="columns" :data="dataList"></Table>
    <v-modal-file-type :modal.sync="fileModal" @checked="fileChecked"></v-modal-file-type>
  </div>
</template>

<script>
import storageServer from "rs/storage";
import oldServer from "rs/oldServer";
import { Base64 } from "js-base64";
export default {
  name: "source_table_detail",
  data() {
    return {
      height: 9000,
      sqlString: "",
      name: this.$route.query.name,
      fileModal: false,
      exportDataModal: false,
      exportData: {
        logicId: "",
        tableName: ""
      },
      keyWord: {
        name: "",
        page: 1,
        pageSize: 10
      },
      total: 100,
      columns: [],
      dataList: [],
      LogicList: [],
      tableList: [],
      noadd: false
    };
  },
  created() {
    /**
     * 处理面包屑
     * */
    let pId = this.$route.query.pId,
      pName = this.$route.query.pName;
    this.$store.commit("setCrumbs", [
      { text: "数据管理", query: {}, name: "storageSource" },
      {
        text: pName,
        query: { name: pName, id: pId },
        name: "source_table_list"
      },
      { text: this.name, query: {} }
    ]);
    this.sqlString = "select * from " + this.name;
    this.getData();
    this.height = parseInt(
      this.$store.state.setTableHeight(330).height.split("px")[0]
    );
  },
  methods: {
    exportModal() {
      storageServer.findLogicList(
        { data: {}, params: { params3: 1, params4: 100 } },
        ({ data, errorCode }) => {
          if (!errorCode) {
            this.LogicList = data.pageData;
            this.exportDataModal = true;
          }
        }
      );
    },
    exportTable() {
      let fileName = this.name;
      let sql = this.sqlString;
      window.open(`/rest/hbase/sparksql/exportTableData/${fileName}/${Base64.encode(sql)}`);
      this.$Notice.info({
        title: "注意",
        desc: "下载数据最多能下载1万条，如果需要下载更多，请联系管理员"
      });
    },
    logicIdChange() {
      let data = {
        themeId: this.exportData.logicId
      };
      this.tableList = [];
      this.exportData.tableName = "";
      storageServer.findItemList(
        { data, params: { params3: 1, params4: 30 } },
        ({ data, errorCode }) => {
          if (!errorCode) {
            this.tableList = data.pageData;
            this.exportDataModal = true;
          }
        }
      );
    },
    getData() {
      oldServer.sparksqlQuery(
        {
          data: {
            limit: 50,
            tableName: "default." + this.name
          },
          params: {}
        },
        (data, errorCode) => {
          if (!errorCode) {
            this.tableMainData = data;
            this.setTable();
          }
        }
      );
    },
    runSQL() {
      let sql = this.sqlString;
      oldServer.executeSql(
        {
          data: { sql },
          params: {}
        },
        (data, errorCode) => {
          if (!errorCode) {
            this.tableMainData = data;
            let temp = this.noadd;
            this.setTable();
            this.noadd = temp;
          }
        }
      );
    },
    setTable() {
      console.log(this.tableMainData);
      if (this.tableMainData.columnInfos.length == 0) {
        this.$Notice.info({ desc: "该表未创建字段", title: "提示" });
        this.noadd = true;
      } else if (this.tableMainData.RowDataSet.length == 0) {
        this.$Notice.info({ desc: "该表还没有数据", title: "提示" });
      }
      let data = JSON.parse(JSON.stringify(this.tableMainData));
      // 表头设置=========
      let newHead = [],
        headIndex = [];
      data.columnInfos.forEach((ob, i) => {
        ob.render = (h, params) => {
          let str =
            params.row[i].length > 20
              ? params.row[i].substring(0, 20) + "..."
              : params.row[i];
          if (params.row[i].length > 20) {
            return h("Tooltip", { placement: "top" }, [
              h("span", str),
              h("div", { slot: "content" }, params.row[i])
            ]);
          } else {
            return h("span", str);
          }
        };
        ob.width = 150;
        ob.title = ob.columnName;
        newHead.push(ob);
      });
      this.columns = newHead;

      //  设置显示表数据=======
      let newData = [];
      data.RowDataSet.forEach(arr => {
        let json = {};
        arr.forEach((item, i) => {
          json[i] = item;
        });
        newData.push(json);
      });
      this.dataList = newData;
    },
    addModal() {
      if (this.noadd) {
        this.$Notice.error({
          desc: "该表未创建字段,无法追加数据",
          title: "无效操作"
        });
        return;
      }
      this.fileModal = true;
    },
    shareData(k) {
      let pName = this.name;
      let pId = this.$route.query.id;
      let gName = this.$route.query.pName;
      let gId = this.$route.query.pId;
      let sql = Base64.encode(this.sqlString);
      let type = "share";
      if (this.noadd) {
        this.$Notice.error({
          desc: "当前查询没有字段,无法加载或共享",
          title: "无效操作"
        });
        return;
      }
      if (k == "s") {
        this.$router.push({
          name: "source_table_share",
          query: { name: "数据共享", type, pName, pId, gName, gId, sql }
        });
      } else
        this.$router.push({
          name: "source_table_share",
          query: { name: "数据加载", pName, pId, gName, gId, sql }
        });
    },
    fileChecked(s) {
      let pName = this.name;
      let pId = this.$route.query.id;
      let gName = this.$route.query.pName;
      let gId = this.$route.query.pId;
      this.$router.push({
        name: "source_table_add_data",
        query: { name: "追加数据", type: s, pName, pId, gName, gId }
      });
    }
  }
};
</script>

<style lang='less'>
@import "../../assets/css/variable.less";

.source_table_detail {
  height: 100%;
  position: relative;
  .h2 {
    font-size: 14px;
    color: rgba(74, 75, 80, 1);
  }
  .cz {
    a {
      margin: 0 4px;
      text-decoration: underline;
    }
  }
  .ivu-page {
    position: absolute;
    bottom: 0;
    right: 0;
  }
  .tabBx {
    height: 100%;
    overflow: hidden;
    // .ivu-table-wrapper{ border: none !important;}
    .ivu-table-header {
      height: 50px !important;
    }
  }
  .ivu-tooltip-inner {
    white-space: inherit;
  }
}
</style>
