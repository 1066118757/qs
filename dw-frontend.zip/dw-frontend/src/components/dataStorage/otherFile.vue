<template>
  <div class="storage_img">
    <Row class="title_box">
      <i-col span="12">
      <span class="h1">文件数据列表</span>
      </i-col>
      <i-col span="12" style="text-align: right">
        <Input v-model="keyWord.name" style="width: 200px;" placeholder="输入文件标题进行模糊查询"></Input>
        <Button type="ghost" @click="search">查询</Button>
        <Button icon="plus" type="info" size="large" shape="circle" @click="newImgModalShow()">上传文件</Button>
      </i-col>
    </Row>
    <Row class="main_list" :gutter="10">
      <i-col :xs="12" :sm="8" :md="8" :lg="6" v-for="(item,index) in listData" :key="index">
        <div>
          <h2 class="title">
							<span style="cursor:pointer;">{{item.name}}</span>
							<Icon style="float:right;margin-left:10px;" type="trash-a" color="#C4D6E6" size="14" @click.native="delItem = item.id;affirm = true"></Icon>
							<!-- <Icon style="float:right;" type="edit" color="#C4D6E6" size="14" @click.native="editItem(item.id)" ></Icon> -->
          </h2>
          <div class="clearfix">
            <div style="height:100px; overflow:hidden;">
              <img :src="'/v1/file/download/'+item.fileId+'?Authorization='+authorization" style="width:100%;" alt="">
            </div>
            <div class="le">
              <Icon type="person"></Icon>
              {{item.uploadUserName}}
            </div>
            <div class="ri">
              <Icon type="calendar"></Icon>
              {{item.uploadTime|date}}
            </div>
          </div>
          <p>{{item.introduction | stringCut(35)}}</p>
        </div>
      </i-col>
    </Row>
    <Page
      :total="total"
      show-elevator
      show-total
      placement="top"
      @on-change="pageChange"
    ></Page>
    <!-- modal -->
    <Modal
      v-model="newModal"
      title="上传文件"
      width="600"
      class="no_footer">
				<div style="text-align:center;">
          <Upload
            action=""
            style="margin:0 auto 18px;width: 80px;color: #4AB9FF;text-align: center"
            :before-upload="beforeUpload"
            :show-upload-list="false"
            >
            <div style="text-align: center;cursor: pointer">
              <p>
                <Icon type="ios-plus-outline" size="50"></Icon>
              </p>
              <p>{{uploadText}}</p>
            </div>
          </Upload>
          <p style="margin-bottom: 6px">已选取的文件:</p>
          <div style="width:300px; border: 1px solid #e0e0e0;padding:3px; color:#797979; margin:5px auto;">{{fileObj.name||"还未选择文件"}}</div>
				</div>
        <Form ref="newImg" :model="newImg" :rules="newImgRules" :label-width="80" style="margin-top:30px">
          <FormItem label="文件标题" prop="name">
              <Input v-model="newImg.name" placeholder="输入标题"></Input>
          </FormItem>
          <FormItem label="文件描述"  prop="summary">
              <Input type="textarea" v-model="newImg.introduction" placeholder="输入描述"></Input>
          </FormItem>
        </Form>
				<div style="text-align:center; margin-top:20px; margin-bottom:50px;">
          <Button type="ghost" style="width: 130px" @click="newModal = false">取消</Button>
          <Button type="primary" style="width: 130px" @click="addSubmit" :loading="loading.modalBtn">提交</Button>
				</div>
    </Modal>
	  <v-affirm :model.sync="affirm" :del="true" @click="deleteItem"></v-affirm>
  </div>
</template>

<script>
import storageServer from "rs/storage";
export default {
  props: {},
  data() {
    return {
      total: 0,
      delItem: "",
      authorization: sessionStorage.getItem("access_token"),
      affirm: false,
      keyWord: {
        name: ""
      },
      fileObj: {},
      uploadText: "选择文件",
      newModal: false,
      loading: {
        list: false,
        modalBtn: false
      },
      newImg: {
        name: "",
        introduction: ""
      },
      fileType: {
        text: "image",
        reg: /\.(png|jpg|bmp|jpeg)$/,
        reg1: /\.(mp4|MP4|Mp4|mP4)$/,
        desc: "请选择非图片或者视频文件！"
      },
      listData: [],
      newImgRules: {}
    };
  },
  created() {
    /**
     * 处理面包屑
     * */
    this.$store.commit("setCrumbs", [
      { text: "文件数据管理", query: {}, name: "otherFile" }
    ]);
    this.getData();
  },
  directives: {},
  computed: {},
  filters: {},
  methods: {
    pageChange(num) {
      this.getData(num);
    },
    search() {
      this.searchName = this.keyWord.name;
      this.getData();
    },
    getData(num) {
      let data = {
        type: 2,
        name: this.searchName
      };
      this.loading.list = true;
      storageServer.storageManageList(
        { data, params: { params3: num || 1, params4: 10 } },
        ({ data, errorCode }) => {
          this.loading.list = false;
          if (!errorCode) {
            this.listData = data.pageData;
            this.total = data.totalCount;
          }
        }
      );
    },
    deleteItem() {
      this.affirm = false;
      storageServer.storageManageDelete(
        { data: {}, params: { id: this.delItem } },
        ({ data, errorCode }) => {
          this.loading.list = false;
          if (!errorCode) {
            this.delItem = "";
            this.getData();
          }
        }
      );
    },
    newImgModalShow() {
      this.newImg.name = "";
      this.newImg.introduction = "";
      this.uploadText = "选择文件";
      this.fileObj = {};
      this.newModal = true;
    },
    beforeUpload(file) {
      let fileType = this.fileType;
  
      if (fileType.reg.test(file.name)) {
        this.$Notice.error({ title: "操作失败", desc: fileType.desc });
        return false;
      }
      if (fileType.reg1.test(file.name)) {
        this.$Notice.error({ title: "操作失败", desc: fileType.desc });
        return false;
      } 
      

      this.uploadText = "重新选择";
      this.fileObj = file;
      return false;
    },
    addSubmit() {
      let fileObj = this.fileObj;
      if (!fileObj.name) {
        this.$Notice.error({ title: "请选择要上传文件！" });
        return;
      }
      this.loading.modalBtn = true;
      let formData = new FormData();
      formData.append(fileObj.name, fileObj);
      formData.append("name", this.newImg.name);
      formData.append("type", 2);
      formData.append("introduction", this.newImg.introduction);
      storageServer.storageManageUpload(
        { data: formData },
        ({ data, errorCode, msg }) => {
          this.loading.modalBtn = false;
          if (errorCode) {
            this.$Notice.error({ title: "上传失败", desc: msg });
            return;
          }
          this.$Notice.success({ title: "上传成功", desc: msg });
          this.newModal = false;
          this.getData();
        }
      );
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
.main_list {
  .ivu-col > div {
    border: 1px solid #ededed;
    margin-bottom: 10px;
    padding: 17px;
    height: 230px;
    font-size: 12px;
    &:hover {
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      cursor: pointer;
    }
    h2 {
      font-size: 16px;
      margin-bottom: 10px;
      height: 20px;
    }
    .ivu-icon {
      color: #4ab9ff;
    }
    .le {
      float: left;
    }
    .ri {
      float: right;
    }
    p {
      margin-top: 4px;
    }
  }
  .ivu-col {
    min-width: 300px;
  }
}
.storage_img {
  height: 100%;
  position: relative;
  .ivu-page {
    position: absolute;
    bottom: 0;
    right: 0;
  }
}
</style>
