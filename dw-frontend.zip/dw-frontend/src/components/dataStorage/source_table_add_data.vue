<template>
  <div class="source_table_add_data">
    <v-steps :data="steps" :step="step"></v-steps>

    <div class="step" v-if="step==1" style="width:360px;margin: 30px auto;">
      <Upload
        action="//jsonplaceholder.typicode.com/posts/"
        style="margin: 37px auto 18px;width: 80px;color: #4AB9FF;text-align: center"
        :before-upload="beforeUpload"
        :show-upload-list="false"
        >
        <div style="text-align: center;cursor: pointer">
          <p>
            <Icon type="ios-plus-outline" size="50"></Icon>
          </p>
          <p>{{uploadText}}</p>
        </div>
      </Upload>
      <p style="margin-bottom: 6px">已选取的文件:</p>
      <div style="border: 1px solid #e0e0e0;padding:3px; color:#797979; margin-bottom:5px;">{{fileObj.name||"还未选择文件"}}</div>
      <div style="text-align:center;margin-top:30px;">
          <!-- <Button type="ghost" style="width: 130px" >返回</Button> -->
          <Button type="primary" style="width: 130px" @click="upload()" >下一步</Button>
      </div>
    </div>
    <div class="step" v-if="step==2" style="width:360px;margin: 30px auto;">
      <vFieldMap :from="sourceTableFiledList" :to="distFiledList" :value="fileMapList" @change="array=>fileMapList = array"></vFieldMap>
      <div style="text-align:center;margin: 30px auto;">
          <Button type="ghost" style="width: 130px"  @click="step--">上一步</Button>
          <Button type="primary" style="width: 130px" @click="getDataPreivew" >下一步</Button>
      </div>
    </div>
    <div class="step" v-if="step==3">
      <div style="text-align:center;margin:15px 0 ;">
          <Button type="ghost" style="width: 130px"  @click="step--" :loading="loading.submitBtn">上一步</Button>
          <Button type="primary" style="width: 130px" @click="addSubmit()" :loading="loading.submitBtn" >确定提交</Button>
      </div>
       <Table  v-if="step==3" :columns="columns" :data="dataList"></Table>
    </div>
    <div class="step" v-if="step==4" style="margin: 50px auto;">
      <v-done>
        <p>恭喜你操作成功！</p>
        <p><span v-text="djs" class="num" style="margin-right: 4px"></span>秒后将会返回<router-link :to="{name:'etl'}" class="link" @click.native="_clearInterval(intervalId)">数据表页面</router-link></p>
      </v-done>
      <div style="text-align:center;margin-top: 20px">
          <Button type="primary" style="width: 130px" @click="goBack" >立即返回</Button>
      </div>
    </div>
  </div>
</template>

<script>
import storageServer from "rs/storage";
import vFieldMap from "cmpts/common/fieldMap"
import oldServer from  "rs/oldServer"
import vDone from "cmpts/common/done"
  export default {
    name: 'source_table_add_data',
    data () {
      return {
        name: this.$route.query.name,
        steps:['上传文件',"字段选择","数据预览","结束"],
        fileObj:{},
        uploadText:"选择文件",
        fileType:undefined,
        step:1,
        djs:5,
        intervalId:'',
        loading:{
         submitBtn:false,
        },
        redisKey:undefined,
        sourceTableFiledList:[],
        distFiledList:[],
        fileMapList:[],
        columns:[],
        dataList:[],
        noticeFlag:true,
        whileTime:""
      }
    },
    components:{vFieldMap,vDone},
    destroyed(){
      if(this.whileTime) clearTimeout(this.whileTime);
      this.$Notice.close("noticeFlag");
      if(this.intervalId)clearInterval(this.intervalId);
    },
    created() {
      /**
       * 处理面包屑
       * */
      let pName = this.$route.query.pName;
      let pId = this.$route.query.pId;
      let gName = this.$route.query.gName;
      let gId = this.$route.query.gId;
      this.$store.commit('setCrumbs', [
        {text: "数据管理", query: {}, name: "storageSource"},
        {text: gName, query: {name:gName,id:gId},name: "source_table_list"},
        {text: pName, query: {name:pName,id:pId,pName:gName,pId:gId},name: "source_table_detail"},
        {text: this.name, query: {}},
      ]);
      //文件类型判定
      let type = this.$store.state.connect.fileType.find(l=>l.key === +this.$route.query.type);
      if(!type)this.$Notice.error({title:"文件类型错误",desc:"暂不支持该类型文件"});
      this.fileType = type;
      this.getCols();
    },
    methods: {
      _clearInterval(id){clearInterval(id)},
      getCols() {
        storageServer.queryDistTableFilelds({
          params:{
          tableName:this.$route.query.pName
        }},({data,errorCode})=>{
          if(!errorCode){
            this.distFiledList = data[0].fields;
          }
        });
      },
      beforeUpload(file) {
        let fileType = this.fileType;
        if(!fileType.reg.test(file.name)){
          this.$Notice.error({title:"操作失败",desc:fileType.desc});
          return false;
        }
        this.uploadText = "重新选择";
        this.fileObj = file;
        return false;
      },
      upload(){
        let fileObj = this.fileObj;
        if(!fileObj.name){
          this.$Notice.error({title:"请选择要上传文件！"});
          return;
        }
        let formData = new FormData();
         formData.append(fileObj.name,fileObj);
          this.loading.submitBtn = true;
        storageServer.findUpload({data:formData},({data,errorCode,msg})=>{
          this.loading.submitBtn = false;
          if(errorCode){
            this.$Notice.error({title:"上传失败",desc:msg});
            return;
          }
          this.$Notice.success({title:"上传成功",desc:msg});
          this.step ++;
          this.redisKey = data.dataKey;
          this.sourceTableFiledList = data.header.map(l=>({fieldName:l}));
        });
      },
      getDataPreivew(){
          if(this.fileMapList.length<this.distFiledList.length){
            this.$Notice.error({title:"违规操作",desc:"目标表字段映射不完整！"});
            return;
          }
          this.loading.submitBtn = true;
          storageServer.findFileData({params:{redisKey:this.redisKey}},({data,errorCode,msg})=>{
            this.loading.submitBtn = false;
            if(errorCode){
              this.$Notice.error({title:"获取预览失败",desc:msg});
              return;
            }
            this.step++;
            let columns = [];
            let header = data[0];
            for(let index in header){
              for(let o of this.fileMapList){
                if(header[index] == o.source){
                  columns.push({
                    title:o.dist,
                    key: index,
                    index
                  })
                }
              }
            }
            data.splice(0,1);
            let dataList= data.map((item)=>{
              let r={};
              for (let i in item){
                r[i] = item[i]
              }
              return r;
            })
            this.columns = columns;
            this.dataList = dataList;
          })
      },
      addSubmit(){
        let data = {
          columnMappingVoList: this.fileMapList,
          redisKey:this.redisKey,
          tableName:this.$route.query.pName
        }
        this.loading.submitBtn = true;
        storageServer.additional({data},({data,errorCode,msg})=>{
          if(errorCode){
            this.$Notice.error({title:"提交失败",desc:msg});
            return;
          }
          this.whileResult(data);
        });
      },
      whileResult(redisKey){
        storageServer.getResult({params:{redisKey}},({data,errorCode,msg})=>{
          if(errorCode==1000){
            if(this.noticeFlag){
              this.noticeFlag = false;
              this.$Notice.info({title:"waiting",desc:"数据正在载入，请稍等！",name:"noticeFlag",duration: 0});
            } 
            this.whileTime = setTimeout(()=>{
              this.whileResult(redisKey);
            },3000) 
            return
          }
          else if(errorCode==0){
            this.noticeFlag = true;
            this.$Notice.close("noticeFlag")
            this.loading.submitBtn = false;
            this.step ++;
            this.intervalId = setInterval(()=>{
              this.djs --;
              if(this.djs)return;
              clearInterval(this.intervalId);
              this.goBack()
              this.djs = 5;
            },1000);
          }
          else{
            this.noticeFlag = true;
            this.$Notice.close("noticeFlag")
            this.loading.submitBtn = false;
            this.$Modal.error({title:"追加失败",content:'发生错误：'+msg});
            return;
          }
        });
      },
      goBack(){
        let pName = this.$route.query.pName;
        let pId = this.$route.query.pId;
        let gName = this.$route.query.gName;
        let gId = this.$route.query.gId;
        this.$router.push({ query: {name:pName,id:pId,pName:gName,pId:gId},name: "source_table_detail"});
      }

    }
  }
</script>

<style lang='less'>
  @import "../../assets/css/variable.less";

  .source_table_add_data {height: 100%; position: relative;
    .h2{
      font-size:14px;
      color:rgba(74,75,80,1);
    }
    .cz{
      a{ margin: 0 4px; text-decoration: underline;}
    }
    .ivu-page{ position: absolute; bottom: 0; right: 0;}
  }
</style>
