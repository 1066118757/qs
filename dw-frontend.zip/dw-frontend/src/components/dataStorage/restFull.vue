<template>
  <div class="rest_fullc">
    <Row class="title_box">
      <i-col span="12">
      <span class="h1">接口管理</span>
      </i-col>
    </Row>
    <div style="text-align: center; margin-top: 150px; color: #999;">开发中...</div>
    <iframe src="" frameborder="0"></iframe>
</div>
</template>

<script>
export default {
  props: {},
  data() {
    return {
     
    };
  },
  created() {
  
  },
  directives: {},
  computed: {},
  filters: {},
  methods: {
    
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
.rest_fullc {
  height: 100%;
}
</style>
