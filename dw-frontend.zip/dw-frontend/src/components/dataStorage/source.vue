<template>
  <div class="storage_source">
    <Row class="title_box">
      <Col span="12">
      <span class="h1">逻辑分区列表</span>
      </Col>
      <Col span="12" style="text-align: right">
      <Input v-model="keyWord.name" style="width: 200px;" placeholder="输入逻辑分区进行模糊查询"></Input>
      <Button type="ghost" @click="search">查询</Button>
      </Col>
    </Row>
    <Row  type="flex" class="main_list code-row-bg" :gutter="10">
      <Col :xs="12" :sm="8" :md="8" :lg="6" v-for="(item,index) in listData" :key="index">
        <div @click="goTableList(item)">
          <h2 class="overflow">{{item.name}}</h2>
          <div class="clearfix">
            <div class="le">
              <Icon type="person"></Icon>
              {{item.createUserName}}
            </div>
            <div class="ri">
              <Icon type="calendar"></Icon>
              {{item.createTime |date}}
            </div>
          </div>
          <p>{{item.remark | stringCut(35)}}</p>
        </div>
      </Col>
    </Row>
    <Page
      :total="total"
      show-elevator
      show-total
      placement="top"
      @on-change="pageChange"
    ></Page>
  </div>
</template>

<script>
import storageServer from "rs/storage"
export default {
  props:{
  },
	data() {
    return {
      total:0,
      keyWord: {
        name:''
      },
      listData:[
      ],
      loading:{
        list:false,
      },
      searchKey:""
    }
	},
	created() {
    /**
     * 处理面包屑
     * */
    this.$store.commit('setCrumbs',[
      {text:"数据管理",query:{},name:"storageSource"},
    ]);
    // 查询数据
    this.getData();
	},
	directives: {

	},
	computed: {

	},
	filters: {
	},
	methods: {
    pageChange(c) {
      this.getData(c);
    },
    search(){
      this.searchKey = this.keyWord.name;
      this.getData(); 
    },
    getData(num) {
      let name = this.searchKey;
      this.loading.list = true;
      storageServer.findLogicList({data:{name},params:{params3:num||1,params4:16}},({data,errorCode})=>{
				this.loading.list = false;
				if(!errorCode){
					this.listData = data.pageData;
					this.total = data.totalCount;
				}
			});
    },
    goTableList:function (item) {
      this.$router.push({name:"source_table_list",query:{id:item.id,name:item.name}})
    }

	}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
  .main_list{
    .ivu-col>div{ border: 1px solid #ededed; margin-bottom: 10px; padding: 17px; height:130px;
      font-size: 12px;
      &:hover{ box-shadow: 0 0 10px rgba(0,0,0,0.1); cursor: pointer;}
       h2{ font-size: 16px; margin-bottom: 10px; height: 20px;}
       .ivu-icon{ color:#4AB9FF; }
      .le{ float: left;}
      .ri{ float: right;}
      p{ margin-top: 4px;}
    }
  .ivu-col{ min-width: 300px;}

  }
  .storage_source{ height: 100%; position: relative;
    .ivu-page{ position: absolute; bottom: 0; right: 0;}
  }
</style>
