<template>
  <h3>我是 dataAnalysisMining 组件</h3>
</template>

<script>
export default {
  props:{
  },
	data() {
    return {
    }
	},
	created() {
	},
	directives: {

	},
	computed: {

	},
	filters: {
	},
	methods: {

	}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
</style>
