<template>
  <div class="meta_item_details_container">
    <v-header text="主体信息">
      <Button type="primary" shape="circle" style="float: right" @click="downloadModal = true">导出数据结构</Button>
    </v-header>
    <Table :columns="columns" :data="data" :loading="loading" :height="$store.state.screenHeight - 274"></Table>
    <Page
      :total="total"
      show-elevator
      show-total
      placement="top"
      @on-change="init"
    ></Page>
    <Modal
      v-model="downloadModal"
      title="选择下载文件类型"
      width="400"
      style="text-align: center;"
      class="no_footer">
      <p style="margin-bottom: 20px">
        <a class="download_btn" :href='"/v1/metaItemDetail/exportData?metadataItemId="+id+"&fileType=0&Authorization="+session.get("access_token")'>导出为csv文件</a>
      </p>
      <p style="margin-bottom: 50px">
        <a class="download_btn" :href='"/v1/metaItemDetail/exportData?metadataItemId="+id+"&fileType=1&Authorization="+session.get("access_token")'>导出为Excel文件</a>
      </p>
    </Modal>
  </div>
</template>

<script>
  import metaServer from "rs/meta"
  import Vue from "vue"
export default {
  props:{
  },
	data() {
    return {
      data:[{colType:301}],
      columns:[
        {
          title:"序号",
          key:"index"
        },
        {
          title:"字段别名",
          key:"colDisplayname"
        },
        {
          title: '字段类型',
          key: 'colType',
          render(h,{row:{colType}}){
            return h("span",Vue.filter("formatterMetaItemType")(colType))
          }
        },
        {
          title:"字段含义",
          key:"colComment"
        },
        {
          title:"字段名",
          key:"colName"
        },
      ],
      total:0,
      loading:false,
      downloadModal:false,
      id:undefined
    }
	},
	created() {
    let query = this.$route.query;
    let isWork = +this.session.get("is_work");
    let text = this.session.get("theme_name"),
      id = this.session.get("theme_first_id"),
      meta_id = this.session.get("meta_id"),
      item_id = query.id;
    this.id = item_id;
    this.$store.commit('setCrumbs',[
      {text:text,query:{id:id},name:"metaWorkList"},
      {text:isWork?"业务元数据":"任务元数据",query:{id:meta_id},name:isWork?"metaWorkList":"metaTaskList"},
      {text:"主体信息",name:"metaItemDetails",query:{id:item_id}}
    ]);
    this.init();
	},
	directives: {

	},
	computed: {

	},
	filters: {
	},
	methods: {
    init(num){
      this.loading = true;
      metaServer.getMetaItemDetailsList({
        params:{params3:num||1,params4:this.$store.getters.minTableColumns},
        data:{
          metadataItemId:+this.$route.query.id
        }
      },({data})=>{
        this.loading = false;
        this.data = data.pageData;
        this.total = data.totalCount
      });
    }
	}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
  .meta_item_details_container{
    position: relative;
    padding-bottom: 42px;
  }
  .ivu-page{
    position: absolute;
    right: 30px;
    bottom:0;
  }
  a.download_btn{
    width: 130px;
    height: 32px;
    line-height: 30px;
    display: inline-block;
    border:@border;
    border-radius: 16px;
    transition: all .2s linear;
    &:hover{
      color:@primary-color;
      border-color:@primary-color;
      text-decoration: none;
    }
  }
</style>
