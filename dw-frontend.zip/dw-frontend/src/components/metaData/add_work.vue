<template>
  <div class="add_meta_container">
    <v-steps :step="step"></v-steps>
    <keep-alive>
      <div class="first" v-if="step === 1">
        <Form ref="form" :model="form" :rules="rule" :label-width="90" class="font_size_14">
          <FormItem prop="name" label="数据表名:">
            <Input v-model="form.name" placeholder="请输入数据表名（最多30个字）" style="width: 280px" :disabled="!!editId"/>
          </FormItem>
          <FormItem prop="type" label="元数据类型:">
            <Select v-model="form.type" style="width:280px">
              <Option v-for="item in $store.state.meta.metaType" :value="item.key" :key="item.key">{{ item.text }}</Option>
            </Select>
          </FormItem>
          <FormItem prop="purpose" label="元数据描述:" style="margin-bottom:80px">
            <Input type="textarea" v-model="form.purpose" :rows="4" style="width: 280px;" placeholder="最多100个字"/>
          </FormItem>
          <FormItem>
            <Button class="height40" type="ghost" @click="$router.go(-1)">返回</Button>
            <Button class="height40" type="primary" @click="firstStep">下一步</Button>
          </FormItem>
        </Form>
      </div>
      <div class="second" v-else-if="step === 2">
        <p class="btn_wrapper">
          <Upload
            style="display: inline-block;margin-right: 10px"
            action="/v1/metaItemDetail/upload"
            :headers="{Authorization:'Bearer '+ session.get('access_token')}"
            :show-upload-list="false"
            :before-upload="beforeUpload"
            :on-success="uploadSuccess">
            <Button type="ghost" shape="circle" style=""  icon="ios-plus-empty">上传EXCEL</Button>
          </Upload>
          <Button type="ghost" shape="circle" style=""  icon="ios-plus-empty" @click="addItem" :disabled="disabledAddBtn">添加字段</Button>
        </p>
        <div class="table" :style="{minHeight:$store.state.screenHeight - 381 + 'px'}">
          <table>
            <thead>
            <tr>
              <th>序号</th>
              <th>字段别名</th>
              <th>字段类型</th>
              <th>字段含义</th>
              <th>字段名</th>
              <th style="text-align: center">操作</th>
            </tr>
            </thead>
            <tbody>
            <tr v-for="(item,index) in detailAddVoList" :key="index" :class="{isEdit:item.active,hasEmpty:item.hasEmpty}">
              <td>
                <span v-text="item.index" style="width: 60px;display: inline-block"></span>
                <!--<InputNumber :min="1" :max="999" v-model="item.index" style="width: 60px;"></InputNumber>-->
              </td>
              <td>
                <span v-text="item.colDisplayname"></span>
                <Input v-model="item.colDisplayname" :maxlength="20" placeholder="最多20字"/>
                <div class="max_length" :class="{full:(item.colDisplayname || '').length === 20}">{{(item.colDisplayname || '').length + "/" + 20}}</div>
              </td>
              <td>
                <span class="type">{{item.colType | formatterMetaItemType}}</span>
                <Select v-model="item.colType">
                  <Option v-for="item in $store.state.meta.metaItemType" :value="item.key" :key="item.key">{{ item.text }}</Option>
                </Select>
              </td>
              <td>
                <span v-text="item.colComment"></span>
                <Input v-model="item.colComment" :maxlength="50" placeholder="最多50字"/>
                <div class="max_length" :class="{full:(item.colComment||'').length === 50}">{{(item.colComment||'').length + "/" + 50}}</div>
              </td>
              <td>
                <span v-text="item.colName"></span>
                <Input v-model="item.colName" :maxlength="30" placeholder="最多30字"/>
                <div class="max_length" :class="{full:(item.colName || '').length === 30}">{{(item.colName || '').length + "/" + 30}}</div>
              </td>
              <td>
                <Icon type="checkmark" v-if="item.active" @click.native="item.active = !item.active" title="保存">
                </Icon><Icon type="edit" v-else @click.native="item.active = !item.active" title="编辑">
              </Icon><Icon type="trash-a" @click.native="delItem(index)" title="删除"></Icon>
              </td>
            </tr>
            </tbody>
          </table>
        </div>
        <div class="footer">
          <Button class="height40" type="ghost" @click="next(-1)">上一步</Button>
          <Button class="height40" type="primary" @click="secondStep">下一步</Button>
        </div>
      </div>
      <div class="third" v-else>
        <div class="table" :style="{minHeight:$store.state.screenHeight - 338 + 'px'}">
          <table>
            <thead>
            <tr>
              <th>序号</th>
              <th>字段名</th>
              <th>字段类型</th>
              <th>字段含义</th>
              <th>原始字段</th>
            </tr>
            </thead>
            <tbody>
            <tr v-for="(item,index) in detailAddVoList" :key="index">
              <td v-text="item.index"></td>
              <td v-text="item.colDisplayname"></td>
              <td>{{item.colType | formatterMetaItemType}}</td>
              <td v-text="item.colComment"></td>
              <td v-text="item.colName"></td>
            </tr>
            </tbody>
          </table>
        </div>
        <div class="footer">
          <Button class="height40" type="ghost" @click="next(-1)">上一步</Button>
          <Button class="height40" type="primary" @click="done">完成</Button>
        </div>
      </div>
    </keep-alive>
  </div>
</template>

<script>
  import metaServer from "rs/meta"
export default {
  props:{
  },
	data() {
    let validateLength = this.$store.state.validateLength;
    return {
      step:1,
      form:{
        "detailAddVoList": [],
        "name": "",
        "purpose": "",
        "type":undefined,
        "themeItemId": +this.$route.query.id,
        id:undefined
      },
      detailAddVoList:[],
      rule:{
        name:{ validator: validateLength(30), trigger: 'blur' },
        type:{ validator: validateLength(), trigger: 'change' },
        purpose:{ validator: validateLength(100), trigger: 'blur' },
      },
      metaTypeList:[],
      addType:1,
      data:[],
      editId:undefined
    }
	},
	created() {
    /**
     * 处理面包屑
     * */
    let query = this.$route.query;
    let isWork = +this.session.get("is_work");
    let editId = query.editId;this.editId = editId;
    let text = this.session.get("theme_name"),meta_id = this.session.get("meta_id"),id = this.session.get("theme_first_id"),item_id = query.id;
    this.$store.commit('setCrumbs',[
      {text:text,query:{id:id},name:"metaWorkList"},
      {text:isWork?"业务元数据":"任务元数据",query:{id:meta_id},name:isWork?"metaWorkList":"metaTaskList"},
      {text:editId?"编辑元数据":"添加元数据",name:"metaAddWork",query:{id:item_id,editId}}
    ]);
    /**
     * 编辑代码
     * */
    if(editId){
      metaServer.getMetaItemDetails({params:{id:editId}},({data:{name,purpose,type}})=>{
        let form = this.form;
        form.name = name;
        form.purpose = purpose;
        form.type = type;
        form.id = editId;
      });
      metaServer.getMetaItemDetailsList({
        params:{params3:1,params4:99999},
        data:{
          metadataItemId:+editId
        }
      },({data})=>{
        data.pageData.forEach(l=>l.active = false);
        this.detailAddVoList = data.pageData;
      });
    }
	},
	directives: {

	},
	computed: {
    disabledAddBtn(){
      return this.form.type === 202 && this.detailAddVoList.length >= 2
    }
	},
	filters: {
	},
	methods: {
    next(num){
      this.step += num;
    },
    delItem(num){
      this.detailAddVoList.splice(num,1);
    },
    firstStep(){
      this.$refs.form.validate(f=>f&&this.next(1));
    },
    secondStep(){
      let array = this.detailAddVoList,flag = false;
      if(!array.length){
        this.$Notice.error({
          title:"请先添加数据字段"
        });
        return;
      }
      if(this.form.type === 202 && array.length >2){
        this.$Notice.error({
          title:"添加数据字段失败",
          desc:"数据字典类型的元数据只能添加2条数据字段！"
        });
        return;
      }
      for(let i = 0;i<array.length;i++){
        for(let j in array[i]){
          let o = array[i];
//          if(j === "colName")
//          break;
          if(o[j] === ""){
            flag = true;
            o.active = true;
            break;
          }
        }
      }
      if(flag){
        this.$Notice.error({
          title:"请先完善字段信息"
        });
        return;
      }
      this.next(1);
    },
    done(){
      let form = this.form;
      form.detailAddVoList = this.detailAddVoList.map(({colComment,colDisplayname,colName,colType,index})=>({colComment,colDisplayname,colName,colType,index}));
      let server = "addMetaItem",text = "新增";
      if(this.editId){
        server = "editMetaItem";text = "编辑";
      }
      metaServer[server]({data:form},({data,errorCode})=>{
        if(errorCode){
          this.$Notice.error({
            title:text+"元数据失败！",
            desc:data
          });
          return;
        }
        this.$Notice.success({
          title:text+"元数据成功！"
        });
        this.$router.go(-1);
      });
    },
    addItem(){
      let array = this.detailAddVoList;
      array.push({
        "colComment": "",
        "colDisplayname": "",
        "colName": "",
        "colType": 301,
        "index":array.length+1,
//        "metadataItemId": this.itemId,
        "active":true,
//        "hasEmpty":false,
      });
    },
    beforeUpload({name}){
      let flag = /\.(?:csv|xls|xlsx)$/i.test(name);
      if(!flag){
        this.$Notice.error({
          title:"上传失败",
          desc:"请选择.csv/xls/xlsx类型的文件上传！"
        });
      }
      return flag;
    },
    uploadSuccess({data,errorCode,msg}){
      this.$Notice.success({
        title:"上传文件成功！"
      });
      if(errorCode){
        this.$Notice.error({
          title:"解析文件失败",
          desc:msg
        });
        return;
      }
      this.$Notice.success({
        title:"解析文件成功"
      });
      let array = data[0].voList;
      let target = this.detailAddVoList,num = target.length;
      array.forEach(l=>{
        l.active = false;
//        l.hasEmpty = false;
        l.colType = +l.colType;
        l.colDisplayname = l.colDisplayName;
        l.index = ++num;
      });
      this.detailAddVoList = target.concat(array);
    }
	}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
  .add_meta_container{
    .height40{
      width: 130px;
      line-height: 24px;
      height:40px;
      font-size: 14px;
      &:nth-of-type(1){
        margin-right: 16px
      }
    }
    .first{
      width: 370px;
      margin: 82px auto 0;
    }
    .second{
      text-align: center;
      border-top:@border;
      padding-top: 20px;
      .btn_wrapper{
        text-align: right;
        .ivu-btn{
          text-align: left;
          // color:#D3D6D9;
          padding-left:22px;
          &:hover{
            color:@primary-color;
            border-color: @primary-color;
          }
        }
      }
      .table{
        margin-top: 10px;
        td:nth-last-of-type(1){
          width: 80px;
          text-align: center;
        }
        td:nth-of-type(1){
          width: 100px;
        }
        .ivu-icon-edit,.ivu-icon-checkmark,.ivu-icon-trash-a{
          padding:4px;
          font-size: 16px;
          color: rgb(196, 214, 230);
          cursor: pointer;
          &:hover{
            color: @primary-color;
          }
        }
        .ivu-input-wrapper{
          width: 163px;
        }
        .ivu-select{
          width: 100px;
        }
        .ivu-input-number{
          width: 80px;
        }
        .ivu-input-number,.ivu-select,.ivu-input-wrapper,.max_length{
          display: none;
        }
        .max_length{
          font-size: 12px;
          width: 34px;
          &.full{
            color: #ed3f14;
          }
        }
        span{
          display: inline-block;
          width: 200px;
          padding: 5px 8px;
          line-height: 1.5;
          font-size: 12px;
          &.type{
            width: 100px;
          }
        }
        .isEdit{
          span{display: none}
          .ivu-input-wrapper,.ivu-select,.ivu-input-number,.max_length{display: inline-block}
        }
      }
    }
    .footer{
     margin-top: 20px;
      text-align: center;
    }
    .third{
      padding-top: 20px;
    }
  }
</style>
