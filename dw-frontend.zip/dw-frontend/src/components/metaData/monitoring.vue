<template>
  <div class="monitoring">
    <v-header text="监控">
    </v-header>
    <iframe src="http://118.190.202.221:8080/toumin/jiankong.jsp" frameborder="0"></iframe>
  </div>
</template>

<script>
export default {
  props: {},
  data() {
    return {
     
    };
  },
  created() {
    let query = this.$route.query;
    let isWork = +this.session.get("is_work");
    let text = this.session.get("theme_name"),
      id = this.session.get("theme_first_id"),
      meta_id = this.session.get("meta_id"),
      item_id = query.id;
    this.id = item_id;
   this.$store.commit('setCrumbs',[
      {text:text,query:{id:id},name:"metaWorkList"},
      {text:isWork?"业务元数据":"任务元数据",query:{id:meta_id},name:isWork?"metaWorkList":"metaTaskList"},
      {text:"监控",name:"metaItemDetails",query:{id:item_id}}
    ]);
  },
  directives: {},
  computed: {},
  filters: {},
  methods: {
    
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
.monitoring { height: 100%; width: 100%; padding: 0;
  iframe{ height: 100%; width: 100%;}
}
</style>
