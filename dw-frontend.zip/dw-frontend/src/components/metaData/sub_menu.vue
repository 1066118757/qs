<template>
  <div class="sub_menu_container" :style="{height:$store.state.screenHeight - 60 + 'px'}">
    <h3>
      <Icon type="stats-bars" size="20" color="#7D7F85" style="float: left"></Icon>
      <span>元数据管理系统</span>
      <Icon
        :type="plus?'ios-plus-outline':'ios-plus'"
        @mouseenter.native="plus = false"
        @mouseleave.native="plus = true"
        @click.native="openModal()"
        size="18"
        color="#4ab9ff"
        style="float: right;padding-top: 2px;cursor: pointer;">
      </Icon>
    </h3>
    <Input type="text" v-model="searchCopy" placeholder="请输入待搜索的逻辑分区" icon="ios-search" @on-enter="searchFn" @on-click="searchFn" @on-blur="searchFn" :maxlength="30"/>
    <div v-show="!loading.themeList">
      <p style="font-size: 12px;text-align: center;color: #e7e7e7;" v-if="!themeForSearchList.length">没有符合条件的元数据</p>
      <div v-else style="position: relative">
        <div class="item_wrapper" v-for="(item,index) in themeForSearchList" :key="index">
          <p class="header">
            <Icon type="ios-paper-outline" size="18" color="#fff" style="float: left"></Icon>
            <span class="bind overflow" v-text="item.name" :title="item.name"></span>
            <span class="right">
          <Icon type="edit" color="#C4D6E6" size="14" @click.native="openModal(item)" v-if="item.id !==100"></Icon>
          <Icon type="trash-a" color="#C4D6E6" size="14" @click.native="affirm = true;delId = item.id;delIndex = index" v-if="item.id !==100"></Icon>
        </span>
          </p>
          <ul>
            <router-link
              tag="li"
              :to="{name:i?'metaTaskList':'metaWorkList',query:{id:li.id}}"
              @click.native="jump(item,li,i?'metaTaskList':'metaWorkList')"
              v-for="(li,i) in item.themeItemListVos"
              :key="i"
              active-class="active"
              :class="{active:li.id === +$route.query.id}"
              exact>{{li.name}}</router-link>
          </ul>
        </div>
      </div>
    </div>
    <Spin fix size="large" v-show="loading.themeList"></Spin>
    <Modal
      v-model="modal"
      title="增加（编辑）逻辑分区"
      width="600"
      class="no_footer"
      @on-visible-change="onVisibleChange">
      <Form ref="form" :model="form" :rules="rule" :label-width="80" style="padding-left: 60px">
        <FormItem prop="name" label="分区名:">
          <Input v-model="form.name" placeholder="请输入逻辑分区名（最多30个字）" style="width: 280px"/>
        </FormItem>
        <FormItem prop="remark" label="分区描述:">
          <Input type="textarea" v-model="form.remark" :rows="4" style="width: 280px;" placeholder="最多100个字"/>
        </FormItem>
        <FormItem>
          <Button type="ghost" style="width: 130px" @click="modal = false">取消</Button>
          <Button type="primary" style="width: 130px" @click="addOrEditTheme" :loading="loading.modalBtn">提交</Button>
        </FormItem>
      </Form>
    </Modal>
    <v-affirm :model.sync="affirm" :del="true" @click="delTheme"></v-affirm>
  </div>
</template>

<script>
  import metaServer from "rs/meta"
export default {
  props:{
  },
	data() {
    let validateLength = this.$store.state.validateLength;
    return {
      search:"",
      searchCopy:"",
      themeList:[],
      isEdit:false,
      plus:true,
      modal:false,
      affirm:false,
      delId:undefined,
      delIndex:undefined,
      loading:{
        modalBtn:false,
        themeList:false
      },
      rule:{
        name:[
              { validator: validateLength(30), trigger: 'blur' },
//              { validator: (r,v,c)=>{
//                let flag = this.themeForSearchList.find(l=>l.name === "default");
//                if(flag&&v.toLowerCase()==="default"){c("default为保留字，不可使用！")}
//                else c();
//                }, trigger: 'blur' }
            ],
        remark:{ validator: validateLength(100), trigger: 'blur' },
      },
      form:{
        name:"",
        remark:""
      }
    }
	},
	created() {
    this.getThemeList(true);
	},
	directives: {

	},
	computed: {
    themeForSearchList(){
      return this.search?this.themeList.filter(l=>l.name.includes(this.search)):this.themeList;
    }
	},
  watch:{
  },
	filters: {
	},
	methods: {
    onVisibleChange(v){
      if(!v)this.$refs.form.resetFields();
    },
    searchFn(){
      this.search = this.searchCopy;
    },
    jump(item){
      this.session.set("theme_id",item.id);
      this.session.set("theme_name",item.name);
      this.session.set("theme_first_id",item.themeItemListVos[0].id);
    },
    addOrEditTheme(){
      this.$refs.form.validate(f=>{
        if(f){
          this.loading.modalBtn = true;
          let server = "addMetaTheme",text = "新增",flag = this.isEdit;
          if(flag){
            server = "updateMetaTheme";text = "编辑";
          }
          metaServer[server]({data:this.form},({errorCode})=>{
            this.loading.modalBtn = false;
            if(errorCode)this.$Notice.error({title:text + "失败！"});
            else this.$Notice.success({title:text + "成功！"});
            this.modal = false;
            this.getThemeList();
          });
        }
      })
    },
    delTheme(e){
	    if(e&&e.preventDefault) e.preventDefault();
      metaServer.delMetaTheme({params:{id:this.delId}},({errorCode,data})=>{
        this.affirm = false;
        if(errorCode){this.$Notice.error({title:"删除失败！",desc:data});return;}
        this.$Notice.success({title:"删除成功！"});
        this.getThemeList(this.delId);
      })
    },
    openModal(item){
      let form = this.form;
      this.isEdit = false;
      form.name = form.remark = "";
      if(item){
        this.isEdit = true;
        form.name = item.name;
        form.remark = item.remark;
        form.state = item.state;
        form.id = item.id;
      }
      this.modal = true;
    },
    getThemeList(flag){
      this.loading.themeList = true;
      metaServer.getThemeList({params:{from:1}},({data})=>{
        this.loading.themeList = false;
        this.themeList = data;
        if(flag)return;
        let id = +this.session.get("theme_id");
        let name = +this.session.get("theme_name");
        let item = data.find(l=>l.id === id);
        if(!item){this.$store.commit('setCrumbs',[]);this.$router.replace({name:"metaData"});return;}
        if(item.name === name)return;
        this.$store.commit('setCrumbsThemeName',item.name);
        this.session.set("theme_name",item.name);
      });
    }
	}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
  .sub_menu_container{
    position: relative;
    padding:50px 30px 30px;
    overflow: auto;
    h3{
      padding-left:20px;
      padding-right: 20px;
      font-size: 14px;
      color:#4A4B50;
      font-weight: 600;
      line-height: 22px;
      margin-bottom: 26px;
      .ivu-icon-stats-bars{
        margin-right: 10px;
      }
    }
    .item_wrapper{
      .header{
        background-color: @primary-color;
        background-image: linear-gradient(-130deg,@primary-color,#7ACBFF);
        height: 36px;
        line-height: 36px;
        border-radius: 18px;
        padding-left: 20px;
        padding-right: 20px;
        color: #fff;
        margin-bottom: 28px;
        cursor: default;
        .ivu-icon-ios-paper-outline{
          line-height: 36px;
          margin-right: 14px;
        }
        .right{
          float: right;
          display: none;
          .ivu-icon-edit{
            margin-right: 8px;
          }
          i{
            cursor: pointer;
          }
        }
        .bind{
          display: inline-block;
          max-width: 122px;
        }
        &:hover{
          .right{
            display: inline-block;
          }
          .bind{
            max-width: 90px;
          }
        }
      }
      ul{
        padding-left: 24px;
        font-size: 12px;
        li{
          cursor: pointer;
          color: #7D7F85;
          margin-bottom: 28px;
          line-height: 12px;
          &::before{
            content: "";
            display: inline-block;
            width: 5px;
            height:5px;
            background-color: #7D7F85;
            border-radius: 50%;
            vertical-align: middle;
            margin-right: 17px;
          }
          &:hover,&.active{
            color: @primary-color;
            &::before{
              background-color: @primary-color;
            }
          }
        }
      }
    }
  }
</style>
<style lang='less'>
  .sub_menu_container .ivu-input-wrapper{
    border-radius: 18px;
    margin-bottom: 30px;
    input{
      border-radius: 18px;
      background-color:rgba(240,243,250,1);
      padding-left: 20px;
    }
    i{
      cursor: pointer;
      &:hover{
        color: #4AB9FF;
      }
    }
    input,i{
      height: 36px;
      line-height: 36px;
    }
  }
</style>
