<template>
  <div class="meta_data_task_container">
    <v-Header :text="text">
      <div class="header_right">
        <span style="font-size: 12px;margin-right: 10px">类型</span>
        <Select v-model="type" style="width:150px" clearable>
          <Option v-for="item in $store.state.meta.metaType" :value="item.key" :key="item.key">{{ item.text }}</Option>
        </Select>
        <Input placeholder="输入关键词进行查询" v-model="search" style="width: 200px;margin-right: 10px;"/>
        <Button type="ghost" @click="init()">查询</Button>
      </div>
    </v-Header>
    <Table :columns="columns" :data="data" :height="$store.state.screenHeight - 274" :loading="loading.metaItem"></Table>
    <Page
      :total="total"
      show-elevator
      show-total
      placement="top"
      @on-change="init"
    ></Page>
    <Modal
      v-model="setAuthorityModal"
      title="选择赋权用户"
      width="900"
      class="no_footer">
      <Table :columns="modalUserTableHeader" @on-selection-change="modalUserSelect" :height="420"  :data="modalUserList"  :loading="loading.modal"></Table>
      <div style="text-align:center; margin-top:20px; margin-bottom:30px;">
        <Button type="ghost" style="width: 130px" @click="setAuthorityModal = false">取消</Button>
        <Button type="primary" style="width: 130px" @click="setAuthoritySubmit()" >提交</Button>
      </div>
    </Modal>
    <Modal
      v-model="downloadModal"
      title="选择下载文件类型"
      width="400"
      style="text-align: center;"
      class="no_footer">
      <p style="margin-bottom: 20px">
        <a class="download_btn" :href='"/v1/metaItemDetail/exportData?metadataItemId="+downloadId+"&fileType=0&Authorization="+session.get("access_token")'>导出为csv文件</a>
      </p>
      <p style="margin-bottom: 50px">
        <a class="download_btn" :href='"/v1/metaItemDetail/exportData?metadataItemId="+downloadId+"&fileType=1&Authorization="+session.get("access_token")'>导出为Excel文件</a>
      </p>
    </Modal>
    <v-affirm :model.sync="affirm" :del="true" @click="delItem" :isMeta="true"></v-affirm>
  </div>
</template>
<script>
  import metaServer from "rs/meta"
  import Vue from "vue"
  import oldServer from  "rs/oldServer"
  export default {
    props:{
    },
    data() {
      return {
        data:[],
        delId:undefined,
        delIndex:undefined,
        downloadId:undefined,
        downloadModal:false,
        affirm:false,
        columns:[
          {
            title: '序号',
            type:"index"
          },
          {
            title: '数据表名',
            key: 'name'
          },
          {
            title: '类型',
            key: 'type',
            render(h,{row:{type}}){
              return h("span",Vue.filter("formatterMetaType")(type))
            }
          },
          {
            title: '创建用户',
            key: 'createUserName'
          },
          {
            title: '创建时间',
            key: 'createTime',
            render(h,{row:{createTime}}){
              return h("span",Vue.filter("date")(createTime))
            }
          },
          {
            title: '编辑时间',
            key: 'auditTime',
            render(h,{row:{auditTime}}){
              return h("span",Vue.filter("date")(auditTime))
            }
          },
          {
            title: '概述',
            key: 'purpose'
          },
          {
            title: '操作',
            width:240,
            render:(h,p)=>{
              return h("div",{
                class:"action_wrapper",
              },[h("span",{
                on:{
                  click:()=>{
                    this.setAuthority(p.row.name)
                  }
                }
              },"赋权"),h("span",{
                on:{
                  click:()=>{
                    this.$router.push({name:"metaItemDetails",query:{id:p.row.id}})
                  }
                }
              },"查看"),h("span",{
                on:{
                  click:()=>{
                    this.$router.push({name:"metaAddWork",query:{id:this.$route.query.id,editId:p.row.id}})
                  }
                }
              },"编辑"),h("span",{
                on:{
                  click:()=>{
                    this.downloadModal = true;
                    this.downloadId = p.row.id;
                  }
                }
              },"导出"),h("span",{
                on:{
                  click:()=>{
                    this.affirm = true;
                    this.delId = p.row.id;
                    this.delIndex = p.row._index;
                  }
                }
              },"删除")])
            }
          },
        ],
        total:0,
        search:"",
        setAuthorityId:undefined,
        setAuthorityModal:false,
        modalUserPage:1,
        modalUserTotal:0,
        modalUserList:[],
        modalUserTableHeader:[
          {
            type: 'selection',
            width: 60,
            align: 'center'
          },
          {
            title: '用户名称',
            render(h,{row}){
              return h("span",row.firstName+" "+row.lastName)
            }
          },
          {
            title: '权限',
            key: 'scope',
          },
          {
            title: '账号',
            key: 'loginAccount'
          }
        ],
        modalUserListCurrent:[],
        type:undefined,
        text:"",//左上角元数据主题的名字
        loading:{
          metaItem:false,
          modal:false,
        },
//      pageSize:this.$store.getters.minTableColumns,
      }
    },
    created() {
      this.setCrumbs();
      this.init();
    },
    directives: {

    },
    watch:{
      "$route.query.id":function () {
        this.setCrumbs();
        this.init();
      }
    },
    computed: {

    },
    filters: {
    },
    methods: {
      delItem(e){
	      if(e&&e.preventDefault) e.preventDefault();
        metaServer.delMetaItem({params:{id:this.delId}},({errorCode})=>{
          this.affirm = false;
          if(!errorCode){
            this.$Notice.success({
              title:"删除成功！"
            });
            this.init();
            return
          }
          this.$Notice.error({
            title:"删除失败！"
          });
        });
      },
      setAuthoritySubmit(){
        let data = {
          cuids:this.modalUserListCurrent,
          tables:[{
            schema:"default",
            tableName:this.setAuthorityId,
            tableType:0,
            columns:[]
          }]
        }
        this.setAuthorityModal = false;
        oldServer.createUserAnalyzeTables({data},(l)=>{
          this.$Notice.success({title:"成功",desc:"赋权操作成功！"})
        })
      },
      modalUserSelect(selection){
        this.modalUserListCurrent = [];
        for(let o of selection){
          this.modalUserListCurrent.push(o.guid)
        }
      },
      setAuthority(name){
        if(!name) return;
        this.setAuthorityId = name;
        this.setAuthorityModal = true;
        // 请求User列表
        let _params = {
          schema:'default',
          table:name
        }
        function _contains(arr, obj) {
          var i = arr.length;
          while (i--) {
            if (arr[i] === obj) {
              return true;
            }
          }
          return false;
        }
        this.loading.modal = true;
        this.modalUserListCurrent = [];
        oldServer.tableUsersChecked({params:_params},(checkedUser)=>{
          let json = {
            params3:'analyzer',
            params4:0,
            params5:9999
          }
          oldServer.getListUser({params:json}, ({data})=>{
            this.loading.modal = false;
            this.modalUserList = data;
            for(let o of data){
              if(_contains(checkedUser,o.guid)){
                o._checked = true;
                this.modalUserListCurrent.push(o.guid);
              }
            }
          });
        })
      },
      setCrumbs(){
        let route = this.$route;
        let flag = route.name === "metaWorkList",id = this.session.get("theme_first_id");
        this.text = this.session.get("theme_name");
        this.$store.commit('setCrumbs',[
          {text:this.text,query:{id:id},name:"metaWorkList"},
          {text:flag?"业务元数据":"任务元数据",query:{id:route.query.id},name:flag?"metaWorkList":"metaTaskList"}
        ]);
        this.session.set("is_work",flag?1:0);
        this.session.set("meta_id",route.query.id);
      },
      init(num){
        this.loading.metaItem = true;
        metaServer.getMetaItemList({
          params:{params3:num||1,params4:this.$store.getters.minTableColumns},
          data:{
            name:this.search||undefined,
            themeItemId:+this.$route.query.id,
            type:this.type
          }
        },({data})=>{
          this.loading.metaItem = false;
          this.data = data.pageData;
          this.total = data.totalCount
        });
      }
    }
  };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
  .meta_data_task_container{
    position: relative;
    padding-bottom: 42px;
    .header_right{
      float: right;
    }
    .ivu-page{
      position: absolute;
      right: 30px;
      bottom:0;
    }
    .action_wrapper{
      /*color: red;*/
    }
  }
</style>
