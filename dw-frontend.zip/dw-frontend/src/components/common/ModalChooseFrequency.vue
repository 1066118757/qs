<template>
  <!--这是.vue文件模板~-->
  <div class="choose_inner">
    <Select v-model="type" style="width: 46px" @on-change="change">
      <Option v-for="item in types" :key="item.key" :value="item.key">{{item.name}}</Option>
    </Select>
    <InputNumber :max="currentFrequency.max" :min="currentFrequency.min" v-model="num" style="width: 56px"></InputNumber>

    <Button type="primary" @click.native="ok">确定</Button>
  </div>
</template>
<script>
export default {
  model:{
    prop: 'value',
    event: 'on-change'
  },
  props:{
    value:{
      type:Object,
      default:function () {
        return {
          type:"second",
          value:1
        }
      }
    }
  },
	data() {
    return {
      num:1,
      type:"second",
      currentFrequency:{
        key:"second",
        name:"秒",
        min:1,
        max:60,
      },
      types:[
        {
          key:"year",
          name:"年",
          min:1,
          max:100,
        },
        {
          key:"month",
          name:"月",
          min:1,
          max:12,
        },
        {
          key:"week",
          name:"周",
          min:1,
          max:7,
        },
        {
          key:"day",
          name:"天",
          min:1,
          max:30,
        },
        {
          key:"hour",
          name:"时",
          min:1,
          max:23,
        },{
          key:"minute",
          name:"分",
          min:1,
          max:60,
        },
        {
          key:"second",
          name:"秒",
          min:1,
          max:60,
        }
      ],
    }
	},
	created() {
    this.init(this.value);
	},
	directives: {

	},
	watch: {
    value(n){
      this.init(n);
    }
	},
	filters: {
	},
	methods: {
    init(n){
      let {type,value} = n;
      this.num = value;
      this.type = type;
      this.currentFrequency = this.types.find(({key})=>key === this.type);
    },
    change(){
      this.currentFrequency = this.types.find(({key})=>key === this.type);
      this.num = this.currentFrequency.min;
    },
    ok(){
      this.$emit('on-change',{
        type:this.type,
        value:this.num
      });
      this.$emit("on-show-change",false);
    }
	}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
  .choose_inner{
    box-shadow:0 1px 6px rgba(0,0,0,.2);
    padding: 2px;
    position: absolute;
    z-index: 999;
    left: 0;
    top: 32px;
    white-space: nowrap;
    height: 40px;
    background-color: #fff;
    .number_item{
      vertical-align: top;
      display: inline-block;
    }
    footer{
      text-align: right;
      line-height: 24px;
      padding-top: 5px;
      button{
        line-height: 12px;
        padding: 5px 10px;
      }
    }
  }
</style>
