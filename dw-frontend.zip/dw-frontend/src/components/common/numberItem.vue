<template>
  <!--这是.vue文件模板~-->
  <div style="width: 56px;cursor: default;height: 165px" class="number_item">
    <p v-text="text" v-if="text" style="padding-left: 16px;line-height: 24px;border-bottom: 1px solid #f3f3f3"></p>
    <ul class="numberItem" ref="ul">
      <li v-for="item in array" @click="click(item)" :class="{active:item.active}">{{item.n}}</li>
    </ul>
  </div>
</template>

<script>
export default {
  model:{
    prop: 'current',
    event: 'on-change'
  },
  props:{
    num:{
      type:Number,
      default:60
    },
    min:{
      type:Number,
      default:0
    },
    text:{
      type:String
    },
    current:{
      type:Number,
    }
  },
	data() {
    return {
      array:[]
    }
	},
	created() {
    let arr = [];
    let c = this.current || this.min;
    c = c<10?"0"+c:c+"";
    for(let i = this.min;i<=this.num;i++){
      let n = i<10?"0"+i:i+"";
      arr.push({n,active:n === c});
    }
    this.array = arr;
	},
  mounted(){
    let c = this.current;
    if(c){
      let num = (c - this.min)*24;
      this.$refs.ul.scrollTop = num
    }
  },
	directives: {

	},
	computed: {},
	filters: {
	},
	methods: {
    click(item){
      this.array.forEach(l=>l.active = false);
      item.active = true;
      this.$emit("on-change",+item.n)
    }
	}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
  .numberItem{
    height: 140px;
    overflow: auto;
    border-right: 1px solid #f3f3f3;
    li{
      line-height: 24px;
      font-size: 12px;
      padding-left:16px;
      cursor: pointer;
      &.active{
        color:@primary-color;
        background-color:#f3f3f3;
      }
      &:hover{
        background-color: #f3f3f3;
      }
    }
  }
</style>
