<template>
  <div class="steps_wrapper">
      <div class="steps_item" v-for="(item,index) in data" :key="index" :class="{done:index+1<=step}">
        <span class="circle">{{index+1}}</span>
        <span class="text">{{item}}</span>
        <Icon type="ios-arrow-right" v-if="index!==data.length - 1" size="26"></Icon>
      </div>
  </div>
</template>

<script>
export default {
  props:{
    data:{
      type:Array,
      default(){
        return ["定义元数据","添加数据字段","结束"]
      }
    },
    step:{
      type:Number,
      default:1
    }
  },
	data() {
    return {
    }
	},
	created() {
	},
	directives: {

	},
	computed: {

	},
	filters: {
	},
	methods: {

	}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
  .steps_wrapper{
    padding-top: 18px;
    padding-bottom: 30px;
    border-bottom: 1px solid #F0F0F0;
    cursor: default;
    text-align: center;
    .steps_item{
      text-align: left;
      display: inline-block;
      margin-right: 30px;
      color: #D3D6D9;
      font-size: 14px;
      &:nth-last-of-type(1){
        margin-right:0;
      }
      &.done{
        color: @primary-color;
        .circle{
          border:1px solid @primary-color;
        }
      }
      span,i{
        vertical-align: middle;
      }
      .circle{
        display: inline-block;
        width: 26px;
        height:26px;
        border:1px solid #D3D6D9;
        border-radius: 50%;
        line-height: 26px;
        text-align: center;
        margin-right:10px;
      }
      .text{
        display: inline-block;
        margin-right: 30px;
      }
    }
  }
</style>
