<template>
  <Modal width="360" v-model="model" :closable="false" :mask-closable="false">
    <p slot="header" class="header" :style="{color:color}">
      <Icon type="information-circled" style="margin-right:8px"></Icon>
      <span v-if="reset">重置确认</span>
      <span v-if="del">删除确认</span>
      <slot name="title"></slot>
    </p>
    <div style='text-align:center'>
      <template v-if="reset">
        <p>该操作将会清空您已填写的内容，并无法恢复</p>
        <p>是否要继续？</p>
      </template>
      <template v-if="del">
        <p v-if="isMeta">该操作将会同时删除已用于创建图表的分析表，</p>
        <p>确定要删除选中项吗？</p>
      </template>
      <slot></slot>
    </div>
    <div slot="footer" style="text-align:center">
      <Button @click="$emit('update:model',false)" type="ghost" style="width:130px">取消</Button>
      <Button @click="$emit('click')" type="error" style="width:130px" :style="{backgroundColor:color,borderColor:color}">继续</Button>
    </div>
  </Modal>
</template>

<script>
export default {
  data() {
    return {
    }
  },
  props:["model","reset","del","color","isMeta"],
  created() {
  },
  directives: {
  },
  computed: {
  },
  filters: {
  },
  methods: {

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
.header{
  color:#f60;text-align:center
}
</style>
