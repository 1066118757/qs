<template>
  <!--这是.vue文件模板~-->
  <div class="done_container">
    <div class="circle">
        <div class="gou" :class="{active:show}">

        </div>
      </div>
    <slot></slot>
  </div>
</template>

<script>
export default {
  props:{
  },
	data() {
    return {
      show:false
    }
	},
	created() {
	},
  mounted(){
    setTimeout(()=>{this.show = true;},100);
  },
	directives: {

	},
	computed: {

	},
	filters: {
	},
	methods: {

	}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
  .done_container{
    cursor: default;
    text-align: center;
    .circle{
      background-color: #19be6b;
      width: 100px;
      height:100px;
      border-radius: 50px;
      position: relative;
      margin: 0 auto 8px;
      .gou{
        width: 60px;
        height: 40px;
        position: absolute;
        overflow: hidden;
        left:22px;
        top:16px;
        transform: rotate(-45deg);
        &::before{
          content: "";
          position: absolute;
          left:-40px;
          top:0;
          width: 7px;
          height: 100%;
          background-color: #fff;
          transition: left 320ms linear;
        }
        &::after{
          content: "";
          position: absolute;
          left: -60px;
          bottom:0;
          width:100%;
          height: 7px;
          background-color: #fff;
          transition: 320ms left 320ms ease-out;
        }
        &.active{
          &::before,&::after{left:0}
        }
      }
    }
  }
</style>
