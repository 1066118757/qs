<template>
  <!--这是.vue文件模板~-->
  <div>
    <div class="choose_wrapper">
      <span @click="click(1,true)" v-text="frequencyText" style="color: #19be6b;" :class="{disabled:disabled}"></span>
      <ModalChooseFrequency
        v-if="!disabled&&showFrequency"
        v-model="frequency"
        @on-show-change="click(1,false)">
      </ModalChooseFrequency>
    </div>
    <span v-show="level !== 5" :class="{disabled:disabled}">/</span>
    <div class="choose_wrapper">
      <span @click="click(2,true)" v-text="timeText" style="color: #ed3f14;" :class="{disabled:disabled}"></span>
      <ModalChooseTime
        v-if="!disabled&&showTime"
        v-model="time"
        :level="level"
        @on-show-change="click(2,false)">
      </ModalChooseTime>
    </div>
  </div>
</template>

<script>
  import ModalChooseTime from "./ModalChooseTime"
  import ModalChooseFrequency from "./ModalChooseFrequency"
export default {
    /**
     * 用法：
     *  使用v-model传入一个对象（对象格式是跟后端约定好了的，初始值可为 "" / {} ）,即可双向绑定。
     *   当传入disabled时，可以启用或者禁用该组件
     *
     * */
  model:{
    prop: 'value',
    event: 'on-change'
  },
  props:{
    disabled:{
      type:Boolean,
      default:false
    },
    value:{
      type:[Object,String]
    }
  },
	data() {
    return {
      showFrequency:false,
      showTime:false,
      frequency:{
        type:"month",
        value:1
      },
      time:{
        month:1,
        day:1,
        hour:0,
        minute:0,
        second:0,
      }
    }
	},
	created() {
    this.init();
	},
	watch: {
    value(){this.init()}
	},
	computed: {
    frequencyText(){
      let frequency = this.frequency;
      if(!frequency)return "选择频率";
      let {type,value} = frequency;
      switch (type){
        case "year":
          return "每" + value + "个自然年";
        case "month":
          return "每" + value + "个自然月";
        case "day":
          return "每" + value + "个自然天";
        case "hour":
          return "每" + value + "个小时";
        case "minute":
          return "每" + value + "分钟";
        case "second":
          return "每" + value + "秒";
        case "week":
          switch (value){
            case 1:
              return "每周一";
            case 2:
              return "每周二";
            case 3:
              return "每周三";
            case 4:
              return "每周四";
            case 5:
              return "每周五";
            case 6:
              return "每周六";
            case 7:
              return "每周日";
          }
      }
    },
    level(){
      let {type} = this.frequency;
      switch (type){
        case "year":
          return 0;
        case "month":
          return 1;
        case "day":
          return 2;
        case "hour":
          return 3;
        case "minute":
          return 4;
        case "second":
          return 5;
        case "week":
          return 2;
      }
    },
    timeText(){
      let level = this.level,fn = (num,type)=>num===undefined?"":(num<10?"0"+num + type:num + type);
      if(level === 5)return "";
      let {month,day,hour,minute,second} = this.time;
      let array = [fn(month,"月"),fn(day,"日"),fn(hour,"点"),fn(minute,"分"),fn(second,"秒")];
      return array.slice(level).join("");
    },
	},
  components:{ModalChooseTime,ModalChooseFrequency},
	filters: {
	},
	methods: {
    init(){
      let value = this.value;
      if((typeof value)==="string"){
        this.output();
        return;
      }
      let entries = Object.entries(value);
      if(!entries.length){
        this.output();
        return;
      }
      let type = entries.find(([k])=>/Type/.test(k))[0].replace("Type","");
      this.frequency = {type,value:value[type]};
      let obj = {};
      entries.forEach(([k,v])=>{
        if(k.includes(type))return;
        obj[k] = v;
      });
      this.time = Object.assign({},this.time,obj);
    },
    click(flag,boo){
      if(!this.disabled){
        switch (flag){
          case 1:
            this.showFrequency = boo;break;
          case 2:
            this.showTime = boo;break;
        }
        if(!boo)this.output();
      }
    },
    output(){
      let {type,value} = this.frequency;
      let time = this.time;
      let arr = ["month","day","hour","minute","second"].slice(this.level);
      let obj = {
        [type]:value,
        [type + "Type"]:"EVERY"
      };
      arr.forEach(attr=>obj[attr] = time[attr]);
      this.$emit("on-change",obj);
    }
	}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
  .choose_wrapper{
    position: relative;
    display: inline-block;
    >span{
     cursor: pointer;
      &:hover{
        color: @primary-color;
      }
    }
  }
  .disabled{
    color: #ccc!important;
    cursor: not-allowed!important;
  }
</style>
