<template>
  <!--这是main.vue文件~-->
  <div class="main_container">
    <div class="main" :style="{height:$store.state.screenHeight - 130 + 'px'}">
      <router-view></router-view>
      <p class="tips" v-if="$route.name === 'metaData'">请在左侧选择需要展示的元数据详情</p>
      <p class="tips" v-if="$route.name === 'dataConnect'">请在左侧选择需要展示的数据引接内容</p>
    </div>
  </div>
</template>

<script>
export default {
  props:{
  },
	data() {
    return {
    }
	},
	created() {
	},
	directives: {

	},
	computed: {

	},
	filters: {
	},
	methods: {

	}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
  .main_container{
    padding: 0 20px 20px 280px;
    .main{
      overflow: auto;
      position: relative;
      border-radius: 10px;
      background-color: #fff;
      padding:12px 30px 30px;
      .tips{
        position: absolute;
        text-align: center;
        top:50%;
        left:50%;
        margin-top:-10px;
        margin-left:-112px;
        cursor: default;
      }
    }
  }
</style>
