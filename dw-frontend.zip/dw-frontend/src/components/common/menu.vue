<template>
  <div class="header_container">
    <div class="menu_container clearfix">
      <div class="logo">
        <img :src="'/v1/file/download/'+logo" alt="">
      </div>
      <div class="line" :style="{left:left + 333 + 'px'}"></div>
      <router-link
          class="item"
          tag="div"
          :to="{name:item.name}"
          :key="index" active-class="active"
          v-for="(item,index) in childrens"
          @click.native="$store.commit('setCrumbs',[]);click(index,item)">
        {{item.meta.name}}
      </router-link>
      <div v-if="$store.state.company.name=='zky'&&scope=='personal_trial'" 
      class="item" @click="goEml()">eml</div>
    </div>
    <div class="user_msg_wrapper">
      <span class="idTask" @click="goDw()">数据处理平台 </span>
      
      <span class="name overflow" v-text="username" :title="username"></span>
      <Dropdown trigger="click" @on-click="v=>dropclick(v)">
        <a href="javascript:void(0)">
          <Icon type="ios-gear" size="20" color="#fff"></Icon>
        </a>
        <DropdownMenu slot="list">
          <DropdownItem v-if="downloadKeyShow" name="downloadkey">
            <a class="drap-link" :href="'/v1/shareData/user/downloadKey?Authorization='+authorization">下载秘钥</a>
          </DropdownItem>
          <DropdownItem name="exit">退出</DropdownItem>
        </DropdownMenu>
      </Dropdown>
    </div>
  </div>
</template>

<script>
import { Base64 } from "js-base64";

export default {
  props: {},
  data() {
    return {
      logo: sessionStorage.getItem("logo"),
      downloadKeyShow: false,
      authorization: sessionStorage.getItem("access_token"),
      username: "",
      childrens: this.$store.state.qx.menuArray,
      left: 0
    };
  },
  created() {
    this.getLogo();
    this.username = this.session.get("userName");
    this.scope = this.session.get("scope");
    this.childrens.forEach(({ path }, index) => {
      if (this.$route.path.includes(path)) this.click(index);
    });
    if (this.session.get("scope") == "personal_trial")
      this.downloadKeyShow = true;
  },
  directives: {},
  computed: {},
  filters: {},
  methods: {
    getLogo() {
      this.logo = sessionStorage.getItem("logo");
      if (!this.logo) {
        setTimeout(this.getLogo, 300);
      }
    },
    goDw() {
      window.location.href =
        window.location.href.split("/idetl/#/")[0] +
        "/#/?token=" +
        this.session.get("access_token");
      //this.router.navigate(['/admin/collect/index']);
    },
    click(index) {
      this.left = index * 106;
    },
    dropclick(v) {
      if (v === "exit") {
        this.session.del("guid");
        this.session.del("scope");
        this.session.del("userName");
        this.session.del("version");
        this.session.del("access_token");
        //window.location.href="/#/login"
        window.location.href =
          window.location.href.split("/idetl/#/")[0] + "/#/";
      }
    },
    goEml() {
      var data = Base64.encode(
        this.session.get("loginName") + "#%#" + this.session.get("loginP")
      );
      let url = "http://127.0.0.1:8888/EMLStudio.html?data=" + data;
      url =
        "http://159.226.140.207:28080/EMLstudio/EMLStudio.html?data=" + data;
      window.open(url);
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
.header_container {
  position: relative;
  background-color: #4bb2f4;
  height: 60px;
  padding-right: 50px;
}

.user_msg_wrapper {
  position: absolute;
  right: 50px;
  top: 20px;
  font-size: 12px;
  color: #fff;
  .idTask {
    margin-right: 20px;
    cursor: pointer;
    &:hover {
      opacity: 0.7;
    }
  }
  .name {
    display: inline-block;
    margin-right: 20px;
    max-width: 80px;
  }
  i,
  .name {
    vertical-align: top;
    cursor: pointer;
  }
  .drap-link:hover {
    text-decoration: none;
  }
}

.menu_container {
  position: relative;
  float: left;
  font-size: 14px;
  padding-left: 330px;
  color: #fff;
  line-height: 60px;
  text-align: center;
  .item {
    min-width: 56px;
    text-align: center;
    opacity: 0.7;
    position: relative;
    float: left;
    cursor: pointer;
    margin-right: 50px;
    &:nth-last-of-type(1) {
      margin-right: 0;
    }
    &:hover,
    &.active {
      opacity: 1;
    }
  }
  .line {
    position: absolute;
    content: "";
    width: 50px;
    min-width: 50px;
    height: 1px;
    background-color: #fff;
    bottom: 10px;
    opacity: 1;
    margin-right: 0;
    float: none;
    cursor: default;
    transition: left 200ms cubic-bezier(0, 0.5, 0.46, 1.46);
  }
  .logo {
    position: absolute;
    left: 0;
    top: 0;
    width: 260px;
    height: 100%;
    /*padding-left: 35px;*/
    img {
      max-width: 100%;
      max-height: 100%;
    }
  }
}
</style>
