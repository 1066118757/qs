<template>
  <!--这是.vue文件模板~-->
</template>

<script>
export default {
  props:{
  },
	data() {
    return {
    }
	},
	created() {
	},
	directives: {

	},
	computed: {

	},
	filters: {
	},
	methods: {

	}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
</style>
