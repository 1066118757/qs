<template>
  <!--这是面包屑.vue~-->
  <Breadcrumb separator=">">
    <!-- <BreadcrumbItem :to="route.path" @click.native="click">{{route.name}}</BreadcrumbItem> -->
    <BreadcrumbItem v-for="(item,index) in $store.state.crumbs" :key="index" :to="{name:item.name,query:item.query}">{{item.text}}</BreadcrumbItem>
  </Breadcrumb>
</template>

<script>
export default {
  props:{
    route:{
      type:Object,
      default(){
        return {
          name:"",
          path:""
        }
      }
    }
  },
	data() {
    return {
    }
	},
	created() {
    /**
     * 所有的操作 store里面的 setCrumbs 都应该在当前路由所对应的组件中进行。置为空除外。
     * */
	},
	directives: {

	},
	computed: {

	},
	filters: {
	},
	methods: {
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang='less'>
  .ivu-breadcrumb-item-separator{
    color:#7D7F85 !important;
  }
  .ivu-breadcrumb > span:last-child{
    font-weight: normal;
    color:inherit;
  }
  .ivu-breadcrumb{
    padding-left: 280px;
    height: 50px;
    line-height: 50px;
    font-size: 12px;
    color: #7D7F85;
  }
  .ivu-breadcrumb{
    span:last-child{
      a{ color: #999; text-decoration: none; cursor: default;
        :hover{ text-decoration: none; cursor: default;}
      }
    }
  }
</style>
