<template>
  <div class="header">
    <span class="text overflow" v-text="text"></span>
    <slot></slot>
  </div>
</template>

<script>
export default {
  props:{
    text:{
      type:String,
      default:""
    }
  },
	data() {
    return {
    }
	},
	created() {
	},
	directives: {

	},
	computed: {

	},
	filters: {
	},
	methods: {

	}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
  .header{
    line-height: 30px;
    /*height: 30px;*/
    margin-bottom: 30px;
    .text{
      display: inline-block;
      vertical-align: middle;
      height: 16px;
      line-height: 16px;
      padding-left: 10px;
      border-left:2px solid @primary-color;
      font-size: 14px;
      color: #4A4B50;
      max-width: 200px;
    }
  }
</style>
