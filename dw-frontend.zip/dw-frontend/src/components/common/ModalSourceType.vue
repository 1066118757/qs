<template>
  <!--这是.vue文件模板~-->
  <Modal
    title="选择数据源类型"
    v-model="show"
    class="no_footer"
    width="600"
  >
    <ul class="source_type_container clearfix">
      <li v-for="(item,index) in $store.state.connect.sourceType" :item="index" @click="check(item)" :key="index" v-if="item.key !== 608 || showWS">
        <img :src="baseUrl+item.src" alt="">
        <p v-text="item.text"></p>
      </li>
    </ul>
  </Modal>
</template>

<script>
export default {
  props:{
    modal:{
      type:Boolean
    },
    showWS:{
      type:Boolean,
      default:true
    },
  },
  data(){
    return {
      baseUrl:"./static/images/source_type/",
    }
  },
	created() {
	},
	directives: {

	},
	computed: {
    show:{
      get(){
        return this.modal;
      },
      set(v){
        this.$emit("update:modal",v);
      }
    }
	},
	filters: {
	},
	methods: {
    check(item){
      this.show = false;
      this.$emit("checked",item.key);
    }
	},
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
 .source_type_container{
   text-align: center;
   cursor: default;
   li{
     float: left;
     width: 25%;
     padding-bottom: 20px;
     font-weight: 600;
     img{
       width: 70px;
       height:70px;
       border-radius: 50%;
       margin-bottom: 10px;
       cursor: pointer;
     }
   }
 }
</style>
