<template>
  <!--这是.vue文件模板~-->
  <div class="choose_inner">
    <numberItem
      :text="item.text"
      :num="item.num"
      :min="item.min"
      v-model="current[key]"
      v-for="(item,key) in array.slice(level)"
      :key="key">
    </numberItem>
    <footer>
      <Button type="text" @click.native="confirm(false)">清空
      </Button><Button type="primary" @click.native="confirm(true)">确定</Button>
    </footer>
  </div>
</template>
<script>
  import numberItem from "./numberItem"

  export default {
  model:{
    prop: 'value',
    event: 'on-change'
  },
  props:{
    value:{
      type:Object,
      default:function () {
        return {
          month:undefined,
          day:undefined,
          hour:undefined,
          minute:undefined,
          second:undefined,
        }
      }
    },
    level:{
      type:Number,
      default:0
    }
  },
	data() {
    return {
      array:[
        {
          text:"月",
          num:12,
          min:1
        },
        {
          text:"日",
          num:30,
          min:1
        },
        {
          text:"时",
          num:23,
          min:0
        },
        {
          text:"分",
          num:60,
          min:0
        },
        {
          text:"秒",
          num:60,
          min:0
        },
      ],
      current:[]
    }
	},
  components:{numberItem},
	created() {
    this.init();
	},
	watch: {
    value(){
      this.init();
    }
	},
	methods: {
    init(){
      let {month,day,hour,minute,second} = this.value;
      this.current = [month,day,hour,minute,second].slice(this.level);
    },
    confirm(f){
      if(f){
        let [second,minute,hour,day,month] = JSON.parse(JSON.stringify(this.current)).reverse();
        this.$emit("on-change",{second,minute,hour,day,month});
      }
      this.$emit("on-show-change",false);
    }
	}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
  .choose_inner{
    box-shadow:0 1px 6px rgba(0,0,0,.2);
    padding: 2px;
    position: absolute;
    z-index: 999;
    left: 0;
    top: 32px;
    white-space: nowrap;
    height: 200px;
    background-color: #fff;
    .number_item{
      vertical-align: top;
      display: inline-block;
    }
    footer{
      text-align: right;
      line-height: 24px;
      padding-top: 5px;
      button{
        line-height: 12px;
        padding: 5px 10px;
      }
    }
  }
</style>
