<template>
  <!--这是.vue文件模板~-->
  <div class="field_map_container clearfix">
    <div class="left">
      <p class="title">目标表</p>
      <p class="item" v-for="(f,i) in to" :key="i">
        <span class="name">字段名:</span>
        <span v-text="returnStr(f.fieldName,f.colFamily)" :title="returnStr(f.fieldName,f.colFamily)" class="overflow"></span>
      </p>
    </div>
    <div class="right">
      <p class="title">来源表</p>
      <p class="item" v-for="item in to.length" :key="item">
        <span class="name">字段名:</span>
        <Select v-model="copyFrom[item - 1]" @on-change="l=>change(l,item - 1)" clearable :disabled="disabled" style="position: relative">
          <Option v-for="(f,i) in from" :key="i" :value="returnStr(f.fieldName,f.colFamily)">{{returnStr(f.fieldName,f.colFamily)}}</Option>
        </Select>
      </p>
    </div>
  </div>
</template>

<script>
  const fn = ()=>[];
export default {
  /**
   * /格式：{
   *  fieldName：string,
   *  fieldType:string (to 需要传 from不做要求)
   * }
   *
   */
  props:{
    from:{
      type:Array,
      default:fn
    },
    to:{
      type:Array,
      default:fn
    },
    value:{
      type:Array,
      default:fn
    },
    disabled:{
      type:Boolean,
      default:false
    }
  },
	data() {
    return {
      copyFrom:[],
      isHBase:+this.$route.query.type === 606
    }
	},
	created() {
    this.getCopyFrom();
	},
	directives: {

	},
	computed: {
	},
  watch:{
  },
	filters: {
	},
	methods: {
    returnStr(v1,v2){
      return v1 + (this.isHBase&&v2? "(family:"+ v2 +")": "");
    },
    returnStrRvs(v){
      if(v&&this.isHBase){
        let arr = v.slice(0,v.length - 1).split("(family:");
        return {v:arr[0],f:arr[1]};
      }
      return {v};
    },
    getCopyFrom(){
      let array = this.value;
      let result = [];
      if(!array.length){
        let toArr = this.to.map(l=>this.returnStr(l.fieldName,l.colFamily)),copyArr = [];
        this.from.forEach(({fieldName,colFamily})=>{
          let name = this.returnStr(fieldName,colFamily);
          let index = toArr.indexOf(name);
          if(index !== -1)result[index] = name;
          else copyArr.push(name)
        });
        for(let i = 0;i<toArr.length;i++){result[i] = result[i] || copyArr.shift()}
      }
      else {
        this.to.forEach(({fieldName})=>{
          let obj = array.find(({dist,family:f})=>dist === (f? f + "_":"") + fieldName) ||{source:""};
          result.push(this.returnStr(obj.source,obj.family));
        });
      }
      this.copyFrom = result;
      this.out();
    },
    change(item,index){
      let from = this.copyFrom;
      from.forEach((l,i)=>{
        if((l === item) && (index !== i))from.splice(i,1,"");
      });
      this.out();
    },
    out(){
      let array = [];
      let from = this.copyFrom;
      //hbase类型数据库需要单独处理
      let isHBase = +this.isHBase;
      this.to.forEach(({fieldName,fieldType},i)=>{
        let {v,f} = this.returnStrRvs(from[i]);
        let o = {
          source:(f? f + "_":"") + fieldName,
          dist:(f? f + "_":"") + fieldName,
          distDataType:isHBase?"string":fieldType
        };
        if(v){
          if(isHBase)o.family = f;
          array.push(o);
        }
      });
      this.$emit("change",array);
      console.log(array);
    }
	}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>
  .field_map_container{
    font-size: 12px;
    cursor: default;
    >div{
      width: 50%;
    }
    .left{
      float: left;
      padding-right: 20px;
    }
    .right{
      padding-left: 20px;
      float: left;
    }
    .ivu-select{
      width: 100px;
    }
    .item{
      height: 38px;
      line-height: 32px;
      padding-top: 3px;
      padding-bottom: 3px;
      .name{
        margin-right:8px;
      }
      .overflow{
        line-height: 30px;
        max-width:108px;
        display: inline-block;
        vertical-align: top;
      }
    }
    .title{
      text-align: center;
    }
  }
</style>
