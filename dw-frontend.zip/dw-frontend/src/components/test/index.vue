<template>
  <div class="dataDesensitization">
    <iframe src="http://118.190.202.221:8080/toumin/categories.jsp" frameborder="0"></iframe>
  </div>
</template>

<script>

  export default {
    props: {},
    data() {
      return {
        total: 0
      }
    },
    created() {
      
    },
    directives: {},
    computed: {},
    filters: {},
    methods: {
      

    }
  };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang='less'>
  #app_container{ height: calc(100%-60px); width: 100%;
  min-height: 90%;}
  .dataDesensitization { width: 100%; height: 100%;
    iframe{ width: 100%; height: 100%;}
  }
</style>
