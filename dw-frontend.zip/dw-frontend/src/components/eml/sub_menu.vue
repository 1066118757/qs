<template>
  <div class="sub_menu_container_com" :style="{minHeight:$store.state.screenHeight - 60 + 'px'}">
    <!--<h3>
      <Icon type="stats-bars" size="20" color="#7D7F85" style="float: left"></Icon>
      <span>数据整合</span>
    </h3>-->
    <router-link tag="p" :to="item.route" active-class="active" class="list_wrapper first" v-for="item in subMenu" :key="item.name">
      <Icon type="ios-paper-outline" size="18" color="#fff" style="float: left"></Icon>
      <span class="bind" v-text="item.name"></span>
    </router-link>
  </div>
</template>

<script>
export default {
  props: {},
  data() {
    return {
      subMenu: [

      ]
    };
  },
  created() {},
  directives: {},
  computed: {},
  filters: {},
  methods: {}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>

</style>
