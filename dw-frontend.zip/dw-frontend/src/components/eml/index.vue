<template>
  <div class="emlIndex">
    跳转到eml
  </div>
</template>

<script>

  export default {
    props: {},
    data() {
      return {

      }
    },
    created() {
    	window.open('http://127.0.0.1:8888/EMLStudio.html?name=bdaict%40hotmail.com&pwd=3d65c11f-b7ea-492e-8318-c52115a27ebd')
	    //window.history.go(-1);
      //window.location.href='http://127.0.0.1:8888/EMLStudio.html?name=bdaict%40hotmail.com&pwd=3d65c11f-b7ea-492e-8318-c52115a27ebd'
    },
    directives: {},
    computed: {},
    filters: {},
    methods: {
    }
  };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>

  .emlIndex{}
</style>
