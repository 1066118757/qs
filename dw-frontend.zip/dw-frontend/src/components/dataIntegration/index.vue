<template>
  <div class="data_integration_work_list">
    <v-Header :text="text">
      <div class="header_right">
        <Input placeholder="输入关键词进行查询" v-model="search.name" style="width: 200px;margin-right: 10px;"/>
        <Button type="ghost" @click="init()">查询</Button>
      </div>
    </v-Header>

    <Row class="item-list" :gutter="10">
      <Col :xs="12" :sm="12" :md="8" :lg="6">
      <div class="list-item add new">
        <div @click="newItem" style="text-align:center;color:#4AB9FF">
          <Icon type="ios-plus-outline" size="40" color="#4AB9FF"></Icon>
          <p>新建流程</p>
        </div>
      </div>
      </Col>
      <Col :xs="12" :sm="12" :md="8" :lg="6" v-for="(item,index) in listData" :key="index">
      <div class="list-item" style="cursor:pointer;" @click="editItem(item.id)">
        <h4 class="title">
          <span style="cursor:pointer" @click="editItem(item.id)">{{item.name}}</span>
          <Icon style="float:right;margin-left:10px;cursor:pointer;" type="trash-a" color="#C4D6E6" size="14"
                @click.native="delItem = item.id;affirm = true"></Icon>
          <!-- <Icon style="float:right;cursor:pointer;" type="edit" color="#C4D6E6" size="14" @click.native="editItem(item.id)" ></Icon> -->
        </h4>
        <div class="lines">
          <label class="database-name">
            <Icon type="social-buffer" :size="12" color="#4AB9FF"></Icon>
            <span>{{item.metadataItemId}}</span></label>
        </div>
        <div class="lines">
          <label class="user-name">
            <Icon type="person" :size="12" color="#4AB9FF"></Icon>
            <span>{{item.createUserName}}</span></label>
          <label class="time">
            <Icon type="ios-calendar" :size="12" color="#4AB9FF"></Icon>
            <span>{{item.createTime|date('yyyy-MM-dd hh:mm')}}</span></label>
        </div>
        <div class="lines">
          <span class="label" v-for="(o,i) in item.labels" :key="i">{{o}}</span>
        </div>
      </div>
      </Col>
    </Row>
    <Page
      :total="total"
      show-elevator
      show-total
      placement="top"
      @on-change="init"
    ></Page>

    <Modal
      v-model="newModal"
      title="新增流程"
      width="600"
      class="no_footer">
      <div style="text-align:center;margin-top:15px;">
        <span>请选择数据表</span>
        <Select v-model="newRecordTableId" style="width:300px; display:inline-block; text-align:left"
                placeholder="请选择数据表">
          <Option :value="o.id" v-for="(o,i) in metaTableList" :key="i">{{o.name}}</Option>
        </Select>
      </div>
      <div style="text-align:center; margin-top:20px; margin-bottom:50px;">
        <Button type="ghost" style="width: 130px" @click="newModal = false">取消</Button>
        <Button type="primary" style="width: 130px" @click="addOrEditSubmit" :loading="loading.modalBtn">提交</Button>
      </div>
    </Modal>
    <v-affirm :model.sync="affirm" :del="true" @click="deleteItem"></v-affirm>
  </div>
</template>

<script>
  import integrationServer from "rs/integration"

  export default {
    props: {},
    data() {
      return {
        total: 0,
        newRecordTableId: undefined,
        delItem: '',
        affirm: false,
        pageSize: 11,
        text: "流程列表",
        loading: {
          list: false,
          modalBtn: false,
        },
        search: {
          name: ""
        },
        metaTableList: [],
        newModal: false,
        listData: []
      }
    },
    created() {
      this.getTableList();
      this.setCrumbs();
      this.init(1);
    },
    directives: {},
    computed: {},
    filters: {},
    methods: {
      getTableList() {
        integrationServer.metaTableList({data: {}, params: {}}, ({data, errorCode}) => {
          if (!errorCode) {
            this.metaTableList = data.pageData;
          }
        })
      },
      setCrumbs() {
        this.$store.commit('setCrumbs', [
          {text: "工作台", name: "integrationWorkTable"}
        ]);
      },
      init(num) {
        let data = {}
        this.loading.list = true;
        integrationServer.clearRecordList({
          data: this.search,
          params: {params3: num || 1, params4: this.pageSize}
        }, ({data, errorCode}) => {
          this.loading.list = false;
          if (!errorCode) {
            this.listData = data.pageData;
            this.total = data.totalCount;
          }
        });
      },
      newItem() {
        // 新增
        this.newModal = true;
      },
      deleteItem() {
        // delete
        this.affirm = false;
        integrationServer.clearRecordDelete({data: {}, params: {id: this.delItem}}, ({data, errorCode}) => {
          this.loading.list = false;
          if (!errorCode) {
            this.delItem = "";
            this.init();
          }
        });
      },
      editItem(id) {
        if (this.affirm) return;
        this.$router.push({name: "integrationWorkDetails", query: {type: 'edit', id}})
      },
      addOrEditSubmit(e) {
	      if(e&&e.preventDefault) e.preventDefault();
        let tableName = "";
        this.metaTableList.forEach(item => {
          if (item.id == this.newRecordTableId) tableName = item.name;
        });
        this.$router.push({
          name: "integrationWorkDetails", query: {
            type: 'new',
            tableId: this.newRecordTableId,
            tableName: tableName
          }
        })
      }

    }
  };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='less'>

  .data_integration_work_list {
    position: relative;
    padding-bottom: 42px;
    .header_right {
      float: right;
    }
    .ivu-page {
      position: absolute;
      right: 30px;
      bottom: 0;
    }
    .action_wrapper {
      /*color: red;*/
    }
    .item-list {
      .list-item {
        // display: inline-block;
        padding: 20px 20px 15px;
        margin: 5px;
        vertical-align: top;
        // width: 300px;
        height: 120px;
        border: 1px solid #eee;
        &:hover {
          box-shadow: -1px 0px 15px 1px #d0d0d0;
        }
        .title {
          font-size: 16px;
          line-height: 20px;
          color: #4a4b50;
        }
        .lines {
          overflow: hidden;
          line-height: 1.5;
          margin-top: 4px;
          .database-name {
            display: block;
            font-size: 12px;
            color: #7d7f85;
          }
          .user-name {
            font-size: 12px;
            color: #4a4b50;
            float: left;
          }
          .time {
            float: right;
            font-size: 12px;
            color: #7d7f85;
          }
          .label {
            display: inline-block;
            border: 1px solid #d0d0d0;
            font-size: 12px;
            line-height: 12px;
            padding: 2px 6px;
            border-radius: 8px;
          }
        }
      }
    }
  }
</style>
