<template>
  <div class="data_integration_algorithm_list">
	  <v-Header :text="text">
        <div class="header_right">
            <Button icon="plus" type="info" size="large" shape="circle" @click="newRule">新增算法</Button>
        </div>
      <div style="margin-top:20px">
				<span>算法名</span>
        <Input placeholder="输入规则名进行模糊查询" v-model="search.name" style="width: 200px;margin-right: 10px;"/>
        <Button type="ghost" @click="init()">查询</Button>
      </div>
    </v-Header>
		<Table class='list-table' :columns="tableHeaders" :data="tableData"></Table>
		<Page
			:total="total"
      :page-size="minPageSize"
      :current="current"
			show-elevator
			show-total
			placement="top"
			@on-change="init"
		></Page>

    <Modal
      v-model="addRuleModal"
      :mask-closable ="false"
      :title="title"
      width="900"
      class="no_footer">
          <v-steps :data="steps" :step="step"></v-steps>
          <div class="step" v-if="step==1" style="width:360px;margin: 30px auto;">
            <Form
              :model="form"
              :label-width="90"
              :rules="rules"
              ref="form"
              style="width:370px;margin: 30px auto 0;">
              <FormItem class="form_item" prop="name">
                <span slot="label">算法名</span>
                <Input v-model="form.name" placeholder="请输入" style="width: 100%"/>
              </FormItem>
              <FormItem class="form_item" prop="alg_type">
                <span slot="label">算法类型</span>
                <Select v-model="form.alg_type">
                  <Option value="聚类">聚类</Option>
                  <Option value="预测">预测</Option>
                </Select>
              </FormItem>
              <FormItem class="form_item" prop="code_type">
                <span slot="label">开发语言</span>
                <Select v-model="form.code_type">
                  <Option value="java">java</Option>
                  <Option value="R">R</Option>
                  <Option value="python">python</Option>
                </Select>
              </FormItem>
              <FormItem class="form_item" prop="main_class" v-if ="form.code_type == 'java'">
                <span slot="label">主类</span>
                 <Input v-model="form.main_class" placeholder="请输入" style="width: 100%"/>
              </FormItem>
              <FormItem class="form_item" prop="description">
                <span slot="label">算法描述</span>
                <Input v-model="form.description" :autosize="{minRows: 2,maxRows: 4}" type="textarea" placeholder="请输入目标表名" style="width: 100%"/>
              </FormItem>
            </Form>
            <div style="text-align:center;margin-top:30px;">
                <Button type="ghost" style="width: 130px"  @click="addRuleModal = false" >返回</Button>
                <Button type="primary" style="width: 130px" @click="nextstep()" >下一步</Button>
            </div>
          </div>
          <div class="step" v-if="step==2" style="width:360px;margin: 30px auto;">
            <Upload
              action="//jsonplaceholder.typicode.com/posts/"
              style="margin: 37px auto 18px;width: 80px;color: #4AB9FF;text-align: center"
              :before-upload="beforeUpload"
              :show-upload-list="false"
              >
              <div style="text-align: center;cursor: pointer">
                <p>
                  <Icon type="ios-plus-outline" size="50"></Icon>
                </p>
                <p>{{uploadText}}</p>
              </div>
            </Upload>
            <p style="margin-bottom: 6px">已选择文件:</p>
            <div style="border: 1px solid #e0e0e0;padding:3px; color:#797979; margin-bottom:5px;">{{fileObj.name||'还未选择'}}</div>
            <div style="margin-top:10px;">
              <p style="line-height:2">算法参数:</p>
              <v-tags :source.sync="form.argsarray" :placeholder="'参数，按Enter隔开'"></v-tags>
              <!-- <Input v-model="form.args" placeholder="请输算法参数" style="width: 100%"/> -->
            </div>
            <div style="text-align:center;margin-top:30px;">
                <Button type="ghost" style="width: 130px" @click="step--">上一步</Button>
                <Button type="primary" style="width: 130px" :loading="loading.modalBtn" @click="upload()" >下一步</Button>
            </div>
          </div>
          <div class="step" v-if="step==3" style="margin: 50px auto;">
            <p style="text-align:center;line-height:2.4;">
              <span style="width:100px;display:inline-block;text-align:right;padding-right:5px;">算法名:</span>
              <span style="width:100px;display:inline-block;text-align:left;">{{form.name}}</span>
            </p>
            <p style="text-align:center;line-height:2.4;">
              <span style="width:100px;display:inline-block;text-align:right;padding-right:5px;">算法类型:</span>
              <span style="width:100px;display:inline-block;text-align:left;">{{form.alg_type}}</span>
            </p>
            <p style="text-align:center;line-height:2.4;">
              <span style="width:100px;display:inline-block;text-align:right;padding-right:5px;">语言:</span>
              <span style="width:100px;display:inline-block;text-align:left;">{{form.code_type}}</span>
            </p>
            <p style="text-align:center;line-height:2.4;">
              <span style="width:100px;display:inline-block;text-align:right;padding-right:5px;">主类:</span>
              <span style="width:100px;display:inline-block;text-align:left;">{{form.main_class}}</span>
            </p>
            <p style="text-align:center;line-height:2.4;">
              <span style="width:100px;display:inline-block;text-align:right;padding-right:5px;">算法路径:</span>
              <span style="width:100px;display:inline-block;text-align:left;">{{form.file_path}}</span>
            </p>
            <p style="text-align:center;line-height:2.4;">
              <span style="width:100px;display:inline-block;text-align:right;padding-right:5px;">参数:</span>
              <span style="width:100px;display:inline-block;text-align:left;">{{form.args}}</span>
            </p>
            <div style="text-align:center;margin-top:30px;">
                <Button type="ghost" style="width: 130px" @click="step--">上一步</Button>
                <Button type="primary" style="width: 130px" :loading="loading.modalBtn" @click="addSubmit" >确定提交</Button>
            </div>
          </div>
    </Modal>
    <v-affirm :model.sync="affirm" :del="true" @click="deleteRule"></v-affirm>
  </div>
</template>

<script>
import sparkJobServer from "rs/sparkJob"
import tags from "cmpts/common/tags"
import vDone from "cmpts/common/done"
export default {
  props:{
  },
  components:{
    'v-tags':tags,
    vDone
  },
	data() {
    const validate = (rule, value, callback) => {
      if (value === undefined) {
        console.log(value,callback)
        callback(new Error('必选项'));
      } else {
        callback();
      }
    };

    return {
      form:{
        alg_type:undefined,
        code_type:undefined,
        name:undefined,
        main_class:'',
        description:undefined,
        args:'',
        argsarray:[],
        file_path:''
      },
      current:1,
      editId:"",
      steps:["算法定义","算法文件上传","预览"],
      step:1,
      title:"",
      affirm:false,
      addRuleModal:false,
			total:0,
      text:"算法列表",
      uploadText:'上传算法文件',
			search:{
				name:''
			},
			loading:{
				modalBtn:false,
			},
      rules:{
        name: [
          { required: true, max: 15, message: '名称不能为空并不能超过15个字', trigger: 'blur  change' }
        ],
        code_type: [
          { required: true, validator:validate, trigger: 'change' }
        ],
        alg_type: [
          { required: true, validator:validate, trigger: 'change' }
        ],
        main_class:[
          { required: true, message: '不能为空并', trigger: 'blur  change' }
        ],
        description:[
           { required: false, max: 50, message: '描述不能超过50个字', trigger: 'blur change' }
        ]
      },
      delItem:"",
      fileObj:{},
			tableHeaders:[
  			{
          title: '序号',
          width:50,
          type:"index"
        },
        {
          title: '算法名',
          key: 'name',
          width:140,
        },
        {
          title: '算法类型',
          width:80,
          render:(h,{row:{alg_type}})=>{
            return h("span",alg_type)
          }
        },
        {
          title: '主类型',
          width:160,
          render:(h,{row:{main_class}})=>{
            return h("span",main_class)
          }
        },
        {
          title: '创建用户',
          width:120,
          key: 'create_by_name'
        },
        {
          title: '创建时间',
          width:180,
          render(h,{row:{create_at}}){
            return h("span",Vue.filter("date")(create_at))
          }
        },

        {
          title: '开发语言',
					width:80,
          key: 'code_type',
        },

        {
          title: '算法概述',
          key: 'description',
        },
        {
          title: '操作',
          width:100,
          render:(h,p)=>{
            return h("div",{
              class:"action_wrapper",
            },[h("span",{
              on:{
                click:(e)=>{
	                if(e&&e.preventDefault) e.preventDefault();
                  this.step = 1;
                  p.row.argsarray =   p.row.args.split(",");
                  this.form = JSON.parse(JSON.stringify(p.row));
                  // this.form.argsarray = this.form.args.split(",");
                  this.editId=p.row.id;
                  this.fileObj = {};
                  // this.uploadText = "重新选择";
                  this.title="编辑算法:"+p.row.name;
                  this.addRuleModal = true;
                }
              }
            },"编辑"),h("span",{
              on:{
                click:(e)=>{
	                if(e&&e.preventDefault) e.preventDefault();
                  this.delItem = p.row.id;
                  this.affirm = true
                }
              }
            },"删除")])
          }
        },
			],
			tableData:[]
    }
	},
	created() {
		 this.setCrumbs();
		 this.init();
	},
	directives: {

	},
	computed: {
      minPageSize(){
        return Math.max(Math.floor((this.$store.state.screenHeight - 377)/41),10);
      }
	},
	filters: {
	},
	methods: {
    setCrumbs(){
      this.$store.commit('setCrumbs',[
        {text:"算法列表",name:"integrationRuleList"}
      ]);
    },
    init(num){
      // 获取数据
      let data = this.search;
      this.loading.list = true;
      sparkJobServer.getSparkJobList({data:data,params:{params3:this.current,params4:this.minPageSize}},({data,success})=>{
        this.loading.list = false;
        this.tableData = data.data;
        this.total = data.totalItems;
      });
    },
    newRule(){
      this.step = 1;
      this.addRuleModal = true;
      this.editId=undefined;
      this.title="添加算法";
      this.uploadText = '上传算法文件';
      this.fileObj = {};
      this.form={
        alg_type:undefined,
        code_type:undefined,
        name:undefined,
        main_class:'',
        description:undefined,
        argsarray:[],
        args:'',
        file_path:''
      };
    },
    deleteRule(e){
	    if(e&&e.preventDefault) e.preventDefault();
      this.affirm = false;
      sparkJobServer.deleteSparkJob({data:{},params:{params3:this.delItem}},({data,errorCode})=>{
        this.loading.list = false;
        if(!errorCode){
          this.delItem ="";
          this.init();
        }
      });
    },

    nextstep(){
       this.$refs['form'].validate((valid) => {
         if(valid){
           this.step++;
         }
       })
    },
    beforeUpload(fileObj) {
      if(!/\.(py|jar|r|R)$/.test(fileObj.name)){
        this.$Notice.error({title:"操作失败",desc:"请上传jar/py/R文件！"});
        return false;
      }
      this.uploadText = "重新选择";
      this.fileObj = fileObj;
      return false;
    },
    upload(){
      this.form.args = "";
      this.form.argsarray.forEach((obb,i)=>{
        if(i==this.form.argsarray.length-1){
          this.form.args+=obb;
        }else{
          this.form.args+=obb+",";
        }
      });
      if(this.form.id&&!this.fileObj.name){//如果是修改且没有上传新文件，直接过
        this.step++
      }else{//否则执行上传
        if(!this.fileObj.name){
          this.$Notice.error({title:"操作无效",desc:"你还未选择文件！"});
          return;
        }
        let fileObj = this.fileObj;
        let formdata = new FormData();
        formdata.append('file',fileObj);
        this.loading.modalBtn = true;
        sparkJobServer.uploadJobFiles({data:formdata},(data)=>{
          this.loading.modalBtn = false;
          if(data.success){
            this.form.file_path = data.data.filePath;
            this.step++;
          }
          else{
            this.$Notice.error({title:"上传失败",desc:"文件上传未成功，请刷新重试！"});
          }
        });
      }
    },
    addSubmit(e){
	    if(e&&e.preventDefault) e.preventDefault();
      if(this.form.file_path == ''){
        this.$Notice.error({title:"未上传文件",desc:"请上传jar文件或py文件！"});
        return false;
      }
      if(this.editId){
        sparkJobServer.updateSparkJob({data:this.form},(data)=>{
          this.addRuleModal = false;
          this.init();
        })
      }
      else{
        sparkJobServer.createSparkJob({data:this.form},(data)=>{
          this.addRuleModal = false;
          this.init();
        })
      }

    },
	}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang='less'>
  .data_integration_algorithm_list{
    position: relative;
    padding-bottom: 42px;
    .status-on{
      display: inline-block;
      background-color: #19be6b;
      color:#fff;
      padding: 0 10px;
      border-radius: 16px;
      font-size: 12px;
      line-height: 19px;
    }
    .status-off{
      display: inline-block;
      background-color: #ed3f14;
      color:#fff;
      padding: 0 10px;
      border-radius: 16px;
      font-size: 12px;
      line-height: 19px;
    }
    .header_right{
      float: right;
    }
    .ivu-page{
      position: absolute;
      right: 30px;
      bottom:0;
    }
    .list-table{
      .ivu-table-cell{
        padding:0 8px;
      }
    }
    .action_wrapper{
      /*color: red;*/
    }


  }
  .view-rule-modal{
    .view-list{
      .line-item{
        display: flex;
        margin-top:20px;
        .item-name{
          width:100px;
          text-align :right;
          line-height: 24px;
        }
        .item-value{
          flex:1;
          line-height: 24px;
          padding-left: 5px;
          border:1px solid #d0d0d0;
          border-radius: 4px;
        }
        .summary{
          height: 48px;
        }
        .scriptcode{
          height: 120px;
        }
      }
    }
  }
</style>
