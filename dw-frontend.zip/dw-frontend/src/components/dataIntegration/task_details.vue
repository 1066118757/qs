<template>
  <div class="data_integration_task_item">
	  <v-Header :text="mainData.name">
				<Icon type="person" :size="12" style="margin-left:26px;" color="#4AB9FF"></Icon>
				<span>{{mainData.createUser}}</span>
				<Icon type="ios-calendar" :size="12" style="margin-left:26px;" color="#4AB9FF"></Icon>
				<span>{{mainData.updateTime | date}}</span>
    </v-Header>
		<div class="main-body">
			<ul class="titles">
				<li @click="chosseTitle(1)" class="title-item" :class="isCurrent==1?'current':''">基本信息</li>
				<li @click="chosseTitle(2)" class="title-item" :class="isCurrent==2?'current':''">数据流程</li>
				<li @click="chosseTitle(3)" class="title-item" :class="isCurrent==3?'current':''">执行历史</li>
			</ul>
			<div class="contents">
				<div v-if="isCurrent==1" class="base-info">
						<div>
							<span class="name">输入表名：</span>
							<div class="value">{{mainData.inItemName}}</div>
						</div>
						<div>
							<span class="name">输出表名：</span>
							<div class="value">{{mainData.outItemName}}</div>
						</div>
						<div>
							<span class="name">状态：</span>
							<div class="value">
									<p>
										<span class="icon">{{mainData.nearResult|codeName(10)}}</span>

										<Button :disabled="mainData.nearResult==1001" @click="nowExecute" type="primary" size="small"
                            class="actions">执行</Button>
										<!--<Button type="Button" size="small"
                            v-if="mainData.nearResult==1002" class="actions">停止</Button>
										<Button size="small"
                            class="actions">查看日志</Button>-->
									</p>
									<p v-if="mainData.nearResult!=1004">
										<span class="time">启动时间{{mainData.nearStartTime|date}}</span>
										<span class="time">结束时间{{mainData.nearEndTime|date}}</span>
									</p>
							</div>
						</div>
						<!--<div>
							<span class="name">对应流程：</span>
							<div class="value">
								<router-link :to="{name:''}">对应的流程表名</router-link>
							</div>
						</div>-->
						<div>
							<span class="name">创建人：</span>
							<div class="value">{{mainData.createUserName}}</div>
						</div>
						<div v-if="mainData.cronCode&&mainData.cronCode.length">
							<span class="name">频率执行：</span>
							<div class="value">
                <v-frequency v-for="(item,i) in mainData.cronCode" :key="i"
                             v-model="item.data" :disabled='true'></v-frequency>
							</div>
						</div>
            <div  v-if="mainData.cronCode1&&mainData.cronCode1.length">
              <span class="name">定时执行：</span>
              <div class="value">
                <DatePicker v-for="(item,i) in mainData.cronCode1" :key="i"  v-model="item.data" type="datetime" placeholder="选择时间"
                            :options="options" :disabled='true'>
                </DatePicker>
              </div>
            </div>
						<div>
							<span class="name">短信提醒：</span>
							<div class="value" v-if="mainData.isNote">
                {{mainData.phone}}
							</div>

						</div>
						<div>
							<span class="name">邮件提醒：</span>
              <div class="value" v-if="mainData.isEmail">
                {{mainData.email}}
              </div>
						</div>
							<div>
							<span class="name">依赖任务：</span>
              <div class="value" v-if="mainData.dependence&&mainData.dependence.etlJobs&&mainData.dependence.etlJobs.length">
                {{mainData.dependence.etlJobs[0].name}}
              </div>
						</div>
				</div>
				<div v-if="isCurrent==2" class="data-flow">
					<div class="center1 clearfix">
						<p>执行流程算发:</p>
						<!-- <p v-for="(item,i) in ruleInstanceList" :key="i">
              <span class="flow-name">{{item.summary}}</span>
            </p> -->
						<div class="boxb">
							<div class="rules" v-for="(item) in ruleInstanceList" :key="item.name">
              <div class="head">
                <span class="title">{{item.name}}{{item.summary}}</span>
              </div>
              <ul v-if="item.show">
                <li v-for="step in item.scriptCode">
                  <h4 class="overflow" :title="step.nodeName">{{step.nodeName}}</h4>
                  <!--列选择-->
                  <div v-if="step.getType==1200">
                    <Select v-model="step.bind" style="width:100%" :disabled="disabled">
                      <Option v-for="ob in tableCols" :value="ob.title" :key="ob.title">{{ ob.title }}</Option>
                    </Select>
                  </div>
                  <!--列多选择-->
                  <div v-if="step.getType==1201">
                    <Select v-model="step.bind" style="width:100%" multiple :disabled="disabled">
                      <Option v-for="ob in tableCols" :value="ob.title" :key="ob.title">{{ ob.title }}</Option>
                    </Select>
                  </div>
                  <!--输入框-->
                  <div v-if="step.getType==1202">
                    <Input v-model="step.bind" placeholder="输入参数" :disabled="disabled"></Input>
                  </div>
                  <!--输入多值框-->
                  <div v-if="step.getType==1203">
                    <v-tags :source.sync="step.bind"></v-tags>
                  </div>
                  <!--输入数字-->
                  <div v-if="step.getType==1204">
                    <InputNumber v-model="step.bind" :disabled="disabled"></InputNumber>
                  </div>
                  <!--下拉-->
                  <div v-if="step.getType==1205">
                    <Select v-model="step.bind" style="width:100%" :disabled="disabled">
                      <Option v-for="ob in step.list" :value="ob" :key="ob">{{ ob }}</Option>
                    </Select>
                  </div>
                  <!--下拉多选-->
                  <div v-if="step.getType==1206">
                    <Select v-model="step.bind" style="width:100%" multiple :disabled="disabled">
                      <Option v-for="ob in step.list" :value="ob" :key="ob">{{ ob }}</Option>
                    </Select>
                  </div>
                  <!--开关-->
                  <div v-if="step.getType==1207">
                    <i-switch v-model="step.bind" :disabled="disabled"></i-switch>
                  </div>
                  <!--数据字典-->
                  <div  v-if="step.getType==1208">
                    <Select :disabled="disabled" v-model="step.bind" style="width:100%" @on-change="dataChange(step)">
                      <Option v-for="ob in tables"
                              :value="ob.id"
                              :key="ob.id">{{ ob.name }}</Option>
                    </Select>
                  </div>
                </li>
              </ul>
            </div>
						</div>
					</div>
				</div>
				<div v-if="isCurrent==3">
          <Table :columns="logHeaders" :data="logList"></Table>
					<Page
						:total="total"
            :page-size="pageSize"
						show-elevator
						show-total
						placement="top"
						@on-change="getLog"
					></Page>
				</div>
			</div>
		</div>
  </div>
</template>

<script>
import vFrequency from "cmpts/common/frequency";
import integrationServer from "rs/integration";
import expandRow from "./table-expand.vue";
export default {
  props: {},
  components: { vFrequency },
  data() {
    return {
      disabled: true,
      tableCols: [],
      options: {
        disabledDate(date) {
          return date && date.valueOf() < Date.now() - 86400000;
        }
      },
      logList: [],
      logHeaders: [
        {
          type: "expand",
          width: 50,
          render: (h, params) => {
            return h(expandRow, {
              props: {
                row: params.row.taskLog
              }
            });
          }
        },
        {
          title: "开始时间",
          render(h, { row: { startTime } }) {
            return h("span", Vue.filter("date")(startTime));
          }
        },
        {
          title: "完成时间",
          render(h, { row: { endTime } }) {
            return h("span", Vue.filter("date")(endTime));
          }
        },
        {
          title: "执行结果",
          width: 120,
          className: "zjxg",
          render(h, { row: { result } }) {
            return h(
              "span",
              {
                class: "st status" + result
              },
              Vue.filter("codeName")(result, 10)
            );
          }
        }
      ],
      ruleInstanceList: {},
      isCurrent: 1,
      pageSize: 10,
      total: 0,
      text: "清洗规则列表",
      search: {
        a: "",
        b: "",
        c: ""
      },
      mainData: {}
    };
  },
  created() {
    this.setCrumbs();
    this.init();
    this.getHead();
  },
  directives: {},
  computed: {},
  filters: {},
  methods: {
    // 获取清洗表头
    getHead() {
      integrationServer.metaTableDetail(
        {
          data: { metadataItemId: this.mainData.metadataItemId },
          params: {}
        },
        ({ data, errorCode }) => {
          if (errorCode == 0) {
            this.tableData = [{}];
            data.pageData.forEach((o, i) => {
              if (i == 0) o.fixed = "left";
              o.key = o.id;
              o.title = o.colName;
            });
            this.tableCols = data.pageData;
          }
        }
      );
    },
    setCrumbs() {
      this.$store.commit("setCrumbs", [
        { text: "任务列表", name: "integrationTaskList" },
        { text: this.mainData.name }
      ]);
    },
    init() {
      // 获取数据
      this.getData();
    },
    nowExecute() {
      this.mainData.nearResult = 1001;
      integrationServer.nowExecute(
        { params: { taskId: this.mainData.id } },
        ({ data, errorCode }) => {
          if (errorCode == 0) {
            this.init();
          } else {
          }
        }
      );
    },
    getLog(page) {
      this.logList = [];
      integrationServer.clearTaskLogList(
        {
          data: { taskId: this.mainData.id },
          params: { params3: page, params4: 10 }
        },
        ({ data, errorCode }) => {
          if (errorCode == 0) {
            this.logList = data.pageData;
            this.total = data.totalCount;
          } else {
          }
        }
      );
    },
    getRecord() {
      integrationServer.clearRecordDetailById(
        { data: {}, params: { id: this.mainData.recordId } },
        ({ data, errorCode }) => {
          if (errorCode == 0) {
            if (data.handleCode)
              this.ruleInstanceList = JSON.parse(data.handleCode).frontend;
            this.getLog(1);
          } else {
          }
        }
      );
    },
    getData() {
      integrationServer.clearTaskDetail(
        { params: { id: this.$route.query.id } },
        response => {
          if (response.errorCode == 0) {
            response.data.cronCode = JSON.parse(response.data.cronCode);
            response.data.cronCode1 = [];
            var cronCode = [];
            response.data.cronCode.forEach(item => {
              if (item.time) {
                response.data.cronCode1.push({ data: item.time });
              } else {
                cronCode.push({ data: item });
              }
            });
            response.data.cronCode = cronCode;
            if (response.data.dependence) {
              response.data.dependence = JSON.parse(response.data.dependence);
            }
            this.mainData = response.data;

            this.setCrumbs();
            this.getRecord();
          } else {
          }
        }
      );
    },
    chosseTitle(n) {
      this.isCurrent = n;
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang='less'>
.data_integration_task_item {
  position: relative;
  padding-bottom: 42px;

  .header_right {
    float: right;
  }
  .ivu-page {
    position: absolute;
    right: 30px;
    bottom: 0;
  }
  .action_wrapper {
    /*color: red;*/
  }
  .main-body {
    .titles {
      text-align: center;
      .title-item {
        display: inline-block;
        width: 90px;
        line-height: 32px;
        cursor: pointer;
      }
      .title-item.current {
        color: #4ab9ff;
        border-bottom: 1px solid #4ab9ff;
      }
    }
    .contents {
      padding: 30px;
      .base-info {
        width: 600px;
        margin: 0 auto;
        line-height: 32px;
        .name {
          display: inline-block;
          width: 100px;
          color: #4a4b50;
          font-size: 14px;
          text-align: right;
          vertical-align: top;
        }
        .value {
          display: inline-block;
          width: 400px;
          padding-left: 2px;
          color: #7d7f85;
          font-size: 12px;
        }
      }
      .data-flow {
        width: 100% !important;
        padding-top: 50px;
        margin: 0 auto;
        .center1 > p {
          text-align: left;
          font-size: 16px;
        }
        .boxb {
        }
        .rules {
          user-select: none;
          margin-top: 12px;
          font-size: 12px;
          border: 1px solid;
          white-space: nowrap;
          line-height: 1.5;
          padding: 6px 15px;
          color: #6ec7ff;
          background-color: transparent;
          border-color: #6ec7ff;
          border-radius: 16px;
          width: 23%;
          float: left;
          margin: 10px 1%;
          .head {
            height: 18px;
            .title {
              display: inline-block;
              white-space: nowrap;
              text-overflow: ellipsis;
              overflow: hidden;
              width: 100%;
            }
            .ivu-icon {
              color: #c0c0c0;
              &:hover {
                color: #2db7f5;
                cursor: pointer;
              }
            }
          }
          ul {
            border-top: 1px solid #ededed;
            margin-top: 6px;
            padding-top: 10px;
            li {
              margin-bottom: 10px;
              font-size: 12px;
              h4 {
                color: #555;
                margin-bottom: 3px;
                font-size: 12px;
              }
              > div {
                padding: 0 10px;
              }
            }
          }
        }
      }
    }
  }
  .zjxg {
    .st {
      display: inline-block;
      height: 20px;
      padding: 0 15px;
      background: #ededed;
      border-radius: 100px;
      color: #fff;
    }
    .status1002 {
      background: #29bc6e;
    }
    .status1003 {
      background: #ea4124;
    }
    .status1001 {
      background: #348eed;
    }
  }
}
</style>
