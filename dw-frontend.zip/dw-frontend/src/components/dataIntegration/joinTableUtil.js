/**
 * @description 合表拖拽
 * @author lixiaolin
 * @export initDrage
 */
export function initDrage(net, netMouseUp) {
    // console.log(net)
    let tableList = document.getElementById("tableList");
    // let chartBox = document.getElementById("chartBox");
    let tableDrag, currentItem, dragBal = true,
        isEnter = false;

    function tableMouseDown(ev) {
        var ev = ev || window.event;
        var target = ev.target || ev.srcElement;
        if (target.nodeName.toLowerCase() == "li" || target.parentNode.nodeName.toLowerCase() == "li") {
            currentItem = target.nodeName.toLowerCase() == "li" ? target : target.parentNode;
            tableDrag = (() => {
                var a = document.createElement("div");
                a.id = "tableDrag";
                a.innerHTML = `<i class="ivu-icon ivu-icon-grid"></i><span id="tableName"></span>`;
                return document.body.appendChild(a);
            })();
            document.documentElement.classList.add("move");
            tableDrag.querySelector("#tableName").innerText = currentItem.dataset.name;
            document.addEventListener("mousemove", documentMouseMove, false);
            document.addEventListener("mouseup", documentMouseUp, false);
            // chartBox.addEventListener("mouseup", newOneNode, false);
            // 监听图形的mouseup 事件，创建节点。
            net.on("itemmouseup", newOneNodeEdge);
            net.on("mouseup", newOneNode);
            net.on("itemmouseenter", nodeMouseEnter);
            net.on("itemmouseleave", nodeMouseLeave);
            // 监听节点的mouseup 创建节点的关系边
        }
        return false;
    }

    function newOneNode(ev) {
        // console.log(ev, currentItem);
        netMouseUp && netMouseUp(ev, currentItem, "Node", isEnter);
        return false;
    }

    function nodeMouseEnter() {
        isEnter = true;
    }

    function nodeMouseLeave() {
        isEnter = false;
    }

    function newOneNodeEdge(ev) {
        // console.log(ev, currentItem);
        netMouseUp && netMouseUp(ev, currentItem, "Edge", isEnter);
        return false;
    }

    function documentMouseUp() {
        tableDrag.classList.remove("show");
        document.documentElement.classList.remove("move");
        document.removeEventListener("mouseup", documentMouseUp, false);
        dragBal = false;
        tableDrag.remove();
        return false;
    }

    function documentMouseMove(ev) {
        if (!dragBal) {
            // console.log(dragBal);
            tableDrag.classList.remove("show");
            net.off("mouseup", newOneNode);
            net.off("itemmouseup", newOneNodeEdge);
            net.off("itemmouseenter", nodeMouseEnter);
            net.off("itemmouseleave", nodeMouseLeave);
            // chartBox.removeEventListener("mouseup", newOneNode, false);
            document.removeEventListener("mousemove", documentMouseMove, false);
            dragBal = true;
            isEnter = false;
            return false;
        }
        tableDrag.classList.add("show");
        tableDrag.style.left = ev.clientX - 25 + "px";
        tableDrag.style.top = ev.clientY - 10 + "px";
        return false;
    }
    tableList.addEventListener("mousedown", tableMouseDown, false);
}

/**
 * @description 自定义节点
 * 
 * @export
 * @param {any} G6 
 * @param {any} net 
 * @param {any} fn 
 * @returns 返回自定义Dom节点
 */
export function registerNode(G6, net, fn) {
    G6.registerNode('customNode', {
        cssSize: true, // 不使用内部 size 作为节点尺寸
        getHtml(cfg) {
            const model = cfg.model;
            // console.log(model);
            const container = G6.Util.createDOM(`<div class="tableDrag"><i class="ivu-icon ivu-icon-grid"></i><span>${model.name}</span></div>`);
            const closeBtn = G6.Util.createDOM(`<div class="close"><span class="ivu-icon ivu-icon-ios-trash"></span></div>`)
            closeBtn.addEventListener('click', () => {
                fn && fn(model);
            });
            container.appendChild(closeBtn);
            return container;
        }
    }, 'html');
}

export const columnTypes = ["TEXT", "NUMBER", "DATE", "FUNCTION"];