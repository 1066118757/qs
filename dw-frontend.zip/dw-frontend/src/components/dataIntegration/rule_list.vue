<template>
  <div class="data_integration_rule_list">
	  <v-Header :text="text">
        <div class="header_right">
            <Button icon="plus" type="info" size="large" shape="circle" @click="newRule">新增规则</Button>
        </div>
      <div style="margin-top:20px">
				<span>规则函数名</span>
        <Input placeholder="输入规则名进行模糊查询" v-model="search.name" style="width: 200px;margin-right: 10px;"/>
				<span>状态</span>
        <Select v-model="search.state" style="width:180px" placeholder="选择类型" clearable>
          <Option :value="1">{{ "启用" }}</Option>
          <Option :value="0">{{ "禁用" }}</Option>
        </Select>
				<span>类型</span>
        <Select v-model="search.ruleType" style="width:180px" placeholder="选择类型" clearable>
          <Option v-for="item in $store.state.integration.ruleType" :value="item.key" :key="item.key">{{ item.text }}</Option>
        </Select>
        <Button type="ghost" @click="init()">查询</Button>
      </div>
    </v-Header>
		<Table :columns="tableHeaders" :data="tableData"></Table>
		<Page
			:total="total"
			show-elevator
			show-total
			placement="top"
			@on-change="init"
		></Page>

    <Modal
      v-model="addRuleModal"
      :mask-closable ="false"
      :title="title"
      width="1200"
      class="no_footer addGzBox">
				<Form ref="newRuleFform" :model="newRuleFform" :rules="ruleNewRuleFform" :label-width="120">
						<FormItem label="规则函数名称" prop="name">
								<Input v-model="newRuleFform.name" placeholder="输入规则函数名称"></Input>
						</FormItem>
						<FormItem label="规则描述名称"  prop="summary"  style="width: 70%">
								<Input v-model="newRuleFform.summary" placeholder="输入描述名称"></Input>
						</FormItem>
            <FormItem label="规则类型" prop="ruleType">
              <Select v-model="newRuleFform.ruleType" style="width:90px" placeholder="选择类型">
                <Option v-for="item in $store.state.integration.ruleType"
                        :value="item.key" :key="item.key">{{ item.text }}</Option>
              </Select>
            </FormItem>
            <FormItem label="开发语言" prop="codeType" v-if="newRuleFform.ruleType==806">
              <Select v-model="newRuleFform.scriptType">
                <Option v-for="item in $store.state.integration.scriptType" v-if="item.key != 903"
                        :value="item.key" :key="item.key">{{ item.text }}</Option>
              </Select>
            </FormItem>

						<FormItem label="规则状态"  prop="state">
								<RadioGroup v-model="newRuleFform.state">
										<Radio :label="1">启用</Radio>
										<Radio :label="0">禁用</Radio>
								</RadioGroup>

						</FormItem>
            <FormItem v-if="newRuleFform.ruleType==806" label="规则代码包"  prop="filePath" class="uploadDiv">
              <Upload
                action="//jsonplaceholder.typicode.com/posts/"
                style="color: #4AB9FF"
                :before-upload="beforeUpload"
                :show-upload-list="false"
              >
                <div style="text-align: center;cursor: pointer">
                  <p v-if="!fileObj.name&&!newRuleFform.filePath">
                    <Icon type="ios-plus-outline" size="50"></Icon>
                  </p>
                  <p>{{fileObj.name||newRuleFform.filePath}}</p>
                  <p v-if="!fileObj.name&&!newRuleFform.filePath">{{uploadText}}</p>
                </div>
              </Upload>
              &nbsp;&nbsp;&nbsp;&nbsp;
              <span class="fileMainClass" v-if="showMainClass||newRuleFform.mainClass">
                <span>mainClass:&nbsp;</span>
                <Input v-model="newRuleFform.mainClass" placeholder="输入mainClass"></Input>
              </span>
            </FormItem>

						<!--<FormItem label="脚本类型" style="display:inline-block; width:400px;">
								<RadioGroup v-model="newRuleFform.scriptType">
										<Radio v-for="item in $store.state.integration.scriptType" :label="item.key" :key="item.key">{{item.text}}</Radio>
								</RadioGroup>
						</FormItem>-->
						<!-- <Button type="ghost" icon="plus" shape="circle">添加附件</Button> -->

						<!--<FormItem label="脚本代码">
								<Input type="textarea" :rows="8" v-model="newRuleFform.scriptCode" placeholder="输入描述"></Input>
						</FormItem>-->

						<FormItem label="参数信息" style="width: 100%;" prop="state">
              <Button icon="plus-round" size="small" @click="addRuleParamAddVos" type="info">添加参数</Button>
              <span style="color:#ccc;"> 请将参数信息按顺序逐条添加</span>
              <ul style="margin: 10px 0;">
                <li v-for="(item,index) in newRuleFform.scriptCode" :key="index" class="bz-li">
                  <Button icon="minus-round" @click="minusRuleParamAddVos(index)" size="small"></Button>
                  <span style="color: #2db7f5">
                    <i>参数名:</i>
                    <Input style="width:180px;" v-model="item.typeName"></Input>
                  </span>
                  <span>
                    <i>参数描述:</i>
                    <Input style="width:280px;" v-model="item.nodeName"></Input>
                  </span>
                  <span>
                    <i>获取方式:</i>
                    <Select style="width:190px;" v-model="item.getType">
                      <Option v-for="item in $store.state.integration.paramGetType" :value="item.key" :key="item.key">{{ item.text }}</Option>
                    </Select>
                  </span>
                  <!--<span>参数类型</span>
                  <Select style="width:90px;" v-model="item.type">
                    <Option v-for="item in $store.state.integration.paramType" :value="item.key" :key="item.key">{{ item.text }}</Option>
                  </Select>-->

                  <span v-if="item.getType==1205||item.getType==1206" style="padding-left: 40px;">
                    <i>输入选择参数:</i>
                    <v-tags :source.sync="item.list" @change="tagsChange"></v-tags>
                  </span>
                  <span v-if="item.getType==1207" style="padding-left: 40px;">
                    <i>默认值:</i>
                    <i-switch v-model="item.bind"></i-switch>
                  </span>

                </li>
              </ul>
						</FormItem>
				</Form>

				<div style="text-align:center; margin-top:20px; margin-bottom:50px;">
          <Button type="ghost" style="width: 130px" @click="addRuleModal = false">取消</Button>
          <Button type="primary" style="width: 130px" @click="addRuleModalSubmit" :loading="loading.modalBtn">提交</Button>
				</div>
    </Modal>
    <v-affirm :model.sync="affirm" :del="true" @click="deleteRule"></v-affirm>
  </div>
</template>

<script>
import integrationServer from "rs/integration"
import tags from "cmpts/common/tags"
import sparkJobServer from "rs/sparkJob"
export default {
  props:{
  },
  components:{
    'v-tags':tags
  },
	data() {
    const validateRuleType = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('必选项'));
      } else {
        callback();
      }
    };
    const validateName = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('必选项'));
      } else {
        callback();
      }
    };

    return {
      showMainClass:false,
      fileObj:{},
      uploadText:'上传算法文件',
      editId:"",
      title:"",
      showFlag:true,
      affirm:false,
      addRuleModal:false,
			total:0,
			text:"清洗规则列表",
			search:{
				name:'',
				ruleType:undefined,
				state:undefined
			},
			loading:{
				modalBtn:false,
			},
			newRuleFform:{
        mainClass:null,
        filePath:null,
        name :null,
        state:1,
				ruleType :null,
        scriptCode :[],
        scriptType :901,
        summary :null,
        ruleParamAddVos:[]
			},
      ruleNewRuleFform:{
        name: [
          { required: true, max: 40, message: '不能为空并不能超过40个字', trigger: 'blur' }
        ],
        summary: [
          { required: true, max: 125, message: '不能为空并不能超过125个字', trigger: 'blur' }
        ],
        ruleType: [
          { required: true, validator: validateRuleType,  trigger: 'change' }
        ],
        codeType:[
          { required: true, validator: validateName,  trigger: 'change' }
        ]
      },
      delItem:"",
			tableHeaders:[
  			{
          title: '序号',
          width:80,
          type:"index"
        },
        {
          title: '规则描述名称',
          key: 'summary',
        },
        {
          title: '规则函数名',

          key: 'name'
        },
        {
          title: '类型',
          width:120,
          render:(h,{row:{ruleType}})=>{
            return h("span",this.ruleTypeFilter(ruleType))
          }
        },
        {
          title: '创建用户',

          key: 'createUserName'
        },
        {
          title: '创建时间',
          width:200,
          key: 'createTime',
          render(h,{row:{createTime}}){
            return h("span",Vue.filter("date")(createTime))
          }
        },

        {
          title: '状态',
					width:100,
          render(h,{row:{state}}){
            return h("span",{
              class:(state==1)?"status-on":"status-off"
            },(state==1)?"启用":"禁用")
          }
        },
        {
          title: '操作',
          width:200,
          render:(h,p)=>{
            return h("div",{
              class:"action_wrapper",
            },[h("span",{
              on:{
                click:(e)=>{
	                if(e&&e.preventDefault) e.preventDefault();
                  this.newRuleFform = JSON.parse(JSON.stringify(p.row));
                  this.newRuleFform.scriptCode = JSON.parse(p.row.scriptCode);
                  this.editId=p.row.id;
                  this.title="编辑规则"+p.row.name;
                  this.addRuleModal = true;
                }
              }
            },"编辑"),h("span",{
              on:{
                click:(e)=>{
	                if(e&&e.preventDefault) e.preventDefault();
                  this.delItem = p.row.id;
                  this.affirm = true
                }
              }
            },"删除")])
          }
        },
			],
			tableData:[]
    }
	},
	created() {
		 this.setCrumbs();
		 this.init();
		 console.log(this.$store.state.integration.ruleType)
	},

	directives: {

	},
	computed: {
      minPageSize(){
        return Math.max(Math.floor((this.$store.state.screenHeight - 377)/41),10);
      }
	},
	filters: {
	},
	methods: {
    beforeUpload(fileObj) {
      this.showMainClass=false;
      if(!/\.(py|jar)$/.test(fileObj.name)){
        this.$Notice.error({title:"操作失败",desc:"请上传jar文件或py文件！"});
        return false;
      }
      this.uploadText = "重新选择";
      if(fileObj.name.indexOf('.jar')!=-1) this.showMainClass=true;
      this.fileObj = fileObj;
      return false;
    },
    upload(){
      let fileObj = this.fileObj;
      let formdata = new FormData();
      formdata.append('file',fileObj);

      sparkJobServer.uploadJobFiles({data:formdata},(data)=>{

        if(data.success){
          this.newRuleFform.filePath = data.data.filePath;
          this.saveEdit();
        }
        else{
          this.$Notice.error({title:"上传失败",desc:"文件上传未成功，请刷新重试！"});
        }
      });
    },
    tagsChange(sf){

    },
    ruleTypeFilter(code){
      for(let o of this.$store.state.integration.ruleType){
        if(o.key == code)
          return o.text;
      }
    },
    paramTypeFilter(code){
      for(let o of this.$store.state.integration.paramType){
        if(o.key == code)
          return o.text;
      }
    },
    paramGetTypeFilter(code){
      for(let o of this.$store.state.integration.paramGetType){
        if(o.key == code)
          return o.text;
      }
    },
    scriptTypeFilter(code){
      for(let o of this.$store.state.integration.scriptType){
        if(o.key == code)
          return o.text;
      }
    },
    setCrumbs(){
      this.$store.commit('setCrumbs',[
        {text:"清洗规则列表",name:"integrationRuleList"}
      ]);
    },
    init(num){
      // 获取数据
      let data = this.search;
      this.loading.list = true;
      integrationServer.clearRuleList({data:data,params:{params3:num||1,params4:this.minPageSize}},({data,errorCode})=>{
        this.loading.list = false;
        if(!errorCode){
          this.tableData = data.pageData;
          this.total = data.totalCount;
        }
      });
    },
    newRule(){
      this.addRuleModal = true;
      this.editId="";
      this.title="添加规则"
      this.newRuleFform = {
        mainClass:null,
        name :"",
        state:1,
        ruleType :null,
        codeType:"java",
        scriptCode :[],
        scriptType :901,
        summary :"",
        ruleParamAddVos:[]
      };
    },
    addRuleParamAddVos(){
      this.newRuleFform.scriptCode.push({list:[]})
    },
    minusRuleParamAddVos(i){

      this.newRuleFform.scriptCode.splice(i,1);
    },
    deleteRule(e){
	    if(e&&e.preventDefault) e.preventDefault();
      this.affirm = false;
      integrationServer.clearRuleDelete({data:{},params:{id:this.delItem}},({data,errorCode})=>{
        this.loading.list = false;
        if(!errorCode){
          this.delItem ="";
          this.init();
        }
      });
    },
    addRuleModalSubmit(e){
	    if(e&&e.preventDefault) e.preventDefault();
      this.$refs['newRuleFform'].validate((valid) => {
        if (valid) {
          this.loading.modalBtn = true;
          if(this.fileObj.name){
            this.upload();
          }else{
            this.saveEdit();
          }
        } else {
          this.$Message.error('验证失败!');
        }
      })
    },
    saveEdit(){
      let postData = JSON.parse(JSON.stringify(this.newRuleFform));
      postData.scriptCode.forEach(item=>{
        switch (item.getType){
          case 1201:
          case 1203:
          case 1206:
            item.bind=[];
            break;
          case 1207:
            break;
          default:
            item.bind=null;
        }
      });
      postData.scriptCode=JSON.stringify(postData.scriptCode);
      if(postData.ruleType!=806){
        postData.filePath=null;
        postData.mainClass=null;
        postData.scriptType=901
      }
      if(!this.editId){
        integrationServer.clearRuleAdd({data:postData},({data,errorCode})=>{
          this.loading.modalBtn = false;
          if(errorCode == 0){
            this.addRuleModal = false;
            this.init();
          }else{
            this.newRuleFform.scriptCode=JSON.parse(this.newRuleFform.scriptCode);
          }
        });
      }else {
        postData.id=this.editId;
        integrationServer.clearRuleUpdate({data:postData},({data,errorCode})=>{
          this.loading.modalBtn = false;
          if(errorCode == 0){
            this.addRuleModal = false;
            this.init();
          }else{
            this.newRuleFform.scriptCode=JSON.parse(this.newRuleFform.scriptCode);
          }
        });
      }
    }
	}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang='less'>

  .data_integration_rule_list{
    position: relative;
    padding-bottom: 42px;
    .action_wrapper{ color: #2b85e4;}
    .status-on{
      display: inline-block;
      background-color: #19be6b;
      color:#fff;
      padding: 0 10px;
      border-radius: 16px;
      font-size: 12px;
      line-height: 19px;
    }
    .status-off{
      display: inline-block;
      background-color: #ed3f14;
      color:#fff;
      padding: 0 10px;
      border-radius: 16px;
      font-size: 12px;
      line-height: 19px;
    }
    .header_right{
      float: right;
    }
    .ivu-page{
      position: absolute;
      right: 30px;
      bottom:0;
    }
    .action_wrapper{
      /*color: red;*/
    }

  }
  .fileMainClass{
    >div{ display: inline-block; width: 300px;}
  }
  .uploadDiv{ width: 100% !important;
    .ivu-upload{ display: inline-block;}
  }
  .view-rule-modal{
    .view-list{
      .line-item{
        display: flex;
        margin-top:20px;
        .item-name{
          width:100px;
          text-align :right;
          line-height: 24px;
        }
        .item-value{
          flex:1;
          line-height: 24px;
          padding-left: 5px;
          border:1px solid #d0d0d0;
          border-radius: 4px;
        }
        .summary{
          height: 48px;
        }
        .scriptcode{
          height: 120px;
        }
      }
    }
  }
</style>
