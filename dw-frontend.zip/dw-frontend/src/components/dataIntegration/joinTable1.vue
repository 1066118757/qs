<template>
  <div class="joinTable">
    <div class="tables">
      <h3 class="panelTitle">我的工作表</h3>
      <div class="tableCont">
        <div class="tableList" id="tableList">
          <div class="loading" v-if="!tables && loading">
            <Col class="demo-spin-col" span="8">
            <Spin fix>
              <Icon type="load-c" size="18" class="demo-spin-icon-load"></Icon>
              <div>加载中...</div>
            </Spin>
            </Col>
          </div>
          <div class="loading" v-else-if="!tables && !loading">暂无数据</div>
          <div v-else-if="tables && !loading" class="item" v-for="(item,key) in tables" :key="key">
            <h2 @click="handleTableActive(item,key)">
              <Icon :type="item.active?'ios-folder':'ios-folder-outline'"></Icon><span>{{key}}</span>
            </h2>
            <ul v-show="!item.active">
              <li :class="{active:i.active}" :data-name="i.displayName" :data-id="i.analyzeMapInfoUuid" :data-key="key" :data-index="k" v-for="(i, k) in item" :key="k">
                <Icon type="grid"></Icon><span>{{i.displayName}}</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="chartBox">
        <h3 class="panelTitle">多表分析</h3>
        <h3 class="panelTitle saveBtn">
          <Button type="primary" size="small" @click="saveTable(preViewJoinTable)"><Icon type="upload"></Icon> 保存</Button>
        </h3>
        <div class="chartCont" id="chartBox">
          <div class="merge-field-select" v-show="context_line" id="currentLink">
            <div class="head-select">
              <span class="fl">关联方式：</span>
              <div class="join-type">
                <div class="select-show-box" v-if="currentLink" @click="joinTypeActive">
                  {{joinType[currentLink.joinType]}} &nbsp;&nbsp; <i class="icon icon-arrow-down"></i>
                </div>
                <ul class="select-option" v-if="currentLink" v-show="join_type_opened">
                  <li @click="joinTypeChange(2)" :class="{'selected': currentLink.joinType == 2}"><i class="join left-join"></i> Left Join
                  </li>
                  <li @click="joinTypeChange(3)" :class="{'selected': currentLink.joinType == 3}"><i class="join right-join"></i> Right Join
                  </li>
                  <li @click="joinTypeChange(1)" :class="{'selected': currentLink.joinType == 1}"><i class="join inner-join"></i> Inner Join
                  </li>
                  <li @click="joinTypeChange(0)" :class="{'selected': currentLink.joinType == 0}"><i class="join full-join"></i> Full Join
                  </li>
                </ul>
              </div>
            </div>
            <ul class="left-column" v-if="currentLink && tableColumns">
              <li class="head">
                <span class="to-tb-name">{{tableColumns.tableName}}</span>
                <span class="from-tb-name">{{tableColumns.joinTableName}}</span>
              </li>
              <li class="">
                <select class="to-field-select" v-model="currentLink.col">
                    <option v-for="(option,index) in tableColumns.tableCol" :key="index" :value="option.colName">
                      {{ option.colName }}
                    </option>
                </select>
                <span class="equal">=</span>
                <select class="from-field-select" v-model="currentLink.joinCol">
                    <option v-for="(option,index) in tableColumns.joinTableCol" :key="index" :value="option.colName">
                      {{ option.colName }}
                    </option>
                </select>
              </li>
            </ul>
            <div class="action-group" v-if="currentLink">
              <a class="" @click="resetRelation(joinType[currentLink.joinType])">确定</a>
              <a class="" @click="context_line = false,join_type_opened=false">取消</a>
            </div>
          </div>
        </div>
      </div>
      <div class="joinTableFilter">
        <h3 class="panelTitle">预览</h3>
        <div class="tablesCont">
          <div class="myTable" id="myTable">
            <table>
              <thead>
                <tr>
                  <th class="tableName" v-for="(item, key) in joinTables" :colspan="item.length" :key="key">表：{{tableName(key)}}</th>
                </tr>
                <tr>
                  <th v-for="(item, key) in shapeField" :key="key">
                    <input type="checkbox" :id="'checkbox'+key" v-model="item.chosen" @change="preViewJoinTable()" class="" checked>
                    <label :for="'checkbox'+key">{{item.colDisplayName || item.colName}}</label>
                  </th>
                </tr>
              </thead>
              <tbody v-if="previewData">
                <tr v-for="(item,key) in previewData.RowDataSet" :key="key">
                  <td v-for="(value,index) in item" :key="index">{{value}}</td>
                </tr>
              </tbody>
            </table>
            <div v-if="!previewData" class="nodata">暂无合表数据</div>
          </div>
        </div>
      </div>
    </div>
    <Modal v-model="saveModal" title="保存合表" width="600" class="no_footer dsrwBox">
      <div class="saveModal">
        <Form ref="pubWorkForm" :model="pubWorkForm" :rules="rulePubWorkForm" :label-width="90">
          <FormItem label="合表名称" prop="outTable">
            <Input v-model="pubWorkForm.outTable" placeholder="请输入表名称"></Input>
          </FormItem>
          <FormItem label="输出表类型" prop="outType">
            <Select v-model="pubWorkForm.outType" style="width:280px">
                        <Option v-for="item in $store.state.meta.metaType" :value="item.key" :key="item.key">{{ item.text }}
                        </Option>
                      </Select>
          </FormItem>
          <FormItem label="输出位置" prop="outSite">
            <Select v-model="pubWorkForm.outSite" style="width:200px" placeholder="请选择">
                        <Option v-for="item in themeList"
                                :value="item.themeItemListVos[1].id" :key="item.themeItemListVos[1].id">{{ item.name }}
                        </Option>
                      </Select>
          </FormItem>
        </Form>
        <div style="text-align:center; margin-top:20px; margin-bottom:50px;">
          <Button size="large" type="ghost" style="width: 130px" @click="saveModal = false">取消</Button>
          <Button size="large" type="primary" style="width: 130px" @click="pubWorkSubmit" :loading="loading.modalBtn">提交
            </Button>
        </div>
      </div>
    </Modal>
  </div>
</template>

<script>
import oldServer from "rs/oldServer";
import metaServer from "rs/meta";
import G6 from "@antv/g6";
import _ from "lodash";
import { initDrage, registerNode, columnTypes } from "./joinTableUtil";
let net = null;
export default {
  props: {},
  data() {
    const validateOutThemeItemId = (rule, value, callback) => {
      if (!value) {
        callback(new Error("必须选项"));
      } else {
        callback();
      }
    };
    return {
      loading: true,
      tables: null,
      context_line: false,
      joinTables: {},
      shapeField: [],
      previewData: null,
      currentLink: null,
      join_type_opened: false,
      tableColumns: null,
      saveTableName: "",
      saveModal: false,
      pubWorkForm: {
        outSite: "",
        outType: "",
        outTable: ""
      },
      rulePubWorkForm: {
        name: [
          {
            required: true,
            max: 20,
            message: "不能为空并不能超过20个字",
            trigger: "blur"
          }
        ],
        outType: [
          {
            required: true,
            validator: validateOutThemeItemId,
            trigger: "change"
          }
        ],
        outSite: [
          {
            required: true,
            validator: validateOutThemeItemId,
            trigger: "change"
          }
        ]
      },
      themeList: [],
      joinType: ["Full Join", "Inner Join", "Left Join", "Right Join"]
    };
  },
  created() {
    //处理面包屑
    this.$store.commit("setCrumbs", [
      {
        text: "创建合表",
        query: {},
        name: "joinTable"
      }
    ]);
    // 查询表数据
    oldServer.pageTables(
      {
        data: {},
        params: {
          containsView: false
        }
      },
      ({ data, errorCode }) => {
        this.loading = false;
        if (!errorCode && data.length) {
          this.tables = _.groupBy(data, function(n) {
            return n.schemaAlias || "default";
          });
        }
      },
      () => {
        this.loading = false;
      }
    );
    metaServer.getThemeList(
      {
        data: {}
      },
      (data, errorCode) => {
        this.themeList = data.data;
      }
    );
  },
  mounted() {
    // 初始化G6图形
    this.initG6();
    // 自定义 HTML 节点
    registerNode(G6, net, this.removeNode);
    // 初始化表格拖拽
    initDrage(net, (ev, domNode, type, isEnter) => {
      let { id, name, key, index } = domNode.dataset;
      if (type === "Edge") {
        let targetNode = ev.item.getModel(),
          dragData = this.tables[key][index],
          targetData = this.tables[targetNode.key][targetNode.index];
        this.newEdge(dragData, targetData);
      } else {
        this.newNode(
          ev,
          {
            id,
            name,
            key,
            index
          },
          isEnter
        );
      }
    });
  },
  directives: {},
  computed: {},
  filters: {},
  methods: {
    columChange() {},
    tableName(id) {
      return net.find(id).getModel().name;
    },
    saveTable() {
      if (_.size(this.joinTables) === 0) {
        return this.$Message.warning("请拖拽左侧表格至右边区域创建合表");
      } else {
        this.saveModal = true;
      }
    },
    pubWorkSubmit(e) {
	    if(e&&e.preventDefault) e.preventDefault();
      this.$refs["pubWorkForm"].validate(valid => {
        if (valid) {
          let postData = JSON.parse(JSON.stringify(this.pubWorkForm));
          this.preViewJoinTable(postData.outTable);
        }
      });
    },
    joinTypeChange(type) {
      this.currentLink.joinType = type;
      this.join_type_opened = false;
    },
    joinTypeActive() {
      this.join_type_opened = !this.join_type_opened;
    },
    resetRelation(label) {
      net.update(this.tableColumns.currenEdge, {
        label
      });
      this.join_type_opened = false;
      this.context_line = false;
      this.preViewJoinTable();
    },
    removeNode({ id, key, index, name }) {
      this.$Modal.confirm({
        title: "提示：",
        content: `<div>将删除此节点的子、父节点的关系</div><div>确认删除表节点：${name}</div>`,
        onOk: () => {
          net.remove(net.find(id));
          this.handleItemActive(key, index, false);
          delete this.joinTables[id];
          if (_.size(this.joinTables) === 0) {
            this.previewData = null;
            this.shapeField = [];
          } else {
            this.preViewJoinTable();
          }
          this.$Message.success("成功删除");
        }
      });
      this.context_line = false;
    },
    // removeChildren(id){
    //   let { edges } = net.save().source;
    // },
    handleItemActive(key, index, active) {
      this.tables[key].splice(index, 1, {
        ...this.tables[key][index],
        active
      });
    },
    handleHasNode(nodes, id) {
      if (_.findIndex(nodes, i => i.id === id) >= 0) {
        return this.$Message.warning("当前表已经存在!");
      }
    },
    handleHasEdge(source, target) {
      let { edges } = net.save().source;
      if (
        _.findIndex(
          edges,
          i =>
            (i.source === source && i.target === target) ||
            (i.source === target && i.target === source)
        ) >= 0 ||
        source === target
      ) {
        return this.$Message.warning("当前表已经存在!");
      }
    },
    newEdge(dragData, targetData) {
      let souceId = dragData.analyzeMapInfoUuid,
        targetId = targetData.analyzeMapInfoUuid;
      if (!this.handleHasEdge(souceId, targetId)) {
        this.getTableColumn(dragData, () => {
          net.add("edge", {
            shape: "arrow",
            label: "Left Join",
            target: targetId,
            source: souceId,
            relation: this.getRelation(targetData, dragData)
          });
          net.refresh();
        });
      }
    },
    getRelation(table, joinTable) {
      let tableList = this.joinTables[table.analyzeMapInfoUuid],
        joinTableList = this.joinTables[joinTable.analyzeMapInfoUuid],
        sameFiled = this.getSameFiled(tableList, joinTableList);
      return {
        col: sameFiled || tableList[0].colName,
        joinCol: sameFiled || joinTableList[0].colName,
        joinTable:
          joinTable.schema +
          ".`" +
          (joinTable.tableNameX || joinTable.tableName) +
          "`",
        joinType: 2,
        table: table.schema + ".`" + (table.tableNameX || table.tableName) + "`"
      };
    },
    getSameFiled(tableList, joinTableList) {
      var sameCol = "";
      tableList.forEach(function(tableCol) {
        joinTableList.forEach(function(joinTableCol) {
          if (tableCol.colName === joinTableCol.colName) {
            sameCol = tableCol.colName;
          }
        });
      });
      return sameCol;
    },
    getTableColumn(dragData, fn) {
      let id = dragData.analyzeMapInfoUuid,
        tableName = `${dragData.schema}.\`${dragData.tableNameX ||
          dragData.tableName}\``;
      oldServer.getAnalyzeTableColumns(
        {
          data: {},
          params: {
            analyzeMapInfoUuid: id
          }
        },
        data => {
          this.joinTables[id] = this.joinTables[id] || [];
          if (!this.joinTables[id].length) {
            _.forEach(data, column => {
              column.columnType = columnTypes[column.colDataType] || "NULL";
              column.tableName = tableName;
              column.analyzeTableUuid = id;
              if (column.colAnalyzeType === 0 || column.colAnalyzeType === 1) {
                this.joinTables[id].push(column);
              }
            });
          }
          fn && fn();
          this.preViewJoinTable();
        },
        () => {
          return this.$Message.warning("返回数据有误，创建合表失败");
        }
      );
    },
    preViewJoinTable(name) {
      if (_.size(this.joinTables) === 0) {
        return this.$Message.warning("请拖拽左侧表格至右边区域创建合表");
      }
      let joins = [],
        selcol = [],
        hasRepeat = false,
        temObj = {};
      if (!name) {
        this.shapeField = [];
        _.forEach(this.joinTables, (value, key) => {
          this.shapeField.splice(this.shapeField.length, 0, ...value);
        });
      }
      this.shapeField.forEach(i => {
        if (!temObj[i.colName + i.colDisplayName]) {
          temObj[i.colName + i.colDisplayName] = true;
          i.chosen = typeof i.chosen !== "undefined" ? i.chosen : true;
        } else {
          i.chosen = typeof i.chosen !== "undefined" ? i.chosen : false;
          hasRepeat = true;
        }
        if (i.chosen) {
          selcol.push({
            tableName: i.tableName,
            colName: i.colName,
            displayName: i.colDisplayName
          });
        }
      });
      let { edges } = net.save().source;
      joins = edges.map(item => {
        return item.relation;
      });
      let view = {
        name: name || "preview",
        selCols: selcol,
        advanceFilter: {
          compositeFilters: [],
          IsAnd: true,
          concreteFilters: []
        },
        joins: joins,
        isJoin: true
      };
      if (name && typeof name === "string") {
        oldServer.add(
          {
            data: {
              ...view,
              itemType: this.pubWorkForm.outType,
              themeItemId: this.pubWorkForm.outSite
            }
          },
          () => {
            this.$Message.success("保存成功");
            this.saveModal = false;
            this.pubWorkForm = {
              outSite: "",
              outType: "",
              outTable: ""
            };
          },
          () => {
            this.$Message.error("保存失败");
          }
        );
      } else {
        oldServer.preview(
          {
            data: view,
            params: {}
          },
          data => {
            _.forEach(this.shapeField, function(item, index) {
              if (item.chosen === false && data.RowDataSet.length) {
                _.forEach(data.RowDataSet, function(rowData) {
                  rowData.splice(index, 0, "");
                });
              }
            });
            this.previewData = data;
          },
          () => {
            this.previewData = null;
            if (hasRepeat) {
              this.$Message.error("预览失败，字段重复");
            } else {
              this.$Message.error("预览失败");
            }
          }
        );
      }
      // console.log("preView");
    },
    newNode(ev, { id, name, key, index }, isEnter) {
      let { nodes } = net.save().source;
      let dragData = this.tables[key][index];
      if (!this.handleHasNode(nodes, id)) {
        this.handleItemActive(key, index, true);
        net.add("node", {
          shape: "customNode",
          id,
          key,
          index,
          name,
          x: isEnter ? ev.x + 300 : ev.x,
          y: ev.y
        });
        net.refresh();
        if (!nodes.length) {
          this.getTableColumn(dragData);
        }
        if (!isEnter && nodes.length) {
          // 未指定目标表，则默认join最后添加的表
          let { nodes } = net.save().source;
          let targetNode = nodes[nodes.length - 2];
          let targetData = this.tables[targetNode.key][targetNode.index];
          this.newEdge(dragData, targetData);
        }
      }
    },
    handleNetClick(ev) {
      if (G6.Util.isEdge(ev.item)) {
        let currentLink = document.getElementById("currentLink"),
          model = ev.item.getModel();
        currentLink.style.left = ev.x + "px";
        currentLink.style.top = ev.y + "px";
        this.currentLink = model.relation;
        this.context_line = true;
        this.tableColumns = {
          tableName: net.find(model.target).getModel().name,
          joinTableName: net.find(model.source).getModel().name,
          tableCol: this.joinTables[model.target],
          joinTableCol: this.joinTables[model.source],
          currenEdge: ev.item
        };
        // console.log(this.tableColumns);
      } else {
        this.context_line = false;
      }
    },
    initG6() {
      // 第四步：配置G6画布
      net = new G6.Net({
        id: "chartBox", // 容器ID
        fitView: "autoSize",
        height: document.getElementById("chartBox").offsetHeight
      });
      net.removeBehaviour(["wheelZoom", "resizeNode", "clickActive"]);
      net
        .node()
        .shape("customNode")
        .style({
          stroke: null // 去除默认边框
        });
      // 第三部 渲染
      net.render();
      net.on("click", ev => this.handleNetClick(ev));
      // 第五步：载入数据
      // net.source(this.tableData.nodes, this.tableData.edges);
    },
    // 菜单激活状态
    handleTableActive(item, key) {
      let subTable = [...item];
      subTable.active = !item.active;
      this.tables[key] = subTable;
    }
  }
};
</script>

<style scoped lang='less'>
.joinTable {
  height: 100%;
  .panelTitle {
    margin-bottom: 10px;
    height: 21px;
    line-height: 21px;
    position: absolute;
    padding-left: 10px;
    border-left: 2px solid #4ab9ff;
    font-size: 12px;
    color: #4a4b50;
    top: 0;
    &.saveBtn {
      right: 0;
      border-left: 0;
    }
  }
  .tables {
    width: 20%;
    height: 100%;
    padding-right: 20px;
    position: relative;
    height: 100%;
    float: left;
    .tableCont {
      height: 100%;
      padding-top: 31px;
      .tableList {
        background-color: #fcfcfc;
        border: solid 1px #efefef;
        border-radius: 5px;
        height: 100%;
        overflow-y: auto;
        -webkit-user-select: none;
        user-select: none;
        -ms-user-select: none;
        .loading {
          display: flex;
          justify-content: center;
          height: 100%;
          align-items: center;
          font-size: 12px;
          color: #666666;
          .ivu-spin-text {
            color: #999999;
          }
          .demo-spin-icon-load {
            animation: ani-demo-spin 1s linear infinite;
          }
          @keyframes ani-demo-spin {
            from {
              transform: rotate(0deg);
            }
            50% {
              transform: rotate(180deg);
            }
            to {
              transform: rotate(360deg);
            }
          }
          .demo-spin-col {
            position: relative;
            width: 100%;
          }
        }
        .item {
          margin: 0 10px;
          h2 {
            font-size: 12px;
            cursor: pointer;
            line-height: 35px;
            display: block;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            text-indent: 10px;
            &:hover {
              background-color: #f8f9fb;
            }
            i {
              margin-right: 10px;
            }
          }
          ul {
            li {
              padding-left: 10px;
              cursor: pointer;
              text-indent: 10px;
              display: inline-block;
              line-height: 28px;
              width: 100%;
              font-size: 12px;
              margin-bottom: 5px;
              &:hover {
                background-color: #f8f9fb;
              }
              &.active {
                box-shadow: 0 0 0 1px #eeeeee;
                background-color: #f8f9fb;
                border-radius: 2px;
              }
              i {
                font-size: 12px;
                color: #7bbfea;
                vertical-align: middle;
                line-height: 28px;
                margin-right: 10px;
              }
            }
          }
        }
      }
    }
  }
  .container {
    width: 80%;
    height: 100%;
    overflow: hidden;
    .chartBox {
      height: 40%;
      padding-top: 31px;
      position: relative;
      .chartCont {
        box-shadow: 0 0 1px 0 #ccc;
        border: solid 1px #efefef;
        border-radius: 5px;
        height: 100%;
        position: relative;
        .merge-field-select {
          box-shadow: 0 0 24px rgba(7, 46, 77, 0.18);
          position: absolute;
          background: white;
          width: 445px;
          z-index: 11;
          font-size: 12px;
          user-select: none;
          .head-select {
            padding: 10px 15px;
            border-bottom: solid 1px #eee;
          }
          .join-type {
            display: inline-block;
            position: relative;
            width: 95px;
            border-bottom: 1px solid #1693f7;
            i {
              vertical-align: middle;
            }
            ul {
              padding: 0;
              position: absolute;
              background: white;
              box-shadow: rgb(204, 204, 204) 0px 1px 1px;
              padding: 2px;
              li {
                padding: 5px;
                cursor: pointer;
                &.selected {
                  border: 1px dashed #1693f7;
                }
                .join {
                  display: inline-block;
                  height: 12px;
                  width: 12px;
                }
                .left-join {
                  background: url("../../assets/images/join.png");
                }
                .inner-join {
                  background: url("../../assets/images/join.png") 24px 0;
                }
                .full-join {
                  background: url("../../assets/images/join.png") 36px 0;
                }
                .right-join {
                  background: url("../../assets/images/join.png") 12px 0;
                }
              }
            }
          }
          .left-column {
            padding: 5px;
            text-align: center;
            .head {
              width: 100%;
              height: 30px;
              padding-right: 0;
              margin-bottom: 5px;
              span {
                width: 50%;
                padding: 0 2.5%;
                line-height: 30px;
                text-align: left;
                float: left;
              }
            }
            select {
              width: 46%;
              border: 0 none;
              border-bottom: solid 1px #1693f7;
              border-radius: 0;
              background: #fff;
              color: #666;
              font-size: 12px;
              outline: none;
            }
          }
          .action-group {
            text-align: center;
            padding: 10px;
            text-align: right;
            a {
              padding: 0 8px;
              text-decoration: none;
            }
          }
        }
      }
    }
    .joinTableFilter {
      height: 58.5%;
      margin-top: 1%;
      position: relative;
      padding-top: 31px;
      .tablesCont {
        height: 100%;
        border: 1px solid #dadbdd;
        border-radius: 5px;
      }
    }
  }
}
.myTable {
  width: 100%;
  height: 100%;
  overflow: auto;
  .nodata {
    text-align: center;
    font-size: 12px;
    color: #666666;
    padding: 50px 0;
  }
  table {
    width: 100%;
    border-collapse: collapse; // border: 1px solid #dadbdd;
    tr {
      line-height: 20px;
      &:nth-child(2n) {
        background-color: #f9f9f9;
      }
      th {
        background-color: #fcfcfc;
        font-weight: normal;
        padding: 5px 0 !important;
        font-weight: bold;
        user-select: none;
        &.tableName {
          background-color: #f9f9f9;
          text-align: left;
          text-indent: 2em;
        }
      }
      th,
      td {
        min-width: 150px;
        padding: 0 10px;
        text-align: left;
        max-width: 400px;
        padding: 0;
        text-align: center;
        border: solid 1px #f0f0f0;
        font-size: 12px;
      }
    }
  }
}
</style>
