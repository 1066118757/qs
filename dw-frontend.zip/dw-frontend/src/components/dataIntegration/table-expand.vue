/**
* Created by zhaowei on 2017/12/22.
*/

<style scoped>
  .expand-row {
    margin-bottom: 16px;
  }
</style>
<template>
  <div>
    <p v-for="(item,i) in data" :key="i">{{item}}</p>
  </div>
</template>
<script>
  export default {
    props: {
      row:null
    },
    data(){
      return{
        data:[]
      }
    },
    created() {
      function isArray(o){
        return Object.prototype.toString.call(o)=='[object Array]';
      }
      if(!isArray(this.row)){
        this.data.push(this.row)
      }else {
        for(var i in this.row){
          if(!isArray(this.row[i])){
            this.data.push(this.row[i])
          }
        }
        this.row.stackTrace.forEach(item=>{
          this.data.push(item.fileName+"("+item.lineNumber+")___"+item.className+"___"+item.methodName+"___"+item.nativeMethod)
        });
      }

    }
  };
</script>
