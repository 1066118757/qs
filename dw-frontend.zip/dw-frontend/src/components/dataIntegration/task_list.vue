<template>
  <div class="data_integration_task_list">
    <v-Header :text="text">

      <div style="margin-top:20px">
        <span>任务名称</span>
        <Input placeholder="输入任务名称进行模糊查询" v-model="name" style="width: 200px;margin-right: 10px;"/>
        <span>输入表</span>
        <Input placeholder="输入表" v-model="inItemName" style="width: 200px;margin-right: 10px;"/>
        <span>输出表</span>
        <Input placeholder="输出表" v-model="outItemName" style="width: 200px;margin-right: 10px;"/>
        <Button type="ghost" @click="init()">查询</Button>
      </div>

    </v-Header>
    <Table :columns="tableHeaders" :data="tableData"></Table>
    <Page
      :total="total"
      show-elevator
      show-total
      placement="top"
      @on-change="init"
    ></Page>
    <Modal
      v-model="pubWorkModal"
      title="部署流程"
      width="600"
      class="no_footer dsrwBox">
      <div>
        <Form ref="pubWorkForm" :model="pubWorkForm" :rules="rulePubWorkForm" :label-width="90">
          <FormItem label="任务名称" prop="name">
            <Input v-model="pubWorkForm.name" placeholder="请输入任务名称"></Input>
          </FormItem>
          <FormItem  label="输出表名" prop="outItemName">
            <Input disabled v-model="pubWorkForm.outItemName" placeholder="输出表名"></Input>
          </FormItem>
          <FormItem label="输出表类型" prop="outItemType">
            <Select disabled v-model="pubWorkForm.outItemType" style="width:280px">
              <Option v-for="item in $store.state.meta.metaType" :value="item.key" :key="item.key">{{ item.text }}
              </Option>
            </Select>
          </FormItem>
          <FormItem label="输出位置" prop="outThemeItemId">
            <Select disabled v-model="pubWorkForm.outThemeItemId" style="width:200px" placeholder="输出位置">
              <Option v-for="item in themeList"
                      :value="item.themeItemListVos[1].id" :key="item.themeItemListVos[1].id">{{ item.name }}
              </Option>
            </Select>
          </FormItem>

          <div class="dsrw">
            <FormItem label="频率执行" style="display:inline-block; width:200px;">
              <!--<i-switch v-model="pubWorkForm.type" @on-change="change"></i-switch>-->
            </FormItem>
            <div class="itm" v-for="item in pubWorkForm.cronCode" v-if="pubWorkForm.type">
              <v-frequency v-model="item.data"></v-frequency>
              <Button size="small" @click="delTime(item)" type="error" shape="circle" icon="minus"></Button>
            </div>
            <Button @click="addTime"
                    style="margin-left:20px; width:72px;border-color:#6ec7ff;color:#6ec7ff">追加
            </Button>
          </div>
          <div class="dsrw">
            <FormItem label="定时执行" style="display:inline-block; width:200px;">
              <!--<i-switch v-model="pubWorkForm.type" @on-change="change"></i-switch>-->
            </FormItem>
            <div class="itm" v-for="item in pubWorkForm.cronCode1">
              <DatePicker v-model="item.data" type="datetime" placeholder="选择时间"
                          :options="options">
              </DatePicker>
              <Button size="small" @click="delTime1(item)" type="error" shape="circle" icon="minus"></Button>
            </div>
            <Button @click="addTime1"
                    style="margin-left:20px; width:72px;border-color:#6ec7ff;color:#6ec7ff">追加
            </Button>
          </div>
          <FormItem label="优先级" prop="outItemName">
            <InputNumber :max="10" :min="0" v-model="pubWorkForm.priority"></InputNumber>
          </FormItem>
          <FormItem label="短信提醒">
            <i-switch v-model="pubWorkForm.isNote" @on-change="change"></i-switch>
            <Input v-if="pubWorkForm.isNote" style="width: 200px;"
                   v-model="pubWorkForm.phone"
                   placeholder="电话号码"></Input>
          </FormItem>
          <FormItem label="邮件提醒">
            <i-switch v-model="pubWorkForm.isEmail" @on-change="change"></i-switch>
            <Input v-if="pubWorkForm.isEmail" style="width: 200px;" v-model="pubWorkForm.email"
                   placeholder="邮箱"></Input>
          </FormItem>
          <FormItem label="依赖任务" prop="dependence">
            <Select v-model="pubWorkForm.dependence" placeholder="请选择依赖任务" style="width: 280px">
              <Option :value="item.id" v-for="item in dependenceList" :key="item.id">{{item.name}}</Option>
            </Select>
          </FormItem>
        </Form>
      </div>
      <div style="text-align:center; margin-top:20px; margin-bottom:50px;">
        <Button size="large" type="ghost" style="width: 130px" @click="pubWorkModal = false">取消</Button>
        <Button size="large" type="primary" style="width: 130px" @click="pubWorkSubmit" :loading="loading.modalBtn">提交
        </Button>
      </div>
    </Modal>

    <v-affirm :model.sync="affirm" :del="true" @click="deleteItem"></v-affirm>
  </div>
</template>

<script>
import integrationServer from "rs/integration";
import connectServer from "rs/connect";
import metaServer from "rs/meta";
import vFrequency from "cmpts/common/frequency";
export default {
  props: {},
  components: { vFrequency },
  data() {
    const validateOutThemeItemId = (rule, value, callback) => {
      if (!value) {
        callback(new Error("必须选项"));
      } else {
        callback();
      }
    };
    return {
      dependenceList: [],
      algorithmList: [],
      tableList: [],
      sfModal: false,
      activeEdit: {},
      loading: {
        modalBtn: false
      },
      options: {
        disabledDate(date) {
          return date && date.valueOf() < Date.now() - 86400000;
        }
      },
      themeList: [],
      pubWorkModal: false,
      pubWorkForm: {
        dependence: "",
        outThemeItemId: null,
        cronCode: [{ data: "" }],
        cronCode1: [{ data: new Date() }],
        type: true,
        priority: 0,
        name: "",
        isEmail: true,
        phone: "",
        email: "",
        outItemName: "",
        isNote: true
      },
      rulePubWorkForm: {
        name: [
          {
            required: true,
            max: 20,
            message: "不能为空并不能超过20个字",
            trigger: "blur"
          }
        ],
        outItemName: [
          {
            required: true,
            max: 20,
            message: "不能为空并不能超过20个字",
            trigger: "blur"
          }
        ],
        outThemeItemId: [
          {
            required: true,
            validator: validateOutThemeItemId,
            trigger: "change"
          }
        ],
        outItemType: [
          {
            required: true,
            validator: validateOutThemeItemId,
            trigger: "change"
          }
        ]
      },

      name: null,
      inItemName: null,
      outItemName: null,
      total: 0,
      text: "任务管理列表",
      search: "",
      tableHeaders: [
        {
          title: "序号",
          type: "index"
        },
        {
          title: "任务名称",
          key: "name",
          render: (h, { row: { name, id } }) => {
            return h(
              "a",
              {
                style: {
                  color: "#57a3f3"
                },
                on: {
                  click: () => {
                    this.$router.push({
                      name: "integrationTaskDetail",
                      query: { name, id }
                    });
                  }
                }
              },
              name
            );
          }
        },
        {
          title: "原始表",
          key: "inItemName"
        },
        {
          title: "输出表",
          key: "outItemName"
        },
        {
          title: "创建人",
          key: "createUserName"
        },
        {
          title: "启动时间",
          key: "startTime",
          render(h, { row: { nearStartTime } }) {
            return h("span", Vue.filter("date")(nearStartTime));
          }
        },
        {
          title: "停止时间",
          key: "endTime",
          render(h, { row: { nearEndTime } }) {
            if (nearEndTime) {
              return h("span", Vue.filter("date")(nearEndTime));
            } else {
              return "";
            }
          }
        },
        {
          title: "执行结果",
          width: 120,
          className: "zjxg",
          key: "status ",
          render(h, { row: { nearResult } }) {
            return h(
              "span",
              {
                class: "st status" + nearResult
              },
              Vue.filter("codeName")(nearResult, 10)
            );
          }
        },
        {
          title: "执行方式",
          key: "type",
          render(h, { row: { type } }) {
            return h("span", Vue.filter("codeName")(type, 11));
          }
        },
        {
          title: "操作",
          width: 180,
          render: (h, { row: { id }, row }) => {
            return h(
              "div",
              {
                class: "action_wrapper"
              },
              [
                h(
                  "span",
                  {
                    on: {
                      click: e => {
                        if (e && e.preventDefault) e.preventDefault();
                        this.$router.push({
                          name: "integrationTaskDetail",
                          query: { name, id }
                        });
                      }
                    }
                  },
                  "日志"
                ),
                h(
                  "span",
                  {
                    on: {
                      click: e => {
                        if (e && e.preventDefault) e.preventDefault();
                        this.delItem = id;
                        this.affirm = true;
                      }
                    }
                  },
                  "删除"
                ),
                h(
                  "span",
                  {
                    on: {
                      click: e => {
                        if (e && e.preventDefault) e.preventDefault();
                        this.activeEdit = row;
                        var cronCode = JSON.parse(row.cronCode);

                        this.pubWorkForm = {
                          id: row.id,
                          status: row.status,
                          outThemeItemId: row.outThemeItemId,
                          cronCode: [{ data: "" }],
                          cronCode1: [],
                          type: row.type,
                          inItemName: row.inItemName,
                          inItemId: row.inItemId,
                          recordId: row.recordId,
                          name: row.name,
                          isEmail: row.isEmail,
                          dependence:
                            row.dependenceDisplayVO &&
                            row.dependenceDisplayVO.etlJobs[0]
                              ? row.dependenceDisplayVO.etlJobs[0].id
                              : "",
                          email: row.email,
                          phone: row.phone,
                          outItemName: row.outItemName,
                          outItemType: row.outItemType,
                          isNote: row.isNote
                        };
                        cronCode.forEach(item => {
                          if (item.time) {
                            this.pubWorkForm.cronCode1.push({
                              data: item.time
                            });
                          } else {
                            this.pubWorkForm.cronCode.push({ data: item });
                          }
                        });
                        this.pubWorkModal = true;
                      }
                    }
                  },
                  "编辑"
                )
              ]
            );
          }
        }
      ],
      tableData: [],
      affirm: false,
      delItem: ""
    };
  },
  created() {
    this.setCrumbs();
    this.init();
    this.getDependenceList();
  },
  directives: {},
  computed: {
    minPageSize() {
      return Math.max(
        Math.floor((this.$store.state.screenHeight - 377) / 41),
        10
      );
    }
  },
  filters: {},
  methods: {
    //获取依赖表
    getDependenceList() {
      connectServer.getYl({ params: { params3: "etl" } }, ({ data }) => {
        this.dependenceList = data;
      });
    },
    deleteItem() {
      this.affirm = false;
      integrationServer.clearTaskDelete(
        { params: { id: this.delItem } },
        data => {
          this.init();
        }
      );
    },
    addTime() {
      this.pubWorkForm.cronCode.push({});
    },
    addTime1() {
      this.pubWorkForm.cronCode1.push({ data: new Date() });
    },
    delTime(item) {
      this.pubWorkForm.cronCode.forEach((obj, i) => {
        if (obj == item) this.pubWorkForm.cronCode.splice(i, 1);
      });
    },
    delTime1(item) {
      this.pubWorkForm.cronCode1.forEach((obj, i) => {
        if (obj == item) this.pubWorkForm.cronCode1.splice(i, 1);
      });
    },
    // 发布
    pubWorkSubmit(e) {
      if (e && e.preventDefault) e.preventDefault();
      this.$refs["pubWorkForm"].validate(valid => {
        if (valid) {
          let postData = JSON.parse(JSON.stringify(this.pubWorkForm));
          if (
            this.pubWorkForm.isNote &&
            !/^1[3|4|5|8|7][0-9]\d{8}$/.test(postData.phone)
          ) {
            this.$Notice.error({
              title: "验证失败",
              desc: "电话号码不正确"
            });
            return;
          }
          if (
            this.pubWorkForm.isEmail &&
            !/^[0-9A-Za-z][\.-_0-9A-Za-z]*@[0-9A-Za-z]+(\.[0-9A-Za-z]+)+$/.test(
              postData.email
            )
          ) {
            this.$Notice.error({
              title: "验证失败",
              desc: "邮箱格式不正确"
            });
            return;
          }

          postData.cronCode.forEach((item, i) => {
            postData.cronCode[i] = item.data;
          });
          postData.cronCode1.forEach((item, i) => {
            postData.cronCode.push({ time: new Date(item.data).getTime() });
          });
          if (!postData.cronCode.length) {
            this.$Notice.error({
              title: "创建失败",
              desc: "频率和定时至少要填一项"
            });
            return;
          }
          postData.cronCode = JSON.stringify(postData.cronCode);

          if (this.pubWorkForm.dependence) {
            postData.dependence = JSON.stringify({
              etlJobs: [this.pubWorkForm.dependence],
              clearJobs: []
            });
          }

          integrationServer.clearTaskUpdate(
            { data: postData },
            ({ data, errorCode }) => {
              if (errorCode == 0) {
                // 修改成功
                this.pubWorkModal = false;
                this.$router.push({ name: "integrationTaskList" });
                this.$Message.success("新增成功");
                this.init();
              } else {
                this.$Notice.error({
                  title: "创建失败",
                  desc: data
                });
              }
            }
          );
        } else {
          this.$Notice.error({
            title: "验证失败",
            desc: "认真填写内容"
          });
        }
      });
    },
    getThemeList() {
      metaServer.getThemeList({ data: {} }, (data, errorCode) => {
        this.themeList = data.data;
      });
    },
    change() {},
    setCrumbs() {
      this.$store.commit("setCrumbs", [
        { text: "任务管理", name: "integrationTaskList" }
      ]);
    },
    init(num) {
      this.getThemeList();
      // 获取数据
      integrationServer.clearTaskList(
        {
          data: {
            outItemName: this.outItemName,
            name: this.name,
            inItemName: this.inItemName
          },
          params: { params3: num || 1, params4: this.minPageSize }
        },
        ({ data, errorCode }) => {
          if (!errorCode) {
            this.tableData = data.pageData;
            this.total = data.totalCount;
          }
        }
      );
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang='less'>
.data_integration_task_list {
  position: relative;
  padding-bottom: 42px;
  .action_wrapper {
    color: #2b85e4;
  }
  .header_right {
    float: right;
  }

  .ivu-page {
    position: absolute;
    right: 30px;
    bottom: 0;
  }

  .action_wrapper {
    /*color: red;*/
  }

  .zjxg {
    .st {
      display: inline-block;
      height: 20px;
      padding: 0 15px;
      background: #ededed;
      border-radius: 100px;
      color: #fff;
    }

    .status1002 {
      background: #29bc6e;
    }

    .status1003 {
      background: #ea4124;
    }

    .status1001 {
      background: #348eed;
    }
  }
}
.dsrwBox {
  .dsrw {
    position: relative;
    padding: 0 100px 0 80px;
    min-height: 50px;

    .itm {
      margin-bottom: 5px;

      > div {
        display: inline-block;
      }

      .ivu-btn-circle {
        min-width: auto;
      }
    }
    > .ivu-form-item {
      position: absolute;
      left: 0;
      top: 0;
    }

    > .ivu-btn {
      position: absolute;
      right: 0;
      top: 0;
    }
  }
}
</style>
