<template>
  <div class="data_integration_task_list">
    <v-Header :text="text">
      <div class="header_right">
        <Button icon="plus" type="info" size="large" shape="circle" @click="newSf">新增算法任务</Button>
      </div>
      <div style="margin-top:20px">
        <span>任务名称</span>
        <Input placeholder="输入任务名称进行模糊查询" v-model="name" style="width: 200px;margin-right: 10px;"/>
        <!--<span>输入表</span>
        <Input placeholder="输入表" v-model="inItemName" style="width: 200px;margin-right: 10px;"/>
        <span>输出表</span>
        <Input placeholder="输出表" v-model="outItemName" style="width: 200px;margin-right: 10px;"/>-->
        <Button type="ghost" @click="init()">查询</Button>
      </div>

    </v-Header>
    <Table :columns="tableHeaders" :data="tableData"></Table>
    <Page
      :total="total"
      show-elevator
      show-total
      placement="top"
      @on-change="init"
    ></Page>
    <Modal
      v-model="sfModal"
      title="算法任务"
      width="600"
      class="no_footer dsrwBox">
      <div>
        <Form ref="pubWorkForm" :model="pubWorkForm" :rules="rulePubWorkForm" :label-width="90">
          <FormItem label="任务名称" prop="name">
            <Input v-model="pubWorkForm.name" placeholder="请输入任务名称"></Input>
          </FormItem>
          <FormItem label="算法选择" prop="sparkJobId">
            <Select v-model="pubWorkForm.sparkJobId" style="width:200px" placeholder="请选择">
              <Option v-for="item in algorithmList"
                      :value="item.id" :key="item.id">{{ item.name }}
              </Option>
            </Select>
          </FormItem>
          <FormItem label="输入表名" prop="inTable">
            <Select v-model="pubWorkForm.inTable" style="width:200px" placeholder="请选择">
              <Option v-for="item in tableList" :value="item.displayName"
                      :key="item.displayName">{{ item.displayName }}
              </Option>
            </Select>
          </FormItem>
          <FormItem label="输出表名" prop="outTable">
            <!-- <Input :disabled="!!pubWorkForm.id" v-model="pubWorkForm.outTable" placeholder="输出表名"></Input> -->
            <Select :disabled="!!pubWorkForm.id" v-model="pubWorkForm.outTable" style="width:200px" placeholder="请选择">
              <Option v-for="item in tableList" :value="item.displayName"
                      :key="item.displayName">{{ item.displayName }}
              </Option>
            </Select>
          </FormItem>
          <FormItem label="输出表类型" prop="outType">
            <Select :disabled="!!pubWorkForm.id" v-model="pubWorkForm.outType" style="width:280px">
              <Option v-for="item in $store.state.meta.metaType" :value="item.key" :key="item.key">{{ item.text }}
              </Option>
            </Select>
          </FormItem>

          <!-- <FormItem label="输出位置" prop="outSite">
            <Select :disabled="!!pubWorkForm.id" v-model="pubWorkForm.outSite" style="width:200px" placeholder="请选择">
              <Option v-for="item in themeList"
                      :value="item.themeItemListVos[1].id" :key="item.themeItemListVos[1].id">{{ item.name }}
              </Option>
            </Select>
          </FormItem> -->

        </Form>
      </div>
      <div style="text-align:center; margin-top:20px; margin-bottom:50px;">
        <Button size="large" type="ghost" style="width: 130px" @click="sfModal = false">取消</Button>
        <Button size="large" type="primary" style="width: 130px" @click="pubWorkSubmit" :loading="loading.modalBtn">提交
        </Button>
      </div>
    </Modal>
    <v-affirm :model.sync="affirm" :del="true" @click="deleteItem"></v-affirm>
  </div>
</template>

<script>
  import integrationServer from "rs/integration"
  import sparkJobServer from "rs/sparkJob"
  import oldServer from "rs/oldServer"
  import metaServer from "rs/meta"
  import vFrequency from "cmpts/common/frequency"
  export default {
    props: {},
    components: {vFrequency},
    data() {
      const validateOutThemeItemId = (rule, value, callback) => {
        if (!value) {
          callback(new Error('必须选项'));
        } else {
          callback();
        }
      };
      return {
        addTable:{
          "detailAddVoList": [{
            "colComment": "result",
            "colDisplayname": "result",
            "colName": "result",
            "colType": 301,
            "index": 1
          }],
          "name": "1234",
          "purpose": "alg execute result",
          "type": 201,
          "themeItemId": 2126964583694336
        },
        algorithmList: [],
        tableList: [],
        sfModal: false,
        loading: {
          modalBtn: false,
        },
        options: {
          disabledDate (date) {
            return date && date.valueOf() < Date.now() - 86400000;
          }
        },
        themeList: [],
        pubWorkModal: false,
        pubWorkForm: {
          sparkJobId: "",
          name: "",
          args: "",
          outSite: "",
          outType: "",
          outTable: "",
          inTable: ""
        },
        rulePubWorkForm: {
          name: [
            {required: true, max: 20, message: '不能为空并不能超过20个字', trigger: 'blur'}
          ],
          outTable: [
            {required: true, max: 20, message: '不能为空并不能超过20个字', trigger: 'blur'}
          ],
          inTable: [
            {required: true, validator: validateOutThemeItemId, trigger: 'change'}
          ],
          outType: [
            {required: true, validator: validateOutThemeItemId, trigger: 'change'}
          ],
          outSite: [
            {required: true, validator: validateOutThemeItemId, trigger: 'change'}
          ],
          sparkJobId: [
            {required: true, validator: validateOutThemeItemId, trigger: 'change'}
          ]
        },

        name: null,
        inItemName: null,
        outItemName: null,
        total: 0,
        text: "任务管理列表",
        search: '',
        tableHeaders: [
          {
            title: '序号',
            type: "index"
          },
          {
            title: '任务名称',
            key: 'name'
          },
          {
            title: '原始表',
            key: 'inTable',
          },
          {
            title: '输出表',
            key: 'outTable',
          },
          {
            title: '创建人',
            // key: 'createBy'
            key: 'createByName'
          },
          {
            title: '操作',
            width:230,
            render: (h, {row: {id}, row}) => {
              let arr = [
                h("span", {
                  on: {
                    click: (e) => {
                    	if(e&&e.preventDefault) e.preventDefault();
                      sparkJobServer.jobExecute({
                        data: {},
                        params: {
                          params3: id
                        }
                      }, (data) => {
                        if(data.code==201){
                          this.$Message.success("运行成功");
                          this.init();
                        }
                      });
                    }
                  }
                }, "运行"),
                h("span", {
                  on: {
                    click: (e) => {
	                    if(e&&e.preventDefault) e.preventDefault();
                      this.delItem = id;
                      this.affirm = true;

                    }
                  }
                }, "删除"),
                h("span", {
                  on: {
                    click: (e) => {
	                    if(e&&e.preventDefault) e.preventDefault();
                      this.getTables();
                      this.pubWorkForm = row;
                      this.sfModal = true;
                    }
                  }
                }, "编辑")
              ];
              if(row.batchId){
                  arr.push(h("span", {
                    on: {
                      click: (e) => {
	                      if(e&&e.preventDefault) e.preventDefault();
                        this.$router.push({name: "jobDetail", query: {name:row.name,batchId:row.batchId, id:id}})
                      }
                    }
                  }, "日志"))
              }

              return h("div", {
                class: "action_wrapper",
              }, arr)
            }
          },
        ],
        tableData: [],
        affirm: false,
        delItem: ""
      }
    },
    created() {
      this.setCrumbs();
      this.init();
      this.getThemeList();


    },
    directives: {},
    computed: {
      minPageSize(){
        return Math.max(Math.floor((this.$store.state.screenHeight - 377) / 41), 10);
      }
    },
    filters: {},
    methods: {
      newSf(){
        this.pubWorkForm ={
          sparkJobId: "",
          name: "",
          args: "",
          outSite: "",
          outType: "",
          outTable: "",
          inTable: ""
        };
        this.getTables();
        this.sfModal = true;
      },
      getTables(){
        if (!this.tableList.length) {
          oldServer.pageTables({
              data: {},
              params: {}
            }, ({data, errorCode}) => {
              if (!errorCode && data.length) {

                this.tableList = data;
              }
            },
            () => {

            }
          );
        }
        if (!this.algorithmList.length) {
          sparkJobServer.getSparkJobList({
            data: {},
            params: {
              params3: 1,
              params4: 1000
            }
          }, ({data}) => {
            this.algorithmList = data.data;
          });
        }
      },
      deleteItem(){
        this.affirm = false;
        sparkJobServer.jobDelete({data: {ids: [this.delItem]}}, data => {
          this.init();
        });
      },
      // 发布
      pubWorkSubmit(e){
	      if(e&&e.preventDefault) e.preventDefault();
        this.$refs['pubWorkForm'].validate((valid) => {
          if (valid) {
            let postData = JSON.parse(JSON.stringify(this.pubWorkForm));

            postData.args = postData.inTable + "," + postData.outTable;
            this.algorithmList.forEach(item => {
              if (item.id == postData.sparkJobId && item.args) {
                postData.args += ',' + item.args;
              }
            });
            postData.rsvColumn = {
              outType: postData.outType,
              outSite: postData.outSite
            };
            postData.rsvColumn = JSON.stringify(postData.rsvColumn);

            if (postData.id) {
              sparkJobServer.jobUpdate({data: postData}, (data) => {
                if (data == 'success') {
                  // 修改成功
                  this.sfModal = false;
                  this.$Message.success("修改成功");
                  this.init();
                } else {
                  this.$Notice.error({
                    title: '修改失败',
                    desc: data
                  });
                }
              });
            } else {
              this.addTable.name=this.pubWorkForm.outTable;
              this.addTable.type=this.pubWorkForm.outType;
              this.addTable.themeItemId=this.pubWorkForm.outSite;
              integrationServer.addAlls({data: this.addTable}, (data) => {
                if (data.errorCode == '9998') {
                  this.$Notice.error({
                    title: '失败',
                    desc: "输出表名已经存在，重新输入！"
                  });
                } else {
                  sparkJobServer.jobAdd({data: postData}, (data) => {
                    if (data == 'success') {
                      // 修改成功
                      this.sfModal = false;
                      this.$Message.success("新增成功")
                      this.init();
                    } else {
                      this.$Notice.error({
                        title: '创建失败',
                        desc: data
                      });
                    }
                  });
                }
              });
            }

          } else {
            this.$Notice.error({
              title: '验证失败',
              desc: '认真填写内容'
            });
          }
        })


      },
      getThemeList(){
        metaServer.getThemeList({data: {}}, (data, errorCode) => {
          this.themeList = data.data;
        })
      },
      change(){
      },
      setCrumbs(){
        this.$store.commit('setCrumbs', [
          {text: "任务管理", name: "integrationTaskList"}
        ]);
      },
      init(num){
        // 获取数据
        sparkJobServer.jobQueryPage({
          data: {
            name: this.name
          }, params: {params3: num || 1, params4: this.minPageSize}
        }, ({data, errorCode}) => {
          if (!errorCode) {
            data.data.forEach(item => {
              let args = item.args.split(",");
              item.inTable = args[0];
              item.outTable = args[1];
              item.args = "";
              args.forEach((it, i) => {
                if (i > 1) {
                  let a = ',';
                  if (i === args.length - 1) a = "";
                  item.args += it + a;
                }
              })

              if (item.rsvColumn) {
                item.rsvColumn = JSON.parse(item.rsvColumn);
                if (item.rsvColumn.outType) item.outType = item.rsvColumn.outType;
                if (item.rsvColumn.outSite) item.outSite = item.rsvColumn.outSite;
              }
            });

            this.tableData = data.data;
            this.total = data.totalItems;
          }
        });
      },
    }
  };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang='less'>

  .data_integration_task_list {
    position: relative;
    padding-bottom: 42px;
    .action_wrapper{ color: #2b85e4;}
  .header_right {
    float: right;
  }

  .ivu-page {
    position: absolute;
    right: 30px;
    bottom: 0;
  }

  .action_wrapper {
    /*color: red;*/
  }

  .zjxg {

  .st {
    display: inline-block;
    height: 20px;
    padding: 0 15px;
    background: #ededed;
    border-radius: 100px;
    color: #fff;
  }

  .status1002 {
    background: #29BC6E;
  }

  .status1003 {
    background: #EA4124;
  }

  .status1001 {
    background: #348EED;
  }

  }

  }
  .dsrwBox {

  .dsrw {
    position: relative;
    padding: 0 100px 0 80px;
    min-height: 50px;

  .itm {
    margin-bottom: 5px;

  >
  div {
    display: inline-block;
  }

  .ivu-btn-circle {
    min-width: auto;
  }

  }
  >
  .ivu-form-item {
    position: absolute;
    left: 0;
    top: 0;
  }

  >
  .ivu-btn {
    position: absolute;
    right: 0;
    top: 0;
  }

  }
  }
</style>
