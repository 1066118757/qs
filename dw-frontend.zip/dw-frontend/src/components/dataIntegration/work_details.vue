<template>
  <div class="data_integration_work_details">
    <v-Header :text="mainData.name">
      <Icon style="margin-left:10px;" type="edit" color="#C4D6E6" size="14" @click.native="editTitle()"></Icon>
      <Input style="width:200px;margin-left:10px;" icon="checkmark" v-model="tempTitle" v-if="isEditTitle"
             @on-click="editTitleSubmit" @on-blur="editTitleSubmit">
      </Input>
      <div class="header_right">
        <Button icon="ios-download" type="ghost" size="large" shape="circle" @click="save()">保存流程</Button>
        <Button :disabled="!mainData.id" icon="ios-play-outline" type="info" size="large"
                shape="circle" @click="pubWorkModal = true">部署流程
        </Button>
      </div>
    </v-Header>
    <div class="main-body">
      <div class="left">
        <Button class="bb1" size="small" icon="plus"
                type="info"
                @click="newRuleModal=true">添加规则
        </Button>
        <Button :disabled="noGetData1||tableLoading" class="bb2" size="small" icon="search" type="info"
                @click="getDataByGz">获取清洗数据
        </Button>

        <draggable v-model="ruleInstanceList" :move="getdata" @update="datadragEnd">
          <transition-group>
            <div class="rules" v-for="(item,index) in ruleInstanceList" :key="item.name">
              <div class="head">
                <span class="title">{{item.name}}</span>
                <Icon @click.native="deleteRuleInstance(index)" style="float:right;margin-left:8px;" :size="16"
                      type="trash-a"></Icon>
                <Icon v-show="!item.show" @click.native="showItem(item,true)" style="float:right"
                      :size="16" type="ios-arrow-down"></Icon>
                <Icon v-show="item.show" @click.native="showItem(item,false)" style="float:right"
                      :size="16" type="ios-arrow-up"></Icon>
              </div>
              <ul v-if="item.show">
                <li v-for="step in item.scriptCode">
                  <h4 class="overflow" :title="step.nodeName">{{step.nodeName}}</h4>
                  <!--列选择-->
                  <div v-if="step.getType==1200">
                    <Select v-model="step.bind" style="width:100%">
                      <Option v-for="ob in tableCols" :value="ob.title" :key="ob.title">{{ ob.title }}</Option>
                    </Select>
                  </div>
                  <!--列多选择-->
                  <div v-if="step.getType==1201">
                    <Select v-model="step.bind" style="width:100%" multiple>
                      <Option v-for="ob in tableCols" :value="ob.title" :key="ob.title">{{ ob.title }}</Option>
                    </Select>
                  </div>
                  <!--输入框-->
                  <div v-if="step.getType==1202">
                    <Input v-model="step.bind" placeholder="输入参数"></Input>
                  </div>
                  <!--输入多值框-->
                  <div v-if="step.getType==1203">
                    <v-tags :source.sync="step.bind"></v-tags>
                  </div>
                  <!--输入数字-->
                  <div v-if="step.getType==1204">
                    <InputNumber v-model="step.bind"></InputNumber>
                  </div>
                  <!--下拉-->
                  <div v-if="step.getType==1205">
                    <Select v-model="step.bind" style="width:100%">
                      <Option v-for="ob in step.list" :value="ob" :key="ob">{{ ob }}</Option>
                    </Select>
                  </div>
                  <!--下拉多选-->
                  <div v-if="step.getType==1206">
                    <Select v-model="step.bind" style="width:100%" multiple>
                      <Option v-for="ob in step.list" :value="ob" :key="ob">{{ ob }}</Option>
                    </Select>
                  </div>
                  <!--开关-->
                  <div v-if="step.getType==1207">
                    <i-switch v-model="step.bind"></i-switch>
                  </div>
                  <!--数据字典-->
                  <div  v-if="step.getType==1208">
                    <Select v-model="step.bind" style="width:100%" @on-change="dataChange(step)">
                      <Option v-for="ob in tables"
                              :value="ob.id"
                              :key="ob.id">{{ ob.name }}</Option>
                    </Select>
                  </div>
                </li>
              </ul>
            </div>
          </transition-group>
        </draggable>
      </div>
      <div class="right">
        <div class="table-body">
          <span class="shClick" @click="showHad=!showHad">
            <Icon type="android-list"></Icon>
            <span>设置显示字段</span>
            <Icon type="ios-arrow-down"></Icon>
          </span>
          <span style="float:right">显示最新100条数据</span>
        </div>
        <div class="showChangBox" v-if="showHad">
          <CheckboxGroup v-model="showChangBoxList" v-for="(ob,i) in tableMainData.columnInfos"
                         :key="i" @on-change="showChangBox">
            <Checkbox :label="ob.columnName"></Checkbox>
          </CheckboxGroup>
          <Icon type="close" @click.native="showHad=false"></Icon>
        </div>
        <div class="tabBx" v-if="height">
          <Table :height="height" :loading="tableLoading" :columns="tableCols" :data="tableData"></Table>
        </div>
      </div>
    </div>
    <Modal
      v-model="newRuleModal"
      title="添加清洗规则"
      width="560"
      class="no_footer ruleModal">
      <div style="text-align:center;  margin-bottom:50px;">
        <ul class="titles">
          <li @click="chosseTitle(o)" v-for="(o,i) in ruleList" class="title-item"
              :class="o.active?'current':''">{{o.name}}
          </li>
        </ul>
        <div class="contents">
          <div v-if="isCurrent==1">
            <RadioGroup v-model="chooseRuleId">
              <Radio style="display:block; line-height:32px;" v-for="(o,i) in ruleListObj.list" :key="o.id"
                     :label="o.id">{{o.summary}}
              </Radio>
            </RadioGroup>
          </div>
        </div>
        <Button type="ghost" style="width: 130px" @click="newRuleModal = false">取消</Button>
        <Button type="primary" style="width: 130px" @click="newRuleInstance" :loading="loading.modalBtn">提交</Button>
      </div>
    </Modal>
    <Modal
      v-model="pubWorkModal"
      title="部署流程"
      width="600"
      class="no_footer dsrwBox">
      <div>
        <Form ref="pubWorkForm" :model="pubWorkForm" :rules="rulePubWorkForm"
              :label-width="90">
          <FormItem label="任务名称" prop="name">
            <Input v-model="pubWorkForm.name" placeholder="请输入任务名称"></Input>
          </FormItem>
          <FormItem label="输出表名" prop="outItemName">
            <Input v-if="!noGetData1" v-model="pubWorkForm.outItemName" placeholder="输出表名"></Input>
            <Select v-if="noGetData1" v-model="pubWorkForm.outItemName" style="width:300px; display:inline-block; text-align:left"
                    placeholder="请选择数据表">
              <Option :value="o.name" v-for="(o,i) in metaTableList" :key="i">{{o.name}}</Option>
            </Select>
          </FormItem>
          <FormItem v-if="!noGetData1" label="输出表类型" prop="outItemType">
            <Select v-model="pubWorkForm.outItemType" style="width:280px">
              <Option v-for="item in $store.state.meta.metaType" :value="item.key" :key="item.key">{{ item.text }}
              </Option>
            </Select>
          </FormItem>
          <FormItem v-if="!noGetData1" label="输出位置"  prop="outThemeItemId">
            <Select v-model="pubWorkForm.outThemeItemId" style="width:200px" placeholder="输出位置">
              <Option v-for="item in themeList"
                      :value="item.themeItemListVos[1].id" :key="item.themeItemListVos[1].id">{{ item.name }}</Option>
            </Select>
          </FormItem>

          <div class="dsrw" style="padding-top: 6px;">
            <FormItem label="频率执行" style="display:inline-block; width:200px;">
              <!--<i-switch v-model="pubWorkForm.type" @on-change="change"></i-switch>-->
            </FormItem>
            <div class="itm" v-for="item in pubWorkForm.cronCode" v-if="pubWorkForm.type">
              <v-frequency v-model="item.data"></v-frequency>
              <Button size="small" @click="delTime(item)" type="error" shape="circle" icon="minus"></Button>
            </div>
            <Button @click="addTime" v-if="pubWorkForm.type"
                    style="margin-left:20px; width:72px;border-color:#6ec7ff;color:#6ec7ff">追加
            </Button>
          </div>
          <div class="dsrw">
            <FormItem label="定时执行" style="display:inline-block; width:200px;">
              <!--<i-switch v-model="pubWorkForm.type" @on-change="change"></i-switch>-->
            </FormItem>
            <div class="itm" v-for="item in pubWorkForm.cronCode1">
              <DatePicker v-model="item.data" type="datetime" placeholder="选择时间"
                          :options="options">
              </DatePicker>
              <Button size="small" @click="delTime1(item)" type="error" shape="circle" icon="minus"></Button>
            </div>
            <Button @click="addTime1" v-if="pubWorkForm.type"
                    style="margin-left:20px; width:72px;border-color:#6ec7ff;color:#6ec7ff">追加
            </Button>
          </div>
          <FormItem label="优先级" prop="outItemName">
            <InputNumber :max="10" :min="0" v-model="pubWorkForm.priority"></InputNumber>
          </FormItem>
          <FormItem label="短信提醒">
            <i-switch v-model="pubWorkForm.isNote" @on-change="change"></i-switch>
            <Input v-if="pubWorkForm.isNote" style="width: 200px;"
                   v-model="pubWorkForm.phone"
                   placeholder="电话号码"></Input>
          </FormItem>
          <FormItem label="邮件提醒">
            <i-switch v-model="pubWorkForm.isEmail" @on-change="change"></i-switch>
            <Input v-if="pubWorkForm.isEmail" style="width: 200px;" v-model="pubWorkForm.email"
                   placeholder="邮箱"></Input>
          </FormItem>
          <FormItem label="依赖任务" prop="dependence">
            <Select v-model="pubWorkForm.dependence" placeholder="请选择依赖任务" style="width: 280px">
              <Option :value="item.id" v-for="item in dependenceList" :key="item.id">{{item.name}}</Option>
            </Select>
          </FormItem>
        </Form>
      </div>
      <div style="text-align:center; margin-top:20px; margin-bottom:50px;">
        <Button size="large" type="ghost" style="width: 130px" @click="pubWorkModal = false">取消</Button>
        <Button size="large" type="primary" style="width: 130px" @click="pubWorkSubmit" :loading="loading.modalBtn">提交
        </Button>
      </div>
    </Modal>
  </div>
</template>

<script>
import draggable from "vuedraggable";
import integrationServer from "rs/integration";
import oldServer from "rs/oldServer";
import vTags from "cmpts/common/tags";
import metaServer from "rs/meta";
import connectServer from "rs/connect";

import vFrequency from "cmpts/common/frequency";

export default {
  props: {},
  components: { vTags, vFrequency, draggable },
  data() {
    const validateOutThemeItemId = (rule, value, callback) => {
      if (!value) {
        callback(new Error("必须选项"));
      } else {
        callback();
      }
    };
    return {
      dependenceList:[],
      sjzdTableList: {},
      tables: [],
      noGetData1: false,
      metaTableList: [],
      height: 9000,
      options: {
        disabledDate(date) {
          return date && date.valueOf() < Date.now() - 86400000;
        }
      },
      themeList: [],
      time: 0,
      timeKey: 0,
      tableLoading: true,
      showHad: false,
      tableMainData: {},
      showChangBoxList: [],
      isCurrent: 1,
      chooseRuleId: null,
      chooseRuleObj: null,
      isEditTitle: false,
      tempTitle: "",
      ruleList: [],
      ruleListObj: {},
      newRuleModal: false,
      pubWorkModal: false,
      loading: {
        modalBtn: false
      },
      mainData: {
        title: "我的流程"
      },
      pubWorkForm: {
        dependence:'',
        outThemeItemId: null,
        cronCode: [{ data: "" }],
        cronCode1: [{ data: new Date() }],
        type: true,
        name: "",
        priority: 0,
        phone: "",
        email: "",
        isEmail: true,
        outItemName: "",
        isNote: true
      },
      rulePubWorkForm: {
        name: [
          {
            required: true,
            max: 20,
            message: "不能为空并不能超过20个字",
            trigger: "blur"
          }
        ],
        outItemName: [
          {
            required: true,
            max: 20,
            message: "不能为空并不能超过20个字",
            trigger: "blur"
          }
        ],
        outThemeItemId: [
          {
            required: true,
            validator: validateOutThemeItemId,
            trigger: "change"
          }
        ],
        outItemType: [
          {
            required: true,
            validator: validateOutThemeItemId,
            trigger: "change"
          }
        ]
      },
      search: "",
      tableCols: [],
      tableData: [],
      ruleInstanceList: []
    };
  },
  created() {
    this.getDependenceList();
    this.init();
    this.getRules();
    this.getThemeList();
    this.height = parseInt(
      this.$store.state.setTableHeight(306).height.split("px")[0]
    );
    this.getTables();
  },
  directives: {},
  computed: {},
  filters: {},
  methods: {
    //获取依赖表
    getDependenceList() {
      connectServer.getYl({ params: { params3: "etl" } }, ({ data }) => {
        this.dependenceList = data;
      });
    },
    dataChange(item) {
      oldServer.sparksqlDict(
        {
          params: { params4: item.bind }
        },
        (data, errorCode) => {
          let key = false;
          for (let obj in this.sjzdTableList) {
            if (obj == item.bind) {
              this.sjzdTableList[obj] = data;
              key = true;
            }
          }
          if (!key) this.sjzdTableList[item.bind] = data;
        },
        () => {
          this.$Notice.error({
            title: "失败",
            desc: "获取数据字典失败！"
          });
        }
      );
    },
    getTableList() {
      integrationServer.metaTableList(
        { data: {}, params: {} },
        ({ data, errorCode }) => {
          if (!errorCode) {
            if (data.pageData) {
              this.metaTableList = [];

              data.pageData.forEach(item => {
                if (item.name != this.mainData.tableName) {
                  this.metaTableList.push(item);
                }
              });
            }
          }
        }
      );
    },
    getTables() {
      metaServer.getMetaItemList(
        {
          params: { params3: 1, params4: 10000 },
          data: {
            type: 202
          }
        },
        ({ data }) => {
          this.tables = data.pageData;
        }
      );
    },
    getdata(evt) {},
    datadragEnd(evt) {},
    delTime(item) {
      this.pubWorkForm.cronCode.forEach((obj, i) => {
        if (obj == item) this.pubWorkForm.cronCode.splice(i, 1);
      });
    },
    delTime1(item) {
      this.pubWorkForm.cronCode1.forEach((obj, i) => {
        if (obj == item) this.pubWorkForm.cronCode1.splice(i, 1);
      });
    },
    addTime() {
      this.pubWorkForm.cronCode.push({ data: "" });
    },
    addTime1() {
      this.pubWorkForm.cronCode1.push({ data: new Date() });
    },
    getThemeList() {
      metaServer.getThemeList({ data: {} }, (data, errorCode) => {
        this.themeList = data.data;
      });
    },
    change() {},
    // 测试清洗规则获取数据返回keyId，根据keyId去获取清洗后的数据
    getDataByGz() {
      if (!this.ruleInstanceList.length) {
        this.setTable();
        return;
      }
      this.timeKey = 0;
      this.tableLoading = true;
      integrationServer.clearResultPreview(
        {
          data: {
            handleCode: JSON.stringify({
              tableName: "default." + this.mainData.tableName,
              limit: 100,
              script: {
                steps: this.gzSet()
              }
            })
          }
        },
        ({ data, errorCode }) => {
          if (errorCode == 0) {
            this.getQxTestData(data);
          }
        }
      );
    },
    // 获取清洗后的数据定时2秒拿一次，最多10次
    getQxTestData(redisKey) {
      integrationServer.getRedisData(
        { params: { redisKey } },
        ({ data, errorCode }) => {
          if (this.time) clearTimeout(this.time);
          if (errorCode == 0 && data) {
            data = JSON.parse(data);
            if (!data.result) {
              this.$Notice.error({
                title: "失败",
                desc: "获取清洗数据失败，显示原数据"
              });
              this.tableLoading = false;
              return;
            }
            this.tableMainData.RowDataSet = data.data;

            //设置清洗后新生成的列--start
            var columnInfos = [];
            data.column.forEach(item => {
              columnInfos.push({ columnName: item });
            });
            columnInfos.forEach(item => {
              this.tableMainData.columnInfos.forEach(obj => {
                if (obj.columnName == item.columnName) {
                  item.has = true;
                }
              });
            });
            columnInfos.forEach(item => {
              if (!item.has) this.showChangBoxList.push(item.columnName);
            });
            this.tableMainData.columnInfos = columnInfos;
            //设置清洗后新生成的列--end

            this.setTable();
            //this.save();

            this.tableLoading = false;
          } else {
            if (this.timeKey >= 500) {
              this.$Notice.error({
                title: "失败",
                desc: "获取清洗数据失败，显示原数据"
              });
              this.tableLoading = false;
              return;
            }
            this.time = setTimeout(() => {
              this.timeKey++;
              this.getQxTestData(redisKey);
            }, 5000);
          }
        }
      );
    },
    showChangBox() {
      this.setTable();
    },
    showItem(item, key) {
      item.show = key;
    },
    chosseTitle(n) {
      this.ruleList.forEach(item => {
        item.active = false;
      });
      n.active = true;
      this.ruleListObj = n;
    },
    editTitle() {
      this.tempTitle = this.title;
      this.isEditTitle = true;
    },
    editTitleSubmit() {
      this.isEditTitle = false;
      this.mainData.name = this.tempTitle;
      this.setCrumbs();
    },
    setCrumbs() {
      this.$store.commit("setCrumbs", [
        { text: "工作台", name: "integrationWorkTable" },
        { text: this.mainData.name, name: "integrationWorkItem" }
      ]);
    },
    // 获取规则列表
    getRules() {
      integrationServer.clearRuleList(
        { data: {}, params: { params3: 1, params4: 1000 } },
        ({ data, errorCode }) => {
          if (!errorCode) {
            var pageData = [];
            data.pageData.forEach(item => {
              if (item.state) pageData.push(item);
            });
            let arr = [];
            pageData.forEach(item => {
              if (item.scriptCode)
                item.scriptCode = JSON.parse(item.scriptCode);
              item.show = true;
              let has = false;
              arr.forEach(obj => {
                if (obj.ruleType == item.ruleType) {
                  obj.list.push(item);
                  has = true;
                }
              });
              if (!has) {
                let name = "";
                this.$store.state.integration.ruleType.forEach(i => {
                  if (i.key == item.ruleType) name = i.text;
                });
                arr.push({ ruleType: item.ruleType, name: name, list: [item] });
              }
            });
            arr = arr.sort(function(o, n) {
              return o.ruleType - n.ruleType;
            });
            if (arr[0]) {
              arr[0].active = true;
              this.ruleListObj = arr[0];
            }
            this.ruleList = arr;
          }
        }
      );
    },
    // 获取清洗表头
    getHead() {
      integrationServer.metaTableDetail(
        {
          data: { metadataItemId: this.mainData.metadataItemId },
          params: {}
        },
        ({ data, errorCode }) => {
          if (errorCode == 0) {
            this.tableData = [{}];
            data.pageData.forEach((o, i) => {
              if (i == 0) o.fixed = "left";
              o.key = o.id;
              o.title = o.colName;
            });
            this.tableCols = data.pageData;
          }
        }
      );
    },
    // 获取表数据
    getTableData(key) {
      oldServer.sparksqlQuery(
        {
          data: {
            limit: 100,
            //tableId:this.mainData.metadataItemId,
            tableName: "default." + this.mainData.tableName + ""
          },
          params: {}
        },
        (data, errorCode) => {
          this.tableLoading = false;
          if (data) {
            this.tableMainData = data;
            this.tableMainData.columnInfos.forEach((ob, i) => {
              this.showChangBoxList.push(ob.columnName);
            });
            this.setTable(key);
            // 编辑状态默认获取数据清洗后的数据
            //if(key) this.getDataByGz()
          }
        },
        () => {
          this.tableLoading = false;
        }
      );
    },
    setTable(key) {
      let data = JSON.parse(JSON.stringify(this.tableMainData));
      // 表头设置=========

      let newHead = [],
        headIndex = [];
      data.columnInfos.forEach((ob, i) => {
        let isShow = false;
        this.showChangBoxList.forEach(item => {
          if (ob.columnName == item) {
            isShow = true;
            headIndex.push(i);
          }
        });
        if (!isShow) return;

        ob.render = (h, params) => {
          return h("span", params.row[i]);
        };
        ob.width = 150;
        ob.title = ob.columnName;
        newHead.push(ob);
      });

      this.tableCols = newHead;
      //  设置显示表数据=======
      let newData = [];
      if (!key) {
        data.RowDataSet.forEach(arr => {
          let json = {};
          arr.forEach((item, i) => {
            let isShow = false;
            headIndex.forEach(j => {
              if (i == j) {
                isShow = true;
              }
            });
            if (!isShow) return;
            json[i] = item;
          });
          newData.push(json);
        });
      } else {
        newData = [{}];
      }
      this.tableData = newData;
    },
    // 获取数据
    init() {
      if (this.$route.query.type == "new") {
        this.isEditTitle = true;
        this.setCrumbs();
        this.mainData = {
          metadataItemId: this.$route.query.tableId,
          tableName: this.$route.query.tableName
        };
        this.getTableData();
        //if(this.mainData.metadataItemId) this.getHead();
      } else if (this.$route.query.type == "edit") {
        let id = this.$route.query.id;
        integrationServer.clearRecordDetailById(
          { data: {}, params: { id } },
          ({ data, errorCode }) => {
            if (errorCode == 0) {
              // 获取到编辑全局对象mainData
              for (let k in data) {
                this.mainData[k] = data[k];
              }

              //this.getTableData(true);
              this.getTableData();
              this.setCrumbs();

              if (data.handleCode)
                this.ruleInstanceList = JSON.parse(data.handleCode).frontend;
              //获取数据字典数据
              this.ruleInstanceList.forEach(fie => {
                if (fie.scriptCode && fie.scriptCode.length) {
                  fie.scriptCode.forEach(ijj => {
                    if (ijj.getType == 1208) {
                      this.dataChange(ijj);
                    }
                  });
                }
              });

              this.setNoGetData();

              //if(this.mainData.metadataItemId) this.getHead();
            } else {
              this.$Notice.error({
                title: "获取详情失败",
                desc: "无法进行编辑！"
              });
            }
          }
        );
      } else {
        this.$router.push({ name: "integrationWorkTable" });
      }
      this.getTableList();
    },
    // 新增规则实例
    newRuleInstance() {
      let key = false;
      this.ruleInstanceList.forEach(obj => {
        if (obj.ruleType == 806) {
          key = true;
        }
      });
      if (key) {
        this.$Notice.error({
          title: "错误",
          desc: "已有自定义规则，自定义规则只能单独使用！"
        });
        return;
      }
      this.ruleListObj.list.forEach(item => {
        if (item.id == this.chooseRuleId) this.chooseRuleObj = item;
      });
      if (this.ruleInstanceList.length && this.chooseRuleObj.ruleType == 806) {
        this.$Notice.error({
          title: "错误",
          desc: "自定义规则只能单独使用！"
        });
        return;
      }

      this.newRuleModal = false;
      this.ruleInstanceList.push(
        JSON.parse(JSON.stringify(this.chooseRuleObj))
      );
      this.setNoGetData();
    },
    setNoGetData() {
      let key1 = false;
      if (!this.ruleInstanceList.length) {
        key1 = true;
      } else {
        this.ruleInstanceList.forEach(item => {
          if (item.ruleType == 806) {
            key1 = true;
          }
        });
      }
      this.noGetData1 = key1;
    },
    // 删除规则实例
    deleteRuleInstance(index) {
      this.ruleInstanceList.splice(index, 1);
      this.tableData = [];
      this.getTableData();
      this.setNoGetData();
    },
    gzSet() {
      let gzObjList = [];
      this.ruleInstanceList.forEach(item => {
        let json = {
          type: item.name,
          param: {}
        };
        item.scriptCode.forEach(obj => {
          var bind = "";
          if (Object.prototype.toString.call(obj.bind) === "[object Array]") {
            obj.bind.forEach((obb, i) => {
              if (i == obj.bind.length - 1) {
                bind += obb;
              } else {
                bind += obb + ",";
              }
            });
          }
          if (obj.getType == 1208) {
            bind = this.sjzdTableList[obj.bind];
            if (!bind) bind = [];
          }
          json.param[obj.typeName] = bind ? bind : obj.bind;
        });
        gzObjList.push(json);
      });
      return gzObjList;
    },
    save() {
      let postData = this.mainData;

      if (!this.mainData.name) {
        this.$Notice.error({
          title: "失败",
          desc: "请输入名称！"
        });
        return;
      }

      postData.handleCode = JSON.stringify({
        frontend: this.ruleInstanceList,
        steps: {
          tableName: "default." + this.mainData.tableName,
          script: {
            steps: this.gzSet()
          }
        }
      });
      postData.ruleInstanceAddVos = [];
      if (this.$route.query.type == "new") {
        //新增表名搞进来
        integrationServer.clearRecordAdd(
          { data: postData },
          ({ data, errorCode }) => {
            if (errorCode == 0) {
              // 保存成功,应该切换到编辑，否则会造成新增重复
              this.$Message.success("保存成功");
              this.$router.push({
                name: "integrationWorkDetails",
                query: {
                  type: "edit",
                  id: data
                }
              });
              this.init();
            }
          }
        );
      } else if (this.$route.query.type == "edit") {
        integrationServer.clearRecordUpdate(
          { data: postData },
          ({ data, errorCode }) => {
            if (errorCode == 0) {
              // 修改成功
              this.$Message.success("保存成功");
            }
          }
        );
      }
    },
    // 发布
    pubWorkSubmit(e) {
      if (e && e.preventDefault) e.preventDefault();
      this.$refs["pubWorkForm"].validate(valid => {
        if (valid) {
          let postData = JSON.parse(JSON.stringify(this.pubWorkForm));
          if (
            this.pubWorkForm.isNote &&
            !/^1[3|4|5|8|7][0-9]\d{8}$/.test(postData.phone)
          ) {
            this.$Notice.error({
              title: "验证失败",
              desc: "电话号码不正确"
            });
            return;
          }
          if (
            this.pubWorkForm.isEmail &&
            !/^[0-9A-Za-z][\.-_0-9A-Za-z]*@[0-9A-Za-z]+(\.[0-9A-Za-z]+)+$/.test(
              postData.email
            )
          ) {
            this.$Notice.error({
              title: "验证失败",
              desc: "邮箱格式不正确"
            });
            return;
          }

          postData.cronCode.forEach((item, i) => {
            postData.cronCode[i] = item.data;
          });

          postData.cronCode1.forEach((item, i) => {
            postData.cronCode.push({ time: new Date(item.data).getTime() });
          });
          if (!postData.cronCode.length) {
            this.$Notice.error({
              title: "创建失败",
              desc: "频率和定时至少要填一项"
            });
            return;
          }
          postData.cronCode = JSON.stringify(postData.cronCode);
          if (this.pubWorkForm.dependence) {
            postData.dependence = JSON.stringify({
              etlJobs: [this.pubWorkForm.dependence],
              clearJobs: []
            });
          }

          postData.recordId = this.$route.query.id; //当前流程ID，如果是新增怎么获取（未解决）
          postData.inItemId = this.mainData.metadataItemId;
          postData.inItemName = this.mainData.tableName;
          postData.type = postData.type ? 1101 : 1102;
          integrationServer.clearTaskAdd(
            { data: postData },
            ({ data, errorCode }) => {
              if (errorCode == 0) {
                // 修改成功
                this.pubWorkModal = false;
                this.$router.push({ name: "integrationTaskList" });
                this.$Message.success("新增成功");
              } else {
                this.$Notice.error({
                  title: "创建失败",
                  desc: data
                });
              }
            }
          );
        } else {
          this.$Notice.error({
            title: "验证失败",
            desc: "认真填写内容"
          });
        }
      });
    }
  },
  destroyed() {
    if (this.time) clearTimeout(this.time);
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang='less'>
.data_integration_work_details {
  position: relative;
  height: 100%;
  padding-top: 50px;
  overflow: hidden;
  .ivu-table {
    min-height: 300px;
  }
  .header {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
  }
  .header_right {
    float: right;
  }
  .main-body {
    height: 100%;
    .left {
      height: 100%;
      overflow-y: auto;
      width: 240px;
      float: left;
      padding: 30px 0;
      padding-right: 10px;
      .rules {
        user-select: none;
        margin-top: 12px;
        font-size: 12px;
        border: 1px solid;
        white-space: nowrap;
        line-height: 1.5;
        padding: 6px 15px;
        color: #6ec7ff;
        background-color: transparent;
        border-color: #6ec7ff;
        border-radius: 16px;
        .head {
          height: 18px;
          .title {
            display: inline-block;
            white-space: nowrap;
            text-overflow: ellipsis;
            overflow: hidden;
            width: 145px;
          }
          .ivu-icon {
            color: #c0c0c0;
            &:hover {
              color: #2db7f5;
              cursor: pointer;
            }
          }
        }
        ul {
          border-top: 1px solid #ededed;
          margin-top: 6px;
          padding-top: 10px;
          li {
            margin-bottom: 10px;
            font-size: 12px;
            h4 {
              color: #555;
              margin-bottom: 3px;
              font-size: 12px;
            }
            > div {
              padding: 0 10px;
            }
          }
        }
      }
      .bb2 {
        float: right;
      }
    }
    .right {
      height: 100%;
      overflow: hidden;
      padding-top: 80px;
      position: relative;
      padding-left: 10px;
      .table-body {
        margin: 30px;
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        .shClick {
          &:hover {
            color: #2db7f5;
            cursor: pointer;
          }
        }
      }
      .tabBx {
        height: 100%;
        overflow: hidden;
        .ivu-table-wrapper {
          border: none !important;
        }
        .ivu-table-header {
          height: 50px !important;
        }
      }
      .showChangBox {
        position: absolute;
        top: 55px;
        left: 20px;
        right: 20px;
        background: #fff;
        border: 1px solid #ededed;
        padding: 10px;
        z-index: 10;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
        padding-right: 40px;
        min-height: 43px;
        > div {
          display: inline-block;
        }
        .ivu-icon-close {
          position: absolute;
          top: 14px;
          right: 12px;
          cursor: pointer;
          &:hover {
            color: #c00;
          }
        }
      }
    }
  }
  .ivu-select-selection {
    *zoom: 1;
    &:after {
      content: ".";
      display: block;
      height: 0;
      clear: both;
      visibility: hidden;
    }
    > div {
      float: left;
    }
  }
}

.ruleModal {
  .titles {
    text-align: center;
    .title-item {
      display: inline-block;
      width: 90px;
      line-height: 32px;
      cursor: pointer;
    }
    .title-item.current {
      color: #4ab9ff;
      border-bottom: 1px solid #4ab9ff;
    }
  }
  .contents {
    padding-left: 100px;
    text-align: left;
    padding-bottom: 20px;
  }
}

.dsrwBox {
  .dsrw {
    position: relative;
    padding: 0 100px 0 80px;
    min-height: 50px;
    .itm {
      margin-bottom: 5px;
      > div {
        display: inline-block;
      }
      .ivu-btn-circle {
        min-width: auto;
      }
    }
    > .ivu-form-item {
      position: absolute;
      left: 0;
      top: 0;
    }
    > .ivu-btn {
      position: absolute;
      right: 0;
      top: 0;
    }
  }
}
</style>
