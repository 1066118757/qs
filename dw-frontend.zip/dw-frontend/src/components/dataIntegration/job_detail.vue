<template>
  <div class="data_integration_task_item">
	  <v-Header :text="mainData.name">
      <Icon type="person" :size="12" style="margin-left:26px;" color="#4AB9FF"></Icon>
      <span>{{mainData.createUserName}}</span>
      <Icon type="ios-calendar" :size="12" style="margin-left:26px;" color="#4AB9FF"></Icon>
      <span style="margin-right: 40px;">{{mainData.createAt | date}}</span>
      <Tag v-if="jgData.state=='success'" color="green">执行成功</Tag>
      <Tag  v-if="jgData.state!='success'" color="yellow">执行失败</Tag>
    </v-Header>
		<div class="main-body">
      <ol>
        <li v-for="(item,index) in logList">{{index}}:&nbsp;{{item}}</li>
      </ol>

		</div>
  </div>
</template>

<script>
  import vFrequency from "cmpts/common/frequency"
  import sparkJobServer from "rs/sparkJob"
  import expandRow from './table-expand.vue';
export default {
  props:{
  },
  components:{vFrequency},
	data() {
    return {
      options:{
        disabledDate (date) {
          return date && date.valueOf() < Date.now() - 86400000;
        }
      },
      jgData:{},
      logList:[],
      ruleInstanceList:{},
			isCurrent:1,
      pageSize:10,
			total:0,
			text:"清洗规则列表",
			search:{
				a:'',
				b:'',
				c:''
			},
      mainData:{}
    }
	},
	created() {
		 this.setCrumbs();
		 this.init();
	},
	directives: {

	},
	computed: {

	},
	filters: {
	},
	methods: {
    setCrumbs(){
      this.$store.commit('setCrumbs',[
        {text:"算法任务列表",name:"integrationTaskListArithmetic"},
        {text:this.mainData.name}
      ]);
    },
    getJg(){
      sparkJobServer.getBatchState({params:{params3:this.$route.query.batchId}},
        (data)=>{
          this.jgData=data;
        });
    },
    init(){
      // 获取数据
      this.getData();
      this.getLog();
      this.getJg();
    },
    getLog(page){
      this.logList=[];
      sparkJobServer.getBatchLog({params:{params3:this.$route.query.batchId}},
        (data)=>{
          this.logList=data;
        });

    },
    getData(){
      sparkJobServer.jobFindById({params:{params3:this.$route.query.id}},response=>{
        this.mainData=response;
        this.setCrumbs();
      })
    },
    chosseTitle(n){
      this.isCurrent = n;
    },
	}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang='less'>

  .data_integration_task_item{
    position: relative;
    padding-bottom: 42px;
    .header_right{
      float: right;
    }
    .ivu-page{
      position: absolute;
      right: 30px;
      bottom:0;
    }
    .action_wrapper{
      /*color: red;*/
		}
		.main-body{
			.titles{
				text-align: center;
				.title-item{
					display: inline-block;
					width: 90px;
					line-height: 32px;
					cursor: pointer;
				}
				.title-item.current{
					color: #4AB9FF;
					border-bottom: 1px solid #4AB9FF;
				}
			}
			.contents{
				padding:30px;
				.base-info{
					width: 600px;
					margin:0 auto;
					line-height: 32px;
					.name{
						display: inline-block;
						width: 100px;
						color: #4A4B50;
						font-size: 14px;
						text-align: right;
						vertical-align: top;
					}
					.value{
						display: inline-block;
						width: 400px;
						padding-left:2px;
						color: #7D7F85;
						font-size: 12px;
					}
				}
				.data-flow{
					width: 500px;
					padding-top:50px;
					text-align: center;
					margin:0 auto;
					line-height: 32px;
					p:first-child{
						color: #7D7F85;
						font-size: 12px;
					}
					.table-name{
						display: inline-block;
						background: #f6f8fa;
						border:1px solid #dfe6ec;
						color:#4A4B50;
						text-align: center;
						height: 20px;
						line-height: 20px;
						padding:0 20px;
					}
					.flow-name{
						display: inline-block;
						border-radius: 10px;
						height: 20px;
						line-height: 20px;
						background-color: #E8F7E1;
						border:1px solid #d9e7d3;
						padding: 0 20px;
						color: #4A4B50;
					}
					.left-side{
						text-align: left;
						width: 120px;
						vertical-align: bottom;
						display: inline-block;
					}
					.center-side{
						text-align: left;
						vertical-align: bottom;
						display: inline-block;
					}
					.right-side{
						text-align: left;
						width: 120px;
						vertical-align: bottom;
						display: inline-block;

					}
				}
			}
		}
    .zjxg{
      .st{ display: inline-block; height: 20px; padding: 0 15px; background: #ededed;
        border-radius: 100px; color: #fff;}
      .status1002{ background: #29BC6E;}
      .status1003{ background: #EA4124;}
      .status1001{ background: #348EED;}
    }
  }
</style>
