import "babel-polyfill";
import axios from 'axios';

if (!String.prototype.includes) {
	String.prototype.includes = function () {
		return String.prototype.indexOf.apply(this, arguments) !== -1;
	};
	Array.prototype.includes = function () {
		return Array.prototype.indexOf.apply(this, arguments) !== -1;
	};
}

/**
 *  设置logo、title、ico；
 *   a. 图片大小和图片的呈现效果还需要稍微优化一下（ui）
 *   b. ico需要提供
 * */
export default function (next) {

	function response({data}) {
		if (data&&data.errorCode === 0) {
			document.title = data.data.name;
			let link1 = document.createElement("link");
			let link2 = document.createElement("link");
			link1.setAttribute("rel", "shortcut icon");
			link2.setAttribute("rel", "bookmark");
			// link1.setAttribute("href", obj.ico);
			// link2.setAttribute("href", obj.ico);
			let head = document.head;
			let title = head.getElementsByTagName("title")[0];
			head.insertBefore(link1, title);
			head.insertBefore(link2, title);
		}
		next();
	}

	axios.get("/v1/version/getCurrentInfo").then(response, response);
}
