import axios from 'axios';
import storage from '@/config/storage'
let defaultInstance = axios.create(process.env.NODE_ENV !== 'production'?{}:{});
/*添加请求拦截器*/
defaultInstance.interceptors.request.use(function(request){
  /*在发送请求之前做某事*/
  let access_token = storage.get('access_token');
  if(!access_token) {
    //window.location.href= window.location.href.split('/idetl/#/')[0] +"/#/"
    //window.location.href="#/login";
  }
  if(access_token){
    request.headers.Authorization= 'Bearer ' + access_token;
  }else{
    request.headers.Authorization= 'Bearer None';
  }
    return request;
},function(error){
  /*请求错误时做些事*/
  return Promise.reject(error);
});
/*添加响应拦截器*/
defaultInstance.interceptors.response.use(function(response){
  /*对响应数据做些事*/
  return response.data;
},function(error){
  /*请求错误时做些事*/
  return Promise.reject(error);
});

export default defaultInstance;
