/**
 * Created by xms on 2017/12/26.
 */
import store from "@/store"
// import {Base64} from "js-base64"
import storage from "@/config/storage"
import {childrens} from "@/router"
export default function (t,f,n) {
  let {flag,route} = judge(t);
  store.commit("setLegal",flag);
  if(!flag)n(); else n(route);
}
//这个函数是用来判断当前路由是否符合权限的
function judge(t) {
  /**
   *  是否为404页面，在root组件中结合vue-router的*已经拦截掉了，这是进入APP路由之前需要执行的判断逻辑，该部分逻辑包含了：
   *  a.请求的页面是否有权限访问，无权限指向404；
   *  b.是否登陆
   *  c.登陆后的跳转页面
   *  d.menu大菜单需要显示的东东
   * 咱们讲道理，这部分的逻辑只会在进入app的时候执行一次，后面的在app内部的路由跳转应该不会执行了，除非路由切换到app路由外面（        login,404 ...），然后再进入app路由的时候又会执行一次。
   *
   * 其他的：
   *  比如后面要做安全性，scope不能保存在本地的话，那么我们现将scope通过我们想要的方式得到，然后再进行下面的逻辑就可以了。
   *  这样看来好像所有的权限逻辑都可以在这儿处理咯
   *
   * */
  let matched = t.matched,fromLogin = matched.length === 1;
  let scope = storage.get("scope"),array,result,o = matched[1] || {};
  let [metaData,test,dataConnect,dataIntegration,dataStorage,dataDesensitization,user,audit] = childrens;
  //admin operator personal_trial analyzer
  switch (scope){
    case "personal_trial":
    case "cas_personal_trial":
    case "cas_admin":
      array = [metaData,dataConnect,dataIntegration,dataStorage];
      result = {flag:fromLogin || array.map(l=>l.name).includes(o.name), route:fromLogin?{name:"metaData"}:undefined};
      break;
    case "admin":
      array = [audit,user];
      result = {flag:fromLogin || array.map(l=>l.name).includes(o.name), route:fromLogin?{name:"user"}:undefined};
      break;
    default:
      array = [];
      result = {flag:true, route:{name:"login"}};
  }
  store.commit("setMenuArray",array);
  return result;
}
