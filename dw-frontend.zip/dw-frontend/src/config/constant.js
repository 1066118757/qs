/**
 * Created by xms on 2017/10/18.
 */
const flag = process.env.NODE_ENV !== 'production';
let url="";
if(flag){
  url="http://192.168.1.42:18080";
  // url="http://www.ndtcd.cn";
}
url="http://192.168.1.42:18080";
url="http://192.168.111.116:8080";
export const baseURL = url;
