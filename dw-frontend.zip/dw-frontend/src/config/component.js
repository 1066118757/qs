import Main from '@/components/common/main'
import Header from '@/components/common/Header'
import Affirm from '@/components/common/Affirm'
export default {
	install:function(Vue){
    //在这里添加全局组件
    Vue.component('vMenu',resove=>{require(['@/components/common/menu'],resove)});
    Vue.component('vSteps',resove=>{require(['@/components/common/steps'],resove)});
    Vue.component('vModalSourceType',resove=>{require(['@/components/common/ModalSourceType'],resove)});
    Vue.component('vModalFileType',resove=>{require(['@/components/common/ModalFileType'],resove)});
    Vue.component('vNoFound',resove=>{require(['@/components/common/noFound'],resove)});
    Vue.component('vMain',Main);
    Vue.component('vHeader',Header);
    Vue.component('vAffirm',Affirm);
	}
};
