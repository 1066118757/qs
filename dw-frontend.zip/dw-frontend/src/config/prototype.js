import Vue from "vue"
import storage from './storage';
import codeTableObj from './getCodeTable';
if(console)Vue.prototype.console=console;
Vue.prototype.session=storage;
Vue.prototype.open=window.open;
Vue.prototype.getCodeTable=codeTableObj.getCodeTable;
Vue.prototype.getCodeName=codeTableObj.getCodeName;

export default Vue;
