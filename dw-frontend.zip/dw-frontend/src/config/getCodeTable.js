/**
 * Created by zhaowei on 2017/9/19.
 */
import storage from '@/config/storage';
import otherServer from 'rs/otherServer';
window.codeTableObj = {
  version: '1.112',
  codeTableObj: {},
  codeTableList: [],
  getKeyList() {
    let arr = [];
    for (var i = 0; i < 100; i++) {
      arr.push(i);
    }
    return arr;
  },
  getAllCodeTable() {
    otherServer.dictList({
      params: {
        params3: 1, params4: 10000
      },
      data: { list: this.getKeyList() }
    }, response => {
      if (response.data && response.data.pageData) {
        this.codeTableList = [];
        this.codeTableObj = [];
        this.codeTableList = response.data.pageData;
        this.codeTableList.forEach((item) => {
          if (!this.codeTableObj[item.typeId]) {
            this.codeTableObj[item.typeId] = {
              typeName: item.typeName,
              typeId: item.typeId,
              list: []
            };
          }
          this.codeTableObj[item.typeId].list.push(item);
          storage.set("codeTableList", JSON.stringify({ list: this.codeTableList }));
          storage.set("codeTableObj", JSON.stringify(this.codeTableObj));
          storage.set("codeTableObjVersion", this.version);
        });
      } else {

      }
    }, err => {

    });
  },
  getCodeName(key) {
    if (!codeTableObj.codeTableList.length && storage.get("codeTableList")) codeTableObj.codeTableList = (JSON.parse(storage.get("codeTableList"))).list;
    codeTableObj.codeTableList.forEach((item) => {
      if (item.id == key) key = item.value
    });
    return key
  },
  getCodeTable(key, callBack) {
    let co = codeTableObj.codeTableObj[key];

    console.log(JSON.parse(storage.get("codeTableObj")))
    if (!co) {
      co = (JSON.parse(storage.get("codeTableObj")))[key];
    }
    if (co) {
      if (callBack) callBack(co.list);
      return co.list;
    }
  }
};
if (!storage.get("codeTableObj") || !storage.get("codeTableList") || storage.get("codeTableObjVersion") != codeTableObj.version) codeTableObj.getAllCodeTable();

export default codeTableObj;
