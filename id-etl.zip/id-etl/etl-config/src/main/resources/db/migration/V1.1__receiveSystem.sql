DROP TABLE IF EXISTS t_data_source;
CREATE TABLE t_data_source (
id numeric NOT NULL,
name varchar(50) COLLATE "default",
type int4,
remark varchar(300) COLLATE "default",
state int4,
latest_connect_log text COLLATE "default",
status int2 default 1,
create_time timestamp(6) default CURRENT_TIMESTAMP,
create_user numeric,
update_time timestamp(6) default CURRENT_TIMESTAMP,
update_user numeric,
CONSTRAINT t_data_source_pkey PRIMARY KEY (id)
)WITH (OIDS=FALSE);

comment on table t_data_source is '数据源';
comment on column t_data_source.name is '名称';
comment on column t_data_source.type is '类型';
comment on column t_data_source.remark is '描述';
comment on column t_data_source.latest_connect_log is '最近连接日志';

INSERT INTO "c_dict_type" ("id", "type_name") VALUES ('6', '数据源类型');
INSERT INTO "c_dict_mapping" VALUES ('601', '6', '1', 'mysql', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('602', '6', '2', 'oracle', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('603', '6', '3', 'sql server', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('604', '6', '4', 'info bright', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('605', '6', '5', 'postgre sql', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('606', '6', '6', 'hbase', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('607', '6', '7', 'mongodb', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('608', '6', '8', 'webservice', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('609', '6', '9', 'excel', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('610', '6', '10', 'txt', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('611', '6', '11', 'csv', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('612', '6', '12', 'xml', '1',  '0',current_timestamp);

DROP TABLE IF EXISTS t_job;
CREATE TABLE t_job (
id numeric NOT NULL,
name varchar(100) COLLATE "default",
dist_table_source int2,
dist_table varchar(50) COLLATE "default",
logic_partition_id numeric,
import_mode int4,
sync_strategy int4,
priority int4,
state int4,
latest_schedule_state int4,
latest_success_rows int8,
latest_schedule_time timestamp(6),
latest_schedule_log text COLLATE "default",
data_source_id numeric,
status int2 default 1,
create_time timestamp(6) default CURRENT_TIMESTAMP,
create_user numeric,
update_time timestamp(6) default CURRENT_TIMESTAMP,
update_user numeric,
CONSTRAINT t_job_pkey PRIMARY KEY (id)
)WITH (OIDS=FALSE);

COMMENT ON COLUMN t_job.name IS '名称';
COMMENT ON COLUMN t_job.dist_table_source IS '目标表来源 1：新建目标表 2：已有目标表';
COMMENT ON COLUMN t_job.dist_table IS '目标表';
COMMENT ON COLUMN t_job.logic_partition_id IS '逻辑分区id';
COMMENT ON COLUMN t_job.import_mode IS '1:全覆盖,2:按列覆盖,3:按列合并更新';
COMMENT ON COLUMN t_job.sync_strategy IS '1:定时,2:频率';
COMMENT ON COLUMN t_job.priority IS '优先级';
COMMENT ON COLUMN t_job.state IS '状态';
COMMENT ON COLUMN t_job.latest_schedule_state IS '最近一次执行状态';
COMMENT ON COLUMN t_job.latest_success_rows IS '最近一执行成功行数';
COMMENT ON COLUMN t_job.latest_schedule_time IS '最近一执行成功时间';
COMMENT ON COLUMN t_job.latest_schedule_log IS '最近一执行日志';
COMMENT ON COLUMN t_job.data_source_id IS '数据源id';

DROP TABLE IF EXISTS t_job_conf;
CREATE TABLE t_job_conf (
id numeric NOT NULL,
key varchar(30) COLLATE "default",
value varchar(500) COLLATE "default",
ref_id numeric,
type int4,
state int4,
status int2 default 1,
create_time timestamp(6) default CURRENT_TIMESTAMP,
create_user numeric,
update_time timestamp(6) default CURRENT_TIMESTAMP,
update_user numeric,
CONSTRAINT t_job_conf_pkey PRIMARY KEY (id)
)WITH (OIDS=FALSE);

COMMENT ON TABLE t_job_conf IS 'etl数据源或任务的相关配置';
COMMENT ON COLUMN t_job_conf.type IS '1:数据源配置,2:任务配置,3:消息提醒机制,4:字段映射';

INSERT INTO "c_dict_type" ("id", "type_name") VALUES ('7', '配置类型');
INSERT INTO "c_dict_mapping" VALUES ('701', '7', '1', '数据源配置', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('702', '7', '2', '引接任务配置', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('703', '7', '3', '消息提醒机制', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('704', '7', '4', '字段映射', '1',  '0',current_timestamp);

DROP TABLE IF EXISTS t_schedule_log;
CREATE TABLE t_schedule_log (
id numeric NOT NULL,
schedule_starttime timestamp(6),
schedule_endtime timestamp(6),
schedule_state int4,
success_rows int8,
schedule_log text COLLATE "default",
job_id numeric,
CONSTRAINT t_schedule_log_pkey PRIMARY KEY (id)
)WITH (OIDS=FALSE);

COMMENT ON TABLE t_schedule_log IS '任务日志';
COMMENT ON COLUMN t_schedule_log.schedule_starttime IS '执行开始时间';
COMMENT ON COLUMN t_schedule_log.schedule_endtime IS '执行结束时间';
COMMENT ON COLUMN t_schedule_log.schedule_state IS '状态';
COMMENT ON COLUMN t_schedule_log.success_rows IS '成功行数';
COMMENT ON COLUMN t_schedule_log.schedule_log IS '日志';