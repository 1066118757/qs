alter table t_operate_action alter COLUMN id type int4;

DELETE from t_operate_action where 1=1;

INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('100', '未知的清洗流程操作', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('101', '清洗流程添加', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('102', '清洗流程更新', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('103', '清洗流程删除', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('104', '清洗流程列表查询', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('105', '清洗流程详情查询', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('106', '清洗结果预览', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('107', '通过redisKey从Redis查询数据预览数据', '1');

INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('200', '未知的清洗规则操作', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('201', '清洗规则添加', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('202', '清洗规则更新', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('203', '清洗规则删除', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('204', '清洗规则列表查询', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('205', '清洗规则详情查询', '1');

INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('300', '未知的清洗任务操作', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('301', '清洗任务添加', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('302', '清洗任务更新', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('303', '清洗任务删除', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('304', '清洗任务列表查询', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('305', '清洗任务详情查询', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('306', '更新kernelId', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('307', '获取定时任务实体类', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('308', '更新定时任务最近执行信息', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('309', '立即执行清洗任务', '1');

INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('400', '未知的清洗任务日志操作', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('401', '清洗任务日志添加', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('402', '清洗任务日志更新', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('403', '清洗任务日志删除', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('404', '清洗任务日志列表查询', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('405', '清洗任务日志详情查询', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('406', '清洗任务日志依据是否有id更新或者保存', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('407', '判断任务是否正在执行', '1');

INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('500', '未知的规则实例化操作', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('501', '规则实例化添加', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('502', '规则实例化更新', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('503', '规则实例化删除', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('504', '规则实例化列表查询', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('505', '规则实例化详情查询', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('506', '通过清洗流程id查询其规则实例化列表信息', '1');

INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('600', '未知的规则实例化参数操作', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('601', '规则实例化参数添加', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('602', '规则实例化参数更新', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('603', '规则实例化参数删除', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('604', '规则实例化参数列表查询', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('605', '规则实例化参数详情查询', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('606', '规则实例化参数详情删除-依据规则实例化id', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('607', '通过规则实例化id查询其参数列表信息', '1');

INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('700', '未知的规则参数操作', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('701', '规则参数添加', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('702', '规则参数更新', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('703', '规则参数删除', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('704', '规则参数列表查询', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('705', '规则参数详情查询', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('706', '规则参数详情删除-依据规则id', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('707', '通过规则id查询其参数列表信息', '1');

INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('800', '未知的清洗任务操作', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('801', '立即执行引接任务', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('802', '添加引接任务', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('803', '删除引接任务', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('804', '更新引接任务', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('805', '更新引接任务基本信息', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('806', '引接任务列表', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('807', '引接任务详情', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('808', '更新引接任务seesion', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('809', '任务历史统计列表', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('810', '任务历史统计汇总记录', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('811', '获取最后一次同步情况', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('812', '数据库迁移', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('813', '数据库迁移new', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('814', '数据库迁移结果', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('815', '获取表对应关系', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('816', '获取列对应关系', '1');

