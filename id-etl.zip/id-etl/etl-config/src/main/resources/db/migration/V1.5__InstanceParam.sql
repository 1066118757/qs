DROP TABLE IF EXISTS "t_rule_instance_param";
CREATE TABLE "t_rule_instance_param" (
  "id"             NUMERIC NOT NULL PRIMARY KEY,
  "name"           VARCHAR(20) DEFAULT '',
  "clear_rule_id" NUMERIC DEFAULT 0,
  "rule_instance_id" NUMERIC DEFAULT 0,
  "type"           INT4  DEFAULT 0,
  "get_type"    INT4 DEFAULT 0,
  "index"        VARCHAR (150) DEFAULT '',
  "bind_col_id"   NUMERIC DEFAULT 0,
  "bind_data"   VARCHAR DEFAULT '',
  "status"         INT4 DEFAULT 1,
  "create_time"    TIMESTAMP DEFAULT current_timestamp,
  "create_user"    NUMERIC DEFAULT 0,
  "update_time"    TIMESTAMP DEFAULT current_timestamp,
  "update_user"    NUMERIC DEFAULT 0
) WITH(OIDS = FALSE);

COMMENT ON TABLE t_rule_instance_param IS '规则实例化参数绑定表';
COMMENT ON COLUMN t_rule_instance_param.id IS 'id';
COMMENT ON COLUMN t_rule_instance_param.name IS '参数名';
COMMENT ON COLUMN t_rule_instance_param.clear_rule_id IS '对应规则id';
COMMENT ON COLUMN t_rule_instance_param.rule_instance_id IS '对应规则实例化id';
COMMENT ON COLUMN t_rule_instance_param.type IS '参数类型 参考码表13';
COMMENT ON COLUMN t_rule_instance_param.get_type IS '参数获取类型 参考码表12';
COMMENT ON COLUMN t_rule_instance_param.index IS '参数所在规则表达式位置';
COMMENT ON COLUMN t_rule_instance_param.bind_col_id IS '绑定列id';
COMMENT ON COLUMN t_rule_instance_param.bind_data IS '绑定值';


