-- ----------------------------
-- Records of cluster
-- ----------------------------
INSERT INTO cluster VALUES ('1', 'c1', null, null, null, null);

-- ----------------------------
-- Records of function_metadata
-- ----------------------------
INSERT INTO function_metadata VALUES ('1', '+', '数值字段1+数值字段2', '返回字段值的和', '1+2', '1', '0');
INSERT INTO function_metadata VALUES ('10', 'ADD_MONTHS', 'ADD_MONTHS(日期字段,整数值n)', '返回日期字段加上n个月后的日期，整数值可以是负数', 'ADD_MONTHS(''2012-01-31'',1),结果为2012-02-29', '2', '0');
INSERT INTO function_metadata VALUES ('16', 'CEIL', 'CEIL(数值字段)', '返回数值向上取整后的值', 'CEIL(3.14),结果为4', '1', '0');
INSERT INTO function_metadata VALUES ('2', '-', '数值字段1-数值字段2', '返回字段值的差', '2-1', '1', '0');
INSERT INTO function_metadata VALUES ('20', 'CURRENT_TIMESTAMP', 'CURRENT_TIMESTAMP()', '返回当前日期及时间', 'CURRENT_TIMESTAMP()', '2', '0');
INSERT INTO function_metadata VALUES ('21', 'DATE_ADD', 'DATE_ADD(日期字段,整数值n)', '返回日期字段加上n天后的日期，整数值可以是负数', 'DATE_ADD(''2015-01-01'',-1),结果为2014-12-31', '2', '0');
INSERT INTO function_metadata VALUES ('23', 'DATEDIFF', 'DATEDIFF(日期字段1,日期字段2)', '返回日期字段1与日期字段2相差的天数,当日期1大于日期2时返回正数，否则返回0或负数', 'DATEDIFF(''2015-01-01'',''2014-01-01''),结果为365', '1', '0');
INSERT INTO function_metadata VALUES ('24', 'DAYOFMONTH', 'DAYOFMONTH(日期字段)', '返回日期的月的第几天', 'DAYOFMONTH(''2015-01-02''),结果为2', '1', '0');
INSERT INTO function_metadata VALUES ('25', 'CONCAT', 'CONCAT(字段1, 字段2...)', '返回顺序联结各参数的字符串', 'CONCAT([货品编号], [类型编号])，返回货品编号和类型编号联结后的字符串', '0', '1');
INSERT INTO function_metadata VALUES ('26', 'DAYOFYEAR', 'DAYOFYEAR(日期字段)', '返回该日期是这一年的第几天', 'DAYOFYEAR(''2016-03-01''),结果为61', '1', '0');
INSERT INTO function_metadata VALUES ('27', 'FLOOR', 'FLOOR(数值字段)', '返回数值向下取整后的值', 'FLOOR(3.8),结果为3', '1', '0');
INSERT INTO function_metadata VALUES ('29', 'FROM_UNIXTIME', 'FROM_UNIXTIME(毫秒数,格式)', '返回1970-01-01 00:00:00 UTC+毫秒数后的格式化日期，格式是可选参数', 'FROM_UNIXTIME(1423243233),结果为2015-02-07 01:20:33', '0', '0');
INSERT INTO function_metadata VALUES ('3', '*', '数值字段1*数值字段2', '返回字段值的积', '1*2', '1', '0');
INSERT INTO function_metadata VALUES ('30', 'INITCAP', 'INITCAP(字符字段)', '返回字段首字母大写后的结果', 'INITCAP(abcd),结果为Abcd', '0', '0');
INSERT INTO function_metadata VALUES ('31', 'INSTR', 'INSTR(字符字段,字符串s)', '返回字符串s在字符字段值中的位置', 'INSTR(''ABC-123'',''-1''),结果为4', '1', '0');
INSERT INTO function_metadata VALUES ('34', 'LENGTH', 'LENGTH(字符字段)', '返回字段的字符长度', 'LENGTH(''中国''),结果为2', '1', '0');
INSERT INTO function_metadata VALUES ('35', 'LOWER', 'LOWER(字符字段)', '返回字段小写后的结果', 'LOWER(''Abc123等等''),结果为abc123等等', '0', '0');
INSERT INTO function_metadata VALUES ('37', 'LTRIM', 'LTRIM(字符字段)', '返回去除字符字段左边空格后的结果', 'LTRIM(''  12312''),结果为12312', '0', '0');
INSERT INTO function_metadata VALUES ('38', 'MD5', 'MD5(字符字段)', '返回字段MD5后的结果', 'MD5(''123456''),结果为e10adc3949ba59abbe56e057f20f883e', '0', '0');
INSERT INTO function_metadata VALUES ('39', 'MINUTE', 'MINUTE(日期字段)', '返回日期中的分钟值', 'MINUTE(''2015-01-01 12:06:01''),结果为6', '1', '0');
INSERT INTO function_metadata VALUES ('4', '/', '数值字段1/数值字段2', '返回字段值的商', '1/2,结果为0.5', '1', '0');
INSERT INTO function_metadata VALUES ('41', 'REPEAT', 'REPEAT(字符字段,次数n)', '返回字符字段重复n次后的结果', 'REPEAT(''ab'',2),结果为abab', '0', '0');
INSERT INTO function_metadata VALUES ('42', 'REVERSE', 'REVERSE(字符字段)', '返回字符字段逆序后的结果', 'REVERSE(''abcdef''),结果为fedcba', '0', '0');
INSERT INTO function_metadata VALUES ('43', 'SECOND', 'SECOND(日期字段)', '返回日期字段的秒的值', 'SECOND(''2015-01-01 12:06:01''),结果为1', '1', '0');
INSERT INTO function_metadata VALUES ('44', 'RPAD', 'RPAD(字符字段,结果字符串长度n,填充字符串s)', '在字符字段的右边填充字符串s,返回n位的字符串.当n小于字符字段的长度时，其结果是从左开始截取n位字符', 'RPAD(''12'',4,''0''),结果为1200', '0', '0');
INSERT INTO function_metadata VALUES ('45', 'RTRIM', 'RTRIM(字符字段)', '返回去除字符字段右边空格后的结果', 'RTRIM('' 12312  ''),结果为 12312', '0', '0');
INSERT INTO function_metadata VALUES ('47', 'SUBSTRING', 'SUBSTRING(字符字段,开始截取位置p,截取位数n)', '返回从字符字段p开始的n位字符串', 'SUBSTRING(''abcdf'',2,3),结果为bcd', '0', '0');
INSERT INTO function_metadata VALUES ('48', 'CAST', 'CAST(字段 AS 字段类型)', '对字段进行类型转换', 'CAST(''2015-12-31'' AS DATE)', '5', '0');
INSERT INTO function_metadata VALUES ('49', 'TRIM', 'TRIM(字符字段)', '去除字段左右空格', 'TRIM('' 231  ''),结果为231', '0', '0');
INSERT INTO function_metadata VALUES ('5', '%', '数值字段1%数值字段2', '返回两个数相除后的余数', '5%2,结果为1', '1', '0');
INSERT INTO function_metadata VALUES ('51', 'UNIX_TIMESTAMP', 'UNIX_TIMESTAMP(日期字段或日期字符串,格式)', '返回日期的毫秒数,两个参数都是可选的', 'UNIX_TIMESTAMP(),结果为当前时间毫秒数,UNIX_TIMESTAMP(CAST(''2014-12-31'' AS DATE))结果为1419955200', '1', '0');
INSERT INTO function_metadata VALUES ('52', 'UPPER', 'UPPER(字符字段)', '返回字符字段大写后的结果', 'UPPER(''abc'')结果为ABC', '0', '0');
INSERT INTO function_metadata VALUES ('54', 'WEEKOFYEAR', 'WEEKOFYEAR(日期字段)', '返回该日期年的周数。只允许传入日期型字段', 'WEEKOFYEAR([下单时间])，返回该行 ''下单时间'' 字段对应的周数', '1', '0');
INSERT INTO function_metadata VALUES ('55', 'DAYOFMONTH', 'DAYOFMONTH(日期字段)', '返回该日期月的号数。只允许传入日期型字段', 'DAYOFMONTH([下单时间])，返回该行 ''下单时间'' 字段对应的号数', '1', '0');
INSERT INTO function_metadata VALUES ('6', 'YEAR', 'YEAR(日期字段)', '返回该日期对应的年份。只允许传入日期型字段', 'YEAR([下单时间])，返回该行''下单时间''字段对应的年份', '1', '0');
INSERT INTO function_metadata VALUES ('7', 'QUARTER', 'QUARTER(日期字段)', '返回该日期在当年的第几个季度，只允许传入日期型字段', 'QUARTER([入职日期])，返回入职日期为该年的第几个季度', '1', '0');
INSERT INTO function_metadata VALUES ('8', 'MONTH', 'MONTH(日期字段)', '返回该日期对应的月份。只允许传入日期型字段', 'MONTH([下单时间])，返回该行 ''下单时间'' 字段对应的月份', '1', '0');

-- ----------------------------
-- Records of function_param_metadata
-- ----------------------------
INSERT INTO function_param_metadata VALUES ('12', '2', '1', '10', '0');
INSERT INTO function_param_metadata VALUES ('13', '1', '2', '10', '0');
INSERT INTO function_param_metadata VALUES ('21', '1', '1', '16', '0');
INSERT INTO function_param_metadata VALUES ('27', '2', '1', '21', '0');
INSERT INTO function_param_metadata VALUES ('28', '1', '2', '21', '0');
INSERT INTO function_param_metadata VALUES ('31', '2', '1', '23', '0');
INSERT INTO function_param_metadata VALUES ('32', '2', '2', '23', '0');
INSERT INTO function_param_metadata VALUES ('34', '2', '1', '24', '0');
INSERT INTO function_param_metadata VALUES ('35', '2', '1', '26', '0');
INSERT INTO function_param_metadata VALUES ('36', '1', '1', '27', '0');
INSERT INTO function_param_metadata VALUES ('39', '1', '1', '29', '0');
INSERT INTO function_param_metadata VALUES ('40', '0', '2', '29', '1');
INSERT INTO function_param_metadata VALUES ('41', '0', '1', '30', '0');
INSERT INTO function_param_metadata VALUES ('42', '0', '1', '31', '0');
INSERT INTO function_param_metadata VALUES ('43', '0', '2', '31', '0');
INSERT INTO function_param_metadata VALUES ('46', '0', '1', '34', '0');
INSERT INTO function_param_metadata VALUES ('47', '0', '1', '35', '0');
INSERT INTO function_param_metadata VALUES ('5', '-1', '1', '25', '0');
INSERT INTO function_param_metadata VALUES ('51', '0', '1', '37', '0');
INSERT INTO function_param_metadata VALUES ('52', '0', '1', '38', '0');
INSERT INTO function_param_metadata VALUES ('53', '2', '1', '39', '0');
INSERT INTO function_param_metadata VALUES ('56', '0', '1', '41', '0');
INSERT INTO function_param_metadata VALUES ('57', '1', '2', '41', '0');
INSERT INTO function_param_metadata VALUES ('58', '0', '1', '42', '0');
INSERT INTO function_param_metadata VALUES ('59', '2', '1', '43', '0');
INSERT INTO function_param_metadata VALUES ('6', '2', '1', '6', '0');
INSERT INTO function_param_metadata VALUES ('60', '0', '1', '44', '0');
INSERT INTO function_param_metadata VALUES ('61', '1', '2', '44', '0');
INSERT INTO function_param_metadata VALUES ('62', '0', '3', '44', '0');
INSERT INTO function_param_metadata VALUES ('63', '0', '1', '45', '0');
INSERT INTO function_param_metadata VALUES ('67', '0', '1', '47', '0');
INSERT INTO function_param_metadata VALUES ('68', '1', '2', '47', '0');
INSERT INTO function_param_metadata VALUES ('69', '1', '3', '47', '0');
INSERT INTO function_param_metadata VALUES ('7', '2', '1', '7', '0');
INSERT INTO function_param_metadata VALUES ('70', '-1', '1', '48', '0');
INSERT INTO function_param_metadata VALUES ('71', '-2', '2', '48', '0');
INSERT INTO function_param_metadata VALUES ('72', '0', '1', '49', '0');
INSERT INTO function_param_metadata VALUES ('74', '2', '1', '51', '1');
INSERT INTO function_param_metadata VALUES ('75', '0', '2', '51', '1');
INSERT INTO function_param_metadata VALUES ('76', '0', '1', '52', '0');
INSERT INTO function_param_metadata VALUES ('77', '2', '1', '54', '0');
INSERT INTO function_param_metadata VALUES ('78', '2', '1', '55', '0');
INSERT INTO function_param_metadata VALUES ('8', '2', '1', '8', '0');


-- ----------------------------
-- Records of id_dictionary
-- ----------------------------
INSERT INTO id_dictionary VALUES ('1', 'tableColTypeNumber', '数字型', 'Number', '1', null, '数据表字段数字类型');
INSERT INTO id_dictionary VALUES ('10', 'analyzeColumnType', 'NATIVE', '0', '1', null, '原生字段');
INSERT INTO id_dictionary VALUES ('11', 'analyzeColumnType', 'CALCULATE', '1', '2', null, '计算字段');
INSERT INTO id_dictionary VALUES ('12', 'analyzeColumnType', 'GROUP', '2', '3', null, '分组字段');
INSERT INTO id_dictionary VALUES ('13', 'dateFormatType', 'YEAR', '0', '1', null, '年');
INSERT INTO id_dictionary VALUES ('14', 'dateFormatType', 'QUARTER', '1', '2', null, '刻钟');
INSERT INTO id_dictionary VALUES ('15', 'dateFormatType', 'MONTH', '2', '3', null, '月');
INSERT INTO id_dictionary VALUES ('16', 'dateFormatType', 'WEEK', '3', '4', null, '周');
INSERT INTO id_dictionary VALUES ('17', 'dateFormatType', 'DAY', '4', '5', null, '日');
INSERT INTO id_dictionary VALUES ('18', 'dateFormatType', 'HOUR', '5', '6', null, '时');
INSERT INTO id_dictionary VALUES ('19', 'dateFormatType', 'MINUTE', '6', '7', null, '分');
INSERT INTO id_dictionary VALUES ('1_1', 'tableColType', '字节型', 'TINYINT', '1', '1', '数据表字段类型');
INSERT INTO id_dictionary VALUES ('1_2', 'tableColType', '短整型', 'SMALLINT', '2', '1', '数据表字段类型');
INSERT INTO id_dictionary VALUES ('1_3', 'tableColType', '整型', 'INT', '3', '1', '数据表字段类型');
INSERT INTO id_dictionary VALUES ('1_4', 'tableColType', '长整型', 'BIGINT', '4', '1', '数据表字段类型');
INSERT INTO id_dictionary VALUES ('1_5', 'tableColType', '浮点型', 'FLOAT', '5', '1', '数据表字段类型');
INSERT INTO id_dictionary VALUES ('1_6', 'tableColType', '双精度浮点型', 'DOUBLE', '6', '1', '数据表字段类型');
INSERT INTO id_dictionary VALUES ('2', 'tableColTypeString', '字符型', 'String', '2', null, '数据表字段字符类型');
INSERT INTO id_dictionary VALUES ('20', 'dateFormatType', 'SECOND', '7', '8', null, '秒');
INSERT INTO id_dictionary VALUES ('21', 'ChartUseColType', 'xAxis', '0', '1', null, 'X轴');
INSERT INTO id_dictionary VALUES ('22', 'ChartUseColType', 'yAxis', '1', '2', null, 'Y轴');
INSERT INTO id_dictionary VALUES ('23', 'ChartUseColType', 'series', '2', '3', null, '系列');
INSERT INTO id_dictionary VALUES ('24', 'ChartUseColType', 'filter', '3', '4', null, '筛选');
INSERT INTO id_dictionary VALUES ('25', 'ChartUseColType', 'orderBy', '4', '5', null, '排序');
INSERT INTO id_dictionary VALUES ('26', 'ChartUseColType', 'innerFilter', '5', '6', null, '图内筛选');
INSERT INTO id_dictionary VALUES ('27', 'dataSourceDBType', '数据源数据库类型类型', 'dataSourceDBType', '0', null, '数据源数据库类型类型');
INSERT INTO id_dictionary VALUES ('27_1', 'dataSourceType', 'Relational Database', '0', '0', '27', '数据源类型');
INSERT INTO id_dictionary VALUES ('27_1_1', 'dbType', 'MySQL', 'MySQL', '0', '27_1', '关系型数据库类型');
INSERT INTO id_dictionary VALUES ('27_1_2', 'dbType', 'Oracle', 'Oracle', '1', '27_1', '关系型数据库类型');
INSERT INTO id_dictionary VALUES ('27_1_3', 'dbType', 'PostgreSQL', 'PostgreSQL', '2', '27_1', '关系型数据库类型');
INSERT INTO id_dictionary VALUES ('27_1_4', 'dbType', 'Sybase', 'Sybase', '3', '27_1', '关系型数据库类型');
INSERT INTO id_dictionary VALUES ('27_1_5', 'dbType', 'DB2', 'IBM DB2', '4', '27_1', '关系型数据库类型');
INSERT INTO id_dictionary VALUES ('27_1_6', 'dbType', 'Informix', 'Informix', '5', '27_1', '关系型数据库类型');
INSERT INTO id_dictionary VALUES ('27_2', 'dataSourceType', 'NoSQL', '1', '1', '27', '数据源类型');
INSERT INTO id_dictionary VALUES ('27_3', 'dataSourceType', 'WebService', '2', '2', '27', '数据源类型');
INSERT INTO id_dictionary VALUES ('27_4', 'dataSourceType', 'Other Database', '3', '2', '27', '数据源类型');
INSERT INTO id_dictionary VALUES ('27_4_1', 'dbType', 'Hadoop Hive 2', 'Hadoop Hive 2', '6', '27_4', 'Other dataBase');
INSERT INTO id_dictionary VALUES ('27_4_2', 'dbType', 'Impala', 'Impala', '7', '27_4', 'Other dataBase');
INSERT INTO id_dictionary VALUES ('28', 'groupType', 'report', '1', '1', null, '报告分组');
INSERT INTO id_dictionary VALUES ('29', 'groupType', 'folder', '2', '2', null, '数据表分组');
INSERT INTO id_dictionary VALUES ('2_1', 'tableColType', '字符型', 'STRING', '1', '2', '数据表字段类型');
INSERT INTO id_dictionary VALUES ('3', 'tableColTypeBoolean', '布尔型', 'Boolean', '3', null, '数据表字段布尔类型');
INSERT INTO id_dictionary VALUES ('3_1', 'tableColType', '布尔型', 'BOOLEAN', '1', '3', '数据表字段类型');
INSERT INTO id_dictionary VALUES ('4', 'tableColTypeDatetime', '日期型', 'Datetime', '4', null, '数据表字段日期类型');
INSERT INTO id_dictionary VALUES ('4_1', 'tableColType', '时间戳', 'TIMESTAMP', '1', '4', '数据表字段类型');
INSERT INTO id_dictionary VALUES ('4_2', 'tableColType', '日期', 'DATE', '2', '4', '数据表字段类型');
INSERT INTO id_dictionary VALUES ('5', 'sqlOperatorType', 'sql操纵类型', 'operator', '1', null, 'All Hive operators');
INSERT INTO id_dictionary VALUES ('5_1', 'sqlRelationalOperator', '关系连接符', 'relationalOperator', '1', '5', '关系连接');
INSERT INTO id_dictionary VALUES ('5_1_1', 'sqlRelationalOperator', '等于', '1', '1', '5_1', 'String,Number,Datetime,Boolean');
INSERT INTO id_dictionary VALUES ('5_1_10', 'sqlRelationalOperator', '小于等于', '10', '10', '5_1', 'Number,Datetime');
INSERT INTO id_dictionary VALUES ('5_1_11', 'sqlRelationalOperator', '在区间内', '11', '11', '5_1', 'Number,Datetime');
INSERT INTO id_dictionary VALUES ('5_1_12', 'sqlRelationalOperator', '为空', '12', '12', '5_1', 'String');
INSERT INTO id_dictionary VALUES ('5_1_13', 'sqlRelationalOperator', '不为空', '13', '13', '5_1', 'String');
INSERT INTO id_dictionary VALUES ('5_1_2', 'sqlRelationalOperator', '包含', '2', '2', '5_1', 'String,Number,Datetime,Boolean');
INSERT INTO id_dictionary VALUES ('5_1_3', 'sqlRelationalOperator', '开始以', '3', '3', '5_1', 'String');
INSERT INTO id_dictionary VALUES ('5_1_4', 'sqlRelationalOperator', '结束以', '4', '4', '5_1', 'String');
INSERT INTO id_dictionary VALUES ('5_1_5', 'sqlRelationalOperator', '为空', '5', '5', '5_1', 'String,Number,Datetime,Boolean');
INSERT INTO id_dictionary VALUES ('5_1_6', 'sqlRelationalOperator', '不为空', '6', '6', '5_1', 'String,Number,Datetime,Boolean');
INSERT INTO id_dictionary VALUES ('5_1_7', 'sqlRelationalOperator', '大于', '7', '7', '5_1', 'Number,Datetime');
INSERT INTO id_dictionary VALUES ('5_1_8', 'sqlRelationalOperator', '小于', '8', '8', '5_1', 'Number,Datetime');
INSERT INTO id_dictionary VALUES ('5_1_9', 'sqlRelationalOperator', '大于等于', '9', '9', '5_1', 'Number,Datetime');
INSERT INTO id_dictionary VALUES ('5_2', 'sqlLogicalOperator', '逻辑连接符', 'logicalOperator', '2', '5', '逻辑连接');
INSERT INTO id_dictionary VALUES ('5_2_1', 'sqlLogicalOperator', '并且', '1', '1', '5_2', '逻辑连接');
INSERT INTO id_dictionary VALUES ('5_2_2', 'sqlLogicalOperator', '或', '2', '2', '5_2', '逻辑连接');
INSERT INTO id_dictionary VALUES ('6', 'analyzeDataAbstractType', 'TEXT', '0', '1', null, '文本类型');
INSERT INTO id_dictionary VALUES ('7', 'analyzeDataAbstractType', 'NUMBER', '1', '2', null, '数字类型');
INSERT INTO id_dictionary VALUES ('8', 'analyzeDataAbstractType', 'TIME', '2', '3', null, '时间类型');
INSERT INTO id_dictionary VALUES ('9', 'analyzeDataAbstractType', 'FUNCTION', '3', '4', null, '方法');

-- ----------------------------
-- Records of operate_permission
-- ----------------------------
INSERT INTO operate_permission VALUES ('1', 'admin', null);
INSERT INTO operate_permission VALUES ('2', 'analyzer', 'apps.createApp,apps.tables.importExcel');
INSERT INTO operate_permission VALUES ('3', 'operator', 'apps.importApp');
INSERT INTO operate_permission VALUES ('4', 'personal_trial', 'apps.createApp,apps.tables.importExcel');

-- ----------------------------
-- Records of role_member
-- ----------------------------
INSERT INTO role_member VALUES ('role_member_default1', 'role_default1', '2', '2017-12-18 17:17:57', '1', '2017-12-18 17:17:57', '1');


-- ----------------------------
-- Records of role_permission
-- ----------------------------
INSERT INTO role_permission VALUES ('role_permission_default1', 'role_default1', 'application', 'application', 'm_write', '2017-12-18 17:17:57', '1', '2017-12-18 17:17:57', '1', '');


-- ----------------------------
-- Records of roles
-- ----------------------------
INSERT INTO roles VALUES ('role_default1', '默认', 'org1', '2017-12-18 17:17:57', '1', '2017-12-18 17:17:57', '1');


-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO users VALUES ('1', 'Thomas', 'Anderson', 'admin@incitedata.cn', '0', '$2a$10$tLLTl3JBG131m7Xx5txgiux/kO2dIfeXYal7e.BYmyqVGdWMN/vrO', '$2a$10$tLLTl3JBG131m7Xx5txgiu', 'admin', '0', null, '2016-07-07 13:44:58', '1', null, null, null, null);
INSERT INTO users VALUES ('2', 'dev', 'analyzer', 'dev@analyzer.cn', '0', '$2a$10$JvBJrvdso4ucv.Lxi1OVS.Orrv/bvnjFAo4dtvqJpn6qwS/.CUNze', '$2a$10$JvBJrvdso4ucv.Lxi1OVS.', 'analyzer', '0', null, '2016-08-24 14:22:59', '1', null, null, null, null);
INSERT INTO users VALUES ('3', 'operator', 'operator', 'operator@operator.com', '1', '$2a$10$x2KLn/aYrn/s4tMNIMAQ6ugxxoyrLvovEhsWItSvFGQLAMbmWj9bG', '$2a$10$x2KLn/aYrn/s4tMNIMAQ6u', 'operator', '0', null, '2017-03-22 13:41:53', '1', null, null, null, null);
