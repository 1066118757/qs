DROP TABLE IF EXISTS "c_dict_type";
CREATE TABLE "c_dict_type" (
  "id" int4 NOT NULL,
  "type_name" varchar(20),
  CONSTRAINT "c_dict_type_pkey" PRIMARY KEY ("id")
)WITH (OIDS=FALSE);
COMMENT ON TABLE "c_dict_type" IS '码表类型';
COMMENT ON COLUMN "c_dict_type"."type_name" IS '类型名';

DROP TABLE IF EXISTS "c_dict_mapping";
CREATE TABLE "c_dict_mapping" (
  "id" int4 NOT NULL,
  "type_id" int4,
  "key" int2,
  "value" varchar(20),
  "status" int2,
  "update_user" numeric,
  "update_time" timestamp(6),
  CONSTRAINT "c_dict_mapping_pkey" PRIMARY KEY ("id")
)WITH (OIDS=FALSE);
COMMENT ON TABLE "c_dict_mapping" IS '码表映射';
COMMENT ON COLUMN "c_dict_mapping"."type_id" IS '码表类型ID';
COMMENT ON COLUMN "c_dict_mapping"."key" IS '码表KEY';
COMMENT ON COLUMN "c_dict_mapping"."value" IS '码表VALUE';
COMMENT ON COLUMN "c_dict_mapping"."status" IS '记录状态';
COMMENT ON COLUMN "c_dict_mapping"."update_user" IS '更新人';
COMMENT ON COLUMN "c_dict_mapping"."update_time" IS '更新时间';


DROP TABLE IF EXISTS "t_storage_data";
CREATE TABLE "t_storage_data" (
  "id"             NUMERIC NOT NULL PRIMARY KEY,
  "name"           VARCHAR(20),
  "upload_user_id" NUMERIC,
  "upload_time"    TIMESTAMP DEFAULT current_timestamp,
  "introduction"   VARCHAR(100),
  "file_id" NUMERIC,
  "type"           INT4  DEFAULT 0,
  "status"         INT4 DEFAULT 1,
  "create_time"    TIMESTAMP DEFAULT current_timestamp,
  "create_user"    NUMERIC,
  "update_time"    TIMESTAMP DEFAULT current_timestamp,
  "update_user"    NUMERIC
) WITH(OIDS = FALSE);
COMMENT ON TABLE t_storage_data IS '数据存储';
COMMENT ON COLUMN t_storage_data.name IS '名称';
COMMENT ON COLUMN t_storage_data.upload_user_id IS '上传用户';
COMMENT ON COLUMN t_storage_data.upload_time IS '上传时间';
COMMENT ON COLUMN t_storage_data.file_id IS '文件id';
COMMENT ON COLUMN t_storage_data.introduction IS '介绍';
COMMENT ON COLUMN t_storage_data.type IS '数据类别,参考码表类型5';
COMMENT ON COLUMN t_storage_data.status  IS '记录状态 1:可用,2:不可用';


DROP TABLE IF EXISTS "t_file";
CREATE TABLE "t_file" (
  "id"          NUMERIC NOT NULL PRIMARY KEY,
  "path"        VARCHAR(60),
  "name"        VARCHAR(100),
  "file_type"   VARCHAR(10),
  "size"        NUMERIC,
  "create_user" NUMERIC,
  "create_time" TIMESTAMP DEFAULT current_timestamp
)WITH (OIDS = FALSE);
COMMENT ON TABLE t_file IS '文件表';
COMMENT ON COLUMN t_file.path IS '文件路径';
COMMENT ON COLUMN t_file.name IS '文件名';
COMMENT ON COLUMN t_file.file_type IS '文件类型';
COMMENT ON COLUMN t_file.size IS '文件大小,单位为kb';
COMMENT ON COLUMN t_file.create_user IS '创建人';
COMMENT ON COLUMN t_file.create_time IS '创建时间';


drop table if EXISTS t_metadata_theme;
create table t_metadata_theme
(
  id   numeric not null,
  name   varchar(30),
  remark varchar(100),
  state int4 DEFAULT 0,
  audit_time  timestamp DEFAULT CURRENT_TIMESTAMP,
  status int2 DEFAULT 1,
  create_user numeric,
  create_time timestamp DEFAULT CURRENT_TIMESTAMP,
  update_user numeric,
  update_time timestamp DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT t_metadata_theme_pkey PRIMARY KEY (id)
)WITH (OIDS=FALSE);
COMMENT ON TABLE t_metadata_theme IS '元数据主题表';
COMMENT ON COLUMN t_metadata_theme.name    IS '主题名';
COMMENT ON COLUMN t_metadata_theme.remark  IS '备注';
COMMENT ON COLUMN t_metadata_theme.state  IS '审核状态,参考码表类型1';
COMMENT ON COLUMN t_metadata_theme.audit_time  IS '审核时间';
COMMENT ON COLUMN t_metadata_theme.status  IS '记录状态 1:可用,2:不可用';


drop table if EXISTS t_metadata_theme_item;
create table t_metadata_theme_item
(
  id   numeric not null,
  theme_id numeric,
  name   varchar(30),
  state int4 DEFAULT 0,
  audit_time  timestamp DEFAULT CURRENT_TIMESTAMP ,
  status int2 DEFAULT 1,
  create_user numeric,
  create_time timestamp DEFAULT CURRENT_TIMESTAMP ,
  update_user numeric,
  update_time timestamp DEFAULT CURRENT_TIMESTAMP ,
  CONSTRAINT t_metadata_theme_item_pkey PRIMARY KEY (id)
)WITH (OIDS=FALSE);
COMMENT ON TABLE t_metadata_theme_item IS '元数据主题条目表';
COMMENT ON COLUMN t_metadata_theme_item.theme_id    IS '对应业务主题id';
COMMENT ON COLUMN t_metadata_theme_item.name    IS '条目名';
COMMENT ON COLUMN t_metadata_theme.state  IS '审核状态,参考码表类型1';
COMMENT ON COLUMN t_metadata_theme.audit_time  IS '审核时间';
COMMENT ON COLUMN t_metadata_theme.status  IS '记录状态 1:可用,2:不可用';


drop table if EXISTS t_metadata_item;
create table t_metadata_item
(
  id   numeric not null,
  theme_item_id numeric,
  name  varchar(30),
  type  int4,
  purpose varchar(500),
  state int4 DEFAULT 0,
  audit_time  timestamp DEFAULT CURRENT_TIMESTAMP ,
  status int2 DEFAULT 1,
  create_user numeric,
  create_time timestamp DEFAULT CURRENT_TIMESTAMP ,
  update_user numeric,
  update_time timestamp DEFAULT CURRENT_TIMESTAMP ,
  CONSTRAINT t_metadata_item_pkey PRIMARY KEY (id)
)WITH (OIDS=FALSE);
COMMENT ON TABLE t_metadata_item IS '元数据条目表';
COMMENT ON COLUMN t_metadata_item.theme_item_id    IS '元数据主题条目id';
COMMENT ON COLUMN t_metadata_item.name    IS '元数据条目名';
COMMENT ON COLUMN t_metadata_item.type    IS '条目类型，例如：数据结构，数据字典等,参考码表类型2';
COMMENT ON COLUMN t_metadata_item.purpose    IS '用途';
COMMENT ON COLUMN t_metadata_theme.state  IS '审核状态,参考码表类型1';
COMMENT ON COLUMN t_metadata_theme.audit_time  IS '审核时间';
COMMENT ON COLUMN t_metadata_theme.status  IS '记录状态 1:可用,2:不可用';


drop table if EXISTS t_metadata_detail;
create table t_metadata_detail
(
  id   numeric not null,
	index int4,
  metadata_item_id numeric,
  col_displayname  varchar(20),
  col_type  int4,
  col_comment  varchar(50),
  col_name varchar(30),
  state int4 DEFAULT 0,
  audit_time  timestamp DEFAULT CURRENT_TIMESTAMP,
  status int2 DEFAULT 1,
  create_user numeric,
  create_time timestamp DEFAULT CURRENT_TIMESTAMP ,
  update_user numeric,
  update_time timestamp DEFAULT CURRENT_TIMESTAMP ,
  CONSTRAINT t_metadata_detail_pkey PRIMARY KEY (id)
)WITH (OIDS=FALSE);
COMMENT ON TABLE t_metadata_detail IS '元数据详情表';
COMMENT ON COLUMN t_metadata_detail.metadata_item_id    IS '元数据条目id';
COMMENT ON COLUMN t_metadata_detail.index    IS '元数据条目序列号';
COMMENT ON COLUMN t_metadata_detail.col_displayname    IS '字段真实名，对应原型：字段名';
COMMENT ON COLUMN t_metadata_detail.col_type    IS '列类型，例如：文本，数值,参考码表类型3';
COMMENT ON COLUMN t_metadata_detail.col_comment    IS '列内容，对应原型：字段含义';
COMMENT ON COLUMN t_metadata_detail.col_name  IS '数据库对应列名，对应原型：原始字段';
COMMENT ON COLUMN t_metadata_detail.state  IS '审核状态,参考码表类型1';
COMMENT ON COLUMN t_metadata_detail.audit_time  IS '审核时间';
COMMENT ON COLUMN t_metadata_detail.status  IS '记录状态 1:可用,2:不可用';

DROP TABLE IF EXISTS "t_operate_log";
CREATE TABLE "t_operate_log" (
  "id" NUMERIC NOT NULL ,
  "operator_id" NUMERIC ,
  "operate_table" VARCHAR (50),
  "operate_time" TIMESTAMP,
  "action_id" int4,
  "result" int4,
  CONSTRAINT "t_operate_log_pkey" PRIMARY KEY  ("id")
)WITH (OIDS=FALSE);
COMMENT ON TABLE "t_operate_log" IS '数据审计操作日志';
COMMENT ON COLUMN "t_operate_log"."id" IS 'ID';
COMMENT ON COLUMN "t_operate_log"."operator_id" IS '操作人ID';
COMMENT ON COLUMN "t_operate_log"."operate_table" IS '操作表';
COMMENT ON COLUMN "t_operate_log"."operate_time" IS '操作时间';
COMMENT ON COLUMN "t_operate_log"."action_id" IS '操作条目';
COMMENT ON COLUMN "t_operate_log"."result" IS '操作状态,参考码表类型4';


DROP TABLE IF EXISTS "t_operate_action";
CREATE TABLE "t_operate_action" (
  "id" int4 NOT NULL,
  "action_desc" VARCHAR (100),
  "scope" int4,
  CONSTRAINT "t_operate_action_pkey" PRIMARY KEY ("id")
)WITH (OIDS=FALSE);
COMMENT ON TABLE "t_operate_action" IS '操作描述表';
COMMENT ON COLUMN "t_operate_action"."id" IS 'id';
COMMENT ON COLUMN "t_operate_action"."action_desc" IS '操作描述';
COMMENT ON COLUMN "t_operate_action"."scope" IS '操作域';


INSERT INTO "c_dict_type" ("id", "type_name") VALUES ('1', '审核状态');
INSERT INTO "c_dict_type" ("id", "type_name") VALUES ('2', '元数据条目类型');
INSERT INTO "c_dict_type" ("id", "type_name") VALUES ('3', '字段类型');
INSERT INTO "c_dict_type" ("id", "type_name") VALUES ('4', '操作结果');
INSERT INTO "c_dict_type" ("id", "type_name") VALUES ('5', '存储数据类别');

INSERT INTO "c_dict_mapping" VALUES ('101', '1', '1', '未审核', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('102', '1', '2', '审核通过', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('103', '1', '3', '审核不通过', '1',  '0',current_timestamp);

INSERT INTO "c_dict_mapping" VALUES ('201', '2', '1', '数据结构', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('202', '2', '2', '数据字典', '1',  '0',current_timestamp);

INSERT INTO "c_dict_mapping" VALUES ('301', '3', '1', '文本', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('302', '3', '2', '数值', '1',  '0',current_timestamp);

INSERT INTO "c_dict_mapping" VALUES ('401', '1', '1', '成功', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('402', '1', '2', '失败', '1',  '0',current_timestamp);

INSERT INTO "c_dict_mapping" VALUES ('501', '5', '1', '图片', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('502', '5', '2', '视频', '1',  '0',current_timestamp);


