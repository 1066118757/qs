INSERT INTO "c_dict_mapping" VALUES ('1503', '15', '3', '视图合表', '1',  '0',current_timestamp);

delete from c_base_config where 1=1;
INSERT INTO c_base_config(id,key,value) VALUES(1,'hdfs.ip','127.0.0.1');
INSERT INTO c_base_config(id,key,value) VALUES(2,'hdfs.port','8020');

INSERT INTO c_base_config(id,key,value) VALUES(3,'notebook.host','127.0.0.1');
INSERT INTO c_base_config(id,key,value) VALUES(4,'notebook.port','8888');

INSERT INTO c_base_config(id,key,value) VALUES(5,'dist.ip','127.0.0.1');
INSERT INTO c_base_config(id,key,value) VALUES(6,'dist.port','10000');
INSERT INTO c_base_config(id,key,value) VALUES(7,'dist.username','');
INSERT INTO c_base_config(id,key,value) VALUES(8,'dist.password','');

INSERT INTO c_base_config(id,key,value) VALUES(9,'kafka.server','127.0.0.1:8092');

INSERT INTO c_base_config(id,key,value) VALUES(10,'idmanager-server.baseUrl','http://127.0.0.1:9000');