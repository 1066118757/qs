ALTER TABLE t_storage_data ADD  COLUMN is_public boolean DEFAULT  FALSE NOT NULL;

ALTER TABLE t_file DROP  COLUMN is_public;
ALTER TABLE t_file DROP  COLUMN  description;
ALTER TABLE t_oozie_job_log ADD  COLUMN app_path varchar(100) DEFAULT  '' NOT NULL;

