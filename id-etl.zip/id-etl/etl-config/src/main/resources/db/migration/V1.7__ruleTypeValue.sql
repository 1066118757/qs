INSERT INTO "c_dict_mapping" VALUES ('802', '8', '2', '更新值', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('803', '8', '3', '新增列', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('804', '8', '4', '表达式', '1',  '0',current_timestamp);

ALTER TABLE t_clear_task add column kernel_id VARCHAR (50);
ALTER TABLE t_clear_task add column session_id VARCHAR (50);