ALTER TABLE t_clear_task add column email VARCHAR(60) DEFAULT '';
ALTER TABLE t_clear_task add column phone VARCHAR(30) DEFAULT '';
ALTER TABLE t_clear_task add column priority INT4 DEFAULT 0;

COMMENT ON COLUMN t_clear_task.email IS '接收电子邮件的email地址';
COMMENT ON COLUMN t_clear_task.phone IS '接收短信的电话号码';
COMMENT ON COLUMN t_clear_task.priority IS '任务优先级（定时）';