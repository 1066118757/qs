alter table t_clear_task_log ALTER COLUMN "start_time" SET DEFAULT NULL;
alter table t_clear_task_log ALTER COLUMN "end_time" SET DEFAULT NULL;
