DROP TABLE IF EXISTS "t_clear_rule";
CREATE TABLE "t_clear_rule" (
  "id"             NUMERIC NOT NULL PRIMARY KEY,
  "name"           VARCHAR(20) DEFAULT '',
  "summary"        VARCHAR (150) DEFAULT '',
  "rule_type"      INT4 DEFAULT 0,
  "script_type"   INT4 DEFAULT 0,
  "script_code"   VARCHAR (1000) DEFAULT '',
  "state"   INT4 DEFAULT 1,
  "status"         INT4 DEFAULT 1,
  "create_time"    TIMESTAMP DEFAULT current_timestamp,
  "create_user"    NUMERIC DEFAULT 0,
  "update_time"    TIMESTAMP DEFAULT current_timestamp,
  "update_user"    NUMERIC DEFAULT 0
) WITH(OIDS = FALSE);

COMMENT ON TABLE t_clear_rule IS '数据整理规则表';
COMMENT ON COLUMN t_clear_rule.id IS 'id';
COMMENT ON COLUMN t_clear_rule.name IS '规则名';
COMMENT ON COLUMN t_clear_rule.summary IS '概述';
COMMENT ON COLUMN t_clear_rule.rule_type IS '规则类型 例：自定义,更新值，过滤值，参考码表8';
COMMENT ON COLUMN t_clear_rule.script_type IS '脚本类型 例：java hql python  参考码表9';
COMMENT ON COLUMN t_clear_rule.script_code IS '脚本代码';
COMMENT ON COLUMN t_clear_rule.state IS '规则状态 1:代表启用,0:代表禁用';


DROP TABLE IF EXISTS "t_rule_param";
CREATE TABLE "t_rule_param" (
  "id"             NUMERIC NOT NULL PRIMARY KEY,
  "name"           VARCHAR(20) DEFAULT '',
  "clear_rule_id" NUMERIC DEFAULT 0,
  "type"           INT4  DEFAULT 0,
  "get_type"    INT4 DEFAULT 0,
  "index"        VARCHAR (150) DEFAULT '',
  "status"         INT4 DEFAULT 1,
  "create_time"    TIMESTAMP DEFAULT current_timestamp,
  "create_user"    NUMERIC DEFAULT 0,
  "update_time"    TIMESTAMP DEFAULT current_timestamp,
  "update_user"    NUMERIC DEFAULT 0
) WITH(OIDS = FALSE);

COMMENT ON TABLE t_rule_param IS '规则参数表';
COMMENT ON COLUMN t_rule_param.id IS 'id';
COMMENT ON COLUMN t_rule_param.name IS '参数名';
COMMENT ON COLUMN t_rule_param.clear_rule_id IS '对应规则id';
COMMENT ON COLUMN t_rule_param.type IS '参数类型 参考码表13';
COMMENT ON COLUMN t_rule_param.get_type IS '参数获取类型 参考码表12';
COMMENT ON COLUMN t_rule_param.index IS '参数所在规则表达式位置';


DROP TABLE IF EXISTS "t_rule_instance";
CREATE TABLE "t_rule_instance" (
  "id"             NUMERIC NOT NULL PRIMARY KEY,
  "clear_record_id"  numeric DEFAULT 0,
  "metadata_detail_id"   numeric DEFAULT 0,
  "expression" VARCHAR (100) DEFAULT '',
  "clear_rule_id"    numeric DEFAULT 0,
  "status"         INT4 DEFAULT 1,
  "create_time"    TIMESTAMP DEFAULT current_timestamp,
  "create_user"    NUMERIC DEFAULT 0,
  "update_time"    TIMESTAMP DEFAULT current_timestamp,
  "update_user"    NUMERIC DEFAULT 0
) WITH(OIDS = FALSE);

COMMENT ON TABLE t_rule_instance IS '清洗规则实例化表';
COMMENT ON COLUMN t_rule_instance.id IS 'id';
COMMENT ON COLUMN t_rule_instance.clear_record_id IS '清洗记录id';
COMMENT ON COLUMN t_rule_instance.metadata_detail_id IS '操作表对应的元数据条目详情id，列对应元数据条目详情';
COMMENT ON COLUMN t_rule_instance.expression IS 'boolean表达式，用于使用表达式选择原始值用于替换';
COMMENT ON COLUMN t_rule_instance.clear_rule_id IS '清洗规则id';


DROP TABLE IF EXISTS "t_clear_record";
CREATE TABLE "t_clear_record" (
  "id"             NUMERIC NOT NULL PRIMARY KEY,
  "name"           VARCHAR(20) DEFAULT '',
  "labels"        Integer[],
  "metadata_item_id"   numeric DEFAULT 0,
  "status"         INT4 DEFAULT 1,
  "create_time"    TIMESTAMP DEFAULT current_timestamp,
  "create_user"    NUMERIC DEFAULT 0,
  "update_time"    TIMESTAMP DEFAULT current_timestamp,
  "update_user"    NUMERIC DEFAULT 0
) WITH(OIDS = FALSE);

COMMENT ON TABLE t_clear_record IS '数据整合记录表';
COMMENT ON COLUMN t_clear_record.id IS 'id';
COMMENT ON COLUMN t_clear_record.name IS '记录名';
COMMENT ON COLUMN t_clear_record.labels IS '标签,参考码表 14';
COMMENT ON COLUMN t_clear_record.metadata_item_id IS '操作表对应的条目id，表对应元数据条目';


DROP TABLE IF EXISTS "t_clear_task";
CREATE TABLE "t_clear_task" (
  "id"             NUMERIC NOT NULL PRIMARY KEY,
  "record_id"   numeric DEFAULT 0,
  "name"           VARCHAR(20) DEFAULT '',
  "in_item_id" numeric DEFAULT 0,
  "in_item_name" numeric DEFAULT 0,
  "out_theme_item_id" numeric DEFAULT 0,
  "out_item_name" varchar(30) DEFAULT '' COLLATE "default",
  "out_item_type" int4 DEFAULT 0,
  "out_item_purpose" varchar(500) DEFAULT '' COLLATE "default",
  "out_item_id" numeric DEFAULT 0,
  "cron_code" VARCHAR (80) DEFAULT '',
  "near_start_time"  TIMESTAMP DEFAULT current_timestamp,
  "near_end_time"  TIMESTAMP DEFAULT current_timestamp,
  "near_result"  INT4 DEFAULT 0,
  "type"  INT4 DEFAULT 0,
  "is_note"  bool DEFAULT FALSE ,
  "is_email"  bool DEFAULT FALSE,
  "status"         INT4 DEFAULT 1,
  "create_time"    TIMESTAMP DEFAULT current_timestamp,
  "create_user"    NUMERIC DEFAULT 0,
  "update_time"    TIMESTAMP DEFAULT current_timestamp,
  "update_user"    NUMERIC DEFAULT 0
) WITH(OIDS = FALSE);

COMMENT ON TABLE t_clear_task IS '数据整合任务表';
COMMENT ON COLUMN t_clear_task.id IS 'id';
COMMENT ON COLUMN t_clear_task.record_id IS '整合记录id';
COMMENT ON COLUMN t_clear_task.name IS '任务名';
COMMENT ON COLUMN t_clear_task.in_item_id IS '输入表id';
COMMENT ON COLUMN t_clear_task.in_item_name IS '输入表名';
COMMENT ON COLUMN t_clear_task.out_theme_item_id IS '输出表所在主题条目id';
COMMENT ON COLUMN t_clear_task.out_item_name IS '输出表名';
COMMENT ON COLUMN t_clear_task.out_item_type IS '输出表类型';
COMMENT ON COLUMN t_clear_task.out_item_purpose IS '输出表用途';
COMMENT ON COLUMN t_clear_task.out_item_id IS '输出表id,对应元数据条目id';
COMMENT ON COLUMN t_clear_task.cron_code IS '定时任务cron表达式';
COMMENT ON COLUMN t_clear_task.near_start_time IS '最近一次开始时间';
COMMENT ON COLUMN t_clear_task.near_end_time IS '最近一次结束时间';
COMMENT ON COLUMN t_clear_task.near_result IS '最近一次任务执行结果，参考码表10';
COMMENT ON COLUMN t_clear_task.type IS '任务执行方式，参考码表11';
COMMENT ON COLUMN t_clear_task.is_note IS '短信提醒，true 开启 false 关闭';
COMMENT ON COLUMN t_clear_task.is_email IS '邮件提醒，true 开启 false 关闭';


DROP TABLE IF EXISTS "t_clear_task_log";
CREATE TABLE "t_clear_task_log" (
  "id"             NUMERIC NOT NULL PRIMARY KEY,
  "task_id"   numeric DEFAULT 0,
  "start_time"  TIMESTAMP DEFAULT current_timestamp,
  "end_time"  TIMESTAMP DEFAULT current_timestamp,
  "result"  INT4 DEFAULT 0,
  "create_user"    NUMERIC DEFAULT 0
) WITH(OIDS = FALSE);

COMMENT ON TABLE t_clear_task_log IS '数据整合任务日志表';
COMMENT ON COLUMN t_clear_task_log.id IS 'id';
COMMENT ON COLUMN t_clear_task_log.task_id IS '任务id';
COMMENT ON COLUMN t_clear_task_log.start_time IS '开始时间';
COMMENT ON COLUMN t_clear_task_log.end_time IS '结束时间';
COMMENT ON COLUMN t_clear_task_log.result IS '任务执行结果，参考码表10';


INSERT INTO "c_dict_type" ("id", "type_name") VALUES ('8', '规则类型');
INSERT INTO "c_dict_mapping" VALUES ('801', '8', '1', '自定义', '1',  '0',current_timestamp);

INSERT INTO "c_dict_type" ("id", "type_name") VALUES ('9', '脚本类型');
INSERT INTO "c_dict_mapping" VALUES ('901', '9', '1', 'java', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('902', '9', '2', 'python', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('903', '9', '3', 'hql', '1',  '0',current_timestamp);

INSERT INTO "c_dict_type" ("id", "type_name") VALUES ('10', '整合任务执行结果');
INSERT INTO "c_dict_mapping" VALUES ('1001', '10', '1', '执行中', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('1002', '10', '2', '成功', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('1003', '10', '3', '失败', '1',  '0',current_timestamp);

INSERT INTO "c_dict_type" ("id", "type_name") VALUES ('11', '整合任务执行方式');
INSERT INTO "c_dict_mapping" VALUES ('1101', '11', '1', '定时任务', '1',  '0',current_timestamp);

INSERT INTO "c_dict_type" ("id", "type_name") VALUES ('12', '规则参数获取方式');
INSERT INTO "c_dict_mapping" VALUES ('1201', '12', '1', '输入框', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('1202', '12', '2', '下拉框', '1',  '0',current_timestamp);

INSERT INTO "c_dict_type" ("id", "type_name") VALUES ('13', '规则参数类型');
INSERT INTO "c_dict_mapping" VALUES ('1301', '13', '1', 'String', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('1302', '13', '2', 'Bigdecimal', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('1303', '13', '3', 'Integer', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('1304', '13', '4', 'Short', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('1305', '13', '5', 'Boolean', '1',  '0',current_timestamp);

INSERT INTO "c_dict_type" ("id", "type_name") VALUES ('14', '标签');


