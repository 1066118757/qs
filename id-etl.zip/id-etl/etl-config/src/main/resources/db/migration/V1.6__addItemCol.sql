ALTER TABLE t_metadata_item add column source_type INT4 DEFAULT 1501;
COMMENT ON COLUMN "t_metadata_item"."source_type" IS '条目来源类型，参考码表15';
alter table t_file ALTER COLUMN "path" TYPE varchar(200);
alter table t_clear_task ALTER COLUMN "in_item_name" TYPE varchar(30) ;
alter table t_clear_task ALTER COLUMN "in_item_name" SET DEFAULT '';

INSERT INTO "c_dict_type" ("id", "type_name") VALUES ('15', '条目来源类型');
INSERT INTO "c_dict_mapping" VALUES ('1501', '15', '1', '管理员', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('1502', '15', '2', '数据清洗', '1',  '0',current_timestamp);