INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('900', '未知的元数据详情操作', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('901', '添加元数据详情', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('902', '删除元数据详情', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('903', '更新元数据详情', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('904', '元数据详情列表查询', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('905', '通过id查询元数据详情信息', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('906', '下载元数据模板', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('907', '导出数据结构', '1');

INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1000', '未知的元数据条目操作', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1001', '添加元数据条目', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1002', '更新元数据条目', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1003', '删除元数据条目', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1004', '元数据条目列表查询', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1005', '通过id查询元数据条目信息', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1006', '元数据条目添加(同时添加详情)', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1007', '元数据条目更新(同时更新详情)', '1');

INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1100', '未知的元数据主题操作', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1101', '添加元数据主题', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1102', '更新元数据主题', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1103', '删除元数据主题', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1104', '元数据主题列表查询', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1105', '通过id查询元数据主题信息', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1106', '查询全部元数据主题信息(包含主题条目)', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1107', '元数据主题更新(同时更新主题条目)', '1');

INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1200', '未知的元数据主题条目操作', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1201', '添加元数据主题条目', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1202', '更新元数据主题条目', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1203', '删除元数据主题条目', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1204', '元数据主题条目列表查询', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1205', '通过id查询元数据主题条目信息', '1');

INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1300', '未知的数据存储操作', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1301', '查询逻辑分区列表', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1302', '查询指定逻辑分区下的所有表', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1303', '数据追加', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1304', '获取文件数据', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1305', '加载，分享', '1');
INSERT INTO "t_operate_action" ("id", "action_desc", "scope") VALUES ('1306', '获取同步记录', '1');


