INSERT INTO "c_dict_mapping" VALUES ('1004', '10', '4', '未执行', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('1005', '10', '5', '正在提交', '1',  '0',current_timestamp);
INSERT INTO "c_dict_mapping" VALUES ('1006', '10', '6', '已提交', '1',  '0',current_timestamp);



