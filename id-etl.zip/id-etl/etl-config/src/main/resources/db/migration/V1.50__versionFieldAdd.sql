ALTER TABLE t_version ADD  COLUMN icon_image varchar(400);
COMMENT ON COLUMN t_version.icon_image IS '图标图片';