DELETE FROM   "c_dict_mapping" WHERE "id" = 1504;
INSERT INTO "c_dict_mapping" ("id", "type_id", "key", "value", "status", "update_user", "update_time") VALUES ('1504', '15', '3', '中科院文献数据', '1', '0', '2018-02-05 15:50:13.667338');
