ALTER TABLE t_tree_object ADD  COLUMN parent_type varchar(10) NOT NULL;
