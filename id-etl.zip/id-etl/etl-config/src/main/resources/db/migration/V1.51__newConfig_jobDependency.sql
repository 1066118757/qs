DELETE FROM   "c_base_config" WHERE  "key" in('repartition.switch','repartition.block.size_mb','repartition.frequency_hour','clear-hdfs-temp-files.switch','create-kafka-topic.switch');
INSERT INTO  "c_base_config" ("id", "key", "value", "status", "create_time", "create_user", "update_time", "update_user")
VALUES ('15', 'repartition.switch', 'true', '1', '2018-05-24 17:52:34.355024', NULL, '2018-05-24 17:52:34.355024', NULL);
INSERT INTO  "c_base_config" ("id", "key", "value", "status", "create_time", "create_user", "update_time", "update_user")
VALUES ('16', 'repartition.block.size_mb', '64', '1', '2018-05-24 17:52:34.355024', NULL, '2018-05-24 17:52:34.355024', NULL);
INSERT INTO  "c_base_config" ("id", "key", "value", "status", "create_time", "create_user", "update_time", "update_user")
VALUES ('17', 'repartition.frequency_hour', '120', '1', '2018-05-24 17:52:34.355024', NULL, '2018-05-24 17:52:34.355024', NULL);
INSERT INTO  "c_base_config" ("id", "key", "value", "status", "create_time", "create_user", "update_time", "update_user")
VALUES ('18', 'clear-hdfs-temp-files.switch', 'false', '1', '2018-05-24 17:52:34.355024', NULL, '2018-05-24 17:52:34.355024', NULL);
INSERT INTO  "c_base_config" ("id", "key", "value", "status", "create_time", "create_user", "update_time", "update_user")
VALUES ('19', 'create-kafka-topic.switch', 'false', '1', '2018-05-24 17:52:34.355024', NULL, '2018-05-24 17:52:34.355024', NULL);

INSERT INTO  "c_base_config" ("id", "key", "value", "status", "create_time", "create_user", "update_time", "update_user")
VALUES ('20', 'job.max.retry.times', '5', '1', '2018-05-24 17:52:34.355024', NULL, '2018-05-24 17:52:34.355024', NULL);
INSERT INTO  "c_base_config" ("id", "key", "value", "status", "create_time", "create_user", "update_time", "update_user")
VALUES ('21', 'retry.frequency_minute', '20', '1', '2018-05-24 17:52:34.355024', NULL, '2018-05-24 17:52:34.355024', NULL);


ALTER TABLE t_job DROP  COLUMN kernel_id;
ALTER TABLE t_job DROP  COLUMN session_id;

ALTER TABLE t_clear_task DROP  COLUMN kernel_id;
ALTER TABLE t_clear_task DROP  COLUMN session_id;

ALTER TABLE t_job ADD  COLUMN dependence VARCHAR(2000) DEFAULT '' NOT NULL;
ALTER TABLE t_clear_task ADD  COLUMN dependence VARCHAR(2000) DEFAULT '' NOT NULL;

