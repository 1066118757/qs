
DROP TABLE IF EXISTS t_tree_object;
CREATE TABLE t_tree_object
(
    id numeric NOT NULL,
    name varchar(50) NOT NULL,
    source_object_id NUMERIC,
    parent_object_id numeric,
    object_type varchar(10) NOT NULL,
    leaf_object_type varchar(10),
    parent_type varchar(10) NOT NULL,
    create_user varchar(40) NOT NULL,
    create_time timestamp without time zone,
    CONSTRAINT t_tree_object_pkey PRIMARY KEY (id)
);
