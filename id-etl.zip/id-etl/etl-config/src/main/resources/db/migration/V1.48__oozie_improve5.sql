DROP TABLE IF EXISTS m_oozieJob_node;
CREATE TABLE m_oozieJob_node
(
    id numeric NOT NULL,
    oozie_job_id NUMERIC,
    node_id numeric,
    node_type varchar(10) NOT NULL,
    create_time timestamp without time zone,
    CONSTRAINT m_oozieJob_node_pkey PRIMARY KEY (id)
);
