ALTER TABLE t_oozie_job_log ADD  COLUMN temp_tables varchar(1000) DEFAULT  '' NOT NULL;

ALTER TABLE t_oozie_job_log ADD  COLUMN cleared boolean DEFAULT  false NOT NULL;

DROP TABLE IF EXISTS m_group_user;

CREATE TABLE m_group_user
(
    id NUMERIC NOT NULL,
    group_id  varchar(40) NOT NULL,
    user_id  varchar(40) NOT NULL,
    create_time  timestamp without time zone,
    CONSTRAINT m_group_user_pkey PRIMARY KEY (id)
);

DROP TABLE IF EXISTS t_oozie_share;
CREATE TABLE t_oozie_share
(
    id numeric NOT NULL,
    source_object_id NUMERIC NOT NULL,
    source_object_type varchar(10),
    dist_object_id varchar(40) NOT NULL,
    dist_object_type varchar(10),
    create_time timestamp without time zone,
    CONSTRAINT t_oozie_share_pkey PRIMARY KEY (id)
);

DROP TABLE IF EXISTS t_tree_object;
CREATE TABLE t_tree_object
(
    id numeric NOT NULL,
    name varchar(50) NOT NULL,
    source_object_id NUMERIC NOT NULL,
    parent_object_id numeric,
    object_type varchar(10) NOT NULL,
    leaf_object_type varchar(10),
    create_user varchar(40) NOT NULL,
    create_time timestamp without time zone,
    CONSTRAINT t_tree_object_pkey PRIMARY KEY (id)
);

ALTER TABLE t_oozie_job_log ADD  COLUMN graph_xml text DEFAULT '' NOT NULL;



