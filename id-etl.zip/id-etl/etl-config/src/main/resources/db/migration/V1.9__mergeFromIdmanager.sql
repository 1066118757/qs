-- ----------------------------
-- Table structure for access_tokens
-- ----------------------------
DROP TABLE IF EXISTS "access_tokens";
CREATE TABLE "access_tokens" (
"access_token" varchar(254) COLLATE "default" NOT NULL,
"refresh_token" varchar(254) COLLATE "default",
"user_guid" varchar(36) COLLATE "default" NOT NULL,
"scope" varchar(254) COLLATE "default",
"expires_in" int8,
"created_at" timestamp(6) DEFAULT now() NOT NULL,
"client_id" varchar(254) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for add_data_source_table
-- ----------------------------
DROP TABLE IF EXISTS "add_data_source_table";
CREATE TABLE "add_data_source_table" (
"id" varchar(36) COLLATE "default" NOT NULL,
"schema" varchar(45) COLLATE "default" NOT NULL,
"name" varchar(45) COLLATE "default" NOT NULL,
"data_source_list_id" varchar(45) COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for analyze_map_detail
-- ----------------------------
DROP TABLE IF EXISTS "analyze_map_detail";
CREATE TABLE "analyze_map_detail" (
"analyze_map_id" varchar(40) COLLATE "default" NOT NULL,
"analyze_map_info_uuid" varchar(36) COLLATE "default" NOT NULL,
"col_name" varchar(45) COLLATE "default" NOT NULL,
"col_analyze_type" int4 NOT NULL,
"col_display_name" varchar(45) COLLATE "default" NOT NULL,
"col_exp" varchar(200) COLLATE "default" NOT NULL,
"col_data_type" int4 NOT NULL,
"introduction" varchar(200) COLLATE "default",
"db_type" varchar(50) COLLATE "default",
"required" bool,
"is_del" bool NOT NULL,
"number_format" varchar(200) COLLATE "default",
"order_index" int2,
"sensitive" int2 DEFAULT 0 NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for analyze_map_detail_group
-- ----------------------------
DROP TABLE IF EXISTS "analyze_map_detail_group";
CREATE TABLE "analyze_map_detail_group" (
"id" varchar(40) COLLATE "default" NOT NULL,
"name" varchar(40) COLLATE "default" NOT NULL,
"values" varchar(4000) COLLATE "default" NOT NULL,
"analyze_map_detail_id" varchar(40) COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for analyze_map_info
-- ----------------------------
DROP TABLE IF EXISTS "analyze_map_info";
CREATE TABLE "analyze_map_info" (
"analyze_map_info_uuid" varchar(36) COLLATE "default" NOT NULL,
"schema" varchar(45) COLLATE "default" NOT NULL,
"table_name" varchar(45) COLLATE "default" NOT NULL,
"display_name" varchar(45) COLLATE "default" NOT NULL,
"scope" varchar(45) COLLATE "default",
"created_uuid" varchar(36) COLLATE "default" NOT NULL,
"table_type" int2 DEFAULT 0 NOT NULL,
"view_text" varchar(4000) COLLATE "default",
"data_update_time" timestamp(6),
"introduction" varchar(200) COLLATE "default",
"is_del" bool NOT NULL,
"group_id" varchar(36) COLLATE "default" NOT NULL,
"shared_from" varchar(36) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for applications
-- ----------------------------
DROP TABLE IF EXISTS "applications";
CREATE TABLE "applications" (
"id" varchar(40) COLLATE "default" NOT NULL,
"name" varchar(200) COLLATE "default",
"description" varchar(500) COLLATE "default",
"created_uuid" varchar(36) COLLATE "default",
"is_del" bool
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for audit_info
-- ----------------------------
DROP TABLE IF EXISTS "audit_info";
CREATE TABLE "audit_info" (
"id" varchar(40) COLLATE "default" NOT NULL,
"audit_object_id" varchar(40) COLLATE "default" NOT NULL,
"audit_object_type" varchar(40) COLLATE "default" NOT NULL,
"audit_status" int2,
"audit_by" varchar(40) COLLATE "default",
"audit_at" timestamp(6) DEFAULT now(),
"audit_desc" varchar(200) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for auth_codes
-- ----------------------------
DROP TABLE IF EXISTS "auth_codes";
CREATE TABLE "auth_codes" (
"authorization_code" varchar(254) COLLATE "default" NOT NULL,
"user_guid" varchar(36) COLLATE "default" NOT NULL,
"redirect_uri" varchar(254) COLLATE "default",
"created_at" timestamp(6) DEFAULT now() NOT NULL,
"scope" varchar(254) COLLATE "default",
"client_id" varchar(254) COLLATE "default",
"expires_in" int4 NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for chart_info
-- ----------------------------
DROP TABLE IF EXISTS "chart_info";
CREATE TABLE "chart_info" (
"chart_uuid" varchar(36) COLLATE "default" NOT NULL,
"chart_name" varchar(45) COLLATE "default" NOT NULL,
"chart_description" varchar(200) COLLATE "default",
"chart_type" varchar(45) COLLATE "default" NOT NULL,
"image_url" varchar(200) COLLATE "default" NOT NULL,
"limit" int4 NOT NULL,
"scope" varchar(200) COLLATE "default" NOT NULL,
"created_at" timestamp(6) DEFAULT now() NOT NULL,
"created_by_guid" varchar(36) COLLATE "default" NOT NULL,
"updated_at" timestamp(6),
"updated_by_guid" varchar(36) COLLATE "default",
"application_id" varchar(36) COLLATE "default",
"rule" varchar(2000) COLLATE "default",
"advance_filter" text COLLATE "default",
"analyze_map_info_uuid" varchar(36) COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for chart_item_join_link
-- ----------------------------
DROP TABLE IF EXISTS "chart_item_join_link";
CREATE TABLE "chart_item_join_link" (
"join_link_id" varchar(36) COLLATE "default" NOT NULL,
"related_chart_uuid" varchar(36) COLLATE "default",
"left_analyze_table_id" varchar(36) COLLATE "default",
"left_analyze_col_id" varchar(36) COLLATE "default",
"join_link_type" int4,
"right_analyze_table_id" varchar(36) COLLATE "default",
"right_analyze_col_id" varchar(36) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for chart_pre_warning
-- ----------------------------
DROP TABLE IF EXISTS "chart_pre_warning";
CREATE TABLE "chart_pre_warning" (
"id" varchar(40) COLLATE "default" NOT NULL,
"name" varchar(40) COLLATE "default" NOT NULL,
"is_and" bool NOT NULL,
"notice_type" int2 NOT NULL,
"notice_channel" varchar(10) COLLATE "default" NOT NULL,
"notice_objs" varchar(4000) COLLATE "default",
"chart_info_id" varchar(40) COLLATE "default" NOT NULL,
"is_on" bool NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for chart_pre_warning_condition
-- ----------------------------
DROP TABLE IF EXISTS "chart_pre_warning_condition";
CREATE TABLE "chart_pre_warning_condition" (
"id" varchar(40) COLLATE "default" NOT NULL,
"operator" int2 NOT NULL,
"threshold" varchar(40) COLLATE "default" NOT NULL,
"chart_pre_warning_id" varchar(40) COLLATE "default" NOT NULL,
"analyze_map_id" varchar(40) COLLATE "default" NOT NULL,
"operator_type" int4 NOT NULL,
"chart_info_id" varchar(40) COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for chart_scope
-- ----------------------------
DROP TABLE IF EXISTS "chart_scope";
CREATE TABLE "chart_scope" (
"chart_scope_id" varchar(36) COLLATE "default" NOT NULL,
"chart_id" varchar(36) COLLATE "default",
"scope" varchar(200) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for chart_used_col_info
-- ----------------------------
DROP TABLE IF EXISTS "chart_used_col_info";
CREATE TABLE "chart_used_col_info" (
"chart_used_col_id" varchar(36) COLLATE "default" NOT NULL,
"chart_uuid" varchar(36) COLLATE "default" NOT NULL,
"analyze_map_id" varchar(36) COLLATE "default" NOT NULL,
"coltype" int4 NOT NULL,
"member" varchar(200) COLLATE "default",
"operator_type" int4,
"seq" int4 DEFAULT 1,
"date_format_type" int4,
"col_display_name" varchar(45) COLLATE "default" NOT NULL,
"time_window" varchar(200) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for client_grant_types
-- ----------------------------
DROP TABLE IF EXISTS "client_grant_types";
CREATE TABLE "client_grant_types" (
"client_grant_id" int4 NOT NULL,
"client_id" varchar(254) COLLATE "default" NOT NULL,
"grant_type_id" int4 NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for clients
-- ----------------------------
DROP TABLE IF EXISTS "clients";
CREATE TABLE "clients" (
"id" varchar(254) COLLATE "default" NOT NULL,
"secret" varchar(254) COLLATE "default",
"redirect_uri" varchar(254) COLLATE "default",
"scope" varchar(254) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for cluster
-- ----------------------------
DROP TABLE IF EXISTS "cluster";
CREATE TABLE "cluster" (
"cluster_id" int4 NOT NULL,
"cluster_name" varchar(45) COLLATE "default" NOT NULL,
"description" varchar(200) COLLATE "default",
"zookeeper" varchar(200) COLLATE "default",
"master" varchar(45) COLLATE "default",
"monitor" varchar(45) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for confirmation_tokens
-- ----------------------------
DROP TABLE IF EXISTS "confirmation_tokens";
CREATE TABLE "confirmation_tokens" (
"id" int8 NOT NULL,
"uuid" varchar(36) COLLATE "default" NOT NULL,
"email" varchar(254) COLLATE "default" NOT NULL,
"creation_time" timestamp(6) DEFAULT now() NOT NULL,
"expiration_time" timestamp(6),
"is_sign_up" bool NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for dashboard_element
-- ----------------------------
DROP TABLE IF EXISTS "dashboard_element";
CREATE TABLE "dashboard_element" (
"id" varchar(40) COLLATE "default" NOT NULL,
"element_type" int2 NOT NULL,
"element_content" varchar(500) COLLATE "default" NOT NULL,
"dashboard_id" varchar(40) COLLATE "default" NOT NULL,
"rule" varchar(2000) COLLATE "default",
"seq" int4 NOT NULL,
"row" int4 NOT NULL,
"col" int4 NOT NULL,
"sizex" int4 NOT NULL,
"sizey" int4 NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for dashboard_info
-- ----------------------------
DROP TABLE IF EXISTS "dashboard_info";
CREATE TABLE "dashboard_info" (
"dashboard_uuid" varchar(36) COLLATE "default" NOT NULL,
"dashboard_title" varchar(45) COLLATE "default" NOT NULL,
"theme" varchar(10) COLLATE "default" NOT NULL,
"created_by_guid" varchar(36) COLLATE "default" NOT NULL,
"created_at" timestamp(6) DEFAULT now() NOT NULL,
"updated_by_guid" varchar(36) COLLATE "default",
"updated_at" timestamp(6),
"scope" varchar(200) COLLATE "default",
"application_id" varchar(36) COLLATE "default",
"template_id" varchar(40) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for data_source_add_list
-- ----------------------------
DROP TABLE IF EXISTS "data_source_add_list";
CREATE TABLE "data_source_add_list" (
"id" varchar(36) COLLATE "default" NOT NULL,
"name" varchar(45) COLLATE "default" NOT NULL,
"ico" varchar(45) COLLATE "default" NOT NULL,
"description" varchar(200) COLLATE "default",
"type" int2 NOT NULL,
"status" int2 DEFAULT 0 NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for data_source_conf
-- ----------------------------
DROP TABLE IF EXISTS "data_source_conf";
CREATE TABLE "data_source_conf" (
"id" varchar(40) COLLATE "default" NOT NULL,
"data_source_info_id" varchar(40) COLLATE "default" NOT NULL,
"prop_name" varchar(50) COLLATE "default" NOT NULL,
"prop_value" varchar(2000) COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for data_source_info
-- ----------------------------
DROP TABLE IF EXISTS "data_source_info";
CREATE TABLE "data_source_info" (
"id" varchar(40) COLLATE "default" NOT NULL,
"name" varchar(50) COLLATE "default" NOT NULL,
"enable" bool NOT NULL,
"source_type" int2 NOT NULL,
"create_at" timestamp(6) DEFAULT now() NOT NULL,
"created_by" varchar(40) COLLATE "default" NOT NULL,
"test_connect_status" int4,
"test_connect_log" varchar(500) COLLATE "default",
"test_connect_at" timestamp(6)
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for drill_path
-- ----------------------------
DROP TABLE IF EXISTS "drill_path";
CREATE TABLE "drill_path" (
"id" varchar(36) COLLATE "default" NOT NULL,
"name" varchar(45) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for etl_history
-- ----------------------------
DROP TABLE IF EXISTS "etl_history";
CREATE TABLE "etl_history" (
"etl_history_id" int8 NOT NULL,
"etl_info_id" varchar(36) COLLATE "default" NOT NULL,
"create_at" timestamp(6) DEFAULT now() NOT NULL,
"affected_rows" int4 NOT NULL,
"status" bool NOT NULL,
"log" text COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for etl_info
-- ----------------------------
DROP TABLE IF EXISTS "etl_info";
CREATE TABLE "etl_info" (
"id" varchar(36) COLLATE "default" NOT NULL,
"src_data_source_info_id" varchar(36) COLLATE "default" NOT NULL,
"etl_name" varchar(45) COLLATE "default" NOT NULL,
"create_at" timestamp(6) DEFAULT now() NOT NULL,
"create_by" varchar(36) COLLATE "default" NOT NULL,
"status" bool NOT NULL,
"source" varchar(300) COLLATE "default" NOT NULL,
"sourcetype" int2 NOT NULL,
"dist_schema" varchar(45) COLLATE "default" NOT NULL,
"dist_table" varchar(45) COLLATE "default" NOT NULL,
"col_mapping" varchar(3000) COLLATE "default" NOT NULL,
"execute_type" int2 NOT NULL,
"partition_col" varchar(45) COLLATE "default",
"update_col" varchar(45) COLLATE "default",
"conf" text COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for etl_schedule
-- ----------------------------
DROP TABLE IF EXISTS "etl_schedule";
CREATE TABLE "etl_schedule" (
"id" varchar(36) COLLATE "default" NOT NULL,
"etl_info_id" varchar(36) COLLATE "default" NOT NULL,
"name" varchar(45) COLLATE "default" NOT NULL,
"cron_expression" varchar(45) COLLATE "default" NOT NULL,
"create_at" timestamp(6) DEFAULT now() NOT NULL,
"create_by" varchar(36) COLLATE "default" NOT NULL,
"status" int2 NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for function_metadata
-- ----------------------------
DROP TABLE IF EXISTS "function_metadata";
CREATE TABLE "function_metadata" (
"id" varchar(40) COLLATE "default" NOT NULL,
"name" varchar(40) COLLATE "default" NOT NULL,
"usage" varchar(200) COLLATE "default" NOT NULL,
"desc" varchar(200) COLLATE "default" NOT NULL,
"demo" varchar(255) COLLATE "default" NOT NULL,
"out_data_type" int2 NOT NULL,
"no_limit" bool
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for function_param_metadata
-- ----------------------------
DROP TABLE IF EXISTS "function_param_metadata";
CREATE TABLE "function_param_metadata" (
"id" varchar(40) COLLATE "default" NOT NULL,
"data_type" int2,
"seq" int2,
"function_metadata_id" varchar(40) COLLATE "default",
"optional" bool
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for global_filter
-- ----------------------------
DROP TABLE IF EXISTS "global_filter";
CREATE TABLE "global_filter" (
"id" varchar(40) COLLATE "default" NOT NULL,
"name" varchar(100) COLLATE "default" NOT NULL,
"dashboard_uuid" varchar(40) COLLATE "default" NOT NULL,
"updated_at" timestamp(6) DEFAULT now() NOT NULL,
"update_by" varchar(40) COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for global_filter_chart
-- ----------------------------
DROP TABLE IF EXISTS "global_filter_chart";
CREATE TABLE "global_filter_chart" (
"id" varchar(40) COLLATE "default" NOT NULL,
"global_filter_id" varchar(40) COLLATE "default" NOT NULL,
"chart_uuid" varchar(40) COLLATE "default" NOT NULL,
"seq" int4 NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for global_filter_column
-- ----------------------------
DROP TABLE IF EXISTS "global_filter_column";
CREATE TABLE "global_filter_column" (
"id" varchar(40) COLLATE "default" NOT NULL,
"global_filter_id" varchar(40) COLLATE "default" NOT NULL,
"analyze_map_detail_id" varchar(40) COLLATE "default" NOT NULL,
"seq" int4 NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for grant_types
-- ----------------------------
DROP TABLE IF EXISTS "grant_types";
CREATE TABLE "grant_types" (
"id" int4 NOT NULL,
"grant_type" varchar(254) COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for group
-- ----------------------------
DROP TABLE IF EXISTS "group";
CREATE TABLE "group" (
"id" varchar(40) COLLATE "default" NOT NULL,
"name" varchar(40) COLLATE "default" NOT NULL,
"create_by" varchar(40) COLLATE "default" NOT NULL,
"create_at" timestamp(6) DEFAULT now() NOT NULL,
"group_type" int2 NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for host
-- ----------------------------
DROP TABLE IF EXISTS "host";
CREATE TABLE "host" (
"host_id" int4 NOT NULL,
"tag" varchar(45) COLLATE "default",
"hostname" varchar(45) COLLATE "default" NOT NULL,
"ipv4" varchar(45) COLLATE "default" NOT NULL,
"enable" bool NOT NULL,
"cluster_id" int4 NOT NULL,
"role_type" varchar(200) COLLATE "default",
"components" varchar(500) COLLATE "default" NOT NULL,
"cores" int4,
"memory" int4,
"disk" int4
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for id_dictionary
-- ----------------------------
DROP TABLE IF EXISTS "id_dictionary";
CREATE TABLE "id_dictionary" (
"id" varchar(36) COLLATE "default" NOT NULL,
"type_name" varchar(45) COLLATE "default" NOT NULL,
"name" varchar(45) COLLATE "default" NOT NULL,
"code" varchar(45) COLLATE "default" NOT NULL,
"sequence" int4 NOT NULL,
"parent_id" varchar(36) COLLATE "default",
"description" varchar(200) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for invitation_code
-- ----------------------------
DROP TABLE IF EXISTS "invitation_code";
CREATE TABLE "invitation_code" (
"id" int4 NOT NULL,
"code" varchar(36) COLLATE "default" NOT NULL,
"register_account" varchar(36) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for learning_model
-- ----------------------------
DROP TABLE IF EXISTS "learning_model";
CREATE TABLE "learning_model" (
"id" varchar(40) COLLATE "default" NOT NULL,
"name" varchar(50) COLLATE "default" NOT NULL,
"project_id" varchar(40) COLLATE "default" NOT NULL,
"model_type" varchar(20) COLLATE "default" NOT NULL,
"predict_variable" varchar(100) COLLATE "default",
"template_type" varchar(50) COLLATE "default" NOT NULL,
"backend" varchar(255) COLLATE "default" NOT NULL,
"create_at" timestamp(6) DEFAULT now() NOT NULL,
"create_by" varchar(40) COLLATE "default" NOT NULL,
"update_at" timestamp(6) DEFAULT now(),
"update_by" varchar(40) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for learning_model_deploy
-- ----------------------------
DROP TABLE IF EXISTS "learning_model_deploy";
CREATE TABLE "learning_model_deploy" (
"id" varchar(40) COLLATE "default" NOT NULL,
"name" varchar(40) COLLATE "default" NOT NULL,
"algorithm" varchar(50) COLLATE "default" NOT NULL,
"train_params" text COLLATE "default" NOT NULL,
"schema" varchar(50) COLLATE "default" NOT NULL,
"table_name" varchar(50) COLLATE "default" NOT NULL,
"source_learning_model_id" varchar(40) COLLATE "default" NOT NULL,
"create_at" timestamp(6) DEFAULT now() NOT NULL,
"create_by" varchar(40) COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for learning_model_setting
-- ----------------------------
DROP TABLE IF EXISTS "learning_model_setting";
CREATE TABLE "learning_model_setting" (
"id" varchar(40) COLLATE "default" NOT NULL,
"prop_name" varchar(50) COLLATE "default" NOT NULL,
"prop_value" text COLLATE "default" NOT NULL,
"learning_model_id" varchar(40) COLLATE "default" NOT NULL,
"update_at" timestamp(6) DEFAULT now() NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for learning_model_train_log
-- ----------------------------
DROP TABLE IF EXISTS "learning_model_train_log";
CREATE TABLE "learning_model_train_log" (
"id" int8 NOT NULL,
"learning_model_id" varchar(40) COLLATE "default" NOT NULL,
"train_time" timestamp(6) DEFAULT now() NOT NULL,
"success" bool NOT NULL,
"algorithm" varchar(50) COLLATE "default" NOT NULL,
"train_params" text COLLATE "default",
"summary" text COLLATE "default",
"train_result" text COLLATE "default" NOT NULL,
"transform_features" text COLLATE "default",
"metrics" text COLLATE "default",
"error_msg" text COLLATE "default",
"end_time" timestamp(6) DEFAULT now()
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for monitor_action_record
-- ----------------------------
DROP TABLE IF EXISTS "monitor_action_record";
CREATE TABLE "monitor_action_record" (
"id" int8 NOT NULL,
"action_type" varchar(45) COLLATE "default" NOT NULL,
"origin_val" varchar(500) COLLATE "default",
"update_val" varchar(500) COLLATE "default",
"create_at" timestamp(6) DEFAULT now() NOT NULL,
"create_by" varchar(50) COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for monitor_event_history
-- ----------------------------
DROP TABLE IF EXISTS "monitor_event_history";
CREATE TABLE "monitor_event_history" (
"log_id" int8 NOT NULL,
"id" varchar(45) COLLATE "default" NOT NULL,
"endpoint" varchar(45) COLLATE "default" NOT NULL,
"metric" varchar(45) COLLATE "default" NOT NULL,
"counter" varchar(100) COLLATE "default" NOT NULL,
"func" varchar(45) COLLATE "default" NOT NULL,
"left_value" varchar(45) COLLATE "default",
"operator" varchar(45) COLLATE "default" NOT NULL,
"right_value" varchar(45) COLLATE "default",
"note" varchar(45) COLLATE "default" NOT NULL,
"max_step" int4 NOT NULL,
"current_step" int4 NOT NULL,
"priority" int4 NOT NULL,
"status" varchar(45) COLLATE "default" NOT NULL,
"timestamp" int8 NOT NULL,
"expression_id" int4 NOT NULL,
"strategy_id" int4 NOT NULL,
"template_id" int4 NOT NULL,
"link" varchar(100) COLLATE "default",
"closed_at" int8 NOT NULL,
"closed_by" varchar(255) COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for operate_permission
-- ----------------------------
DROP TABLE IF EXISTS "operate_permission";
CREATE TABLE "operate_permission" (
"id" varchar(36) COLLATE "default" NOT NULL,
"scope" varchar(20) COLLATE "default" NOT NULL,
"permissions" varchar(2000) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for path_node
-- ----------------------------
DROP TABLE IF EXISTS "path_node";
CREATE TABLE "path_node" (
"id" varchar(36) COLLATE "default" NOT NULL,
"seq" int4 NOT NULL,
"analyze_map_detail_id" varchar(45) COLLATE "default" NOT NULL,
"drill_path_id" varchar(40) COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for play_evolutions
-- ----------------------------
DROP TABLE IF EXISTS "play_evolutions";
CREATE TABLE "play_evolutions" (
"id" int4 NOT NULL,
"hash" varchar(255) COLLATE "default" NOT NULL,
"applied_at" timestamp(6) DEFAULT now() NOT NULL,
"apply_script" text COLLATE "default",
"revert_script" text COLLATE "default",
"state" varchar(255) COLLATE "default",
"last_problem" text COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for project
-- ----------------------------
DROP TABLE IF EXISTS "project";
CREATE TABLE "project" (
"id" varchar(40) COLLATE "default" NOT NULL,
"name" varchar(50) COLLATE "default" NOT NULL,
"description" varchar(255) COLLATE "default",
"analyze_map_info_uuid" varchar(40) COLLATE "default" NOT NULL,
"preprocess_conf" text COLLATE "default",
"kernel_id" varchar(40) COLLATE "default",
"create_at" timestamp(6) DEFAULT now() NOT NULL,
"create_by" varchar(40) COLLATE "default" NOT NULL,
"update_at" timestamp(6) DEFAULT now(),
"update_by" varchar(40) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for project_script_deploy
-- ----------------------------
DROP TABLE IF EXISTS "project_script_deploy";
CREATE TABLE "project_script_deploy" (
"id" varchar(40) COLLATE "default" NOT NULL,
"name" varchar(40) COLLATE "default" NOT NULL,
"preprocess_conf" text COLLATE "default",
"dist_schema" varchar(50) COLLATE "default" NOT NULL,
"dist_table_name" varchar(50) COLLATE "default" NOT NULL,
"dist_display_name" varchar(50) COLLATE "default" NOT NULL,
"dist_group_id" varchar(40) COLLATE "default",
"source_project_id" varchar(40) COLLATE "default",
"create_at" timestamp(6) DEFAULT now() NOT NULL,
"create_by" varchar(40) COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for r_job
-- ----------------------------
DROP TABLE IF EXISTS "r_job";
CREATE TABLE "r_job" (
"id_job" int8 NOT NULL,
"id_directory" int4,
"name" varchar(255) COLLATE "default",
"description" text COLLATE "default",
"extended_description" text COLLATE "default",
"job_version" varchar(255) COLLATE "default",
"job_status" int4,
"id_database_log" int4,
"table_name_log" varchar(255) COLLATE "default",
"created_user" varchar(255) COLLATE "default",
"created_date" timestamp(6),
"modified_user" varchar(255) COLLATE "default",
"modified_date" timestamp(6),
"use_batch_id" char(1) COLLATE "default",
"pass_batch_id" char(1) COLLATE "default",
"use_logfield" char(1) COLLATE "default",
"shared_file" varchar(255) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for registe_black_list
-- ----------------------------
DROP TABLE IF EXISTS "registe_black_list";
CREATE TABLE "registe_black_list" (
"id" varchar(36) COLLATE "default" NOT NULL,
"black_list_val" varchar(30) COLLATE "default" NOT NULL,
"val_type" int2 NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for report
-- ----------------------------
DROP TABLE IF EXISTS "report";
CREATE TABLE "report" (
"id" varchar(40) COLLATE "default" NOT NULL,
"name" varchar(100) COLLATE "default" NOT NULL,
"category" varchar(40) COLLATE "default",
"desc" varchar(500) COLLATE "default",
"price" int4 DEFAULT 0 NOT NULL,
"grade" int4 DEFAULT 0,
"tag" varchar(200) COLLATE "default",
"cover_url" varchar(255) COLLATE "default",
"background" varchar(200) COLLATE "default",
"group_id" varchar(40) COLLATE "default" NOT NULL,
"status" int2,
"sample_url" varchar(255) COLLATE "default",
"create_by" varchar(40) COLLATE "default" NOT NULL,
"create_at" timestamp(6) DEFAULT now() NOT NULL,
"owner" varchar(40) COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for report_element
-- ----------------------------
DROP TABLE IF EXISTS "report_element";
CREATE TABLE "report_element" (
"id" varchar(40) COLLATE "default" NOT NULL,
"element_type" int2 NOT NULL,
"element_content" varchar(2000) COLLATE "default" NOT NULL,
"report_id" varchar(40) COLLATE "default" NOT NULL,
"rule" varchar(2000) COLLATE "default",
"seq" int4 NOT NULL,
"row" int4 NOT NULL,
"col" int4 NOT NULL,
"sizex" int4 NOT NULL,
"sizey" int4 NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for role_member
-- ----------------------------
DROP TABLE IF EXISTS "role_member";
CREATE TABLE "role_member" (
"id" varchar(45) COLLATE "default" NOT NULL,
"role_uuid" varchar(45) COLLATE "default" NOT NULL,
"user_uuid" varchar(45) COLLATE "default" NOT NULL,
"create_at" timestamp(6) DEFAULT now() NOT NULL,
"create_by" varchar(40) COLLATE "default" NOT NULL,
"update_at" timestamp(6) DEFAULT now() NOT NULL,
"update_by" varchar(40) COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for role_permission
-- ----------------------------
DROP TABLE IF EXISTS "role_permission";
CREATE TABLE "role_permission" (
"id" varchar(40) COLLATE "default" NOT NULL,
"role_uuid" varchar(40) COLLATE "default" NOT NULL,
"object_name" varchar(45) COLLATE "default" NOT NULL,
"object_uuid" varchar(40) COLLATE "default" NOT NULL,
"permission" varchar(45) COLLATE "default" NOT NULL,
"create_at" timestamp(6) DEFAULT now() NOT NULL,
"create_by" varchar(40) COLLATE "default" NOT NULL,
"update_at" timestamp(6) DEFAULT now() NOT NULL,
"update_by" varchar(40) COLLATE "default" NOT NULL,
"user_uuid" varchar(36) COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for roles
-- ----------------------------
DROP TABLE IF EXISTS "roles";
CREATE TABLE "roles" (
"id" varchar(40) COLLATE "default" NOT NULL,
"name" varchar(40) COLLATE "default" NOT NULL,
"org_id" varchar(45) COLLATE "default" NOT NULL,
"create_at" timestamp(6) DEFAULT now() NOT NULL,
"create_by" varchar(40) COLLATE "default" NOT NULL,
"update_at" timestamp(6) DEFAULT now() NOT NULL,
"update_by" varchar(40) COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for shared_analyze_map_detail
-- ----------------------------
DROP TABLE IF EXISTS "shared_analyze_map_detail";
CREATE TABLE "shared_analyze_map_detail" (
"shared_analyze_map_id" varchar(40) COLLATE "default" NOT NULL,
"shared_analyze_map_info_uuid" varchar(36) COLLATE "default" NOT NULL,
"col_name" varchar(45) COLLATE "default" NOT NULL,
"col_analyze_type" int4 NOT NULL,
"col_display_name" varchar(45) COLLATE "default" NOT NULL,
"col_exp" varchar(200) COLLATE "default" NOT NULL,
"col_data_type" int4 NOT NULL,
"introduction" varchar(200) COLLATE "default",
"db_type" varchar(50) COLLATE "default",
"required" bool,
"number_format" varchar(200) COLLATE "default",
"order_index" int2,
"sensitive" int2 DEFAULT 0 NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for shared_analyze_map_info
-- ----------------------------
DROP TABLE IF EXISTS "shared_analyze_map_info";
CREATE TABLE "shared_analyze_map_info" (
"shared_analyze_map_info_uuid" varchar(36) COLLATE "default" NOT NULL,
"schema" varchar(45) COLLATE "default" NOT NULL,
"category" varchar(45) COLLATE "default" NOT NULL,
"table_name" varchar(45) COLLATE "default" NOT NULL,
"display_name" varchar(45) COLLATE "default" NOT NULL,
"created_uuid" varchar(36) COLLATE "default" NOT NULL,
"table_type" int2 DEFAULT 0 NOT NULL,
"view_text" varchar(4000) COLLATE "default",
"introduction" varchar(200) COLLATE "default",
"source_map_info_uuid" varchar(36) COLLATE "default" NOT NULL,
"audit_status" int2 DEFAULT 0 NOT NULL,
"create_at" timestamp(6) DEFAULT now() NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for shared_dashboard_info
-- ----------------------------
DROP TABLE IF EXISTS "shared_dashboard_info";
CREATE TABLE "shared_dashboard_info" (
"shared_dashboard_info_id" varchar(36) COLLATE "default" NOT NULL,
"dashboard_info_id" varchar(36) COLLATE "default" NOT NULL,
"application_name" varchar(45) COLLATE "default" NOT NULL,
"dashboard_name" varchar(45) COLLATE "default" NOT NULL,
"description" varchar(200) COLLATE "default",
"create_by" varchar(36) COLLATE "default" NOT NULL,
"create_at" timestamp(6) DEFAULT now() NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for sms_send_history
-- ----------------------------
DROP TABLE IF EXISTS "sms_send_history";
CREATE TABLE "sms_send_history" (
"id" varchar(36) COLLATE "default" NOT NULL,
"login_name" varchar(30) COLLATE "default" NOT NULL,
"sms_code" varchar(6) COLLATE "default" NOT NULL,
"ip" varchar(20) COLLATE "default" NOT NULL,
"send_time" timestamp(6) DEFAULT now() NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for snapshot
-- ----------------------------
DROP TABLE IF EXISTS "snapshot";
CREATE TABLE "snapshot" (
"id" varchar(40) COLLATE "default" NOT NULL,
"snapshot_type" varchar(30) COLLATE "default" NOT NULL,
"source_id" varchar(40) COLLATE "default",
"data" text COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for task
-- ----------------------------
DROP TABLE IF EXISTS "task";
CREATE TABLE "task" (
"task_uuid" int4 NOT NULL,
"task_name" varchar(45) COLLATE "default" NOT NULL,
"task_status" varchar(45) COLLATE "default" NOT NULL,
"workflow_id" varchar(45) COLLATE "default" NOT NULL,
"ipv4" varchar(45) COLLATE "default" NOT NULL,
"message" varchar(200) COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for template
-- ----------------------------
DROP TABLE IF EXISTS "template";
CREATE TABLE "template" (
"id" varchar(40) COLLATE "default" NOT NULL,
"name" varchar(100) COLLATE "default" NOT NULL,
"category" varchar(40) COLLATE "default",
"desc" varchar(500) COLLATE "default",
"price" int4 DEFAULT 0 NOT NULL,
"grade" int4 DEFAULT 0,
"tag" varchar(200) COLLATE "default",
"cover_url" varchar(255) COLLATE "default",
"status" int2,
"sample_url" varchar(255) COLLATE "default",
"create_by" varchar(40) COLLATE "default" NOT NULL,
"create_at" timestamp(6) DEFAULT now() NOT NULL,
"owner" varchar(40) COLLATE "default" NOT NULL,
"dashboard_id" varchar(40) COLLATE "default" NOT NULL,
"ref_template_id" varchar(40) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for template_chart
-- ----------------------------
DROP TABLE IF EXISTS "template_chart";
CREATE TABLE "template_chart" (
"id" varchar(40) COLLATE "default" NOT NULL,
"name" varchar(100) COLLATE "default" NOT NULL,
"template_id" varchar(40) COLLATE "default" NOT NULL,
"chart_type" varchar(45) COLLATE "default" NOT NULL,
"desc" varchar(200) COLLATE "default",
"limit" int4 NOT NULL,
"rule" text COLLATE "default",
"advance_filter" text COLLATE "default",
"schema" varchar(50) COLLATE "default" NOT NULL,
"table_name" varchar(50) COLLATE "default" NOT NULL,
"display_name" varchar(100) COLLATE "default",
"introduction" varchar(200) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for template_chart_used_column
-- ----------------------------
DROP TABLE IF EXISTS "template_chart_used_column";
CREATE TABLE "template_chart_used_column" (
"id" varchar(40) COLLATE "default" NOT NULL,
"col_type" int2 NOT NULL,
"display_name" varchar(50) COLLATE "default",
"operator_type" int2,
"member" varchar(200) COLLATE "default",
"seq" int4,
"template_chart_id" varchar(40) COLLATE "default" NOT NULL,
"template_column_id" varchar(40) COLLATE "default" NOT NULL,
"date_format_type" int2,
"time_window" varchar(200) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for template_column
-- ----------------------------
DROP TABLE IF EXISTS "template_column";
CREATE TABLE "template_column" (
"id" varchar(40) COLLATE "default" NOT NULL,
"name" varchar(45) COLLATE "default" NOT NULL,
"display_name" varchar(50) COLLATE "default" NOT NULL,
"col_type" int2 DEFAULT 0 NOT NULL,
"col_exp" varchar(200) COLLATE "default" NOT NULL,
"col_data_type" int2 NOT NULL,
"number_format" varchar(200) COLLATE "default",
"seq" int4 NOT NULL,
"introduction" varchar(200) COLLATE "default",
"db_type" varchar(50) COLLATE "default",
"required" bool,
"template_chart_id" varchar(40) COLLATE "default" NOT NULL,
"allowed_export" bool NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for template_element
-- ----------------------------
DROP TABLE IF EXISTS "template_element";
CREATE TABLE "template_element" (
"id" varchar(40) COLLATE "default" NOT NULL,
"element_type" int2 NOT NULL,
"element_content" varchar(2000) COLLATE "default" NOT NULL,
"template_id" varchar(40) COLLATE "default" NOT NULL,
"rule" varchar(2000) COLLATE "default",
"seq" int4 NOT NULL,
"row" int4 NOT NULL,
"col" int4 NOT NULL,
"size_x" int4 NOT NULL,
"size_y" int4 NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for template_global_filter
-- ----------------------------
DROP TABLE IF EXISTS "template_global_filter";
CREATE TABLE "template_global_filter" (
"id" varchar(40) COLLATE "default" NOT NULL,
"name" varchar(100) COLLATE "default" NOT NULL,
"template_id" varchar(40) COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for template_global_filter_chart
-- ----------------------------
DROP TABLE IF EXISTS "template_global_filter_chart";
CREATE TABLE "template_global_filter_chart" (
"id" varchar(40) COLLATE "default" NOT NULL,
"template_global_filter_id" varchar(40) COLLATE "default" NOT NULL,
"template_chart_id" varchar(40) COLLATE "default" NOT NULL,
"seq" int4 NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for template_global_filter_column
-- ----------------------------
DROP TABLE IF EXISTS "template_global_filter_column";
CREATE TABLE "template_global_filter_column" (
"id" varchar(40) COLLATE "default" NOT NULL,
"template_global_filter_id" varchar(40) COLLATE "default" NOT NULL,
"template_column_id" varchar(40) COLLATE "default" NOT NULL,
"seq" int4 NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for user_report
-- ----------------------------
DROP TABLE IF EXISTS "user_report";
CREATE TABLE "user_report" (
"id" varchar(40) COLLATE "default" NOT NULL,
"report_id" varchar(40) COLLATE "default" NOT NULL,
"user_id" varchar(40) COLLATE "default" NOT NULL,
"create_time" timestamp(6) DEFAULT now() NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for user_template
-- ----------------------------
DROP TABLE IF EXISTS "user_template";
CREATE TABLE "user_template" (
"id" varchar(40) COLLATE "default" NOT NULL,
"template_id" varchar(40) COLLATE "default" NOT NULL,
"user_id" varchar(40) COLLATE "default" NOT NULL,
"create_time" timestamp(6) DEFAULT now() NOT NULL,
"installed" bool NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS "users";
CREATE TABLE "users" (
"guid" varchar(36) COLLATE "default" NOT NULL,
"first_name" varchar(50) COLLATE "default" NOT NULL,
"last_name" varchar(50) COLLATE "default" NOT NULL,
"login_account" varchar(100) COLLATE "default" NOT NULL,
"account_type" int4 NOT NULL,
"password" varchar(254) COLLATE "default" NOT NULL,
"salt" varchar(254) COLLATE "default",
"scope" varchar(255) COLLATE "default" NOT NULL,
"quota" int4 NOT NULL,
"photo_url" varchar(100) COLLATE "default",
"created_at" timestamp(6) DEFAULT now() NOT NULL,
"created_by_guid" varchar(36) COLLATE "default" NOT NULL,
"updated_at" timestamp(6),
"updated_by_guid" varchar(36) COLLATE "default",
"deleted_at" timestamp(6),
"deleted_by_guid" varchar(36) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Table structure for workflow
-- ----------------------------
DROP TABLE IF EXISTS "workflow";
CREATE TABLE "workflow" (
"workflow_id" varchar(45) COLLATE "default" NOT NULL,
"workflow_name" varchar(45) COLLATE "default" NOT NULL,
"workflow_status" varchar(45) COLLATE "default" NOT NULL,
"namespace" varchar(45) COLLATE "default" NOT NULL,
"start_time" int8 NOT NULL,
"user_id" varchar(40) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Alter Sequences Owned By 
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table access_tokens
-- ----------------------------
ALTER TABLE "access_tokens" ADD PRIMARY KEY ("access_token");

-- ----------------------------
-- Primary Key structure for table add_data_source_table
-- ----------------------------
ALTER TABLE "add_data_source_table" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Indexes structure for table analyze_map_detail
-- ----------------------------
CREATE INDEX "analyze_map_detail_fk_analyze_map_detail_analyze_map_info1_idx" ON "analyze_map_detail" USING btree ("analyze_map_info_uuid");

-- ----------------------------
-- Primary Key structure for table analyze_map_detail
-- ----------------------------
ALTER TABLE "analyze_map_detail" ADD PRIMARY KEY ("analyze_map_id");

-- ----------------------------
-- Primary Key structure for table analyze_map_detail_group
-- ----------------------------
ALTER TABLE "analyze_map_detail_group" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table analyze_map_info
-- ----------------------------
ALTER TABLE "analyze_map_info" ADD PRIMARY KEY ("analyze_map_info_uuid");

-- ----------------------------
-- Primary Key structure for table applications
-- ----------------------------
ALTER TABLE "applications" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table audit_info
-- ----------------------------
ALTER TABLE "audit_info" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table auth_codes
-- ----------------------------
ALTER TABLE "auth_codes" ADD PRIMARY KEY ("authorization_code");

-- ----------------------------
-- Primary Key structure for table chart_info
-- ----------------------------
ALTER TABLE "chart_info" ADD PRIMARY KEY ("chart_uuid");

-- ----------------------------
-- Indexes structure for table chart_item_join_link
-- ----------------------------
CREATE INDEX "chart_item_join_link_fk1_idx" ON "chart_item_join_link" USING btree ("left_analyze_table_id");
CREATE INDEX "chart_item_join_link_fk2_idx" ON "chart_item_join_link" USING btree ("left_analyze_col_id");
CREATE INDEX "chart_item_join_link_fk4_idx" ON "chart_item_join_link" USING btree ("right_analyze_col_id");
CREATE INDEX "chart_item_join_link_fk5_idx" ON "chart_item_join_link" USING btree ("related_chart_uuid");
CREATE INDEX "chart_item_join_link_kf3_idx" ON "chart_item_join_link" USING btree ("right_analyze_table_id");

-- ----------------------------
-- Primary Key structure for table chart_item_join_link
-- ----------------------------
ALTER TABLE "chart_item_join_link" ADD PRIMARY KEY ("join_link_id");

-- ----------------------------
-- Primary Key structure for table chart_pre_warning
-- ----------------------------
ALTER TABLE "chart_pre_warning" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table chart_pre_warning_condition
-- ----------------------------
ALTER TABLE "chart_pre_warning_condition" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table chart_scope
-- ----------------------------
ALTER TABLE "chart_scope" ADD PRIMARY KEY ("chart_scope_id");

-- ----------------------------
-- Indexes structure for table chart_used_col_info
-- ----------------------------
CREATE INDEX "chart_used_col_info_fk_chart_col_analyze_col_idx" ON "chart_used_col_info" USING btree ("analyze_map_id");
CREATE INDEX "chart_used_col_info_fk_chart_used_col_chart_info1_idx" ON "chart_used_col_info" USING btree ("chart_uuid");

-- ----------------------------
-- Primary Key structure for table chart_used_col_info
-- ----------------------------
ALTER TABLE "chart_used_col_info" ADD PRIMARY KEY ("chart_used_col_id");

-- ----------------------------
-- Primary Key structure for table client_grant_types
-- ----------------------------
ALTER TABLE "client_grant_types" ADD PRIMARY KEY ("client_grant_id");

-- ----------------------------
-- Primary Key structure for table clients
-- ----------------------------
ALTER TABLE "clients" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Uniques structure for table cluster
-- ----------------------------
ALTER TABLE "cluster" ADD UNIQUE ("cluster_name");

-- ----------------------------
-- Primary Key structure for table cluster
-- ----------------------------
ALTER TABLE "cluster" ADD PRIMARY KEY ("cluster_id");

-- ----------------------------
-- Primary Key structure for table confirmation_tokens
-- ----------------------------
ALTER TABLE "confirmation_tokens" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table dashboard_element
-- ----------------------------
ALTER TABLE "dashboard_element" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table dashboard_info
-- ----------------------------
ALTER TABLE "dashboard_info" ADD PRIMARY KEY ("dashboard_uuid");

-- ----------------------------
-- Primary Key structure for table data_source_add_list
-- ----------------------------
ALTER TABLE "data_source_add_list" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table data_source_conf
-- ----------------------------
ALTER TABLE "data_source_conf" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table data_source_info
-- ----------------------------
ALTER TABLE "data_source_info" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table drill_path
-- ----------------------------
ALTER TABLE "drill_path" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table etl_history
-- ----------------------------
ALTER TABLE "etl_history" ADD PRIMARY KEY ("etl_history_id");

-- ----------------------------
-- Primary Key structure for table etl_info
-- ----------------------------
ALTER TABLE "etl_info" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table etl_schedule
-- ----------------------------
ALTER TABLE "etl_schedule" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table function_metadata
-- ----------------------------
ALTER TABLE "function_metadata" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table function_param_metadata
-- ----------------------------
ALTER TABLE "function_param_metadata" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table global_filter
-- ----------------------------
ALTER TABLE "global_filter" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table global_filter_chart
-- ----------------------------
ALTER TABLE "global_filter_chart" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table global_filter_column
-- ----------------------------
ALTER TABLE "global_filter_column" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table grant_types
-- ----------------------------
ALTER TABLE "grant_types" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table group
-- ----------------------------
ALTER TABLE "group" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Indexes structure for table host
-- ----------------------------
CREATE INDEX "host_fk_host_cluster1_idx" ON "host" USING btree ("cluster_id");

-- ----------------------------
-- Uniques structure for table host
-- ----------------------------
ALTER TABLE "host" ADD UNIQUE ("hostname");

-- ----------------------------
-- Primary Key structure for table host
-- ----------------------------
ALTER TABLE "host" ADD PRIMARY KEY ("host_id");

-- ----------------------------
-- Primary Key structure for table id_dictionary
-- ----------------------------
ALTER TABLE "id_dictionary" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Uniques structure for table invitation_code
-- ----------------------------
ALTER TABLE "invitation_code" ADD UNIQUE ("code");

-- ----------------------------
-- Primary Key structure for table invitation_code
-- ----------------------------
ALTER TABLE "invitation_code" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table learning_model
-- ----------------------------
ALTER TABLE "learning_model" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table learning_model_deploy
-- ----------------------------
ALTER TABLE "learning_model_deploy" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table learning_model_setting
-- ----------------------------
ALTER TABLE "learning_model_setting" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table learning_model_train_log
-- ----------------------------
ALTER TABLE "learning_model_train_log" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table monitor_action_record
-- ----------------------------
ALTER TABLE "monitor_action_record" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table monitor_event_history
-- ----------------------------
ALTER TABLE "monitor_event_history" ADD PRIMARY KEY ("log_id");

-- ----------------------------
-- Uniques structure for table operate_permission
-- ----------------------------
ALTER TABLE "operate_permission" ADD UNIQUE ("scope");

-- ----------------------------
-- Primary Key structure for table operate_permission
-- ----------------------------
ALTER TABLE "operate_permission" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table path_node
-- ----------------------------
ALTER TABLE "path_node" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table play_evolutions
-- ----------------------------
ALTER TABLE "play_evolutions" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table project
-- ----------------------------
ALTER TABLE "project" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table project_script_deploy
-- ----------------------------
ALTER TABLE "project_script_deploy" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table r_job
-- ----------------------------
ALTER TABLE "r_job" ADD PRIMARY KEY ("id_job");

-- ----------------------------
-- Primary Key structure for table registe_black_list
-- ----------------------------
ALTER TABLE "registe_black_list" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table report
-- ----------------------------
ALTER TABLE "report" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table report_element
-- ----------------------------
ALTER TABLE "report_element" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table role_member
-- ----------------------------
ALTER TABLE "role_member" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table role_permission
-- ----------------------------
ALTER TABLE "role_permission" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table roles
-- ----------------------------
ALTER TABLE "roles" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table shared_analyze_map_detail
-- ----------------------------
ALTER TABLE "shared_analyze_map_detail" ADD PRIMARY KEY ("shared_analyze_map_id");

-- ----------------------------
-- Primary Key structure for table shared_analyze_map_info
-- ----------------------------
ALTER TABLE "shared_analyze_map_info" ADD PRIMARY KEY ("shared_analyze_map_info_uuid");

-- ----------------------------
-- Primary Key structure for table shared_dashboard_info
-- ----------------------------
ALTER TABLE "shared_dashboard_info" ADD PRIMARY KEY ("shared_dashboard_info_id");

-- ----------------------------
-- Primary Key structure for table sms_send_history
-- ----------------------------
ALTER TABLE "sms_send_history" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table snapshot
-- ----------------------------
ALTER TABLE "snapshot" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Indexes structure for table task
-- ----------------------------
CREATE INDEX "task_task___fk_workflow_id" ON "task" USING btree ("workflow_id");
CREATE INDEX "task_task_status_index" ON "task" USING btree ("task_status");

-- ----------------------------
-- Primary Key structure for table task
-- ----------------------------
ALTER TABLE "task" ADD PRIMARY KEY ("task_uuid");

-- ----------------------------
-- Primary Key structure for table template
-- ----------------------------
ALTER TABLE "template" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table template_chart
-- ----------------------------
ALTER TABLE "template_chart" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table template_chart_used_column
-- ----------------------------
ALTER TABLE "template_chart_used_column" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table template_column
-- ----------------------------
ALTER TABLE "template_column" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table template_element
-- ----------------------------
ALTER TABLE "template_element" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table template_global_filter
-- ----------------------------
ALTER TABLE "template_global_filter" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table template_global_filter_chart
-- ----------------------------
ALTER TABLE "template_global_filter_chart" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table template_global_filter_column
-- ----------------------------
ALTER TABLE "template_global_filter_column" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table user_report
-- ----------------------------
ALTER TABLE "user_report" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table user_template
-- ----------------------------
ALTER TABLE "user_template" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Uniques structure for table users
-- ----------------------------
ALTER TABLE "users" ADD UNIQUE ("login_account");

-- ----------------------------
-- Primary Key structure for table users
-- ----------------------------
ALTER TABLE "users" ADD PRIMARY KEY ("guid");

-- ----------------------------
-- Indexes structure for table workflow
-- ----------------------------
CREATE INDEX "workflow_workflow_status_index" ON "workflow" USING btree ("workflow_status");

-- ----------------------------
-- Primary Key structure for table workflow
-- ----------------------------
ALTER TABLE "workflow" ADD PRIMARY KEY ("workflow_id");
