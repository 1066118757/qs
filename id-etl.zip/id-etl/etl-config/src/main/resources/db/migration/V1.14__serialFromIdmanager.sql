-- ----------------------------
-- Table structure for cluster
-- ----------------------------
DROP TABLE IF EXISTS "cluster";
CREATE TABLE "cluster" (
"cluster_id" serial NOT NULL,
"cluster_name" varchar(45) COLLATE "default" NOT NULL,
"description" varchar(200) COLLATE "default",
"zookeeper" varchar(200) COLLATE "default",
"master" varchar(45) COLLATE "default",
"monitor" varchar(45) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Records of cluster
-- ----------------------------
INSERT INTO "cluster" VALUES ('1', 'c1', null, null, null, null);

-- ----------------------------
-- Table structure for confirmation_tokens
-- ----------------------------
DROP TABLE IF EXISTS "confirmation_tokens";
CREATE TABLE "confirmation_tokens" (
"id" serial NOT NULL,
"uuid" varchar(36) COLLATE "default" NOT NULL,
"email" varchar(254) COLLATE "default" NOT NULL,
"creation_time" timestamp(6) DEFAULT now() NOT NULL,
"expiration_time" timestamp(6),
"is_sign_up" bool NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Records of confirmation_tokens
-- ----------------------------

-- ----------------------------
-- Table structure for etl_history
-- ----------------------------
DROP TABLE IF EXISTS "etl_history";
CREATE TABLE "etl_history" (
"etl_history_id" serial NOT NULL,
"etl_info_id" varchar(36) COLLATE "default" NOT NULL,
"create_at" timestamp(6) DEFAULT now() NOT NULL,
"affected_rows" int4 NOT NULL,
"status" bool NOT NULL,
"log" text COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Records of etl_history
-- ----------------------------

-- ----------------------------
-- Table structure for host
-- ----------------------------
DROP TABLE IF EXISTS "host";
CREATE TABLE "host" (
"host_id" serial NOT NULL,
"tag" varchar(45) COLLATE "default",
"hostname" varchar(45) COLLATE "default" NOT NULL,
"ipv4" varchar(45) COLLATE "default" NOT NULL,
"enable" bool NOT NULL,
"cluster_id" int4 NOT NULL,
"role_type" varchar(200) COLLATE "default",
"components" varchar(500) COLLATE "default" NOT NULL,
"cores" int4,
"memory" int4,
"disk" int4
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Records of host
-- ----------------------------

-- ----------------------------
-- Table structure for invitation_code
-- ----------------------------
DROP TABLE IF EXISTS "invitation_code";
CREATE TABLE "invitation_code" (
"id" serial NOT NULL,
"code" varchar(36) COLLATE "default" NOT NULL,
"register_account" varchar(36) COLLATE "default"
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Records of invitation_code
-- ----------------------------

-- ----------------------------
-- Table structure for learning_model_train_log
-- ----------------------------
DROP TABLE IF EXISTS "learning_model_train_log";
CREATE TABLE "learning_model_train_log" (
"id" serial NOT NULL,
"learning_model_id" varchar(40) COLLATE "default" NOT NULL,
"train_time" timestamp(6) DEFAULT now() NOT NULL,
"success" bool NOT NULL,
"algorithm" varchar(50) COLLATE "default" NOT NULL,
"train_params" text COLLATE "default",
"summary" text COLLATE "default",
"train_result" text COLLATE "default" NOT NULL,
"transform_features" text COLLATE "default",
"metrics" text COLLATE "default",
"error_msg" text COLLATE "default",
"end_time" timestamp(6) DEFAULT now()
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Records of learning_model_train_log
-- ----------------------------

-- ----------------------------
-- Table structure for monitor_action_record
-- ----------------------------
DROP TABLE IF EXISTS "monitor_action_record";
CREATE TABLE "monitor_action_record" (
"id" serial NOT NULL,
"action_type" varchar(45) COLLATE "default" NOT NULL,
"origin_val" varchar(500) COLLATE "default",
"update_val" varchar(500) COLLATE "default",
"create_at" timestamp(6) DEFAULT now() NOT NULL,
"create_by" varchar(50) COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Records of monitor_action_record
-- ----------------------------

-- ----------------------------
-- Table structure for monitor_event_history
-- ----------------------------
DROP TABLE IF EXISTS "monitor_event_history";
CREATE TABLE "monitor_event_history" (
"log_id" serial NOT NULL,
"id" varchar(45) COLLATE "default" NOT NULL,
"endpoint" varchar(45) COLLATE "default" NOT NULL,
"metric" varchar(45) COLLATE "default" NOT NULL,
"counter" varchar(100) COLLATE "default" NOT NULL,
"func" varchar(45) COLLATE "default" NOT NULL,
"left_value" varchar(45) COLLATE "default",
"operator" varchar(45) COLLATE "default" NOT NULL,
"right_value" varchar(45) COLLATE "default",
"note" varchar(45) COLLATE "default" NOT NULL,
"max_step" int4 NOT NULL,
"current_step" int4 NOT NULL,
"priority" int4 NOT NULL,
"status" varchar(45) COLLATE "default" NOT NULL,
"timestamp" int8 NOT NULL,
"expression_id" int4 NOT NULL,
"strategy_id" int4 NOT NULL,
"template_id" int4 NOT NULL,
"link" varchar(100) COLLATE "default",
"closed_at" int8 NOT NULL,
"closed_by" varchar(255) COLLATE "default" NOT NULL
)
WITH (OIDS=FALSE)

;

-- ----------------------------
-- Records of monitor_event_history
-- ----------------------------

-- ----------------------------
-- Alter Sequences Owned By
-- ----------------------------

-- ----------------------------
-- Uniques structure for table cluster
-- ----------------------------
ALTER TABLE "cluster" ADD UNIQUE ("cluster_name");

-- ----------------------------
-- Primary Key structure for table cluster
-- ----------------------------
ALTER TABLE "cluster" ADD PRIMARY KEY ("cluster_id");

-- ----------------------------
-- Primary Key structure for table confirmation_tokens
-- ----------------------------
ALTER TABLE "confirmation_tokens" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table etl_history
-- ----------------------------
ALTER TABLE "etl_history" ADD PRIMARY KEY ("etl_history_id");

-- ----------------------------
-- Indexes structure for table host
-- ----------------------------
CREATE INDEX "host_fk_host_cluster1_idx" ON "host" USING btree ("cluster_id");

-- ----------------------------
-- Uniques structure for table host
-- ----------------------------
ALTER TABLE "host" ADD UNIQUE ("hostname");

-- ----------------------------
-- Primary Key structure for table host
-- ----------------------------
ALTER TABLE "host" ADD PRIMARY KEY ("host_id");

-- ----------------------------
-- Uniques structure for table invitation_code
-- ----------------------------
ALTER TABLE "invitation_code" ADD UNIQUE ("code");

-- ----------------------------
-- Primary Key structure for table invitation_code
-- ----------------------------
ALTER TABLE "invitation_code" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table learning_model_train_log
-- ----------------------------
ALTER TABLE "learning_model_train_log" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table monitor_action_record
-- ----------------------------
ALTER TABLE "monitor_action_record" ADD PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table monitor_event_history
-- ----------------------------
ALTER TABLE "monitor_event_history" ADD PRIMARY KEY ("log_id");
