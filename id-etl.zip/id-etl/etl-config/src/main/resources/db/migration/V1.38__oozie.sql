
DROP TABLE IF EXISTS t_program;

CREATE TABLE t_program
(
    id numeric NOT NULL,
    name VARCHAR(50) DEFAULT '' NOT NULL,
    path VARCHAR(200) DEFAULT '' NOT NULL,
    programType VARCHAR(10) DEFAULT  'JAVA' NOT NULL,
    personal_conf text DEFAULT '' NOT NULL,
    parameters text  DEFAULT '' NOT NULL,
    is_public boolean NOT NULL,
    downloadable boolean NOT NULL,
    owner VARCHAR(36) DEFAULT '' NOT NULL,
    label VARCHAR(200) DEFAULT '' NOT NULL,
    description VARCHAR(500) DEFAULT '',
    source_link VARCHAR(200) DEFAULT '' NOT NULL,
    create_time timestamp without time zone,
    update_time timestamp without time zone NOT NULL,
    CONSTRAINT t_program_pkey PRIMARY KEY (id)
)
WITH (
    OIDS = FALSE
);
COMMENT ON COLUMN t_program.personal_conf
    IS '专有配置';

COMMENT ON COLUMN t_program.create_time
    IS '创建时间';

COMMENT ON COLUMN t_program.downloadable
    IS '是否可下载';

COMMENT ON COLUMN t_program.id
    IS '主键ID';

COMMENT ON COLUMN t_program.is_public
    IS '是否公开';

COMMENT ON COLUMN t_program.name
    IS '程序名';

COMMENT ON COLUMN t_program.owner
    IS '所有者';

COMMENT ON COLUMN t_program.path
    IS '存放路径';

COMMENT ON COLUMN t_program.source_link
    IS '源码链接';

COMMENT ON COLUMN t_program.update_time
    IS '更新时间';

COMMENT ON COLUMN t_program.label
    IS '标签';


DROP TABLE IF EXISTS t_oozie_job;

CREATE TABLE t_oozie_job
(
    id numeric NOT NULL,
    name VARCHAR(50) DEFAULT '' NOT NULL,
    path VARCHAR(200) DEFAULT '' NOT NULL,
    graph_xml text DEFAULT '' NOT NULL,
    create_user character(36) DEFAULT '' NOT NULL,
    latest_status VARCHAR(12) DEFAULT '' NOT NULL,
    latest_oozie_job_id VARCHAR(50) DEFAULT '' NOT NULL,
    description VARCHAR(500) DEFAULT '',
    latest_start_time timestamp without time zone,
    latest_end_time timestamp without time zone,
    create_time timestamp without time zone NOT NULL,
    update_time timestamp without time zone NOT NULL,
    timeout integer NOT NULL DEFAULT 0,
    CONSTRAINT t_oozie_job_pkey PRIMARY KEY (id)
)
WITH (
    OIDS = FALSE
);

COMMENT ON COLUMN t_oozie_job.id
    IS '主键ID';

COMMENT ON COLUMN t_oozie_job.name
    IS '任务名称';

COMMENT ON COLUMN t_oozie_job.path
    IS '任务存放路径';

COMMENT ON COLUMN t_oozie_job.graph_xml
    IS '任务定义的xml';

COMMENT ON COLUMN t_oozie_job.create_user
    IS '创建人';

COMMENT ON COLUMN t_oozie_job.latest_status
    IS '最近一次运行状态';

COMMENT ON COLUMN t_oozie_job.latest_oozie_job_id
    IS '提交到oozie后返回的job ID';

COMMENT ON COLUMN t_oozie_job.description
    IS '描述';

COMMENT ON COLUMN t_oozie_job.latest_start_time
    IS '最近一次运行开始时间';

COMMENT ON COLUMN t_oozie_job.latest_end_time
    IS '最近一次运行结束时间';

COMMENT ON COLUMN t_oozie_job.create_time
    IS '创建时间';

COMMENT ON COLUMN t_oozie_job.update_time
    IS '更新时间';

COMMENT ON COLUMN t_oozie_job.timeout
    IS '运行超时时间';


DROP  TABLE  IF EXISTS t_oozie_job_log;

CREATE TABLE t_oozie_job_log
(
    id numeric NOT NULL,
    job_id numeric NOT NULL,
    status VARCHAR(12) DEFAULT '' NOT NULL,
    start_time timestamp without time zone NOT NULL,
    oozie_job_id VARCHAR(40) DEFAULT '' NOT NULL,
    end_time timestamp without time zone,
    info_log text DEFAULT '',
    error_log text DEFAULT '',
    CONSTRAINT t_oozie_job_log_pkey PRIMARY KEY (id)
)
WITH (
    OIDS = FALSE
);
COMMENT ON TABLE t_oozie_job_log
    IS 'oozie任务的运行日志';

COMMENT ON COLUMN t_oozie_job_log.id
    IS '主键ID';

COMMENT ON COLUMN t_oozie_job_log.job_id
    IS 't_oozie_job_id';

COMMENT ON COLUMN t_oozie_job_log.status
    IS '运行结果';

COMMENT ON COLUMN t_oozie_job_log.start_time
    IS '开始时间';

COMMENT ON COLUMN t_oozie_job_log.oozie_job_id
    IS '提交到oozie-server后返回的ID';

COMMENT ON COLUMN t_oozie_job_log.end_time
    IS '结束时间';

COMMENT ON COLUMN t_oozie_job_log.info_log
    IS '输出日志';

COMMENT ON COLUMN t_oozie_job_log.error_log
    IS '错误日志';

DROP  TABLE  IF EXISTS t_oozie_action_log;

CREATE TABLE t_oozie_action_log
(
    id numeric NOT NULL,
    action_name VARCHAR(50) DEFAULT '' NOT NULL,
    oozie_job_id VARCHAR(50) DEFAULT ''  NOT NULL,
    status VARCHAR(12) DEFAULT '' NOT NULL,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone,
    CONSTRAINT t_oozie_action_log_pkey PRIMARY KEY (id)
)
WITH (
    OIDS = FALSE
);
COMMENT ON COLUMN t_oozie_action_log.id
    IS '主键ID';

COMMENT ON COLUMN t_oozie_action_log.action_name
    IS '节点名';

COMMENT ON COLUMN t_oozie_action_log.oozie_job_id
    IS '提交到oozie-server后返回的任务ID';

COMMENT ON COLUMN t_oozie_action_log.status
    IS '运行结果';

COMMENT ON COLUMN t_oozie_action_log.start_time
    IS '节点开始时间';

COMMENT ON COLUMN t_oozie_action_log.end_time
    IS '节点结束时间';


ALTER TABLE t_file ADD  COLUMN is_public boolean DEFAULT  FALSE NOT NULL;
ALTER TABLE t_file ADD  COLUMN  description VARCHAR(500) DEFAULT '';