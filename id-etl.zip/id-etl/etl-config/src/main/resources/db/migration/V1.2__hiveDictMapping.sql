INSERT INTO "c_dict_mapping" ("id", "type_id", "key", "value", "status", "update_user", "update_time") VALUES ('613', '6', '13', 'hive', '1', '0', current_timestamp);
