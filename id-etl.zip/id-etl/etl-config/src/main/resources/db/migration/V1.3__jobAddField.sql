ALTER TABLE t_job ADD kernel_id varchar(50);
ALTER TABLE t_job ADD session_id varchar(50);