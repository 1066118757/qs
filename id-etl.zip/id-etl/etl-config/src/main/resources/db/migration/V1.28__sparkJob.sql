drop table  if EXISTS spark_job;
create table spark_job(
  "id" varchar(40)  NOT NULL,
  "name" varchar(50) NOT NULL,
  "description" varchar(255),
  "alg_type"  varchar(10),
  "code_type" varchar(10) NOT NULL,
  "file_path" TEXT NOT NULL,
  "main_class"  varchar(200),
  "args"  TEXT,
  "is_default" boolean default false,
  "create_at" timestamp(6) DEFAULT now() NOT NULL,
  "create_by" varchar(40)  NOT NULL,
  "update_at" timestamp(6) DEFAULT now(),
  "update_by" varchar(40) ,
CONSTRAINT "spark_job_pkey" PRIMARY KEY ("id")
);
drop table  if EXISTS spark_job_deploy;
create table spark_job_deploy(
   "id" varchar(40)  NOT NULL,
  "name" varchar(50),
  "spark_job_id" varchar(50) NOT NULL,
  "args"  TEXT,
  "create_at" timestamp(6) DEFAULT now() NOT NULL,
  "create_by" varchar(40)  NOT NULL,
  CONSTRAINT "spark_job_deploy_pkey" PRIMARY KEY ("id")
);

