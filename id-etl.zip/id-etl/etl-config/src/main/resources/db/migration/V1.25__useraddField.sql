ALTER TABLE users ADD "private_key" varchar(500);
ALTER TABLE users ADD "public_key" varchar(500);
