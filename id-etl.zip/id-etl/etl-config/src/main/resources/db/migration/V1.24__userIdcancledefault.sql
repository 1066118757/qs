alter table t_clear_record alter COLUMN "create_user"  DROP DEFAULT;
alter table t_clear_record alter COLUMN "update_user"  DROP DEFAULT;

alter table t_clear_rule alter COLUMN "create_user"  DROP DEFAULT;
alter table t_clear_rule alter COLUMN "update_user"  DROP DEFAULT;

alter table t_clear_task alter COLUMN "create_user"  DROP DEFAULT;
alter table t_clear_task alter COLUMN "update_user"  DROP DEFAULT;

alter table t_clear_task_log alter COLUMN "create_user"  DROP DEFAULT;

alter table t_data_source alter COLUMN "create_user"  DROP DEFAULT;
alter table t_data_source alter COLUMN "update_user"  DROP DEFAULT;

alter table t_file alter COLUMN "create_user"  DROP DEFAULT;

alter table t_job alter COLUMN "create_user"  DROP DEFAULT;
alter table t_job alter COLUMN "update_user"  DROP DEFAULT;

alter table t_job_conf alter COLUMN "create_user"  DROP DEFAULT;
alter table t_job_conf alter COLUMN "update_user"  DROP DEFAULT;

alter table t_metadata_detail alter COLUMN "create_user"  DROP DEFAULT;
alter table t_metadata_detail alter COLUMN "update_user"  DROP DEFAULT;

alter table t_metadata_item alter COLUMN "create_user"  DROP DEFAULT;
alter table t_metadata_item alter COLUMN "update_user"  DROP DEFAULT;

alter table t_metadata_theme alter COLUMN "create_user"  DROP DEFAULT;
alter table t_metadata_theme alter COLUMN "update_user"  DROP DEFAULT;

alter table t_metadata_theme_item alter COLUMN "create_user"  DROP DEFAULT;
alter table t_metadata_theme_item alter COLUMN "update_user"  DROP DEFAULT;

alter table t_operate_log alter COLUMN "operator_id"  DROP DEFAULT;

alter table t_rule_instance alter COLUMN "create_user"  DROP DEFAULT;
alter table t_rule_instance alter COLUMN "update_user"  DROP DEFAULT;

alter table t_rule_instance_param alter COLUMN "create_user"  DROP DEFAULT;
alter table t_rule_instance_param alter COLUMN "update_user"  DROP DEFAULT;

alter table t_rule_param alter COLUMN "create_user"  DROP DEFAULT;
alter table t_rule_param alter COLUMN "update_user"  DROP DEFAULT;

alter table t_storage_data alter COLUMN "create_user"  DROP DEFAULT;
alter table t_storage_data alter COLUMN "update_user"  DROP DEFAULT;
alter table t_storage_data alter COLUMN "upload_user_id"  DROP DEFAULT;
