UPDATE "c_dict_mapping" SET "id"='801', "type_id"='8', "key"='1', "value"='更新值', "status"='1', "update_user"='0', "update_time"='2017-12-12 18:14:17.933539' WHERE ("id"='801');
UPDATE "c_dict_mapping" SET "id"='802', "type_id"='8', "key"='2', "value"='数据清洗', "status"='1', "update_user"='0', "update_time"='2017-12-12 18:14:17.933539' WHERE ("id"='802');
UPDATE "c_dict_mapping" SET "id"='803', "type_id"='8', "key"='3', "value"='数据筛选', "status"='1', "update_user"='0', "update_time"='2017-12-12 18:14:17.933539' WHERE ("id"='803');
UPDATE "c_dict_mapping" SET "id"='804', "type_id"='8', "key"='4', "value"='列操作', "status"='1', "update_user"='0', "update_time"='2017-12-12 18:14:17.933539' WHERE ("id"='804');
INSERT INTO "c_dict_mapping" ("id", "type_id", "key", "value", "status", "update_user", "update_time") VALUES ('805', '8', '5', '其他', '1', '0', '2017-12-12 18:14:17.933539');
INSERT INTO "c_dict_mapping" ("id", "type_id", "key", "value", "status", "update_user", "update_time") VALUES ('806', '8', '6', '自定义', '1', '0', '2017-12-12 18:14:17.933539');

ALTER TABLE t_clear_rule add column file_path VARCHAR(150) ;
ALTER TABLE t_clear_rule add column main_class VARCHAR(50);

COMMENT ON COLUMN t_clear_rule.file_path IS '自定义算法路径';
COMMENT ON COLUMN t_clear_rule.main_class IS '自定义算法主函数';

