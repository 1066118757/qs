alter table t_metadata_detail alter COLUMN "col_displayname" type varchar(100);
alter table t_metadata_detail alter COLUMN "col_name" type varchar(100);

alter table t_metadata_item alter COLUMN "name" type varchar(100);