DROP TABLE IF EXISTS "chart_scope";
DROP TABLE IF EXISTS "data_source_conf";
DROP TABLE IF EXISTS "data_source_info";
DROP TABLE IF EXISTS "etl_history";
DROP TABLE IF EXISTS "etl_info";
DROP TABLE IF EXISTS "etl_schedule";
DROP TABLE IF EXISTS "project_script_deploy";
DROP TABLE IF EXISTS "r_job";
DROP TABLE IF EXISTS "t_rule_instance";
DROP TABLE IF EXISTS "t_rule_instance_param";
DROP TABLE IF EXISTS "t_rule_param";

ALTER TABLE learning_model_deploy add column config VARCHAR(60);
ALTER TABLE learning_model_deploy add column model_type varchar(10);
ALTER TABLE learning_model_deploy add column schedule_config text;
ALTER TABLE learning_model_deploy add column notice_config text;
ALTER TABLE learning_model_deploy add column latest_schedule_state int4;
ALTER TABLE learning_model_deploy add column latest_schedule_start_time timestamp(6);
ALTER TABLE learning_model_deploy add column latest_schedule_end_time timestamp(6);
ALTER TABLE learning_model_deploy add column latest_schedule_log text;

ALTER TABLE t_schedule_log  add column job_type varchar(10) default 'etl';


