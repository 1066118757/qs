DELETE FROM  "group" where id in('1','2','3');
INSERT INTO "group" (id, name, create_by, create_at, group_type) VALUES ('1', '我的文件夹', '1', now(), 2);
INSERT INTO "group" (id, name, create_by, create_at, group_type) VALUES ('2', '我的文件夹', '2', now(), 2);
INSERT INTO "group" (id, name, create_by, create_at, group_type) VALUES ('3', '我的文件夹', '3', now(), 2);

ALTER  TABLE  t_operate_action  ALTER  COLUMN "id" TYPE  NUMERIC;