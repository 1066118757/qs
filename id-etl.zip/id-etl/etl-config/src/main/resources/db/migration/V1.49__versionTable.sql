DROP TABLE IF EXISTS "t_version";
CREATE TABLE "t_version" (
  id  NUMERIC NOT NULL PRIMARY KEY,
  no varchar(20),
  name varchar(40),
  description varchar(300),
  logo varchar(400),
  image varchar(500),
  state int4,
  create_user varchar(60),
  create_time timestamp(6) DEFAULT CURRENT_TIMESTAMP,
  update_user varchar(60),
  update_time timestamp(6) DEFAULT CURRENT_TIMESTAMP,
  flag int2 DEFAULT 1
) WITH(OIDS = FALSE);

COMMENT ON TABLE t_version IS '版本管理表';
COMMENT ON COLUMN t_version.no IS '版本号';
COMMENT ON COLUMN t_version.name IS '版本名';
COMMENT ON COLUMN t_version.description IS '版本描述';
COMMENT ON COLUMN t_version.logo IS '版本logo';
COMMENT ON COLUMN t_version.image IS '版本图片';
COMMENT ON COLUMN t_version.state IS '状态';
COMMENT ON COLUMN t_version.flag IS '删除标记 1:有效,0:无效';