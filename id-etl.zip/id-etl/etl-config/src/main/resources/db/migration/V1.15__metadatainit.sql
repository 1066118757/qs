INSERT INTO t_metadata_theme(id,name,remark) VALUES(100,'default','分享逻辑分区');
INSERT INTO t_metadata_theme_item(id,theme_id,name) VALUES(1001,100,'业务元数据'),(1002,100,'任务元数据');