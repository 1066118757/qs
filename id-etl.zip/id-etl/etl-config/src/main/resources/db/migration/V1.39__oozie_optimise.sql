DROP  TABLE  IF EXISTS t_oozie_action_log;

ALTER TABLE t_program ADD  COLUMN filename VARCHAR(50) DEFAULT  '' NOT NULL;
