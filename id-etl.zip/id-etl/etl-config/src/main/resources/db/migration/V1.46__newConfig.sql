DELETE FROM   "c_base_config" WHERE  "key" in('zk.server','redis.server');
INSERT INTO  "c_base_config" ("id", "key", "value", "status", "create_time", "create_user", "update_time", "update_user") VALUES ('13', 'redis.server', '127.0.0.1', '1', '2018-05-24 17:52:34.355024', NULL, '2018-05-24 17:52:34.355024', NULL);
INSERT INTO  "c_base_config" ("id", "key", "value", "status", "create_time", "create_user", "update_time", "update_user") VALUES ('14', 'zk.server', 'zk.server.host:2181', '1', '2018-05-24 17:52:34.355024', NULL, '2018-05-24 17:52:34.355024', NULL);
