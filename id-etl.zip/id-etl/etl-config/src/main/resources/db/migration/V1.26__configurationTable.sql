DROP TABLE IF EXISTS "c_base_config";
CREATE TABLE "c_base_config" (
  "id" NUMERIC NOT NULL PRIMARY KEY,
  "key" varchar(100) DEFAULT '',
  "value" varchar(300) DEFAULT '',
  "status"         INT4 DEFAULT 1,
  "create_time"    TIMESTAMP DEFAULT current_timestamp,
  "create_user"    NUMERIC,
  "update_time"    TIMESTAMP DEFAULT current_timestamp,
  "update_user"    NUMERIC
)WITH (OIDS=FALSE);
COMMENT ON TABLE "c_base_config" IS '配置属性表';
COMMENT ON COLUMN "c_base_config"."key" IS '配置属性的key';
COMMENT ON COLUMN "c_base_config"."value" IS '配置属性的value';

