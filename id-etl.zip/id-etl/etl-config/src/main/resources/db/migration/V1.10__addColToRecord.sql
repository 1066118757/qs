ALTER TABLE t_clear_record add column handle_code text DEFAULT '' COLLATE "default";
COMMENT ON COLUMN t_clear_record.handle_code IS '封装了操作表以及规则实例化信息的json串';

