DELETE FROM   "c_base_config" WHERE  "key" in('oozie.server','yarn');
INSERT INTO  "c_base_config" ("id", "key", "value", "status", "create_time", "create_user", "update_time", "update_user") VALUES ('11', 'oozie.server', 'http://192.168.55.115:11000/oozie', '1', '2018-05-24 17:52:34.355024', NULL, '2018-05-24 17:52:34.355024', NULL);
INSERT INTO  "c_base_config" ("id", "key", "value", "status", "create_time", "create_user", "update_time", "update_user") VALUES ('12', 'yarn', '192.168.55.115:8050', '1', '2018-05-24 17:53:27.365145', NULL, '2018-05-24 17:53:27.365145', NULL);
