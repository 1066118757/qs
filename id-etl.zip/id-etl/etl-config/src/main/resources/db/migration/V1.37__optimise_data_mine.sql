ALTER  TABLE learning_model DROP  COLUMN "project_id";
ALTER  TABLE learning_model ADD COLUMN "table_id"  VARCHAR(40);
UPDATE "c_dict_mapping" SET "value"='phoenix' WHERE id=606;