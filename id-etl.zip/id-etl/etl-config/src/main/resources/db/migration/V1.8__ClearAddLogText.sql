ALTER TABLE t_clear_task_log add column success_rows int8;
ALTER TABLE t_clear_task_log add column task_log text COLLATE "default";

