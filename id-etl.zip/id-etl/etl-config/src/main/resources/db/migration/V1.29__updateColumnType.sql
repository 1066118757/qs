DROP TABLE IF EXISTS "learning_model_train_log";
CREATE TABLE "learning_model_train_log" (
"id" varchar(40)  NOT NULL,
"learning_model_id" varchar(40)  NOT NULL,
"train_time" timestamp(6) DEFAULT now() NOT NULL,
"success" bool NOT NULL,
"algorithm" varchar(50)  NOT NULL,
"train_params" text ,
"summary" text ,
"train_result" text  NOT NULL,
"transform_features" text ,
"metrics" text ,
"error_msg" text ,
"end_time" timestamp(6) DEFAULT now(),
CONSTRAINT "learning_model_train_log_pkey" PRIMARY KEY ("id")
)
WITH (OIDS=FALSE);

ALTER TABLE spark_job_deploy add column batch_id VARCHAR(60);

ALTER TABLE spark_job_deploy add column rsv_column text;