DROP TABLE IF EXISTS "t_storage_data";
CREATE TABLE "t_storage_data" (
  "id"             NUMERIC NOT NULL PRIMARY KEY,
  "name"           VARCHAR(20),
  "upload_user_id" NUMERIC,
  "upload_time"    TIMESTAMP DEFAULT current_timestamp,
  "introduction"   VARCHAR(100),
  "file_id" NUMERIC,
  "type"           INT4  DEFAULT 0,
  "status"         INT4 DEFAULT 1,
  "create_time"    TIMESTAMP DEFAULT current_timestamp,
  "create_user"    NUMERIC,
  "update_time"    TIMESTAMP DEFAULT current_timestamp,
  "update_user"    NUMERIC
) WITH(OIDS = FALSE);

COMMENT ON TABLE t_storage_data IS '数据存储表';
COMMENT ON COLUMN t_storage_data.id IS 'id';
COMMENT ON COLUMN t_storage_data.name IS '名称';
COMMENT ON COLUMN t_storage_data.upload_user_id IS '上传用户';
COMMENT ON COLUMN t_storage_data.upload_time IS '上传时间';
COMMENT ON COLUMN t_storage_data.file_id IS '文件id';
COMMENT ON COLUMN t_storage_data.introduction IS '介绍';
COMMENT ON COLUMN t_storage_data.type IS '类型 0:代表图片,1:代表视频';


DROP TABLE IF EXISTS "t_file";
CREATE TABLE "t_file" (
  "id"          NUMERIC NOT NULL PRIMARY KEY,
  "path"        VARCHAR(60) COLLATE "default",
  "name"        VARCHAR(100) COLLATE "default",
  "file_type"   VARCHAR(10) COLLATE "default",
  "size"        INT8,
  "create_user" NUMERIC,
  "create_time" TIMESTAMP DEFAULT current_timestamp
)
WITH (OIDS = FALSE
);


COMMENT ON TABLE t_file IS '文件表';
COMMENT ON COLUMN t_file.path IS '文件路径';
COMMENT ON COLUMN t_file.name IS '文件名';
COMMENT ON COLUMN t_file.file_type IS '文件类型';
COMMENT ON COLUMN t_file.size IS '文件大小';
COMMENT ON COLUMN t_file.create_user IS '创建人';
COMMENT ON COLUMN t_file.create_time IS '创建时间';
