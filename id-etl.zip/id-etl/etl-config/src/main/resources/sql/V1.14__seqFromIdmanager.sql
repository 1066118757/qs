-- ----------------------------
-- Sequence structure for cluster_cluster_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "cluster_cluster_id_seq";
CREATE SEQUENCE "cluster_cluster_id_seq"
 INCREMENT 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 START 1
 CACHE 1;
 
ALTER TABLE cluster ALTER COLUMN cluster_id SET DEFAULT nextval('cluster_cluster_id_seq');

-- ----------------------------
-- Sequence structure for confirmation_tokens_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "confirmation_tokens_id_seq";
CREATE SEQUENCE "confirmation_tokens_id_seq"
 INCREMENT 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 START 1
 CACHE 1;
 
ALTER TABLE confirmation_tokens ALTER COLUMN id SET DEFAULT nextval('confirmation_tokens_id_seq');
 

-- ----------------------------
-- Sequence structure for etl_history_etl_history_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "etl_history_etl_history_id_seq";
CREATE SEQUENCE "etl_history_etl_history_id_seq"
 INCREMENT 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 START 1
 CACHE 1;
 
ALTER TABLE etl_history ALTER COLUMN etl_history_id SET DEFAULT nextval('etl_history_etl_history_id_seq');

-- ----------------------------
-- Sequence structure for host_host_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "host_host_id_seq";
CREATE SEQUENCE "host_host_id_seq"
 INCREMENT 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 START 1
 CACHE 1;
 
ALTER TABLE host ALTER COLUMN host_id SET DEFAULT nextval('host_host_id_seq');

-- ----------------------------
-- Sequence structure for invitation_code_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "invitation_code_id_seq";
CREATE SEQUENCE "invitation_code_id_seq"
 INCREMENT 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 START 1
 CACHE 1;
 
ALTER TABLE invitation_code ALTER COLUMN id SET DEFAULT nextval('invitation_code_id_seq');
-- ----------------------------
-- Sequence structure for learning_model_train_log_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "learning_model_train_log_id_seq";
CREATE SEQUENCE "learning_model_train_log_id_seq"
 INCREMENT 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 START 1
 CACHE 1;
 
ALTER TABLE learning_model_train_log ALTER COLUMN id SET DEFAULT nextval('learning_model_train_log_id_seq');

-- ----------------------------
-- Sequence structure for monitor_action_record_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "monitor_action_record_id_seq";
CREATE SEQUENCE "monitor_action_record_id_seq"
 INCREMENT 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 START 1
 CACHE 1;
 
ALTER TABLE monitor_action_record ALTER COLUMN id SET DEFAULT nextval('monitor_action_record_id_seq');

-- ----------------------------
-- Sequence structure for monitor_event_history_log_id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "monitor_event_history_log_id_seq";
CREATE SEQUENCE "monitor_event_history_log_id_seq"
 INCREMENT 1
 MINVALUE 1
 MAXVALUE 9223372036854775807
 START 1
 CACHE 1;
 
ALTER TABLE monitor_event_history ALTER COLUMN log_id SET DEFAULT nextval('monitor_event_history_log_id_seq');
 