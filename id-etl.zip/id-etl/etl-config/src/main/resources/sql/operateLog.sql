DROP TABLE IF EXISTS "t_operate_log";
CREATE TABLE "t_operate_log" (
  "id" NUMERIC NOT NULL ,
  "operator_id" NUMERIC ,
  "operate_table" VARCHAR (50),
  "operate_time" TIMESTAMP,
  "action_id" int4,
  "result" int2,
  CONSTRAINT "t_operate_log_pkey" PRIMARY KEY  ("id")
)WITH (OIDS=FALSE);

COMMENT ON TABLE "t_operate_log" IS '数据审计操作日志';
COMMENT ON COLUMN "t_operate_log"."id" IS 'ID';
COMMENT ON COLUMN "t_operate_log"."operator_id" IS '操作人ID';
COMMENT ON COLUMN "t_operate_log"."operate_table" IS '操作表';
COMMENT ON COLUMN "t_operate_log"."operate_time" IS '操作时间';
COMMENT ON COLUMN "t_operate_log"."action_id" IS '操作条目';
COMMENT ON COLUMN "t_operate_log"."result" IS '操作状态';


DROP TABLE IF EXISTS "t_operate_action";
CREATE TABLE "t_operate_action" (
  "id" int4 NOT NULL,
  "action_desc" VARCHAR (100),
  CONSTRAINT "t_operate_action_pkey" PRIMARY KEY ("id")
)WITH (OIDS=FALSE);

COMMENT ON TABLE "t_operate_action" IS '操作描述表';
COMMENT ON COLUMN "t_operate_action"."id" IS 'id';
COMMENT ON COLUMN "t_operate_action"."action_desc" IS '操作描述';

