drop table if EXISTS t_metadata_detail;
create table t_metadata_detail
(
  id   numeric not null,
	index int4,
  metadata_item_id numeric,
  col_displayname  varchar(20),
  col_type  int4,
  col_comment  varchar(50),
  col_name varchar(30),
  state int4 DEFAULT 0,
  audit_time  timestamp DEFAULT CURRENT_TIMESTAMP,
  status int2 DEFAULT 1,
  create_user numeric,
  create_time timestamp DEFAULT CURRENT_TIMESTAMP ,
  update_user numeric,
  update_time timestamp DEFAULT CURRENT_TIMESTAMP ,
  CONSTRAINT t_metadata_detail_pkey PRIMARY KEY (id)
)WITH (OIDS=FALSE);
COMMENT ON TABLE t_metadata_detail IS '元数据详情表';
COMMENT ON COLUMN t_metadata_detail.metadata_item_id    IS '元数据条目id';
COMMENT ON COLUMN t_metadata_detail.index    IS '元数据条目序列号';
COMMENT ON COLUMN t_metadata_detail.col_displayname    IS '字段真实名';
COMMENT ON COLUMN t_metadata_detail.col_type    IS '列类型，例如：文本，数值,参考码表类型3';
COMMENT ON COLUMN t_metadata_detail.col_comment    IS '列内容';
COMMENT ON COLUMN t_metadata_detail.col_name  IS '数据库对应列名';
COMMENT ON COLUMN t_metadata_theme.state  IS '审核状态,参考码表类型1';
COMMENT ON COLUMN t_metadata_theme.audit_time  IS '审核时间';
COMMENT ON COLUMN t_metadata_theme.status  IS '记录状态 1:可用,2:不可用';