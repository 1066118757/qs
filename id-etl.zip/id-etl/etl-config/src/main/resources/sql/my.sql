drop table if EXISTS t_metadata_theme;
create table t_metadata_theme
(
  id   numeric not null,
  name   varchar(30),
  remark varchar(100),
  state int4 DEFAULT 0,
  audit_time  timestamp DEFAULT CURRENT_TIMESTAMP,
  status int2 DEFAULT 1,
  create_user numeric,
  create_time timestamp DEFAULT CURRENT_TIMESTAMP,
  update_user numeric,
  update_time timestamp DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT t_metadata_theme_pkey PRIMARY KEY (id)
)WITH (OIDS=FALSE);

COMMENT ON TABLE t_metadata_theme IS '元数据主题表';
COMMENT ON COLUMN t_metadata_theme.name    IS '主题名';
COMMENT ON COLUMN t_metadata_theme.remark  IS '备注';
COMMENT ON COLUMN t_metadata_theme.state  IS '状态';
COMMENT ON COLUMN t_metadata_theme.audit_time  IS '审核时间';
COMMENT ON COLUMN t_metadata_theme.status  IS '记录状态 1:可用,2:不可用';


drop table if EXISTS t_metadata_theme_item;
create table t_metadata_theme_item
(
  id   numeric not null,
  theme_id numeric,
  name   varchar(30),
  remark varchar(100),
  state int4 DEFAULT 0,
  audit_time  timestamp DEFAULT CURRENT_TIMESTAMP ,
  status int2 DEFAULT 1,
  create_user numeric,
  create_time timestamp DEFAULT CURRENT_TIMESTAMP ,
  update_user numeric,
  update_time timestamp DEFAULT CURRENT_TIMESTAMP ,
  CONSTRAINT t_metadata_theme_item_pkey PRIMARY KEY (id)
)WITH (OIDS=FALSE);

COMMENT ON TABLE t_metadata_theme_item IS '元数据主题条目表';
COMMENT ON COLUMN t_metadata_theme_item.theme_id    IS '对应业务主题id';
COMMENT ON COLUMN t_metadata_theme_item.name    IS '条目名';
COMMENT ON COLUMN t_metadata_theme_item.audit_state  IS '审核状态';
COMMENT ON COLUMN t_metadata_theme_item.audit_time  IS '审核时间';
COMMENT ON COLUMN t_metadata_theme_item.remark  IS '备注';
COMMENT ON COLUMN t_metadata_theme_item.state  IS '状态';
COMMENT ON COLUMN t_metadata_theme_item.status  IS '记录状态';


drop table if EXISTS t_metadata_item;
create table t_metadata_item
(
  id   numeric not null,
  theme_item_id numeric,
  name  varchar(30),
  type  int4,
  purpose varchar(500),
  remark varchar(500),
  state int4 DEFAULT 0,
  audit_time  timestamp DEFAULT CURRENT_TIMESTAMP ,
  status int2 DEFAULT 1,
  create_user numeric,
  create_time timestamp DEFAULT CURRENT_TIMESTAMP ,
  update_user numeric,
  update_time timestamp DEFAULT CURRENT_TIMESTAMP ,
  CONSTRAINT t_metadata_item_pkey PRIMARY KEY (id)
)WITH (OIDS=FALSE);

COMMENT ON TABLE t_metadata_item IS '元数据条目表';
COMMENT ON COLUMN t_metadata_item.theme_item_id    IS '元数据主题条目id';
COMMENT ON COLUMN t_metadata_item.name    IS '元数据条目名';
COMMENT ON COLUMN t_metadata_item.type    IS '条目类型，例如：数据结构，数据字典等';
COMMENT ON COLUMN t_metadata_item.purpose    IS '用途';
COMMENT ON COLUMN t_metadata_item.audit_state  IS '审核状态';
COMMENT ON COLUMN t_metadata_item.audit_time  IS '审核时间';
COMMENT ON COLUMN t_metadata_item.remark  IS '备注';
COMMENT ON COLUMN t_metadata_item.state  IS '状态';
COMMENT ON COLUMN t_metadata_item.status  IS '记录状态';


drop table if EXISTS t_metadata_detail;
create table t_metadata_detail
(
  id   numeric not null,
  metadata_item_id numeric,
  col_displayname  varchar(20),
  col_type  int4,
  col_comment  varchar(50),
  col_name varchar(30),
  state int4 DEFAULT 0,
  audit_time  timestamp DEFAULT CURRENT_TIMESTAMP,
  status int2 DEFAULT 1,
  create_user numeric,
  create_time timestamp DEFAULT CURRENT_TIMESTAMP ,
  update_user numeric,
  update_time timestamp DEFAULT CURRENT_TIMESTAMP ,
  CONSTRAINT t_metadata_detail_pkey PRIMARY KEY (id)
)WITH (OIDS=FALSE);

COMMENT ON TABLE t_metadata_detail IS '元数据详情表';
COMMENT ON COLUMN t_metadata_detail.metadata_item_id    IS '元数据条目id';
COMMENT ON COLUMN t_metadata_detail.field_name    IS '字段名';
COMMENT ON COLUMN t_metadata_detail.field_type    IS '字段类型，例如：文本，数值';
COMMENT ON COLUMN t_metadata_detail.field_means    IS '字段含义';
COMMENT ON COLUMN t_metadata_detail.base_field  IS '原始字段';
COMMENT ON COLUMN t_metadata_detail.audit_state  IS '审核状态';
COMMENT ON COLUMN t_metadata_detail.audit_time  IS '审核时间';
COMMENT ON COLUMN t_metadata_detail.remark  IS '备注';
COMMENT ON COLUMN t_metadata_detail.state  IS '状态';
COMMENT ON COLUMN t_metadata_detail.status  IS '记录状态';