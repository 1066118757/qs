INSERT INTO c_base_config(id,key,value) VALUES(1,'hdfs.ip','192.168.55.10');
INSERT INTO c_base_config(id,key,value) VALUES(2,'hdfs.port','8020');

INSERT INTO c_base_config(id,key,value) VALUES(3,'notebook.host','192.168.55.12');
INSERT INTO c_base_config(id,key,value) VALUES(4,'notebook.port','8888');

INSERT INTO c_base_config(id,key,value) VALUES(5,'dist.ip','192.168.55.11');
INSERT INTO c_base_config(id,key,value) VALUES(6,'dist.port','10000');
INSERT INTO c_base_config(id,key,value) VALUES(7,'dist.username','');
INSERT INTO c_base_config(id,key,value) VALUES(8,'dist.password','');

INSERT INTO c_base_config(id,key,value) VALUES(9,'kafka.server','192.168.55.12:8092');

INSERT INTO c_base_config(id,key,value) VALUES(10,'idmanager-server.baseUrl','http://192.168.55.10:9000');