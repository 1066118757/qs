COMMENT ON TABLE t_metadata_detail IS '元数据详情表';
COMMENT ON COLUMN t_metadata_detail.metadata_item_id    IS '元数据条目id';
COMMENT ON COLUMN t_metadata_detail.index    IS '元数据条目序列号';
COMMENT ON COLUMN t_metadata_detail.col_displayname    IS '字段真实名，对应原型：字段名';
COMMENT ON COLUMN t_metadata_detail.col_type    IS '列类型，例如：文本，数值,参考码表类型3';
COMMENT ON COLUMN t_metadata_detail.col_comment    IS '列内容，对应原型：字段含义';
COMMENT ON COLUMN t_metadata_detail.col_name  IS '数据库对应列名，对应原型：原始字段';
COMMENT ON COLUMN t_metadata_theme.state  IS '审核状态,参考码表类型1';
COMMENT ON COLUMN t_metadata_theme.audit_time  IS '审核时间';
COMMENT ON COLUMN t_metadata_theme.status  IS '记录状态 1:可用,2:不可用';

INSERT INTO "c_dict_mapping" VALUES ('101', '1', '1', 'PC', '1', current_timestamp, '0');
INSERT INTO "c_dict_mapping" VALUES ('7002', '70', '2', 'App', '1', current_timestamp, '0');