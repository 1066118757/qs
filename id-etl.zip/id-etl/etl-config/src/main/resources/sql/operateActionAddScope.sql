DROP TABLE IF EXISTS "t_operate_action";
CREATE TABLE "t_operate_action" (
  "id" int4 NOT NULL,
  "action_desc" VARCHAR (100),
  "scope" int4,
  CONSTRAINT "t_operate_action_pkey" PRIMARY KEY ("id")
)WITH (OIDS=FALSE);
COMMENT ON TABLE "t_operate_action" IS '操作描述表';
COMMENT ON COLUMN "t_operate_action"."id" IS 'id';
COMMENT ON COLUMN "t_operate_action"."action_desc" IS '操作描述';
COMMENT ON COLUMN "t_operate_action"."scope" IS '操作域';