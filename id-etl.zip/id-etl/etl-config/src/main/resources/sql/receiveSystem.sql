DROP TABLE IF EXISTS t_data_source;
CREATE TABLE t_data_source (
id numeric NOT NULL PRIMARY KEY,
name varchar(50) COLLATE "default",
type int4,
remark varchar(300) COLLATE "default",
state int4,
latest_connect_log text COLLATE "default",
status int2 default 1,
create_time timestamp(6) default CURRENT_TIMESTAMP,
create_user numeric COLLATE "default",
update_time timestamp(6) default CURRENT_TIMESTAMP,
update_user numeric COLLATE "default"
)WITH (OIDS=FALSE);

comment on table t_data_source is '数据源';
comment on column t_data_source.name is '名称';
comment on column t_data_source.type is '类型';
comment on column t_data_source.remark is '描述';
comment on column t_data_source.latest_connect_log is '最近连接日志';

DROP TABLE IF EXISTS t_job;
CREATE TABLE t_job (
id numeric NOT NULL PRIMARY KEY,
name varchar(100) COLLATE "default",
dist_table varchar(50) COLLATE "default",
logic_partition_id numeric,
import_mode int4,
sync_strategy int4,
priority int4,
state int4,
latest_schedule_state int4,
latest_success_rows int8,
latest_schedule_time timestamp(6),
latest_schedule_log text COLLATE "default",
data_source_id numeric,
status int2 default 1,
create_time timestamp(6) default CURRENT_TIMESTAMP,
create_user numeric COLLATE "default",
update_time timestamp(6) default CURRENT_TIMESTAMP,
update_user numeric COLLATE "default"
)WITH (OIDS=FALSE);

COMMENT ON COLUMN t_job.name IS '名称';
COMMENT ON COLUMN t_job.dist_table IS '目标表';
COMMENT ON COLUMN t_job.logic_partition_id IS '逻辑分区id';
COMMENT ON COLUMN t_job.import_mode IS '1:全覆盖,2:按列覆盖,3:按列合并更新';
COMMENT ON COLUMN t_job.sync_strategy IS '1:定时,2:频率';
COMMENT ON COLUMN t_job.priority IS '优先级';
COMMENT ON COLUMN t_job.state IS '状态';
COMMENT ON COLUMN t_job.latest_schedule_state IS '最近一次执行状态';
COMMENT ON COLUMN t_job.latest_success_rows IS '最近一执行成功行数';
COMMENT ON COLUMN t_job.latest_schedule_time IS '最近一执行成功时间';
COMMENT ON COLUMN t_job.latest_schedule_log IS '最近一执行日志';
COMMENT ON COLUMN t_job.data_source_id IS '数据源id';

DROP TABLE IF EXISTS t_job_conf;
CREATE TABLE t_job_conf (
id numeric NOT NULL PRIMARY KEY,
key varchar(30) COLLATE "default",
value varchar(500) COLLATE "default",
ref_id numeric,
type int4,
status int2 default 1,
create_time timestamp(6) default CURRENT_TIMESTAMP,
create_user numeric COLLATE "default",
update_time timestamp(6) default CURRENT_TIMESTAMP,
update_user numeric COLLATE "default"
)WITH (OIDS=FALSE);

COMMENT ON TABLE t_job_conf IS 'etl数据源或任务的相关配置';
COMMENT ON COLUMN t_job_conf.type IS '1:数据源配置,2:任务配置';

DROP TABLE IF EXISTS t_schedule_log;
CREATE TABLE t_schedule_log (
id numeric NOT NULL PRIMARY KEY,
schedule_time timestamp(6),
schedule_state int4,
success_rows int8,
schedule_log text COLLATE "default",
job_id numeric
)WITH (OIDS=FALSE);

COMMENT ON TABLE t_schedule_log IS '任务日志';
COMMENT ON COLUMN t_schedule_log.schedule_time IS '执行时间';
COMMENT ON COLUMN t_schedule_log.schedule_state IS '状态';
COMMENT ON COLUMN t_schedule_log.success_rows IS '成功行数';
COMMENT ON COLUMN t_schedule_log.schedule_log IS '日志';
