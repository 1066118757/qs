package com.cdid.service.datasource;

import com.cdid.api.common.IDGeneratorService;
import com.cdid.api.datasource.DataSourceService;
import com.cdid.api.datasource.JDBCService;
import com.cdid.api.datasource.WebServiceService;
import com.cdid.api.datasource.vo.*;
import com.cdid.api.jobconf.JobConfService;
import com.cdid.api.jobconf.vo.JobConfAddVo;
import com.cdid.api.jobconf.vo.JobConfDetailVo;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.constant.RecordStatus;
import com.cdid.common.dict.ConfType;
import com.cdid.common.dict.DataSourceType;
import com.cdid.common.vo.*;
import com.cdid.dao.datasource.DataSourceDao;
import com.cdid.dao.jobconf.JobConfDao;
import com.cdid.dao.metadata.item.ItemDao;
import com.cdid.dao.user.UsersDao;
import com.cdid.jooq.tables.records.TDataSourceRecord;
import com.cdid.jooq.tables.records.TJobConfRecord;
import com.cdid.jooq.tables.records.TMetadataItemRecord;
import com.cdid.utils.DbTypeUtil;
import com.cdid.utils.VoReTraversalUtil;
import com.cdid.utils.jdbc.ConfKey;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.net.util.Base64;
import org.jooq.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.*;

import static com.cdid.jooq.tables.TDataSource.T_DATA_SOURCE;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/02 15:20 
 */
@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class DataSourceServiceImpl implements DataSourceService{

    @Value("${dist.ip}")
    private String distIp;
    @Value("${dist.port}")
    private String distPort;
    @Value("${dist.database}")
    private String distDatabase;
    @Value("${dist.username}")
    private String distUserName;
    @Value("${dist.password}")
    private String distPassword;
    @Value("${dist.dbtype}")
    private String distdbtype;
    @Value("${dist.schema}")
    private String distSchema;

    @Autowired
    IDGeneratorService<Long> idGeneratorService;

    @Autowired
    DataSourceDao dataSourceDao;
    @Autowired
    JobConfService jobConfService;
    @Autowired
    JobConfDao jobConfDao;
    @Autowired
    JDBCService jdbcService;
    @Autowired
    WebServiceService webServiceService;
    @Autowired
    UsersDao usersDao;
    @Autowired
    ItemDao itemDao;

    private static Logger logger = LoggerFactory.getLogger(DataSourceServiceImpl.class);

    @Override
    public ResultVo<BigDecimal> add(DataSourceAddVo dataSourceAddVo,String userId) throws Exception {

        List<JobConfAddVo> confs = dataSourceAddVo.getConfs();
        //datasourceId
        BigDecimal dataSourceId = BigDecimal.valueOf(idGeneratorService.id());
        //添加数据源配置
        addConf(confs,dataSourceId,userId);
        TDataSourceRecord dataSourceRecord = VoReTraversalUtil.traversal(dataSourceAddVo, TDataSourceRecord.class);
        dataSourceRecord.setId(dataSourceId);
        dataSourceRecord.setCreateUser(userId);
        dataSourceRecord.setUpdateUser(userId);
        dataSourceDao.insert(dataSourceRecord);
        return new ResultVo<>(0, dataSourceId,"SUCCESS");
    }

    @Override
    public ResultVo<String> delete(BigDecimal id,String userId) throws Exception {
        dataSourceDao.updateStatus(id,userId, RecordStatus.Deleted.getStatus());
        jobConfService.deleteByRefId(id);
        return new ResultVo<>(0,null,"SUCCESS");
    }

    @Override
    public ResultVo<String> update(DataSourceUpdateVo dataSourceUpdateVo,String userId) throws Exception {
        TDataSourceRecord dataSourceRecord = VoReTraversalUtil.traversal(dataSourceUpdateVo, TDataSourceRecord.class);
        dataSourceRecord.setUpdateUser(userId);
        dataSourceRecord.setUpdateTime(new Timestamp(System.currentTimeMillis()));
        dataSourceDao.update(dataSourceRecord);
        BigDecimal dataSourceId = dataSourceUpdateVo.getId();
        //删除配置
        jobConfService.deleteByRefId(dataSourceId);
        //添加数据源配置
        List<JobConfAddVo> confs = dataSourceUpdateVo.getConfs();
        addConf(confs,dataSourceId,userId);

        return new ResultVo<>(0,null,"SUCCESS");
    }

    @Override
    public ResultVo<String> updateInfo(DataSourceUpdateVo dataSourceUpdateVo, String userId) throws Exception {
        TDataSourceRecord dataSourceRecord = VoReTraversalUtil.traversal(dataSourceUpdateVo, TDataSourceRecord.class);
        dataSourceRecord.setUpdateUser(userId);
        dataSourceRecord.setUpdateTime(new Timestamp(System.currentTimeMillis()));
        dataSourceDao.update(dataSourceRecord);
        return new ResultVo<>(0,null,"SUCCESS");
    }

    /**
     * 添加数据源配置
     * @param confs
     * @param dataSourceId
     * @param userId
     * @throws Exception
     */
    private void addConf(List<JobConfAddVo> confs,BigDecimal dataSourceId,String userId) throws Exception{
        if(confs != null && confs.size() > 0){
            List<JobConfAddVo> confAddVos = new ArrayList<>();
            for(JobConfAddVo conf:confs){
                conf.setRefId(dataSourceId);
                conf.setType(ConfType.DATASOURCE.getValue());
                confAddVos.add(conf);
            }
            //批量添加配置
            jobConfService.batchAdd(confAddVos,userId);
        }
    }

    @Override
    public ResultVo<PageVo<DataSourceListVo>> list(DataSourceQueryVo dataSourceQueryVo,String userId,Integer page,Integer size) throws Exception {
        List<Condition> conditions = new ArrayList<>();
        List<SortField<?>> sortList = new ArrayList<>();
        sortList.add(T_DATA_SOURCE.UPDATE_TIME.desc());
        Integer type = dataSourceQueryVo.getType();
        if(type != null){
            conditions.add(T_DATA_SOURCE.TYPE.eq(type));
        }
        Integer state = dataSourceQueryVo.getState();
        if(state != null){
            conditions.add(T_DATA_SOURCE.STATE.eq(state));
        }
        String name = dataSourceQueryVo.getName();
        if(name != null){
            conditions.add(T_DATA_SOURCE.NAME.like("%" + name + "%"));
        }

        String createUserName = dataSourceQueryVo.getCreateUserName();
        if(!StringUtils.isEmpty(createUserName)){
            String[] idsByName = usersDao.getIdsByName(createUserName);
            //根据用户名称模糊查询用户id集合
            conditions.add(T_DATA_SOURCE.CREATE_USER.in(idsByName));
        }
        if(!StringUtils.isEmpty(userId)){
            conditions.add(T_DATA_SOURCE.CREATE_USER.eq(userId));
        }
        conditions.add(T_DATA_SOURCE.STATUS.eq(RecordStatus.Effective.getStatus()));
        conditions.add(T_DATA_SOURCE.TYPE.notIn(DataSourceType.EXCEL.getValue(),DataSourceType.TXT.getValue(),DataSourceType.CSV.getValue(),DataSourceType.XML.getValue()));
        PageVo<TDataSourceRecord> query = dataSourceDao.fetchByPage(conditions, new OffsetPagingVo(page, size), sortList);
        List<TDataSourceRecord> records = query.getPageData();
        List<DataSourceListVo> list = new ArrayList<>();
        DataSourceListVo  vo = null;
        List<String> createUserIds = new ArrayList();
        for (TDataSourceRecord record : records) {
            createUserIds.add(record.getCreateUser());
        }
        Map<String, Result<Record2<String,String>>> createUserMapper = usersDao.getNameByUserIds(createUserIds.toArray(new String[createUserIds.size()]));

        for (TDataSourceRecord record : records) {
            vo = VoReTraversalUtil.traversal(record, DataSourceListVo.class);
            Result<Record2<String,String>> record2s = createUserMapper.get(record.getCreateUser());
            if(record2s != null && record2s.size() > 0){
                vo.setCreateUserName(record2s.get(0).value1());
            }else {
                vo.setCreateUserName("");
            }
            list.add(vo);
        }
        PageVo<DataSourceListVo> result = new PageVo<>();
        result.setPageData(list);
        result.setTotalCount(query.getTotalCount());
        return new ResultVo(0, result,"SUCCESS");
    }

    @Override
    public ResultVo<DataSourceDetailVo> findById(BigDecimal id) throws Exception {
        TDataSourceRecord dataSourceRecord = dataSourceDao.findById(id);
        DataSourceDetailVo detailVo = VoReTraversalUtil.traversal(dataSourceRecord, DataSourceDetailVo.class);
        //查配置
        List<JobConfDetailVo> confDetailVos = jobConfService.findByRefId(id, ConfType.DATASOURCE.getValue());
        detailVo.setConfs(confDetailVos);
        String userName = usersDao.getNameByUserId(detailVo.getCreateUser());
        detailVo.setCreateUserName(userName);
        return new ResultVo<>(0,detailVo,"SUCCESS");
    }

    @Override
    public ResultVo<ResponseVo>connectionTest(JDBCVo jdbcVo, String userId){
        ResultVo<ResponseVo> resultVo = new ResultVo<>();
        BigDecimal id = jdbcVo.getDataSourceId();
        Integer type = jdbcVo.getType();
        String password = jdbcVo.getPassword();
        if(!StringUtils.isEmpty(password)){
            String pwdDecode = new String(Base64.decodeBase64(password));
            jdbcVo.setPassword(pwdDecode);
        }
        if(id == null){
            //webservice
            if(DataSourceType.WEBSERVICE.getValue() == type){
                WebServiceVo webServiceVo = new WebServiceVo();
                webServiceVo.setBody(jdbcVo.getBody());
                webServiceVo.setHeaders(jdbcVo.getHeaders());
                webServiceVo.setRequestMethod(jdbcVo.getRequestMethod());
                webServiceVo.setRequestUrl(jdbcVo.getRequestUrl());
                resultVo = webServiceService.connectTest(webServiceVo);
            }else {
                ResultVo<Boolean> result = jdbcService.connectTest(jdbcVo);
                resultVo.setErrorCode(result.getErrorCode());
                resultVo.setMsg(result.getMsg());
            }
        }else {
            try {
                jdbcVo = new JDBCVo();

                //webservice
                if(DataSourceType.WEBSERVICE.getValue() == type){

                    String requestMethod = null;
                    String requestUrl = null;
                    String headers = null;
                    String body = null;
                    Result<TJobConfRecord> byRefId = jobConfDao.findByRefId(id);
                    for(TJobConfRecord  record : byRefId){
                        String key = record.getKey();
                        switch (key){
                            case ConfKey.REQUEST_METHOD:
                                requestMethod = record.getValue();
                                break;
                            case ConfKey.REQUEST_URL:
                                requestUrl = record.getValue();
                                break;
                            case ConfKey.HEADERS:
                                headers = record.getValue();
                                break;
                            case ConfKey.BODY:
                                body = record.getValue();
                                break;
                            default:
                                break;
                        }
                    }

                    WebServiceVo webServiceVo = new WebServiceVo();
                    webServiceVo.setBody(body);
                    webServiceVo.setHeaders(headers);
                    webServiceVo.setRequestMethod(requestMethod);
                    webServiceVo.setRequestUrl(requestUrl);
                    resultVo = webServiceService.connectTest(webServiceVo);
                }else {
                    jdbcVo.setType(type);

                    ResultVo<DataSourceDetailVo> dataSourceDetailVoResultVo = findById(id);
                    DataSourceDetailVo data = dataSourceDetailVoResultVo.getData();
                    type = data.getType();
                    Map<String,String> confMap = new HashMap<>();
                    List<JobConfDetailVo> confs = data.getConfs();
                    for(JobConfDetailVo conf:confs){
                        confMap.put(conf.getKey(),conf.getValue());
                    }

                    jdbcVo.setUrl(confMap.get(ConfKey.SERVER_IP));
                    jdbcVo.setPort(confMap.get(ConfKey.PORT));
                    jdbcVo.setUserName(confMap.get(ConfKey.USER_NAME));
//                    jdbcVo.setPassword(confMap.get(ConfKey.USER_PWD));
                    jdbcVo.setDatabaseName(confMap.get(ConfKey.DATABASE_NAME));
                    password = confMap.get(ConfKey.USER_PWD);
                    if(!StringUtils.isEmpty(password)){
                        String pwdDecode = new String(Base64.decodeBase64(password));
                        jdbcVo.setPassword(pwdDecode);
                    }
                    ResultVo<Boolean> result = jdbcService.connectTest(jdbcVo);
                    resultVo.setErrorCode(result.getErrorCode());
                    resultVo.setMsg(result.getMsg());
                }

                //更新连接信息
                DataSourceUpdateVo updateVo = new DataSourceUpdateVo();
                updateVo.setId(id);
                updateVo.setLatestConnectLog(resultVo.getErrorCode() == 0 ? "连接成功" : "连接失败");
                try {
                    updateInfo(updateVo,userId);
                }catch (Exception e){
                    e.printStackTrace();
                }

            }catch (Exception e){
                e.printStackTrace();
                resultVo = new ResultVo<>(ErrorCode.UnknownError.getErrorCode(),null,e.getMessage());
            }
        }

        return resultVo;
    }

    @Override
    public ResultVo<List<TablesVo>> queryTableName(JDBCVo jdbcVo) {
        BigDecimal id = jdbcVo.getDataSourceId();
        if(id == null){
            return jdbcService.queryTableName(jdbcVo);
        }
        try {
            jdbcVo = new JDBCVo();
            ResultVo<DataSourceDetailVo> dataSourceDetailVoResultVo = findById(id);
            DataSourceDetailVo data = dataSourceDetailVoResultVo.getData();
            Integer type = data.getType();
            Map<String,String> confMap = new HashMap<>();
            List<JobConfDetailVo> confs = data.getConfs();
            for(JobConfDetailVo conf:confs){
                confMap.put(conf.getKey(),conf.getValue());
            }
            jdbcVo.setType(type);
            jdbcVo.setDatabaseName(confMap.get(ConfKey.DATABASE_NAME));
            String password = confMap.get(ConfKey.USER_PWD);
            if(!StringUtils.isEmpty(password)){
                String pwdDecode = new String(Base64.decodeBase64(password));
                jdbcVo.setPassword(pwdDecode);
            }
            jdbcVo.setUserName(confMap.get(ConfKey.USER_NAME));
            jdbcVo.setPort(confMap.get(ConfKey.PORT));
            jdbcVo.setUrl(confMap.get(ConfKey.SERVER_IP));
        }catch (Exception e){
            e.printStackTrace();
        }
        return jdbcService.queryTableName(jdbcVo);
    }

    @Override
    public ResultVo<List<TableAndFieldVo>> queryTableFilelds(JDBCVo jdbcVo) {
        BigDecimal id = jdbcVo.getDataSourceId();
        String tableName = jdbcVo.getTableName();
        if (tableName==null){
            return new ResultVo<>(ErrorCode.ParamError.getErrorCode());
        }
        if(id == null){
            return jdbcService.queryTableFilelds(jdbcVo);
        }
        try {
            jdbcVo = new JDBCVo();
            jdbcVo.setTableName(tableName);
            ResultVo<DataSourceDetailVo> dataSourceDetailVoResultVo = findById(id);
            DataSourceDetailVo data = dataSourceDetailVoResultVo.getData();
            Integer type = data.getType();
            Map<String,String> confMap = new HashMap<>();
            List<JobConfDetailVo> confs = data.getConfs();
            for(JobConfDetailVo conf:confs){
                confMap.put(conf.getKey(),conf.getValue());
            }
            jdbcVo.setType(type);
            jdbcVo.setDatabaseName(confMap.get(ConfKey.DATABASE_NAME));
//            jdbcVo.setPassword(confMap.get(ConfKey.USER_PWD));
            String password = confMap.get(ConfKey.USER_PWD);
            if(!StringUtils.isEmpty(password)){
                String pwdDecode = new String(Base64.decodeBase64(password));
                jdbcVo.setPassword(pwdDecode);
            }
            jdbcVo.setUserName(confMap.get(ConfKey.USER_NAME));
            jdbcVo.setPort(confMap.get(ConfKey.PORT));
            jdbcVo.setUrl(confMap.get(ConfKey.SERVER_IP));
        }catch (Exception e){
            e.printStackTrace();
        }
        return jdbcService.queryTableFilelds(jdbcVo);
    }

    @Override
    public ResultVo<List<TablesVo>> queryDistTableName() {
        JDBCVo jdbcVo = new JDBCVo();
        jdbcVo.setType(DbTypeUtil.getTypeByDb(distdbtype));
        jdbcVo.setDatabaseName(distDatabase);
        jdbcVo.setPassword(distPassword);
        jdbcVo.setUserName(distUserName);
        jdbcVo.setPort(distPort);
        jdbcVo.setUrl(distIp);
        return jdbcService.queryTableName(jdbcVo);
    }

    @Override
    public ResultVo<List<TablesVo>> queryDistTableName(String userId) {
        List<TablesVo> tablesVos = new ArrayList<>();
        Result<TMetadataItemRecord> itemRecords = itemDao.fetchAll(userId);
        TablesVo tablesVo = null;
        for(TMetadataItemRecord itemRecord : itemRecords){
            tablesVo = new TablesVo();
            tablesVo.setTableName(itemRecord.getName());
            tablesVos.add(tablesVo);
        }
        return new ResultVo<>(0,tablesVos);
    }

    @Override
    public ResultVo<List<TableAndFieldVo>> queryDistTableFilelds(String tableName) {
        JDBCVo jdbcVo = new JDBCVo();
        jdbcVo.setType(DbTypeUtil.getTypeByDb(distdbtype));
        jdbcVo.setDatabaseName(distDatabase);
        jdbcVo.setPassword(distPassword);
        jdbcVo.setUserName(distUserName);
        jdbcVo.setPort(distPort);
        jdbcVo.setUrl(distIp);
        jdbcVo.setTableName(tableName);
        return jdbcService.queryTableFilelds(jdbcVo);
    }
}
