package com.cdid.service.cas;


import com.cdid.utils.xml.util.XmlParserUtil;
import com.opencsv.CSVWriter;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.dom4j.Element;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.*;

public class LiteratureFileParser {

    public static final void parseWOS(InputStream is, String charSet, CSVWriter csvWriter, String format) throws IOException {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader(is, charSet));
            String line;
            StringBuilder columnContent = null;
            String column = "";
            Map<String, String> lineMap = new HashMap<>();
            String fileName = "";
            String version = "";
            while ((line = br.readLine()) != null) {
                if (line.isEmpty()) {
                    continue;
                }
                if (line.startsWith("EF")) {
                    break;
                }
                if (line.startsWith("ER")) {
                    if (lineMap != null && !lineMap.isEmpty()) {
                        if (!column.isEmpty() && columnContent != null) {
                            lineMap.put(column, columnContent.toString());
                        }
                        csvWriter.writeNext(mapToOrderedArray(lineMap, format));
                    }
                    lineMap = null;
                    continue;
                }
                if (line.startsWith("PT ")) {
                    if (lineMap == null) {
                        lineMap = new HashMap<>();
                    }
                    if (!fileName.isEmpty()) {
                        lineMap.put("FN", fileName);
                    }
                    if (!version.isEmpty()) {
                        lineMap.put("VR", version);
                    }
                }
                if (line.startsWith("   ")) {
                    columnContent.append(line);
                } else {
                    if (columnContent != null) {
                        if (!("ER".equals(column))) {
                            lineMap.put(column, columnContent.toString());
                            if ("FN".equals(column)) {
                                fileName = columnContent.toString();
                            }
                            if ("VR".equals(column)) {
                                version = columnContent.toString();
                            }

                        }
                    }
                    columnContent = new StringBuilder("");
                    if (line.length() >= 3) {
                        if (line.length() >= 4 && "FN ".equals(line.substring(1, 4))) {
                            columnContent.append(line.substring(4, line.length()));
                            column = line.substring(1, 3);
                        } else {
                            columnContent.append(line.substring(3, line.length()));
                            column = line.substring(0, 2);
                        }
                    } else {
                        column = line.substring(0, 2);
                    }
                }

            }
        } finally {
            close(br);
        }
    }


    private static String[] mapToOrderedArray(Map<String, String> columnMap, String fileType) {
        if (columnMap == null) {
            return null;
        }
        columnMap.put("DB", fileType);
        int columnsLength=71;
        String[] lineData = new String[columnsLength];
        Map<Integer, String[]> indexKeymap = new HashMap<>();
        switch (fileType) {
            case "ISI":
                indexKeymap = configISIIndexKeyMap();
                break;
            case "CNKI":
                indexKeymap = configCNKIIndexKeyMap();
                break;
            case "SCI":
                indexKeymap = configCSSCIIndexKeyMap();
                break;
            case "EI":
                indexKeymap = configEIIndexKeyMap();
                break;
            case "CSCD":
                indexKeymap = configCSCDIndexMap();
                break;
            case "PUBM":
                indexKeymap = configPUBMIndexMap();
            case "SCOPUS":
                break;
            case "DW":
                indexKeymap = configDWIndexKeyMap();
                break;
            default:
                break;
        }
        StringBuilder value;
        String data;
        for (int i = 0; i < columnsLength-1; i++) {
            String[] indexKey = indexKeymap.get(Integer.valueOf(i));
            if (indexKey == null || indexKey.length == 0) {
                lineData[i] = "";
            } else {
                value = new StringBuilder();
                for (String key : indexKey) {
                    data = columnMap.get(key);
                    if (data != null) {
                        value.append(data).append(" ");
                    }
                }
                if (value.length() > 0) {
                    lineData[i] = value.substring(0, value.length() - 1);
                } else {
                    lineData[i] = "";
                }
            }
        }
        lineData[columnsLength-1]= DateFormatUtils.format(new Date(),"yyyy-MM-dd HH:mm:ss");
        return lineData;
    }

    private static Map<Integer, String[]> configISIIndexKeyMap() {
        Map<Integer, String[]> indexKeyMap = new HashMap<>();
        indexKeyMap.put(0, new String[]{"DB"});
        indexKeyMap.put(1, new String[]{"FN"});
        indexKeyMap.put(2, new String[]{"VR"});
        indexKeyMap.put(3, new String[]{"PT"});
        indexKeyMap.put(4, new String[]{"AU"});
        indexKeyMap.put(5, new String[]{"AF"});
        indexKeyMap.put(6, new String[]{"BA"});
        indexKeyMap.put(7, new String[]{"CA"});
        indexKeyMap.put(8, new String[]{"GP"});
        indexKeyMap.put(9, new String[]{"BE"});
        indexKeyMap.put(10, new String[]{"TI"});
        indexKeyMap.put(11, new String[]{"SO"});
        indexKeyMap.put(12, new String[]{"SE"});
        indexKeyMap.put(13, new String[]{"BS"});
        indexKeyMap.put(14, new String[]{"LA"});
        indexKeyMap.put(15, new String[]{"DT"});
        indexKeyMap.put(16, new String[]{"CT"});
        indexKeyMap.put(17, new String[]{"CY"});
        indexKeyMap.put(18, new String[]{"CL"});
        indexKeyMap.put(19, new String[]{"SP"});
        indexKeyMap.put(20, new String[]{"HO"});
        indexKeyMap.put(21, new String[]{"DE"});
        indexKeyMap.put(22, new String[]{"ID"});
        indexKeyMap.put(23, new String[]{"AB"});
        indexKeyMap.put(24, new String[]{"C1"});
        indexKeyMap.put(25, new String[]{"RP"});
        indexKeyMap.put(26, new String[]{"EM"});
        indexKeyMap.put(27, new String[]{"FU"});
        indexKeyMap.put(28, new String[]{"FX"});
        indexKeyMap.put(29, new String[]{"CR"});
        indexKeyMap.put(30, new String[]{"NR"});
        indexKeyMap.put(31, new String[]{"TC"});
        indexKeyMap.put(32, new String[]{"Z9"});
        indexKeyMap.put(33, new String[]{"PU"});
        indexKeyMap.put(34, new String[]{"PI"});
        indexKeyMap.put(35, new String[]{"PA"});
        indexKeyMap.put(36, new String[]{"SN"});
        indexKeyMap.put(37, new String[]{"BN"});
        indexKeyMap.put(38, new String[]{"J9"});
        indexKeyMap.put(39, new String[]{"JI"});
        indexKeyMap.put(40, new String[]{"PD"});
        indexKeyMap.put(41, new String[]{"PY"});
        indexKeyMap.put(42, new String[]{"VL"});
        indexKeyMap.put(43, new String[]{"IS"});
        indexKeyMap.put(44, new String[]{"SI"});
        indexKeyMap.put(45, new String[]{"PN"});
        indexKeyMap.put(46, new String[]{"SU"});
        indexKeyMap.put(47, new String[]{"BP"});
        indexKeyMap.put(48, new String[]{"EP"});
        indexKeyMap.put(49, new String[]{"AR"});
        indexKeyMap.put(50, new String[]{"DI"});
        indexKeyMap.put(51, new String[]{"D2"});
        indexKeyMap.put(52, new String[]{"PG"});
        indexKeyMap.put(53, new String[]{"P2"});
        indexKeyMap.put(54, new String[]{"WC"});
        indexKeyMap.put(55, new String[]{"SC"});
        indexKeyMap.put(56, new String[]{"GA"});
        indexKeyMap.put(57, new String[]{"UT"});
        indexKeyMap.put(58, new String[]{"ER"});
        indexKeyMap.put(59, new String[]{"EF"});
        indexKeyMap.put(60, new String[]{"D_AE"});
        indexKeyMap.put(61, new String[]{"D_GA"});
        indexKeyMap.put(62, new String[]{"D_DC"});
        indexKeyMap.put(63, new String[]{"D_MC"});
        indexKeyMap.put(64, new String[]{"D_IP"});
        indexKeyMap.put(65, new String[]{"D_PD"});
        indexKeyMap.put(66, new String[]{"D_AD"});
        indexKeyMap.put(67, new String[]{"D_PI"});
        indexKeyMap.put(68, new String[]{"D_DS"});
        indexKeyMap.put(69, new String[]{"D_PN"});
        return indexKeyMap;
    }

    private static Map<Integer, String[]> configDWIndexKeyMap() {
        Map<Integer, String[]> indexKeyMap = new HashMap<>();
        indexKeyMap.put(0, new String[]{"DB"});
        indexKeyMap.put(1, new String[]{"FN"});
        indexKeyMap.put(2, new String[]{"VR"});
        indexKeyMap.put(3, new String[]{"PT"});
        indexKeyMap.put(4, new String[]{"AU"});
        indexKeyMap.put(10, new String[]{"TI"});
        indexKeyMap.put(23, new String[]{"AB"});
        indexKeyMap.put(60, new String[]{"AE"});
        indexKeyMap.put(61, new String[]{"GA"});
        indexKeyMap.put(62, new String[]{"DC"});
        indexKeyMap.put(63, new String[]{"MC"});
        indexKeyMap.put(64, new String[]{"IP"});
        indexKeyMap.put(65, new String[]{"PD"});
        indexKeyMap.put(66, new String[]{"AD"});
        indexKeyMap.put(67, new String[]{"PI"});
        indexKeyMap.put(68, new String[]{"DS"});
        indexKeyMap.put(69, new String[]{"PN"});
        return indexKeyMap;
    }

    private static Map<Integer, String[]> configCNKIIndexKeyMap() {
        Map<Integer, String[]> indexKeyMap = new HashMap<>();
        indexKeyMap.put(0, new String[]{"DB"});
        indexKeyMap.put(3, new String[]{"DataType"});
        indexKeyMap.put(4, new String[]{"Author"});
        indexKeyMap.put(10, new String[]{"Title"});
        indexKeyMap.put(11, new String[]{"Source"});
        indexKeyMap.put(21, new String[]{"Keyword"});
        indexKeyMap.put(23, new String[]{"Summary"});
        indexKeyMap.put(24, new String[]{"Organ"});
        indexKeyMap.put(40, new String[]{"PubTime"});
        indexKeyMap.put(41, new String[]{"Year"});
        indexKeyMap.put(43, new String[]{"Period"});
        indexKeyMap.put(52, new String[]{"PageCount"});
        return indexKeyMap;
    }

    private static Map<Integer, String[]> configCSSCIIndexKeyMap() {
        Map<Integer, String[]> indexKeyMap = new HashMap<>();
        indexKeyMap.put(0, new String[]{"DB"});
        indexKeyMap.put(4, new String[]{"【来源作者】"});
        indexKeyMap.put(10, new String[]{"【来源篇名】", "【英文篇名】"});
        indexKeyMap.put(21, new String[]{"【关 键 词】"});
        indexKeyMap.put(24, new String[]{"【机构名称】"});
        indexKeyMap.put(28, new String[]{"【基    金】"});
        return indexKeyMap;
    }

    private static Map<Integer, String[]> configEIIndexKeyMap() {
        Map<Integer, String[]> indexKeyMap = new HashMap<>();
        indexKeyMap.put(0, new String[]{"DB"});
        indexKeyMap.put(3, new String[]{"Document type"});
        indexKeyMap.put(4, new String[]{"Authors"});
        indexKeyMap.put(10, new String[]{"Title"});
        indexKeyMap.put(11, new String[]{"Source title"});
        indexKeyMap.put(14, new String[]{"Language"});
        indexKeyMap.put(16, new String[]{"Conference name"});
        indexKeyMap.put(17, new String[]{"Conference date"});
        indexKeyMap.put(18, new String[]{"Conference location"});
        indexKeyMap.put(24, new String[]{"Author affiliation"});
        indexKeyMap.put(40, new String[]{"Issue date"});
        indexKeyMap.put(41, new String[]{"Publication year"});
        return indexKeyMap;
    }

    private static Map<Integer,String[]> configCSCDIndexMap(){
        Map<Integer, String[]> indexKeyMap = new HashMap<>();
        indexKeyMap.put(0, new String[]{"DB"});
        indexKeyMap.put(4, new String[]{"作者"});
        indexKeyMap.put(10, new String[]{"题名"});
        indexKeyMap.put(11, new String[]{"来源"});
        indexKeyMap.put(23, new String[]{"文摘"});
        indexKeyMap.put(24, new String[]{"单位"});
        indexKeyMap.put(28, new String[]{"基金"});
        indexKeyMap.put(32, new String[]{"被引频次"});
        return indexKeyMap;
    }

    private static Map<Integer,String[]> configPUBMIndexMap(){
        Map<Integer, String[]> indexKeyMap = new HashMap<>();
        indexKeyMap.put(0, new String[]{"DB"});
        indexKeyMap.put(3, new String[]{"PT"});
        indexKeyMap.put(5, new String[]{"FAU"});
        indexKeyMap.put(10, new String[]{"TI"});
        indexKeyMap.put(11, new String[]{"JT"});
        indexKeyMap.put(14, new String[]{"LA"});
        indexKeyMap.put(21, new String[]{"OT"});
        indexKeyMap.put(23, new String[]{"AB"});
        indexKeyMap.put(24, new String[]{"AD"});
        indexKeyMap.put(39, new String[]{"TA"});
        indexKeyMap.put(40, new String[]{"PHST"});
        indexKeyMap.put(69,new String[]{"PL"});
        return indexKeyMap;
    }


    public static final void parseEI(InputStream is, String charSet, CSVWriter csvWriter) throws IOException {
        BufferedReader br = null;
        try {
            String line;
            br = new BufferedReader(new InputStreamReader(is, charSet));
            Map<String, String> columnMap = new HashMap<>();
            while ((line = br.readLine()) != null) {
                if (line.isEmpty()) {
                    continue;
                }
                if (line.startsWith("Compilation and indexing terms")) {
                    if (!columnMap.isEmpty()) {
                        csvWriter.writeNext(mapToOrderedArray(columnMap, "EI"));
                    }
                }
                if (line.startsWith("<RECORD ")) {
                    columnMap = new HashMap<>();
                }
                if (line.contains(":")) {
                    int index = line.indexOf(":");
                    columnMap.put(line.substring(0, index), line.substring(index + 1));
                }
            }
        } finally {
            close(br);
        }
    }

    public static final void parseCSCD(InputStream is, String charSet, CSVWriter csvWriter) throws IOException {
        BufferedReader br = null;
        try {
            String line;
            br = new BufferedReader(new InputStreamReader(is, charSet));
            Map<String, String> columnMap = new HashMap<>();
            while ((line = br.readLine()) != null) {
                if (line.isEmpty()) {
                    if(!columnMap.isEmpty()){
                        csvWriter.writeNext(mapToOrderedArray(columnMap, "CSCD"));
                    }
                    continue;
                }
                if (line.startsWith("题名：")) {
                    columnMap = new HashMap<>();
                }
                if (line.contains("：")) {
                    int index = line.indexOf("：");
                    columnMap.put(line.substring(0, index), line.substring(index + 1));
                }
            }
        } finally {
            close(br);
        }
    }

    private static void close(BufferedReader br) {
        if (br != null) {
            try {
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static final void parseSCI(InputStream is, String charSet, CSVWriter csvWriter) throws IOException {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader(is, charSet));
            String line;
            String column = null;
            StringBuilder content = null;
            Map<String, String> columnMap = new HashMap<>();
            while ((line = br.readLine()) != null) {
                if (line.isEmpty()) {
                    continue;
                }
                if (line.startsWith("-----")) {
                    if (columnMap != null && column != null && content != null) {
                        columnMap.put(column, content.toString());
                    }
                    if (columnMap != null && !columnMap.isEmpty()) {
                        csvWriter.writeNext(mapToOrderedArray(columnMap, "SCI"));
                    }
                    columnMap = null;
                }
                if (line.startsWith("【")) {
                    if (columnMap != null && column != null) {
                        columnMap.put(column, content.toString());
                    }
                    if (columnMap == null) {
                        columnMap = new HashMap<>();
                    }

                    content = new StringBuilder("");
                    int index = line.indexOf("】");
                    column = line.substring(0, index + 1);
                    content.append(line.substring(index + 1));
                } else {
                    if (content != null) {
                        content.append(line);
                    }
                }
            }
        } finally {
            close(br);
        }
    }

    public static final void parseCNKI(InputStream is, String charSet, CSVWriter csvWriter) throws IOException {
        File formattedFile = null;
        try {
            formattedFile = formatCNKI(is, charSet);
            Element rootNode = XmlParserUtil.getRootNode(new FileInputStream(formattedFile));
            Map<String, String> columnMap;
            Iterator<Element> it = rootNode.elementIterator("DATA");
            while (it.hasNext()) {
                columnMap = new HashMap<>();
                Element e = it.next();
                List<Element> list = e.elements();
                for (Element child : list) {
                    columnMap.put(child.getName(), child.getText().replace("\n", ""));
                }
                if (!columnMap.isEmpty()) {
                    csvWriter.writeNext(mapToOrderedArray(columnMap, "CNKI"));
                }
            }
        } finally {
            if (formattedFile != null && formattedFile.exists()) {
                formattedFile.delete();
            }
        }
    }

    public static final void parsePUBM(InputStream is, String charSet, CSVWriter csvWriter) throws IOException {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader(is, charSet));
            String line;
            StringBuilder columnContent = null;
            String column = "";
            Map<String, String> lineMap = new HashMap<>();
            int i=0;
            while ((line = br.readLine()) != null) {
                i++;
                if ((line.startsWith("PHST") && !line.endsWith("[pubmed]"))||(line.startsWith("PMC -"))) {
                    continue;
                }
                if(line.isEmpty()){
                    if(!lineMap.isEmpty()){
                        if (!column.isEmpty() && columnContent != null) {
                            lineMap.put(column, columnContent.toString());
                        }
                        csvWriter.writeNext(mapToOrderedArray(lineMap, "PUBM"));
                    }
                    lineMap=new HashMap<>();
                    continue;
                }
                int columnIndex=line.indexOf("-");
                if(columnIndex==4){
                    String newColumn=line.substring(0,columnIndex).trim();
                    if(newColumn.equals(column)){
                        if(columnContent!=null){
                            columnContent.append(";").append(line.substring(columnIndex+1).trim());
                        }
                    }else{
                        if(columnContent!=null && !column.isEmpty()){
                            lineMap.put(column,columnContent.toString().replace("[pubmed]","").trim());
                        }
                        columnContent=new StringBuilder(line.substring(columnIndex+1));
                        column=newColumn;
                    }
                }else{
                    if(columnContent!=null){
                        columnContent.append(" ").append(line.trim());
                    }
                }
            }
        } finally {
            close(br);
        }
    }

    public static File formatCNKI(InputStream is, String charset) throws IOException {
        String fileName = UUID.randomUUID().toString() + ".xml";
        File distFile = new File(getSystemTempDir(), fileName);
        BufferedReader br = new BufferedReader(new InputStreamReader(is, charset));
        BufferedWriter bw = Files.newBufferedWriter(distFile.toPath(), Charset.forName("UTF-8"));
        String line;
        while ((line = br.readLine()) != null) {
            if (line.startsWith("<!DOCTYPE html>")) break;
            if (!line.isEmpty()) {
                bw.write(line + "\n");
            }
        }
        br.close();
        bw.flush();
        bw.close();
        return distFile;
    }

    public static File createNewFile(File distFile) throws IOException {
        if (distFile.exists()) {
            distFile.delete();
        }
        distFile.createNewFile();
        return distFile;
    }

    public static File getSystemTempDir() {
        return new File(System.getProperty("java.io.tmpdir"));
    }


    public static void main(String[] args) throws IOException {
        InputStream is=new FileInputStream("C:\\Users\\Administrator\\Desktop\\1w_1.txt");
        File distCsvFile=new File("C:\\Users\\Administrator\\Desktop\\1w_1.csv");
        LiteratureFileParser.createNewFile(distCsvFile);
        BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(distCsvFile),"UTF-8"));
        CSVWriter csvWriter = new CSVWriter(bw, ',');
        parsePUBM(is,"UTF-8",csvWriter);
    }
}
