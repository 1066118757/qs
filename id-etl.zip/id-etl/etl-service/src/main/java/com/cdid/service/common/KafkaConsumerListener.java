package com.cdid.service.common;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cdid.api.common.IDGeneratorService;
import com.cdid.api.common.RedisService;
import com.cdid.api.dataclear.cleartask.ClearTaskService;
import com.cdid.api.dataclear.cleartask.vo.ClearTaskFinishedResponseVO;
import com.cdid.api.job.JobService;
import com.cdid.api.job.vo.JobFinishedResponseVO;
import com.cdid.common.constant.RedisKey;
import com.cdid.dao.analyzeMapInfo.AnalyzeMapInfoDao;
import com.cdid.dao.job.JobDao;
import com.cdid.dao.jobconf.JobConfDao;
import com.cdid.dao.metadata.detail.DetailDao;
import com.cdid.dao.metadata.item.AnalyzeColumnDao;
import com.cdid.dao.metadata.item.AnalyzeTableDao;
import com.cdid.dao.metadata.item.ItemDao;
import com.cdid.jooq.tables.*;
import com.cdid.jooq.tables.records.*;
import com.cdid.utils.jdbc.ConfKey;
import com.cdid.utils.jdbc.SpringUtil;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.jooq.Condition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class KafkaConsumerListener {

    private static final Logger logger = LoggerFactory.getLogger(KafkaConsumerListener.class);


    @KafkaListener(topics ={"ETLResult","dataCleanResult","addColumnsResult"} )
    public void listen(ConsumerRecord<String,String> record){
        logger.info("Kafka-enter:********");
        String topic=record.topic();
        String taskId=record.key();
        JSONObject response = JSON.parseObject(record.value());
        if(taskId==null){
           taskId=response.getString("taskId");
        }
        if(taskId==null){
            logger.error("task id not found,message content is:"+record.value());
            return;
        }
        logger.info("jobId:" + taskId + "  响应 ：" + JSON.toJSONString(record.value()));
        //释放资源
        logger.info("onTaskFinished ---" + RedisKey.JOB_RES + "  incr");
        RedisService redis = SpringUtil.getBean(RedisService.class);
        redis.incr(RedisKey.JOB_RES);

        ExecutorService executorService = Executors.newSingleThreadExecutor();

        switch (topic){
            case "ETLResult":
                executorService.execute(new Runnable() {
                    @Override
                    public void run() {
                        //写日志，发送消息
                        try {
                            JobService jobService=SpringUtil.getBean(JobService.class);
                            jobService.jobFinishedCallBack(JSON.parseObject(record.value(), JobFinishedResponseVO.class));
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                });
                //TODO saveLog,sendMessage
                break;
            case "dataCleanResult":
                //TODO saveLog,sendMessage
                executorService.execute(new Runnable() {
                    @Override
                    public void run() {
                        logger.info("dataCleanResult:run-enter");
                        //写日志，发送消息
                        ClearTaskService taskService=SpringUtil.getBean(ClearTaskService.class);
                        taskService.clearTaskFinished(JSON.parseObject(record.value(), ClearTaskFinishedResponseVO.class));
                    }
                });
                break;
            case "addColumnsResult":{
                executorService.execute(new Runnable() {
                    @Override
                    public void run() {
                        logger.info("addColumnsResult:run-enter");
                        //写日志，发送消息
                        addColumnsCallBack(response);
                    }
                });
            }
            break;
            default: break;
        }
        executorService.shutdown();
    }

    public void addColumnsCallBack(JSONObject response){
        String tableName=response.getString("tableName");
        Boolean updateMappings=response.getBoolean("updateMappings");
        JSONArray columnArr=response.getJSONArray("columns");
        List<String> columns=new ArrayList<>();
        for(int i=0;i<columnArr.size();i++){
            columns.add(columnArr.getString(i));
        }
        addItemDetails(tableName,columns);
        addAnalyzeColumns(tableName,columns);
        if(updateMappings!= null && updateMappings){
            updateColMapping(tableName,columns);
        }
    }

    private void addItemDetails(String tableName,List<String> columns){
        ItemDao itemDao=SpringUtil.getBean(ItemDao.class);
        DetailDao detailDao=SpringUtil.getBean(DetailDao.class);
        IDGeneratorService<Long> idGeneratorService=SpringUtil.getBean(IDGeneratorService.class);
        TMetadataItemRecord item=itemDao.findByName(tableName);
        if(item !=null){
            List<TMetadataDetailRecord> detailList=new ArrayList<>();
            List<TMetadataDetailRecord> existedColumns=detailDao.findByConditions(Arrays.asList(TMetadataDetail.T_METADATA_DETAIL.METADATA_ITEM_ID.eq(item.getId())));
            Optional<TMetadataDetailRecord> maxIndexRecord=existedColumns.stream().max(new Comparator<TMetadataDetailRecord>() {
                @Override
                public int compare(TMetadataDetailRecord o1, TMetadataDetailRecord o2) {
                    return o1.getIndex().compareTo(o2.getIndex());
                }
            });
            int startIndex=100;
            String userId="1";
            if(maxIndexRecord.isPresent()){
                startIndex=maxIndexRecord.get().getIndex()+1;
                userId=maxIndexRecord.get().getCreateUser();
            }
            Timestamp now=new Timestamp(System.currentTimeMillis());
            for(String columnName:columns){
                TMetadataDetailRecord detailRecord=new TMetadataDetailRecord();
                detailRecord.setId(BigDecimal.valueOf(idGeneratorService.id()));
                detailRecord.setAuditTime(now);
                detailRecord.setColComment(columnName);
                detailRecord.setColDisplayname(columnName);
                detailRecord.setColName(columnName);
                detailRecord.setColType(301);
                detailRecord.setCreateTime(now);
                detailRecord.setCreateUser(userId);
                detailRecord.setIndex(startIndex);
                detailRecord.setMetadataItemId(item.getId());
                detailRecord.setState(0);
                detailRecord.setStatus((short)1);
                detailRecord.setUpdateTime(now);
                detailRecord.setUpdateUser(userId);
                detailList.add(detailRecord);
                startIndex++;
            }
            detailDao.insert(detailList);
        }
    }

    private void addAnalyzeColumns(String tableName,List<String> columns){
        AnalyzeMapInfoDao analyzeMapInfoDao=SpringUtil.getBean(AnalyzeMapInfoDao.class);
        AnalyzeColumnDao columnDao=SpringUtil.getBean(AnalyzeColumnDao.class);
        List<AnalyzeMapInfoRecord> analyzeTables=analyzeMapInfoDao.findByConditions(Arrays.asList(AnalyzeMapInfo.ANALYZE_MAP_INFO.SCHEMA.eq("default"),
                AnalyzeMapInfo.ANALYZE_MAP_INFO.TABLE_NAME.eq(tableName)));
        if(!analyzeTables.isEmpty()){
            List<AnalyzeMapDetailRecord>  detailRecordList=new ArrayList<>();
            for(AnalyzeMapInfoRecord analyzeTable:analyzeTables){
                List<AnalyzeMapDetailRecord> existedAnalyzeColumns = columnDao.findByConditions(Arrays.asList(AnalyzeMapDetail.ANALYZE_MAP_DETAIL.ANALYZE_MAP_INFO_UUID.eq(analyzeTable.getAnalyzeMapInfoUuid())));
                Optional<AnalyzeMapDetailRecord> maxOrderIndexRecord=existedAnalyzeColumns.stream().max(new Comparator<AnalyzeMapDetailRecord>() {
                    @Override
                    public int compare(AnalyzeMapDetailRecord o1, AnalyzeMapDetailRecord o2) {
                        return o1.getOrderIndex().compareTo(o2.getOrderIndex());
                    }
                });
                int startOrderIndex=100;
                if(maxOrderIndexRecord.isPresent()){
                    startOrderIndex=maxOrderIndexRecord.get().getOrderIndex()+1;
                }
                for(String columnName:columns){
                    AnalyzeMapDetailRecord detailRecord=new AnalyzeMapDetailRecord();
                    detailRecord.setAnalyzeMapId(UUID.randomUUID().toString());
                    detailRecord.setAnalyzeMapInfoUuid(analyzeTable.getAnalyzeMapInfoUuid());
                    detailRecord.setColAnalyzeType(0);
                    detailRecord.setColDataType(0);
                    detailRecord.setColDisplayName(columnName);
                    detailRecord.setColExp("`"+columnName+"`");
                    detailRecord.setColName(columnName);
                    detailRecord.setDbType("STRING");
                    detailRecord.setIntroduction("");
                    detailRecord.setIsDel(false);
                    detailRecord.setOrderIndex((short)startOrderIndex);
                    detailRecord.setRequired(false);
                    detailRecord.setSensitive((short)0);
                    detailRecordList.add(detailRecord);
                    startOrderIndex++;
                }
                if(maxOrderIndexRecord.isPresent() && maxOrderIndexRecord.get().getColName().equals("id_import_time") ){
                   AnalyzeMapDetailRecord detailRecord= maxOrderIndexRecord.get();
                    detailRecord.setOrderIndex((short)(startOrderIndex+1));
                    columnDao.update(detailRecord);
                }
            }
            columnDao.insert(detailRecordList);
        }
    }

    private void updateColMapping(String tableName,List<String> columns){
        JobDao jobDao=SpringUtil.getBean(JobDao.class);
        JobConfDao jobConfDao=SpringUtil.getBean(JobConfDao.class);
        List<TJobRecord> jobs=jobDao.findByConditions(Arrays.asList(TJob.T_JOB.DIST_TABLE.lower().eq(tableName)));
        for(TJobRecord jobRecord:jobs){
            List<Condition> conditions=Arrays.asList(TJobConf.T_JOB_CONF.REF_ID.eq(jobRecord.getId()),TJobConf.T_JOB_CONF.KEY.eq(ConfKey.FIELD_MAPPING));
            TJobConfRecord conf=jobConfDao.findAnyByCondition(conditions);
            if(conf != null){
                String mappingStr=conf.getValue();
                JSONArray colMapping=JSON.parseArray(mappingStr);
                for(String column:columns){
                    JSONObject mapping=new JSONObject();
                    mapping.put("dist",column);
                    mapping.put("source",column);
                    mapping.put("distDataType","STRING");
                    colMapping.add(mapping);
                }
                conf.setValue(colMapping.toJSONString());
                jobConfDao.update(conf);
            }
        }

    }
}
