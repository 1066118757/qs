package com.cdid.log.dataclear.clearrecord;

import com.alibaba.fastjson.JSON;
import com.cdid.api.operate.operatelog.OperateLogService;
import com.cdid.api.operate.operatelog.vo.OperateLogAddVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.token.AccessTokenDao;
import com.cdid.log.GetUserIdUtil;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashSet;
import java.util.Set;

/**
 * @Author LQL
 * @CreateAt 2017/11/29
 */

@Aspect
@Component
public class ClearRecordLogAspect {
    @Resource
    private OperateLogService operateLogService;
    @Resource
    private AccessTokenDao accessTokenDao;

    private static Logger logger = LoggerFactory.getLogger(ClearRecordLogAspect.class);

    private Set<String> tableName = new HashSet();

    // controller层切点
    @Pointcut("(execution(public * com.cdid.api.dataclear.clearrecord.ClearRecordService.*(..)))")
    public void clearRecordAspect() {
    }

    @Before("clearRecordAspect()")
    public void beforeClearRecord(JoinPoint joinPoint) {
        try {
            logger.info("=====beforeClearRecord前置通知开始=====");
            logger.info("请求Param：" + joinPoint.getArgs());
            tableName.add(JSON.toJSONString(joinPoint.getArgs()[0]));
        } catch (Exception e) {
            logger.error("=====beforeClearRecord前置异常通知====");
            logger.error(e.getMessage());
        }
    }

    @AfterReturning(pointcut = "clearRecordAspect()", returning = "retValue")
    public void afterClearRecord(JoinPoint joinPoint, Object retValue) {
        try {
            //从请求中获取userId
            String userId = GetUserIdUtil.getUserId();
            logger.info("=====afterClearRecord后置通知开始=====");
            String className = joinPoint.getTarget().getClass().getName();
            String methodName = joinPoint.getSignature().getName() + "()";
            logger.info("请求方法:" + className);
            logger.info("请求人:" + userId);
            Integer result = ((ResultVo) retValue).getErrorCode();
            logger.info("返回值：" + result);
            //写入数据库
            logger.info("====写入operateAction====");
            OperateLogAddVo operateLogAddVo = new OperateLogAddVo();
            Integer actionId;
            switch (methodName){
                case "add()":actionId=101;break;
                case "update()":actionId=102;break;
                case "delete()":actionId=103;break;
                case "list()":actionId=104;break;
                case "clearRecordById()":actionId=105;break;
                case "clearResultPreview()":actionId=106;break;
                case "getRedisData()":actionId=107;break;
                default:actionId=100;
            }
            operateLogAddVo.setActionId(actionId);
            operateLogAddVo.setOperatorId(userId);
            operateLogAddVo.setResult(result);
            //操作表暂定为前接口对应表
            operateLogAddVo.setOperateTable("t_clear_record");
            operateLogService.add(operateLogAddVo);
            logger.info("====写入operateLog====");
            /*for (String table : tableName
                    ) {
                logger.info("操作表: " + table);
                operateLogAddVo.setOperateTable(table);
                operateLogService.add(operateLogAddVo);
                logger.info("====写入operateLog====");
            }*/
        } catch (Exception e) {
            logger.error("=====afterClearRecord后置异常通知====");
            logger.error(e.getMessage());
        } finally {
            tableName.clear();
        }
    }
}
