package com.cdid.service.oozie.graph;



import com.cdid.service.oozie.command.Parameter;
import com.cdid.service.oozie.constant.ParameterDataType;
import com.cdid.service.oozie.constant.ParameterIOType;
import com.cdid.service.oozie.constant.ProgramType;
import com.cdid.service.oozie.vo.ProgramVO;
import com.cdid.utils.StringUtil;
import org.apache.commons.lang3.RandomStringUtils;
import org.dom4j.*;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

/**
 * A Oozie workflow graph, whose nodes are Oozie widgets
 */
public class OozieGraph  {
	/** Dataset nodes */
	List<OozieDatasetNode> dnodes = new ArrayList<>();
	/** Program nodes */
	List<OozieProgramNode> pnodes = new ArrayList<OozieProgramNode>();

	List<OozieEdge> edges = new ArrayList<OozieEdge>();

	private String name;

	private String description;

	private Integer timeout;

	private BigDecimal id;

	private String oozieJobId;

	private String appPath;

	public BigDecimal getId() {
		return id;
	}

	public void setId(BigDecimal id) {
		this.id = id;
	}

	/**
	 * activeList
	 */
	private List<String> activeList = new ArrayList<String>();

	public void addActiveNode(String nodeId) {
		this.activeList.add(nodeId);
	}

	public boolean isActiveNode(String nodeId) {
		return this.activeList.contains(nodeId);
	}

	/** Return the total number of nodes in the graph */
	public int getNodeNum() {
		return dnodes.size() + pnodes.size();
	}

	public List<OozieDatasetNode> getDnodes() {
		return dnodes;
	}

	public List<OozieEdge> getEdges() {
		return edges;
	}

	public List<OozieProgramNode> getPnodes() {
		return pnodes;
	}

	public void setActiveList(List<String> activeList) {
		this.activeList = activeList;
	}

	public void setDnodes(List<OozieDatasetNode> dnodes) {
		this.dnodes = dnodes;
	}

	public void setEdges(List<OozieEdge> edges) {
		this.edges = edges;
	}

	public void setPnodes(List<OozieProgramNode> pnodes) {
		this.pnodes = pnodes;
	}

	public List<String> getActiveList() {
		return activeList;
	}

	/** Add a dataset node */
	public void addDatasetNode(OozieDatasetNode node) {
		dnodes.add(node);
	}
	/** Add a program node */
	public void addProgramNode(OozieProgramNode node) {
		pnodes.add(node);
	}
	/** Add a edge */
	public void addEdge(OozieEdge edge) {
		edges.add(edge);
	}

	public Integer getTimeout() {
		return timeout;
	}

	public void setTimeout(Integer timeout) {
		this.timeout = timeout;
	}

	/**
	 *  Generate a XML string for the graph 
	 * */
	public String toXML() {
		StringBuffer sb = new StringBuffer(5000);
		sb.append("<graph>\n");
		for (OozieDatasetNode node : dnodes)
			sb.append(node.toXML());
		for (OozieProgramNode node : pnodes)
			sb.append(node.toXML());
		for (OozieEdge edge : edges)
			sb.append(edge.toXML());
		sb.append("</graph>");
		return sb.toString();
	}

	public List<String> initProgramWorkPathAndOutPutParameters(){
		List<String> tempTableNames=new ArrayList<>();
		for(OozieProgramNode node:pnodes){
			if(StringUtil.isEmpty(node.getWorkPath())){
				node.setWorkPath(node.getId());
			}
			for(Parameter parameter:node.getParams()){
				if(ParameterDataType.IN.getName().equals(parameter.getDataType())||ParameterDataType.OUT.getName().equals(parameter.getDataType())){
					parameter.setParamValue(null);
				}
				if(parameter.getDataType().equals(ParameterDataType.OUT.getName())){
					if(parameter.getIoType().equals(ParameterIOType.FILE.name())){
						String outPutFilePath=node.getWorkPath()+"/"+parameter.getParamName()+System.currentTimeMillis();
						parameter.setParamValue(outPutFilePath);
					}else if(parameter.getIoType().equals(ParameterIOType.TABLE.name())){
						String outPutTableName= RandomStringUtils.random(4,true,false)+System.currentTimeMillis();
						parameter.setParamValue(outPutTableName);
						tempTableNames.add(outPutTableName);
					}
				}
			}
		}
		return tempTableNames;
	}

	public static OozieGraph valueOf(String xml) throws DocumentException {
		OozieGraph graph=new OozieGraph();
		Document doc = DocumentHelper.parseText(xml);
		Element root = doc.getRootElement();
		// parse widgets
		List<Element> nodes = root.elements("widget");
		for( Element node: nodes){
			String type = node.attributeValue("type");
			if (type.equals("dataset")) {
				OozieDatasetNode odn = OozieDatasetNode.valueOf(node);
				graph.addDatasetNode(odn);
			} else if(type.equals("program")){
				OozieProgramNode opn = OozieProgramNode.valueOf(node);
				graph.addProgramNode(opn);
				graph.addActiveNode(opn.getId());
			}

		}
		// parse edges
		List<Element> enodes = root.elements("edge");
		for(Element elem: enodes){
			OozieEdge edge = OozieEdge.valueOf(elem);
			if (edge != null){
				graph.addEdge(edge);
			}
		}
		return graph;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return toXML();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOozieJobId() {
		return oozieJobId;
	}

	public void setOozieJobId(String oozieJobId) {
		this.oozieJobId = oozieJobId;
	}

	public String getAppPath() {
		return appPath;
	}

	public void setAppPath(String appPath) {
		this.appPath = appPath;
	}
}
