package com.cdid.service.oozie.constant;

public enum ParameterIOType {
    FILE,TABLE;
}
