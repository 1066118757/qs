package com.cdid.service.common;


import com.alibaba.fastjson.JSONObject;
import com.cdid.api.common.RedisService;
import com.cdid.api.common.TokenService;
import com.cdid.api.common.TokenVo;
import com.cdid.utils.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

/**
 * Froid_Li
 * 2018/1/4  10:49
 */
@Service
public class TokenServiceImpl implements TokenService {
    @Autowired
    RedisService redisService;

    @Override
    public String getUserId(HttpServletRequest request) throws Exception {
        String token = request.getHeader("Authorization");
        if (StringUtil.isEmpty(token)) {
            token = request.getParameter("Authorization");
        }
        if (StringUtil.isEmpty(token)) {
            throw new Exception();
        }
        token = token.replaceAll("Bearer ", "");
        if (!redisService.exists(token)) {
            throw new Exception();
        }
        TokenVo tokenVo = JSONObject.toJavaObject(JSONObject.parseObject(redisService.get(token)), TokenVo.class);
        return tokenVo.getUserId();
    }

    @Override
    public String getToken(HttpServletRequest request){
        String token = request.getHeader("Authorization");
        if (StringUtil.isEmpty(token)) {
            return request.getParameter("Authorization");
        }
        return token;
    }
}
