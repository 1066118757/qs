/**
 * Copyright 2017 Institute of Computing Technology, Chinese Academy of Sciences.
 * Licensed under the terms of the Apache 2.0 license.
 * Please see LICENSE file in the project root for terms
 */
package com.cdid.service.oozie.graph;


import org.dom4j.Element;

import java.util.List;

/**
 * Dataset node in Oozie workflow graph
 */
public class OozieDatasetNode extends OozieNode  {

	/** File id */
	private String filePath = "";

	private String data;

	public OozieDatasetNode() {
		super();
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	/** Generate a XML String for the node */
	@Override
	public String toXML() {
		StringBuffer sb = new StringBuffer(100);
		sb.append("<widget type='dataset'>\n");
		sb.append("  <id>" + id + "</id>\n");
		sb.append("  <alias>" + alias + "</alias>\n");
		sb.append("  <moduleId>" + moduleId + "</moduleId>\n");
		sb.append("  <x>" + x + "</x>\n");
		sb.append("  <y>" + y + "</y>\n");
		sb.append("  <filePath>" + filePath + "</filePath>\n");
		sb.append("  <data>" + data + "</data>\n");
		sb.append("</widget>\n");
		return sb.toString();
	}


	public static OozieDatasetNode valueOf(Element xml_node){
		List<Element> childNodes = xml_node.elements();
		OozieDatasetNode node = new OozieDatasetNode();

		for( Element child : childNodes){
			String value = child.getText();
			String name = child.getName();

			if ("id".equals(name))
				node.setId(value);
			else if ("moduleId".equals(name))
				node.setModuleId(value);
			else if ("x".equals(name))
				node.setX((int) Float.parseFloat(value));
			else if ("y".equals(name))
				node.setY((int) Float.parseFloat(value));
			else if ("filePath".equals(name))
				node.setFilePath(value);
			else if("data".equals(name)){
				node.setData(value);
			}else if("alias".equals(name)){
				node.setAlias(value);
			}
		}
		return node;
	}
}
