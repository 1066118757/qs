package com.cdid.service.oozie.vo;

import java.math.BigDecimal;

public class TableTreeListVO extends TreeObjectListVO {

    private BigDecimal tableId;

    private String tableName;

    private Long createTime;

    private String mapInfoid;


    public String getMapInfoid() {
        return mapInfoid;
    }

    public void setMapInfoid(String mapInfoid) {
        this.mapInfoid = mapInfoid;
    }

    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    public BigDecimal getTableId() {
        return tableId;
    }

    public void setTableId(BigDecimal tableId) {
        this.tableId = tableId;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
}
