package com.cdid.service.oozie.task;

import com.cdid.common.vo.SimpleJDBCVO;
import com.cdid.config.PropertyUtil;
import com.cdid.dao.oozie.OozieJobDao;
import com.cdid.dao.oozie.OozieJobLogDao;
import com.cdid.dao.oozie.ProgramDao;
import com.cdid.jooq.tables.TOozieJob;
import com.cdid.jooq.tables.TOozieJobLog;
import com.cdid.jooq.tables.TProgram;
import com.cdid.jooq.tables.records.TOozieJobLogRecord;
import com.cdid.jooq.tables.records.TProgramRecord;
import com.cdid.service.oozie.util.HDFSIO;
import com.cdid.utils.StringUtil;
import com.cdid.utils.jdbc.JDBCUtil;
import org.apache.hadoop.fs.Path;
import org.jooq.Condition;
import org.jooq.SortField;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ClearTaskService implements Job {

    private static final Logger logger= LoggerFactory.getLogger(ClearTaskService.class);

    @Autowired
    ProgramDao programDao;
    @Autowired
    OozieJobDao jobDao;

    @Autowired
    OozieJobLogDao jobLogDao;
    public  void clearProgramFiles(){
        try {
            Path[] programPaths=HDFSIO.list(PropertyUtil.getMergedProperty("hdfs.programPath","/PROGRAM"));
            if(programPaths ==null){
                return;
            }
            for(Path path:programPaths){
              List<TProgramRecord> records= programDao.fetch(TProgram.T_PROGRAM.PATH,path.toUri().getPath());
                if(records.isEmpty()){
                    HDFSIO.remove(path);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void clearTempFiles() {
        try {
            Path[] appPaths=HDFSIO.list(PropertyUtil.getMergedProperty("oozie.app.path", "/EML/oozie"));
            if(appPaths == null){
                return;
            }
            for(Path path:appPaths){
                String appPath=path.toUri().getPath();
                if(!jobDao.fetchOptional(TOozieJob.T_OOZIE_JOB.PATH,appPath).isPresent()){
                    HDFSIO.remove(path);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void clearTempTables(){
        List<Condition> conditionList=new ArrayList<>();
        conditionList.add(TOozieJobLog.T_OOZIE_JOB_LOG.CLEARED.eq(false));
        List<SortField<?>> sortFieldList=new ArrayList<>();
        sortFieldList.add(TOozieJobLog.T_OOZIE_JOB_LOG.START_TIME.desc());
        List<TOozieJobLogRecord> recordList= jobLogDao.findByConditions(conditionList,sortFieldList);
        Map<BigDecimal,List<TOozieJobLogRecord>> jobIdMap=recordList.stream().collect(Collectors.groupingBy(a -> a.getJobId()));
        List<String> dropTableSqlList=new ArrayList<>();
        for(List<TOozieJobLogRecord> records:jobIdMap.values()){
            if(records.size()!=1){
               List<TOozieJobLogRecord> clearList=records.subList(1,records.size()-1);
                for(TOozieJobLogRecord record:clearList){
                    if(StringUtil.isNotEmpty(record.getTempTables())){
                        Arrays.asList(record.getTempTables().split(",")).forEach(tableName ->
                                dropTableSqlList.add("DROP TABLE IF EXISTS "+tableName)
                        );
                    }
                }
            }
        }
        SimpleJDBCVO jdbcvo=SimpleJDBCVO.getCurrentEnvHiveJDBCVO();
        JDBCUtil.executeBatch(dropTableSqlList,jdbcvo.getDriver(),jdbcvo.getUrl(),jdbcvo.getUsername(),jdbcvo.getPassword());
    }

    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        clearProgramFiles();
        clearTempFiles();
        clearTempTables();
    }
}
