package com.cdid.service.job;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cdid.api.asynctask.AsyncTaskExecuteService;
import com.cdid.api.asynctask.vo.AsyncTaskConfigVo;
import com.cdid.api.common.IDGeneratorService;
import com.cdid.api.common.IdNameVO;
import com.cdid.api.common.RedisService;
import com.cdid.api.common.SmsService;
import com.cdid.api.dataimport.vo.*;
import com.cdid.api.datasource.DataSourceService;
import com.cdid.api.datasource.vo.*;
import com.cdid.api.job.JobService;
import com.cdid.api.job.vo.*;
import com.cdid.api.jobconf.JobConfService;
import com.cdid.api.jobconf.vo.JobConfAddVo;
import com.cdid.api.jobconf.vo.JobConfDetailVo;
import com.cdid.api.jupyter.vo.DependenceDisplayVO;
import com.cdid.api.jupyter.vo.DependenceVO;
import com.cdid.api.metadata.detail.vo.DetailAddVo;
import com.cdid.api.metadata.item.ItemService;
import com.cdid.api.metadata.item.vo.ItemAddAllsVo;
import com.cdid.api.schedulelog.ScheduleLogService;
import com.cdid.api.schedulelog.vo.ScheduleLogAddVo;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.constant.RecordStatus;
import com.cdid.common.constant.RedisKey;
import com.cdid.common.dict.ConfType;
import com.cdid.common.dict.DataSourceType;
import com.cdid.common.dict.JobState;
import com.cdid.common.vo.JDBCVo;
import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.config.PropertyUtil;
import com.cdid.dao.analyzeMapInfo.AnalyzeMapInfoDao;
import com.cdid.dao.chartInfo.ChartInfoDao;
import com.cdid.dao.dataclear.cleartask.ClearTaskDao;
import com.cdid.dao.datasource.DataSourceDao;
import com.cdid.dao.job.JobDao;
import com.cdid.dao.jobconf.JobConfDao;
import com.cdid.dao.metadata.item.ItemDao;
import com.cdid.dao.schedulelog.SchedulelogDao;
import com.cdid.dao.user.UsersDao;
import com.cdid.jooq.tables.ChartInfo;
import com.cdid.jooq.tables.records.*;
import com.cdid.service.dataimport.ETLJobPreProcessor;
import com.cdid.utils.DateUtils;
import com.cdid.utils.DbTypeUtil;
import com.cdid.utils.StringUtil;
import com.cdid.utils.VoReTraversalUtil;
import com.cdid.utils.cron.CronTab;
import com.cdid.utils.cron.CronUtil;
import com.cdid.utils.email.EmailUtil;
import com.cdid.utils.jdbc.ConfKey;
import com.cdid.utils.jdbc.JDBCUtil;
import com.cdid.utils.jdbc.SpringUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.net.util.Base64;
import org.jooq.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

import static com.cdid.jooq.tables.TDataSource.T_DATA_SOURCE;
import static com.cdid.jooq.tables.TJob.T_JOB;
import static com.cdid.jooq.tables.TScheduleLog.T_SCHEDULE_LOG;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/02 15:20 
 */
@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class JobServiceImpl implements JobService {


    @Value("${dist.ip}")
    private String distIp;
    @Value("${dist.port}")
    private String distPort;
    @Value("${dist.database}")
    private String distDatabase;
    @Value("${dist.username}")
    private String distUserName;
    @Value("${dist.password}")
    private String distPassword;
    @Value("${dist.dbtype}")
    private String distdbtype;
    @Value("${dist.schema}")
    private String distSchema;
    @Value("${redis.host}")
    private String redisHost;
    @Value("${redis.port}")
    private String redisPort;
    @Value("${redis.index}")
    private String redisIndex;

    @Autowired
    IDGeneratorService<Long> idGeneratorService;

    @Autowired
    JobDao jobDao;
    @Autowired
    JobConfDao jobConfDao;
    @Autowired
    DataSourceService dataSourceService;
    @Autowired
    DataSourceDao dataSourceDao;
    @Autowired
    JobConfService jobConfService;

    @Autowired
    private ScheduleUtils scheduleUtils;

    @Autowired
    private ScheduleLogService scheduleLogService;
    @Autowired
    private AsyncTaskExecuteService asyncTaskExecuteService;
    @Autowired
    private ItemService itemService;
    @Autowired
    private UsersDao usersDao;

    @Autowired
    RedisService redisService;
    @Autowired
    ItemDao itemDao;

    @Autowired
    ClearTaskDao clearTaskDao;

    @Autowired
    SchedulelogDao schedulelogDao;

    @Autowired
    AnalyzeMapInfoDao analyzeMapInfoDao;

    @Autowired
    ChartInfoDao chartInfoDao;

    @Autowired
    SmsService smsService;

    private static Logger logger = LoggerFactory.getLogger(JobServiceImpl.class);


    @Override
    public ResultVo<Boolean> promptlyRun(BigDecimal jobId) {
        Integer type = jobDao.getDataSourceType(jobId);
        Integer dbType = JobServiceUtil.isDbType(type);
        if (dbType == JobServiceUtil.IS_FILE) {
            return new ResultVo<>(ErrorCode.ParamError.getErrorCode(), Boolean.FALSE, "文件类型不能执行");
        }
        JobBaseConfigVo jobConfigVo = null;
        try {
            jobConfigVo = getJobConfigVo(jobId, dbType);
            AsyncTaskConfigVo asyncTaskConfigVo = JobServiceUtil.getAsyncTaskConfigVo(jobConfigVo);
            if (asyncTaskConfigVo != null) {
//                noteBookTask.run(jobConfigVo);
                asyncTaskExecuteService.execute(asyncTaskConfigVo, true);

            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.info(e.getMessage());
            return new ResultVo<>(ErrorCode.ParamError.getErrorCode(), Boolean.FALSE, e.getMessage());
        }
        return new ResultVo<>(0, Boolean.TRUE, "SUCCESS");
    }


    @Override
    public ResultVo<String> add(JobAddVo jobAddVo, String userId) throws Exception {
        BigDecimal dataSourceId = jobAddVo.getDataSourceId();
        DataSourceAddVo dataSourceAddVo = jobAddVo.getDataSourceAddVo();
        Integer type = dataSourceAddVo.getType();
        List<JobConfAddVo> confs = jobAddVo.getConfs();
        String redisKey = jobAddVo.getRedisKey();
        BigDecimal id = jobAddVo.getId();

        Short distTableSource = jobAddVo.getDistTableSource();

        //创建表
        if (distTableSource == 1) {
            String distTable = jobAddVo.getDistTable();
            BigDecimal logicPartitionId = jobAddVo.getLogicPartitionId();
            ItemAddAllsVo itemAddAllsVo = JobServiceUtil.getCreateTableVo(distTable, logicPartitionId, confs);
            ResultVo<Object> objectResultVo = itemService.addAlls(itemAddAllsVo, userId, false);
            if (objectResultVo.getErrorCode() != 0) {
                return new ResultVo<>(ErrorCode.UnknownError.getErrorCode(), null, objectResultVo.getData().toString());
            }
        } else {
            //已有表
            TMetadataItemRecord metadataItemRecord = itemDao.findByName(jobAddVo.getDistTable());
            BigDecimal themeItemId = metadataItemRecord.getThemeItemId();
            jobAddVo.setLogicPartitionId(themeItemId);
        }

        boolean isFile = JobServiceUtil.isDbType(type) == JobServiceUtil.IS_FILE;
        if (isFile && StringUtils.isEmpty(redisKey)) {
            return new ResultVo<>(ErrorCode.ParamError.getErrorCode(), null, "为文件类型时，redisKey不能为null");
        }
        if (isFile && id == null) {
            dataSourceAddVo.setState(1);
            //文件引接时，数据源名称 默认 任务名称
            dataSourceAddVo.setName(jobAddVo.getName());
        }
        if (isFile && id != null) {
            Integer dataSourceType = jobDao.getDataSourceType(id);
            try {
                updateQuartzJob(id, dataSourceType, redisKey);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return new ResultVo<>(0, "SUCCESS");
        }
        //新增数据源
        if (dataSourceId == null) {
            //若为文件类型 添加文件类型数据源
            ResultVo<BigDecimal> dataSourceIdVo = dataSourceService.add(dataSourceAddVo, userId);
            dataSourceId = dataSourceIdVo.getData();
            //为任务设置dataSourceId
            jobAddVo.setDataSourceId(dataSourceId);
        }
        //添加配置
        id = BigDecimal.valueOf(idGeneratorService.id());
        addConf(confs, id, userId);
        TJobRecord jobRecord = VoReTraversalUtil.traversal(jobAddVo, TJobRecord.class);
        jobRecord.setId(id);
        jobRecord.setCreateUser(userId);
        jobRecord.setUpdateUser(userId);
        jobRecord.setState(1);
        jobDao.insert(jobRecord);
        try {
            updateQuartzJob(id, type, redisKey);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ResultVo<>(0, "SUCCESS");
    }

    /**
     * 获取corn表达式
     *
     * @param jobId
     * @param syncStrategy
     * @return
     * @throws Exception
     */
    @Override
    public String getCornStr(BigDecimal jobId, Integer syncStrategy) throws Exception {
        Result<TJobConfRecord> confRecords = jobConfDao.findByRefId(jobId, ConfType.JOB.getValue());
        Map<String, String> confMap = new HashMap<>();
        for (TJobConfRecord confRecord : confRecords) {
            confMap.put(confRecord.getKey(), confRecord.getValue());
        }
        String cronStr = null;
        //封装corn
        try {
            String value = null;
            switch (syncStrategy) {
                case 1:
                    value = confMap.get(ConfKey.SYNCSTRATEGY_TIMING);
                    long time = Long.parseLong(value);
                    long currentTime = System.currentTimeMillis();
                    if (time < currentTime) {
                        break;
                    } else {
                        long longTime = Long.parseLong(value);
                        cronStr = CronUtil.toCronString(longTime);
                    }
                    break;
                case 2:
                    value = confMap.get(ConfKey.SYNCSTRATEGY_FREQUENCY);
                    CronTab cronTab = JSON.parseObject(value, CronTab.class);
                    cronStr = CronUtil.toCronString(cronTab);
                    break;
                default:
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cronStr;
    }

    /**
     * 添加任务配置
     *
     * @param confs
     * @param jobId
     * @param userId
     * @throws Exception
     */
    private void addConf(List<JobConfAddVo> confs, BigDecimal jobId, String userId) throws Exception {
        if (confs != null && confs.size() > 0) {
            List<JobConfAddVo> confAddVos = new ArrayList<>();
            for (JobConfAddVo conf : confs) {
                conf.setRefId(jobId);
                confAddVos.add(conf);
            }
            //批量添加配置
            jobConfService.batchAdd(confAddVos, userId);
        }
    }

    @Override
    public ResultVo<String> delete(BigDecimal id, String userId) throws Exception {
        jobDao.updateStatus(id, userId, RecordStatus.Deleted.getStatus());
        jobConfService.deleteByRefId(id);
        //删除日志
        scheduleLogService.deleteByJobId(id);
        try {
            scheduleUtils.deleteScheduleJob(id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ResultVo<>(0, null, "SUCCESS");
    }

    @Override
    public ResultVo<String> update(JobUpdateVo jobUpdateVo, String userId, String accessToken) throws Exception {

        BigDecimal jobId = jobUpdateVo.getId();
        TJobRecord jobRecord = jobDao.findById(jobId);
        List<JobConfAddVo> confs = jobUpdateVo.getConfs();

        Integer latestScheduleState = jobRecord.getLatestScheduleState();
        //更新目标表
        if (latestScheduleState == null) {
            String distTable = jobUpdateVo.getDistTable();
            BigDecimal logicPartitionId = jobRecord.getLogicPartitionId();
            //
            BigDecimal itemId = itemDao.fetchIdByThemeItemIdAndName(logicPartitionId, distTable);
            if (itemId == null) {
                return new ResultVo<>(ErrorCode.UnknownError.getErrorCode(), null, "没有找到该目标表！");
            }
            ResultVo<Object> delete = itemService.delete(itemId, accessToken);
            if (delete.getErrorCode() != 0) {
                return new ResultVo<>(ErrorCode.UnknownError.getErrorCode(), null, "更新目标表失败！");
            }
            ItemAddAllsVo itemAddAllsVo = JobServiceUtil.getCreateTableVo(distTable, logicPartitionId, confs);
            ResultVo<Object> objectResultVo = itemService.addAlls(itemAddAllsVo, userId, false);
            if (objectResultVo.getErrorCode() != 0) {
                return new ResultVo<>(objectResultVo.getErrorCode(), null, objectResultVo.getData().toString());
            }
        }
        //删除配置
        jobConfService.deleteByRefId(jobId);
        //添加数据源配置
        DataSourceAddVo dataSourceAddVo = jobUpdateVo.getDataSourceAddVo();
        Integer type = dataSourceAddVo.getType();
        String redisKey = jobUpdateVo.getRedisKey();
        addConf(confs, jobId, userId);

        BigDecimal dataSourceId = jobUpdateVo.getDataSourceId();
        //若编辑了dataSource 前端传过来的dataSourceId必须为null
        //若选择了其他数据源 前端传过来的dataSourceAddVo必须为null
        //若没有编辑dataSource并且没有选择其他数据源 前端传过来的DataSource为null或dataSourceId不等于null
        if (dataSourceAddVo != null && dataSourceId == null) {
            ResultVo<BigDecimal> dataSourceIdVo = dataSourceService.add(dataSourceAddVo, userId);
            dataSourceId = dataSourceIdVo.getData();
            jobUpdateVo.setDataSourceId(dataSourceId);
        }

        TJobRecord record = VoReTraversalUtil.traversal(jobUpdateVo, TJobRecord.class);
        record.setUpdateUser(userId);
        record.setUpdateTime(new Timestamp(System.currentTimeMillis()));
        jobDao.update(record);
        //TODO   更新定时任务
        try {
            updateQuartzJob(jobId, type, redisKey);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ResultVo<>(0, null, "SUCCESS");
    }


    /**
     * 更新定时任务
     *
     * @throws Exception
     */

    private void updateQuartzJob(BigDecimal jobId, Integer type, String redisKey) throws Exception {
        Integer dbType = JobServiceUtil.isDbType(type);
//        JobBaseConfigVo jobConfigVo = getJobConfigVo(jobId, dbType);
        JobBaseConfigVo jobConfigVo = getJobConfigVo(jobId, dbType);
        AsyncTaskConfigVo asyncTaskConfigVo = null;
        if (jobConfigVo == null) {
            return;
        }
        ScheduleJobEntity jobEntity = new ScheduleJobEntity();
        jobEntity.setJobId(jobId);
        //文件类型
        if (dbType == JobServiceUtil.IS_FILE) {
            String dataJosn = redisService.get(redisKey);
            if (!StringUtils.isEmpty(dataJosn)) {
//                List<List<String>> data = (List<List<String>>) JSONArray.parse(dataJosn);
                FileJobConfigVo fileJobConfigVo = (FileJobConfigVo) jobConfigVo;

//                fileJobConfigVo.setData(data);
                fileJobConfigVo.setTaskId(jobId);
                fileJobConfigVo.setRedisKey(redisKey);
                asyncTaskConfigVo = JobServiceUtil.getAsyncTaskConfigVo(fileJobConfigVo);
                //直接执行，不走定时任务
//                noteBookTask.run(jobConfigVo);
                asyncTaskExecuteService.execute(asyncTaskConfigVo, true);
            } else {
                //记录日志
                ScheduleLogAddVo scheduleLogAddVo = new ScheduleLogAddVo();
                scheduleLogAddVo.setJobId(jobId);
                scheduleLogAddVo.setScheduleState(JobState.Fail.getValue());
                scheduleLogAddVo.setScheduleEndtime(new Timestamp(System.currentTimeMillis()));
                scheduleLogAddVo.setScheduleStarttime(new Timestamp(System.currentTimeMillis()));
                scheduleLogService.saveOrUpdate(scheduleLogAddVo);
            }
        } else {
//            jobEntity.setTaskRequestVo(jobConfigVo);
            asyncTaskConfigVo = JobServiceUtil.getAsyncTaskConfigVo(jobConfigVo);
            Integer syncStrategy = jobConfigVo.getSyncStrategy();
            String cornStr = getCornStr(jobId, syncStrategy);
            Set<String> crons = new HashSet<>();
            crons.add(cornStr);
            jobEntity.setCronExpressions(crons);
            //任务优先级
            jobEntity.setPriority(jobConfigVo.getPriority());
            jobEntity.setAsyncTaskConfigVo(asyncTaskConfigVo);
//            List<CronTrigger> cronTriggers = scheduleUtils.getCronTrigger(jobId);
            if (!StringUtils.isEmpty(cornStr)) {
//                if(cronTriggers != null && cronTriggers.size() > 0){
//                    //删除
//                    scheduleUtils.deleteScheduleJob(jobId);
//                }
                //添加
                scheduleUtils.createScheduleJob(jobEntity);
            }
        }
    }

    @Override
    public ResultVo<String> updateInfo(JobUpdateVo jobUpdateVo, String userId) throws Exception {
        BigDecimal id = jobUpdateVo.getId();
        TJobRecord jobRecord = jobDao.findById(id);
        Integer oldState = jobRecord.getState();
        TJobRecord record = VoReTraversalUtil.traversal(jobUpdateVo, TJobRecord.class);
        record.setUpdateUser(userId);
        record.setUpdateTime(new Timestamp(System.currentTimeMillis()));
        jobDao.update(record);

        try {
            Integer newState = jobUpdateVo.getState();
            if (newState != null && oldState != null) {
                if (newState == RecordStatus.Deleted.getStatus() && oldState == RecordStatus.Effective.getStatus()) {
                    //更改为禁用状态 要删除定时任务
                    scheduleUtils.deleteScheduleJob(id);
                }
                if (newState == RecordStatus.Effective.getStatus() && oldState == RecordStatus.Deleted.getStatus()) {
                    //更改为启用状态 要创建定时任务
                    scheduleUtils.deleteScheduleJob(id);
                    TDataSourceRecord dataSourceRecord = dataSourceDao.findById(jobRecord.getDataSourceId());
                    Integer type = dataSourceRecord.getType();
                    updateQuartzJob(id, type, null);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ResultVo<>(0, null, "SUCCESS");
    }

    @Override
    public ResultVo<PageVo<JobListVo>> list(JobQueryVo jobQueryVo, String userId, Integer page, Integer size) throws Exception {
        List<Condition> conditions = new ArrayList<>();
        List<SortField<?>> sortList = new ArrayList<>();
        sortList.add(T_JOB.UPDATE_TIME.desc());

        Integer dataSourceType = jobQueryVo.getDataSourceType();
        if (dataSourceType != null) {
            List<BigDecimal> ids = dataSourceDao.findIdsByType(dataSourceType);
            conditions.add(T_JOB.DATA_SOURCE_ID.in(ids));
        }
        Integer state = jobQueryVo.getState();
        if (state != null) {
            conditions.add(T_JOB.STATE.eq(state));
        }
        if (!StringUtils.isEmpty(userId)) {
            conditions.add(T_JOB.CREATE_USER.eq(userId));
        }

        Integer latestScheduleState = jobQueryVo.getLatestScheduleState();
        if (latestScheduleState != null) {
            conditions.add(T_JOB.LATEST_SCHEDULE_STATE.eq(latestScheduleState));
        }
        String name = jobQueryVo.getName();
        if (!StringUtils.isEmpty(name)) {
            conditions.add(T_JOB.NAME.like("%" + name + "%"));
        }
        String createUserName = jobQueryVo.getCreateUserName();
        if (!StringUtils.isEmpty(createUserName)) {
            //根据useName模糊查询userId
            String[] idsByName = usersDao.getIdsByName(createUserName);
            conditions.add(T_JOB.CREATE_USER.in(idsByName));
        }
        BigDecimal dataSourceId = jobQueryVo.getDataSourceId();
        if (dataSourceId != null) {
            conditions.add(T_JOB.DATA_SOURCE_ID.eq(dataSourceId));
        }
        String dataSourceName = jobQueryVo.getDataSourceName();
        if (!StringUtils.isEmpty(dataSourceName)) {
            List<BigDecimal> dataSourceIds = dataSourceDao.findIdsByIds(dataSourceName);
            conditions.add(T_JOB.DATA_SOURCE_ID.in(dataSourceIds));
        }

        conditions.add(T_JOB.STATUS.eq(RecordStatus.Effective.getStatus()));
        PageVo<TJobRecord> query = jobDao.fetchByPage(conditions, new OffsetPagingVo(page, size), sortList);
        List<TJobRecord> records = query.getPageData();
        List<JobListVo> list = new ArrayList<>();

        List<String> createUserIds = new ArrayList();
        for (TJobRecord record : records) {
            createUserIds.add(record.getCreateUser());
        }
        Map<String, Result<Record2<String, String>>> createUserMapper = usersDao.getNameByUserIds(createUserIds.toArray(new String[createUserIds.size()]));

        JobListVo vo = null;
        for (TJobRecord record : records) {
            vo = VoReTraversalUtil.traversal(record, JobListVo.class);
            dataSourceId = record.getDataSourceId();
            TDataSourceRecord dataSourceRecord = dataSourceDao.findById(dataSourceId);
            if (dataSourceRecord != null) {
                DataSourceDetailVo dataSourceDetailVo = VoReTraversalUtil.traversal(dataSourceRecord, DataSourceDetailVo.class);
                vo.setDataSourceDetailVo(dataSourceDetailVo);
            }

            Result<Record2<String, String>> record2s = createUserMapper.get(record.getCreateUser());
            if (record2s != null && record2s.size() > 0) {
                vo.setCreateUserName(record2s.get(0).value1());
            } else {
                vo.setCreateUserName("");
            }

            list.add(vo);
        }
        PageVo<JobListVo> result = new PageVo<>();
        result.setPageData(list);
        result.setTotalCount(query.getTotalCount());
        return new ResultVo(0, result, "SUCCESS");
    }

    @Override
    public ResultVo<JobDetailVo> findById(BigDecimal id) throws Exception {
        TJobRecord record = jobDao.findById(id);
        BigDecimal dataSourceId = record.getDataSourceId();
        JobDetailVo jobDetailVo = VoReTraversalUtil.traversal(record, JobDetailVo.class);

        ResultVo<DataSourceDetailVo> dataSourceDetailVoResultVo
                = dataSourceService.findById(dataSourceId);
        DataSourceDetailVo dataSourceDetailVo = dataSourceDetailVoResultVo.getData();
        jobDetailVo.setDataSourceDetailVo(dataSourceDetailVo);

        List<JobConfDetailVo> confDetailVos = jobConfService.findByRefId(id, ConfType.JOB.getValue(), ConfType.MESSAGE.getValue(), ConfType.FIELD.getValue());
        jobDetailVo.setConfs(confDetailVos);
        String createUser = record.getCreateUser();
        if (!StringUtils.isEmpty(createUser)) {
            jobDetailVo.setCreateUserName(usersDao.getNameByUserId(createUser));
        }
        jobDetailVo.setDependenceVO(convertToDisplayVO(record.getDependence()));
        return new ResultVo<>(0, jobDetailVo, "SUCCESS");
    }

    @Override
    public DependenceDisplayVO convertToDisplayVO(String dependence) {
        if (StringUtil.isNotEmpty(dependence)) {
            DependenceVO dependenceVO = JSON.parseObject(dependence, DependenceVO.class);
            List<IdNameVO> clearJobs = new ArrayList<>();
            if (dependenceVO.getClearJobs() != null && !dependenceVO.getClearJobs().isEmpty()) {
                clearJobs = jobDao.findIdNameByIds(dependenceVO.getClearJobs()).stream().map(r -> new IdNameVO(r.value1(), r.value2())).collect(Collectors.toList());
            }
            List<IdNameVO> etlJobs = new ArrayList<>();
            if (dependenceVO.getEtlJobs() != null && !dependenceVO.getEtlJobs().isEmpty()) {
                etlJobs = jobDao.findIdNameByIds(dependenceVO.getEtlJobs()).stream().map(r -> new IdNameVO(r.value1(), r.value2())).collect(Collectors.toList());
            }
            return new DependenceDisplayVO(clearJobs, etlJobs);
        }
        return null;
    }

    @Override
    public ResultVo<PageVo<StatisticsJobListVo>> statisticsList(StatisticsJobQueryVo statisticsJobQueryVo, Integer page, Integer size) {
        PageVo<StatisticsJobListVo> result = new PageVo<>();
        Timestamp endTime = statisticsJobQueryVo.getEndTime();
        Timestamp startTime = statisticsJobQueryVo.getStartTime();
        Integer scheduleState = statisticsJobQueryVo.getScheduleState();
        BigDecimal jobId = statisticsJobQueryVo.getJobId();
        BigDecimal dataSourceId = statisticsJobQueryVo.getDataSourceId();
        String jobName = statisticsJobQueryVo.getJobName();
        List<Condition> conditions = new ArrayList<>();
        List<SortField<?>> sortList = new ArrayList<>();
        sortList.add(T_SCHEDULE_LOG.SCHEDULE_STARTTIME.desc());
        if (startTime != null) {
            conditions.add(T_SCHEDULE_LOG.SCHEDULE_STARTTIME.greaterOrEqual(startTime));
        }
        if (endTime != null) {
            conditions.add(T_SCHEDULE_LOG.SCHEDULE_ENDTIME.lessOrEqual(endTime));
        }
        if (scheduleState != null) {
            conditions.add(T_SCHEDULE_LOG.SCHEDULE_STATE.eq(scheduleState));
        }
        if (jobId != null) {
            conditions.add(T_JOB.ID.eq(jobId));
        }
        if (dataSourceId != null) {
            conditions.add(T_DATA_SOURCE.ID.eq(dataSourceId));
        }
        if (jobName != null) {
            conditions.add(T_JOB.NAME.like("%" + jobName + "%"));
        }
        PageVo<Record10<Timestamp, Timestamp, String, Integer, Long, String, BigDecimal, String, Integer, String>> record10PageVo
                = jobDao.statisticsList(conditions, new OffsetPagingVo(page, size), sortList);
        List<Record10<Timestamp, Timestamp, String, Integer, Long, String, BigDecimal, String, Integer, String>> record10s =
                record10PageVo.getPageData();
        List<StatisticsJobListVo> listVos = new ArrayList<>();
        StatisticsJobListVo vo = null;
        for (Record10<Timestamp, Timestamp, String, Integer, Long, String, BigDecimal, String, Integer, String> record : record10s) {
            vo = new StatisticsJobListVo();
            vo.setId((BigDecimal) record.get("jobId"));
            vo.setName((String) record.get("jobName"));
            vo.setDataSourceName((String) record.get("dataSourceName"));
            vo.setState((Integer) record.get("state"));
            vo.setCreateUser((String) record.get("createUser"));
            vo.setScheduleStartTime((Timestamp) record.get("startLogTime"));
            vo.setScheduleEndTime((Timestamp) record.get("endLogTime"));
            vo.setScheduleState((Integer) record.get("scheduleState"));
            vo.setSuccessRows((Long) record.get("successRows"));
            vo.setScheduleLog((String) record.get("scheduleLog"));
            listVos.add(vo);
        }
        result.setPageData(listVos);
        result.setTotalCount(record10PageVo.getTotalCount());
        return new ResultVo(0, result, "SUCCESS");
    }

    @Override
    public ResultVo<StatisticsJobInfoVo> statisticsInfo(StatisticsJobQueryVo statisticsJobQueryVo) {
        Timestamp endTime = statisticsJobQueryVo.getEndTime();
        Timestamp startTime = statisticsJobQueryVo.getStartTime();
        Integer scheduleState = statisticsJobQueryVo.getScheduleState();
        BigDecimal jobId = statisticsJobQueryVo.getJobId();
        BigDecimal dataSourceId = statisticsJobQueryVo.getDataSourceId();
        String jobName = statisticsJobQueryVo.getJobName();
        List<Condition> conditions = new ArrayList<>();
        if (startTime != null) {
            conditions.add(T_SCHEDULE_LOG.SCHEDULE_STARTTIME.greaterOrEqual(startTime));
        }
        if (endTime != null) {
            conditions.add(T_SCHEDULE_LOG.SCHEDULE_STARTTIME.lessOrEqual(endTime));
        }
        if (scheduleState != null) {
            conditions.add(T_SCHEDULE_LOG.SCHEDULE_STATE.eq(scheduleState));
        }
        if (jobId != null) {
            conditions.add(T_JOB.ID.eq(jobId));
        }
        if (dataSourceId != null) {
            conditions.add(T_DATA_SOURCE.ID.eq(dataSourceId));
        }
        if (jobName != null) {
            conditions.add(T_JOB.NAME.like("%" + jobName + "%"));
        }
        Map<String, Object> data = jobDao.statisticsInfo(conditions);
        StatisticsJobInfoVo infoVo = new StatisticsJobInfoVo();
        infoVo.setTotalTime((Integer) data.get("totalTime"));
        infoVo.setSuccessTime((BigDecimal) data.get("successTime"));
        infoVo.setFailTime((BigDecimal) data.get("failTime"));
        infoVo.setRunningTime((BigDecimal) data.get("runningTime"));
        infoVo.setTotalDataCount((BigDecimal) data.get("totalDataCount"));
        return new ResultVo<>(0, infoVo);
    }

    @Override
    public JobBaseConfigVo getJobConfigVo(BigDecimal id, Integer type) throws Exception {
        Map<BigDecimal, Result<Record>> all = jobDao.findAllConfig(id);
        JobBaseConfigVo jobBaseConfigVo = null;
        Result<Record> record = all.get(id);
        logger.info(record == null ? "null" : "notnull");
        if (record == null) {
            return null;
        }
        switch (type) {
            case JobServiceUtil.IS_DB:
                jobBaseConfigVo = initDb(record);
                break;
            case JobServiceUtil.IS_WEBSERVICE:
                jobBaseConfigVo = initWebService(record);
                break;
            case JobServiceUtil.IS_FILE:
                jobBaseConfigVo = initFile(record);
                break;
            default:
                break;
        }
        if (jobBaseConfigVo != null) {
            //TODO 获取目标数据库的jdbcUrl
            //设置目标数据库jdbcUrl
            JDBCVo distjdbcVo = new JDBCVo();
            distjdbcVo.setType(DbTypeUtil.getTypeByDb(distdbtype));
            distjdbcVo.setDatabaseName(distDatabase);
            distjdbcVo.setPassword(distPassword);
            distjdbcVo.setUserName(distUserName);
            distjdbcVo.setPort(distPort);
            distjdbcVo.setUrl(distIp);
            String distUrl = (String) JDBCUtil.getDriverAndUrl(distjdbcVo).get("jdbcUrl");
            jobBaseConfigVo.setDistJdbcUrl(distUrl);
            jobBaseConfigVo.setDistUserName(distUserName);
            jobBaseConfigVo.setDistPassword(distPassword);
            jobBaseConfigVo.setDistSchema(distSchema);
            jobBaseConfigVo.setDistDataBase(distDatabase);
            jobBaseConfigVo.setPreProcessProcessor(new ETLJobPreProcessor());

        }
        return jobBaseConfigVo;
    }

    @Override
    public AsyncTaskConfigVo getAsyncTaskConfigVo(BigDecimal id, Integer type) throws Exception {

        JobBaseConfigVo jobConfigVo = getJobConfigVo(id, type);
        AsyncTaskConfigVo asyncTaskConfigVo = JobServiceUtil.getAsyncTaskConfigVo(jobConfigVo);
        return asyncTaskConfigVo;
    }

    /**
     * jdbcjdb配置vo
     *
     * @param records
     */
    private DatabaseJobConfigVo initDb(Result<Record> records) {
        DatabaseJobConfigVo databaseJobConfigVo = null;
        Integer syncStrategy = null;
        Map<String, String> confMap = new HashMap<>();
        if (records.size() > 0) {
            databaseJobConfigVo = new DatabaseJobConfigVo();
            databaseJobConfigVo.setDistDbType(DbTypeUtil.getTypeByDb(distdbtype)); //目标表类型
            databaseJobConfigVo.setDbType(records.get(0).get(T_DATA_SOURCE.TYPE));
            databaseJobConfigVo.setTaskId(records.get(0).get(T_JOB.ID));
            syncStrategy = (Integer) records.get(0).get("sync_strategy");
            databaseJobConfigVo.setSyncStrategy(syncStrategy);
            databaseJobConfigVo.setDistTable((String) records.get(0).get("dist_table"));
            databaseJobConfigVo.setImportMode((Integer) records.get(0).get("import_mode"));
            databaseJobConfigVo.setPriority((Integer) records.get(0).get("priority"));
            databaseJobConfigVo.setDependence((String) records.get(0).get("dependence"));
        }
        for (Record record : records) {
            confMap.put((String) record.get("key"), (String) record.get("value"));
        }
        String feildJson = confMap.get(ConfKey.FIELD_MAPPING);
//        List<ColumnMappingVo> columnMappingVoList = JSONArray.parseArray(feildJson, ColumnMappingVo.class);
        if (databaseJobConfigVo != null) {
//            databaseJobConfigVo.setColumnMappingVoList(columnMappingVoList);
            databaseJobConfigVo.setColumnMapping(feildJson);

            databaseJobConfigVo.setUserName(confMap.get(ConfKey.USER_NAME));
            String password = confMap.get(ConfKey.USER_PWD);
            if (!StringUtils.isEmpty(password)) {
                String pwdDecode = new String(Base64.decodeBase64(password));
                databaseJobConfigVo.setPassword(pwdDecode);
            }
            databaseJobConfigVo.setSourceTable(confMap.get(ConfKey.SOURCE_TABLE));

            //设置消息提醒
            databaseJobConfigVo.setSmsReminding(confMap.get(ConfKey.SMS_REMINDING));
            databaseJobConfigVo.setEmailReminding(confMap.get(ConfKey.EMAIL_REMINDING));
            //HBASE
            if (databaseJobConfigVo.getDbType() == DataSourceType.HBASE.getValue()) {
                databaseJobConfigVo.setPort(confMap.get(ConfKey.PORT));
                databaseJobConfigVo.setServerIp(confMap.get(ConfKey.SERVER_IP));
            } else {
                JDBCVo jdbcVo = new JDBCVo();
                jdbcVo.setType(databaseJobConfigVo.getDbType());
                jdbcVo.setUrl(confMap.get(ConfKey.SERVER_IP));
                jdbcVo.setPort(confMap.get(ConfKey.PORT));
                jdbcVo.setDatabaseName(confMap.get(ConfKey.DATABASE_NAME));
                Map driverAndUrl = JDBCUtil.getDriverAndUrl(jdbcVo);
                databaseJobConfigVo.setJdbcUrl((String) driverAndUrl.get("jdbcUrl"));
            }
        }

        return databaseJobConfigVo;

    }

    /**
     * webservice配置vo
     *
     * @param records
     * @return
     */
    private WebServiceJobConfigVo initWebService(Result<Record> records) {
        if (records == null) {
            return null;
        }
        WebServiceJobConfigVo webServiceJobConfigVo = null;
        Integer syncStrategy = null;
        Map<String, String> confMap = new HashMap<>();
        if (records.size() > 0) {
            webServiceJobConfigVo = new WebServiceJobConfigVo();
            webServiceJobConfigVo.setDistDbType(DbTypeUtil.getTypeByDb(distdbtype)); //目标表类型
            webServiceJobConfigVo.setTaskId(records.get(0).get(T_JOB.ID));
            syncStrategy = (Integer) records.get(0).get("sync_strategy");
            webServiceJobConfigVo.setSyncStrategy(syncStrategy);
            webServiceJobConfigVo.setDistTable((String) records.get(0).get("dist_table"));
            webServiceJobConfigVo.setImportMode((Integer) records.get(0).get("import_mode"));
            webServiceJobConfigVo.setPriority((Integer) records.get(0).get("priority"));
            webServiceJobConfigVo.setDependence((String) records.get(0).get("dependence"));
        }
        for (Record record : records) {
            confMap.put((String) record.get("key"), (String) record.get("value"));
        }

        //响应RespContentType
        String respContentType = confMap.get(ConfKey.RESPCONTENTTYPE);

//        if(respContentType.contains("application/xml")){
//            webServiceJobConfigVo.setRespContentType(1);
//        }

        //设置字段映射
        String feildJson = confMap.get(ConfKey.FIELD_MAPPING);
//        List<ColumnMappingVo> columnMappingVoList = JSONArray.parseArray(feildJson, ColumnMappingVo.class);

        if (webServiceJobConfigVo != null) {
//            webServiceJobConfigVo.setColumnMappingVoList(columnMappingVoList);
            webServiceJobConfigVo.setColumnMapping(feildJson);

            webServiceJobConfigVo.setUrl(confMap.get(ConfKey.REQUEST_URL));
            webServiceJobConfigVo.setBody(confMap.get(ConfKey.BODY));
            webServiceJobConfigVo.setMethod(confMap.get(ConfKey.REQUEST_METHOD));
            webServiceJobConfigVo.setDataPath(confMap.get(ConfKey.DATAPATH));//设置dataPath
            //设置headers
            String headersJson = confMap.get(ConfKey.HEADERS);
            if (!StringUtils.isEmpty(headersJson)) {
                webServiceJobConfigVo.setHeaders((Map<String, String>) JSON.parseObject(headersJson, Map.class));
            }
            webServiceJobConfigVo.setRespContentType(21);
            //设置消息提醒
            webServiceJobConfigVo.setSmsReminding(confMap.get(ConfKey.SMS_REMINDING));
            webServiceJobConfigVo.setEmailReminding(confMap.get(ConfKey.EMAIL_REMINDING));
        }

        return webServiceJobConfigVo;
    }

    /**
     * 文件配置vo
     *
     * @param records
     * @return
     */
    private FileJobConfigVo initFile(Result<Record> records) {
        if (records == null) {
            return null;
        }
        FileJobConfigVo fileJobConfigVo = new FileJobConfigVo();
        Map<String, String> confMap = new HashMap<>();

        for (Record record : records) {
            confMap.put((String) record.get("key"), (String) record.get("value"));
        }
        if (records.size() > 0) {
            fileJobConfigVo = new FileJobConfigVo();
            fileJobConfigVo.setDistDbType(DbTypeUtil.getTypeByDb(distdbtype)); //目标表类型
            fileJobConfigVo.setTaskId(records.get(0).get(T_JOB.ID));
            Integer syncStrategy = (Integer) records.get(0).get("sync_strategy");
            fileJobConfigVo.setSyncStrategy(syncStrategy);
            fileJobConfigVo.setDistTable((String) records.get(0).get("dist_table"));
            fileJobConfigVo.setImportMode((Integer) records.get(0).get("import_mode"));
            fileJobConfigVo.setPriority((Integer) records.get(0).get("priority"));
            String feildJson = confMap.get(ConfKey.FIELD_MAPPING);
//            List<ColumnMappingVo> columnMappingVoList = JSONArray.parseArray(feildJson, ColumnMappingVo.class);
//            fileJobConfigVo.setColumnMappingVoList(columnMappingVoList);
            fileJobConfigVo.setColumnMapping(feildJson);
            fileJobConfigVo.setRedisPort(redisPort);
            fileJobConfigVo.setRedisHost(redisHost);
            fileJobConfigVo.setRedisIndex(redisIndex);
        }
//        fileJobConfigVo.setData(null);
        return fileJobConfigVo;
    }


    @Override
    public ResultVo<Integer> getlastSyncResult(BigDecimal jobId) {

        TJobRecord record = jobDao.findById(jobId);
        Integer latestScheduleState = record.getLatestScheduleState();
        latestScheduleState = latestScheduleState == null ? -1 : latestScheduleState;
        String msg = "";
        switch (latestScheduleState) {
            case 1:
                msg = "正在引接";
                break;
            case 2:
                msg = "引接成功";
                break;
            case 3:
                msg = "引接失败";
                break;
            default:
                msg = "引接任务从未执行";
                break;
        }

        return new ResultVo<>(0, latestScheduleState, msg);
    }

    @Override
    public ResultVo<DbMoveResVo> dbmove(DbMoveVo dbMoveVo, String userId) throws Exception {
        List<String> tableNames = dbMoveVo.getTableNames();
        BigDecimal dataSourceId = dbMoveVo.getDataSourceId();
        BigDecimal logicPartitionId = dbMoveVo.getLogicPartitionId();
        Integer metadataType = dbMoveVo.getMetadataType();
        Integer priority = dbMoveVo.getPriority();
        String name = dbMoveVo.getName();
        //获取数据源中的所有表
        JDBCVo jdbcVo = new JDBCVo();
        jdbcVo.setDataSourceId(dataSourceId);
        ResultVo<List<TablesVo>> queryTableNameVo = dataSourceService.queryTableName(jdbcVo);
        if (queryTableNameVo.getErrorCode() != 0) {
            return new ResultVo<>(ErrorCode.UnknownError.getErrorCode(), null, "查询该数据源下的表时出现异常");
        }
        if (queryTableNameVo.getData().size() == 0) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), null, "该数据源下没有表");
        }

        //创建引接任务
        TJobRecord jobRecord = new TJobRecord();
        BigDecimal jobId = BigDecimal.valueOf(idGeneratorService.id());
        jobRecord.setId(jobId);
        jobRecord.setName(name);
        jobRecord.setDistTableSource(Short.parseShort("1"));
        jobRecord.setLogicPartitionId(logicPartitionId);
        jobRecord.setImportMode(1);
        jobRecord.setPriority(priority);
        jobRecord.setDataSourceId(dataSourceId);
        jobRecord.setUpdateUser(userId);
        jobRecord.setCreateUser(userId);
        jobRecord.setState(1);
        jobRecord.setStatus(RecordStatus.Effective.getStatus());
        //保存引接任务
        jobDao.insert(jobRecord);
        JobBaseConfigVo jobConfigVo = getJobConfigVo(jobId, JobServiceUtil.IS_DB);
        if (jobConfigVo == null) {
            throw new Exception("引接任务创建失败！");
        }
        //在目标数据源中创建表
        List<TablesVo> tablesVos = queryTableNameVo.getData();
        int tableSum = tablesVos.size();
        jobConfigVo.setDbMoveJobId(jobId);
        jobConfigVo.setDbMoveTableCount(tableSum);
//        jobConfigVo.setDistJdbcUrl("jdbc:hive2://192.168.55.11:10000/nc_yiliao2");
        String json = JSON.toJSONString(jobConfigVo);
        List<String> tables = tableNames;//Arrays.asList(tablesArr);
        if (tables != null && tables.size() > 0) {
            jobConfigVo.setDbMoveTableCount(tables.size());
        }

        TJobConfRecord conf = new TJobConfRecord();
        conf.setId(BigDecimal.valueOf(idGeneratorService.id()));
        conf.setKey(ConfKey.DBMOVE_TABLE_COUNT);
        conf.setValue(jobConfigVo.getDbMoveTableCount() + "");
        conf.setRefId(jobId);
        conf.setType(ConfType.JOB.getValue());
        jobConfDao.insert(conf);

        //线程池创建
        ExecutorService fixedThreadPool = Executors.newFixedThreadPool(2);
        for (TablesVo tablesVo : tablesVos) {
            if (tables != null && tables.size() > 0 && !tables.contains(tablesVo.getTableName())) {
                continue;
            }
            logger.info("table : " + tablesVo.getTableName());
            fixedThreadPool.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (StringUtils.isEmpty(json)) {
                            return;
                        }
                        DatabaseJobConfigVo databaseJobConfigVo = JSON.parseObject(json, DatabaseJobConfigVo.class);
                        if (databaseJobConfigVo == null) {
                            return;
                        }
                        ItemAddAllsVo itemAddAllsVo = getItemAddAllsVo(dataSourceId, tablesVo, metadataType, logicPartitionId);
                        if (itemAddAllsVo == null) {
                            return;
                        }
                        itemAddAllsVo.setFlag(Boolean.FALSE);
                        ResultVo<Object> objectResultVo = itemService.addAlls(itemAddAllsVo, userId, false);
                        if (objectResultVo.getErrorCode() != 0) {
                            logger.info(tablesVo.getTableName() + objectResultVo.getData());
                            return;
                        }
                        List<ColumnMappingVo> columnMappingVos = new ArrayList<>();
                        ColumnMappingVo columnMappingVo = null;
                        List<DetailAddVo> detailAddVoList = itemAddAllsVo.getDetailAddVoList();
                        for (DetailAddVo detailAddVo : detailAddVoList) {
                            columnMappingVo = new ColumnMappingVo();
                            columnMappingVo.setSource(detailAddVo.getColName());
                            columnMappingVo.setDist(detailAddVo.getColDisplayname());
                            columnMappingVo.setDistDataType(detailAddVo.getColType() == 302 ? "BIGINT" : "VARCHAR");
                            columnMappingVos.add(columnMappingVo);
                        }
                        TJobConfRecord confRecord = new TJobConfRecord();
                        confRecord.setId(BigDecimal.valueOf(idGeneratorService.id()));
                        confRecord.setKey(tablesVo.getTableName() + ":" + itemAddAllsVo.getName());
                        confRecord.setValue(JSON.toJSONString(columnMappingVos));
                        confRecord.setRefId(jobId);
                        confRecord.setType(ConfType.JOB.getValue());
                        jobConfDao.insert(confRecord);
                        databaseJobConfigVo.setPreProcessProcessor(new ETLJobPreProcessor());
                        databaseJobConfigVo.setDistTable(itemAddAllsVo.getName());
                        databaseJobConfigVo.setSourceTable(tablesVo.getTableName());
                        databaseJobConfigVo.setColumnMapping(JSON.toJSONString(columnMappingVos));
                        databaseJobConfigVo.setTaskId(jobId);
                        logger.info("************************" + itemAddAllsVo.getName());
                        AsyncTaskConfigVo asyncTaskConfigVo = JobServiceUtil.getAsyncTaskConfigVo(databaseJobConfigVo);
                        asyncTaskExecuteService.execute(asyncTaskConfigVo, true);
                    } catch (Exception e) {
                        e.printStackTrace();
                        logger.info(e.getMessage());
                    }
                }
            });
        }
        fixedThreadPool.shutdown();
        return new ResultVo<>(0, new DbMoveResVo(jobId, jobConfigVo.getDbMoveTableCount()), "SUCCESS");
    }

    @Override
    public ResultVo<DbMoveResVo> dbmoveNew(DbMoveVo dbMoveVo, String userId) throws Exception {

        BigDecimal dataSourceId = dbMoveVo.getDataSourceId();
        BigDecimal logicPartitionId = dbMoveVo.getLogicPartitionId();
        Integer metadataType = dbMoveVo.getMetadataType();
        Integer priority = dbMoveVo.getPriority();
        String name = dbMoveVo.getName();
        //获取数据源中的所有表
        JDBCVo jdbcVo = new JDBCVo();
        jdbcVo.setDataSourceId(dataSourceId);
        ResultVo<List<TablesVo>> queryTableNameVo = dataSourceService.queryTableName(jdbcVo);
        if (queryTableNameVo.getErrorCode() != 0) {
            return new ResultVo<>(ErrorCode.UnknownError.getErrorCode(), null, "查询该数据源下的表时出现异常");
        }
        if (queryTableNameVo.getData().size() == 0) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), null, "该数据源下没有表");
        }

        //创建引接任务
        TJobRecord jobRecord = new TJobRecord();
        BigDecimal jobId = BigDecimal.valueOf(idGeneratorService.id());
        jobRecord.setId(jobId);
        jobRecord.setName(name);
        jobRecord.setDistTableSource(Short.parseShort("1"));
        jobRecord.setLogicPartitionId(logicPartitionId);
        jobRecord.setImportMode(1);
        jobRecord.setPriority(priority);
        jobRecord.setDataSourceId(dataSourceId);
        jobRecord.setUpdateUser(userId);
        jobRecord.setCreateUser(userId);
        jobRecord.setState(1);
        jobRecord.setStatus(RecordStatus.Effective.getStatus());
        //保存引接任务
        jobDao.insert(jobRecord);
        JobBaseConfigVo jobConfigVo = getJobConfigVo(jobId, JobServiceUtil.IS_DB);
        if (jobConfigVo == null) {
            throw new Exception("引接任务创建失败！");
        }
        //在目标数据源中创建表
        List<TablesVo> tablesVos = queryTableNameVo.getData();
        int tableSum = tablesVos.size();
        jobConfigVo.setDbMoveJobId(jobId);
        jobConfigVo.setDbMoveTableCount(tableSum);
        String json = JSON.toJSONString(jobConfigVo);
        //线程池创建
        ExecutorService fixedThreadPool = Executors.newFixedThreadPool(5);
        //保存元数据
        for (TablesVo tablesVo : tablesVos) {
            logger.info("table : " + tablesVo.getTableName());
            fixedThreadPool.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (StringUtils.isEmpty(json)) {
                            return;
                        }
                        ItemAddAllsVo itemAddAllsVo = getItemAddAllsVo(dataSourceId, tablesVo, metadataType, logicPartitionId);
                        if (itemAddAllsVo == null) {
                            return;
                        }
                        ResultVo<Object> objectResultVo = itemService.addAlls(itemAddAllsVo, userId, false);
                        if (objectResultVo.getErrorCode() != 0) {
                            logger.info(tablesVo.getTableName() + objectResultVo.getData());
                            return;
                        }
                        List<ColumnMappingVo> columnMappingVos = new ArrayList<>();
                        ColumnMappingVo columnMappingVo = null;
                        List<DetailAddVo> detailAddVoList = itemAddAllsVo.getDetailAddVoList();
                        for (DetailAddVo detailAddVo : detailAddVoList) {
                            columnMappingVo = new ColumnMappingVo();
                            columnMappingVo.setSource(detailAddVo.getColName());
                            columnMappingVo.setDist(detailAddVo.getColDisplayname());
                            columnMappingVo.setDistDataType(detailAddVo.getColType() == 302 ? "BIGINT" : "VARCHAR");
                            columnMappingVos.add(columnMappingVo);
                        }
                        TJobConfRecord confRecord = new TJobConfRecord();
                        confRecord.setId(BigDecimal.valueOf(idGeneratorService.id()));
                        confRecord.setKey(tablesVo.getTableName() + ":" + itemAddAllsVo.getName());
                        confRecord.setValue(JSON.toJSONString(columnMappingVos));
                        confRecord.setRefId(jobId);
                        confRecord.setType(ConfType.JOB.getValue());
                        jobConfDao.insert(confRecord);
                        logger.info("************************" + itemAddAllsVo.getName());
                    } catch (Exception e) {
                        e.printStackTrace();
                        logger.info(e.getMessage());
                    }
                }
            });
        }
        fixedThreadPool.shutdown();

//        noteBookTask.run(jobConfigVo);
        AsyncTaskConfigVo asyncTaskConfigVo = JobServiceUtil.getAsyncTaskConfigVo(jobConfigVo);
        asyncTaskExecuteService.execute(asyncTaskConfigVo, true);

        return new ResultVo<>(0, new DbMoveResVo(jobId, tableSum), "SUCCESS");
    }

    @Override
    public ResultVo<List<DbMoveRedisVo>> dbmoveResult(BigDecimal id) {
        Map<String, String> data = redisService.hmGetAll(id.toString());
        List<DbMoveRedisVo> listData = new ArrayList<>();

        Set<String> keySet = data.keySet();
        if (keySet.size() == 0) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), null, "没有记录");
        }
        String s = null;
        DbMoveRedisVo dbMoveRedisVo = null;
        for (String k : keySet) {
            s = data.get(k);
            dbMoveRedisVo = JSON.parseObject(s, DbMoveRedisVo.class);
            listData.add(dbMoveRedisVo);
        }
        return new ResultVo<>(0, listData);
    }

    private ItemAddAllsVo getItemAddAllsVo(BigDecimal dataSourceId, TablesVo tablesVo, Integer metadataType, BigDecimal logicPartitionId) {
        String tableName = tablesVo.getTableName();
        //通过tableName获取该表下的所有字段
        JDBCVo jdbcVo = new JDBCVo();
        jdbcVo.setTableName(tableName);
        jdbcVo.setDataSourceId(dataSourceId);
        ResultVo<List<TableAndFieldVo>> listResultVo = dataSourceService.queryTableFilelds(jdbcVo);
        List<TableAndFieldVo> fieldVos = listResultVo.getData();
        TableAndFieldVo tableAndFieldVo = null;
        if (fieldVos.size() > 0) {
            tableAndFieldVo = fieldVos.get(0);
        }
        if (tableAndFieldVo == null) {
            return null;
        }
        List<FieldsVo> fields = tableAndFieldVo.getFields();

        List<DetailAddVo> detailAddVos = new ArrayList<>();
        String fieldName = null;
        String fieldType = null;
        Integer colType = null;
        DetailAddVo detailAddVo = null;
        int index = 1;
        for (FieldsVo fieldsVo : fields) {
            fieldName = fieldsVo.getFieldName();
            fieldType = fieldsVo.getFieldType();
            colType = JobServiceUtil.hiveFeildTypeConvert(fieldType);
            detailAddVo = new DetailAddVo();
            detailAddVo.setMetadataItemId(logicPartitionId);
            detailAddVo.setColDisplayname(fieldName);
            detailAddVo.setColName(fieldName);
            detailAddVo.setColType(colType);
            detailAddVo.setIndex(index);
            detailAddVos.add(detailAddVo);
            index++;
        }
        //调用元数据接口创建表
        ItemAddAllsVo itemAddAllsVo = new ItemAddAllsVo();
        itemAddAllsVo.setThemeItemId(logicPartitionId);
        if (metadataType == null) {
            metadataType = 201;
        }
        itemAddAllsVo.setType(metadataType);
        itemAddAllsVo.setDetailAddVoList(detailAddVos);
        itemAddAllsVo.setName(tableName);
//        itemAddAllsVo.setName(tableName + "_mv12");
        return itemAddAllsVo;
    }

    @Override
    public ResultVo<List<MappingVo>> getTableMapping(BigDecimal jobId) throws Exception {
        List<MappingVo> mappingVos = new ArrayList<>();
        ResultVo<JobDetailVo> jobDetailVoResultVo = findById(jobId);
        JobDetailVo data = jobDetailVoResultVo.getData();
        List<JobConfDetailVo> confs = data.getConfs();

        String sourceTableName = null;
        String distTable = data.getDistTable();

        if (StringUtils.isEmpty(distTable)) {
            //是数据库迁移
            MappingVo mappingVo = null;
            for (JobConfDetailVo conf : confs) {
                String key = conf.getKey();
                String[] split = key.split(":");
                mappingVo = new MappingVo();
                mappingVo.setSource(split[0]);
                mappingVo.setDist(split[1]);
                mappingVos.add(mappingVo);
            }
        } else {
            for (JobConfDetailVo conf : confs) {
                if (ConfKey.SOURCE_TABLE.equals(conf.getKey())) {
                    sourceTableName = conf.getValue();
                }
            }
            MappingVo mappingVo = new MappingVo();
            mappingVo.setDist(distTable);
            mappingVo.setSource(sourceTableName);
            mappingVos.add(mappingVo);
        }
        return new ResultVo<>(0, mappingVos);
    }

    @Override
    public ResultVo<TableMappingVo> getTablefieldMapping(BigDecimal jobId, String table) throws Exception {
        List<MappingVo> mappingVos = new ArrayList<>();
        ResultVo<JobDetailVo> jobDetailVoResultVo = findById(jobId);
        JobDetailVo data = jobDetailVoResultVo.getData();
        List<JobConfDetailVo> confs = data.getConfs();
        String distTable = data.getDistTable();
        String colsJson = null;
        MappingVo mappingVo = null;
        if (StringUtils.isEmpty(distTable)) {
            for (JobConfDetailVo conf : confs) {
                String key = conf.getKey();
                String value = conf.getValue();
                String[] split = key.split(":");
                String source = split[0];
                if (table.equals(source)) {
                    distTable = split[1];
                    colsJson = value;
                    break;
                }
            }
        } else {
            for (JobConfDetailVo conf : confs) {
                if (ConfKey.FIELD_MAPPING.equals(conf.getKey())) {
                    colsJson = conf.getValue();
                }
                if (ConfKey.SOURCE_TABLE.equals(conf.getKey())) {
                    table = conf.getValue();
                }
            }
        }

        if (!StringUtils.isEmpty(colsJson)) {
            List<ColumnMappingVo> columnMappingVoList = JSONArray.parseArray(colsJson, ColumnMappingVo.class);
            for (ColumnMappingVo columnMapping : columnMappingVoList) {
                mappingVo = new MappingVo();
                mappingVo.setSource(columnMapping.getSource());
                mappingVo.setDist(columnMapping.getDist());
                mappingVos.add(mappingVo);
            }
        }

        TableMappingVo tableMappingVo = new TableMappingVo();
        tableMappingVo.setSrcTable(table);
        tableMappingVo.setDisTable(distTable);
        tableMappingVo.setMappingVoList(mappingVos);

        return new ResultVo<>(0, tableMappingVo);
    }

    @Override
    public List<IdNameVO> findSelectableDependenceJob(String name, String type) {
        switch (type) {
            case "clear":
                return clearTaskDao.findSelectableDependenceJob(name).stream().map(r -> new IdNameVO(r.value1(), r.value2())).collect(Collectors.toList());
            case "etl":
                return jobDao.findSelectableDependenceJob(name).stream().map(r -> new IdNameVO(r.value1(), r.value2())).collect(Collectors.toList());
            default:
                return new ArrayList<>();
        }
    }

    @Override
    public void jobFinishedCallBack(JobFinishedResponseVO resp) {
        BigDecimal jobId = BigDecimal.valueOf(Long.parseLong(resp.getTaskId()));
        JobDao jobDao = SpringUtil.getBean(JobDao.class);
        TJobRecord jobRecord = jobDao.findById(jobId);
        if(resp.getSuccess()!=null && resp.getSuccess() && resp.getSuccessRows() !=null && resp.getSuccessRows()>0 && StringUtil.isNotEmpty(resp.getTargetTable())){
            clearChartCache(resp.getTargetTable());
        }
        //数据存储的响应
        if (jobRecord == null) {
            redisService.put(RedisKey.DATASTORAGE_RESULT + resp.getTaskId(), JSON.toJSONString(resp), 60);
            return;
        }
        try {
            updateJobScheduleResult(resp);
        } catch (Exception e) {
            e.printStackTrace();
        }
        sendMessage(jobRecord.getName(), resp.getSuccess()==null?false:resp.getSuccess(), jobId, resp.getSuccessRows());

    }

    private void updateJobScheduleResult(JobFinishedResponseVO resp) throws Exception {
        BigDecimal jobId = BigDecimal.valueOf(Long.parseLong(resp.getTaskId()));
        ScheduleLogAddVo addVo = new ScheduleLogAddVo();
        addVo.setJobId(jobId);
        if(StringUtil.isNotEmpty(resp.getLogId())){
            addVo.setId(new BigDecimal(resp.getLogId()));
        }
        addVo.setScheduleEndtime(new Timestamp(System.currentTimeMillis()));
        addVo.setScheduleState(resp.getSuccess() == null || !resp.getSuccess() ? JobState.Fail.getValue() : JobState.Success.getValue());
        addVo.setScheduleLog(resp.getErrorMsg());
        addVo.setSuccessRows(resp.getSuccessRows());
        addVo.setJobId(jobId);
        scheduleLogService.saveOrUpdate(addVo);
    }

    private void sendMessage(String jobName, boolean success, BigDecimal jobId, Long successRows) {
        try {
            Result<TJobConfRecord> records = jobConfDao.findByRefId(jobId, ConfType.MESSAGE.getValue());
            for (TJobConfRecord record : records) {
                String key = record.getKey();
                //邮箱
                String emailReminding = null;
                if (ConfKey.EMAIL_REMINDING.equals(key)) {
                    emailReminding = record.getValue();
                }
                //
                String smsReminding = null;
                if (ConfKey.SMS_REMINDING.equals(key)) {
                    smsReminding = record.getValue();
                }
                String[] smsPhones = null;
                String[] emails = null;
                if (!org.apache.commons.lang.StringUtils.isEmpty(smsReminding)) {
                    smsPhones = smsReminding.split(",");
                }
                if (!org.apache.commons.lang.StringUtils.isEmpty(emailReminding)) {
                    emails = emailReminding.split(",");
                }

                String formatDate = DateUtils.format(new Date(), DateUtils.DATE_TIME_PATTERN);

                String result = success ? "成功" : "失败";
                if (smsPhones != null && smsPhones.length > 0) {
                    //发送短信
                    for (String phone : smsPhones) {
                        smsService.sendETLJobNotice(phone, jobName, formatDate, result, successRows + "");
                    }
                }
                if (emails != null && emails.length > 0) {
                    String content = "[金控征信大数据基础平台]引接任务(JOB_NAME)执行完毕，完成时间(COMPLETE_TIME),结果(IS_SUCCESS),引接数据量(DATA_COUNT)";
                    content = content.replace("(JOB_NAME)", jobName)
                            .replace("(COMPLETE_TIME)", formatDate)
                            .replace("(IS_SUCCESS)", result)
                            .replace("(DATA_COUNT)", successRows == null ? "" : String.valueOf(successRows));
                    String subject = "【成都金控征信有限公司-大数据基础平台消息提醒】";
                    for (String email : emails) {
                        EmailUtil.sendHtmlMail(email, subject, content);
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void refreshHiveTable(String tableName){
        String hiveIP= PropertyUtil.getMergedProperty("dist.ip");
        String hivePort=PropertyUtil.getMergedProperty("dist.port");
        String userName=PropertyUtil.getMergedProperty("dist.username");
        String password=PropertyUtil.getProperty("dist.password");
        if(StringUtil.isEmpty(hiveIP)||StringUtil.isEmpty(hivePort)||StringUtil.isEmpty(userName)){
            logger.error("dist.ip,port,username not config!");
            return;
        }
        String sql="REFRESH TABLE "+tableName;
        String jdbcUrl="jdbc:hive2://"+hiveIP+":"+hivePort;
        logger.info("sql="+sql);
        logger.info("jdbcUrl="+jdbcUrl);
        try {
            JDBCUtil.executeUpdate(sql,"org.apache.hive.jdbc.HiveDriver",jdbcUrl,userName,password);
        } catch (SQLException e) {
            logger.error(" execute refresh table fail",e);
            e.printStackTrace();
        }
        logger.info("refresh table success");
    }

    @Override
    public void clearChartCache(String tableName){
        //查询analyzeMapInfoUuid
        List<String> analyzeMapInfoUuids = analyzeMapInfoDao.getUuidBySchemaAndTableName("default", tableName);
        //查询chartId
        List<ChartInfoRecord> chartInfoRecords = chartInfoDao.fetch(ChartInfo.CHART_INFO.ANALYZE_MAP_INFO_UUID, analyzeMapInfoUuids);
        if (chartInfoRecords!=null && chartInfoRecords.size()>0){
            //准备需要删除的rediskey
            List<String> deleteRedisKeys=new ArrayList<>();
            for (ChartInfoRecord item:chartInfoRecords) {
                String redisKey="chartExecute."+item.getChartUuid();
                deleteRedisKeys.add(redisKey);

            }
            if (deleteRedisKeys.size()>0){
                logger.info("删除clearTaskFinished任务表的rediskey:"+deleteRedisKeys.toString());
                String[] strings = new String[deleteRedisKeys.size()];
                redisService.batchDelete(0,deleteRedisKeys.toArray(strings));
            }
        }
    }

}