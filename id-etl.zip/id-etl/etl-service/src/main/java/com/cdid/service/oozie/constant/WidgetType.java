package com.cdid.service.oozie.constant;


public enum  WidgetType {

    INPUT,RADIO,CHECKBOX;
}
