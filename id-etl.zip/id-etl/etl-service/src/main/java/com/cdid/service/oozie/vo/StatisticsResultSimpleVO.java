package com.cdid.service.oozie.vo;

public class StatisticsResultSimpleVO {

    private String dimensionValue;

    private Integer statisticsValue;

    public String getDimensionValue() {
        return dimensionValue;
    }

    public void setDimensionValue(String dimensionValue) {
        this.dimensionValue = dimensionValue;
    }

    public Integer getStatisticsValue() {
        return statisticsValue;
    }

    public void setStatisticsValue(Integer statisticsValue) {
        this.statisticsValue = statisticsValue;
    }

    public StatisticsResultSimpleVO() {
    }

    public StatisticsResultSimpleVO(String dimensionValue, Integer statisticsValue) {
        this.dimensionValue = dimensionValue;
        this.statisticsValue = statisticsValue;
    }
}
