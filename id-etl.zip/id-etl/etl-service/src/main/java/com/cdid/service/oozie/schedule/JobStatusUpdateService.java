package com.cdid.service.oozie.schedule;

import com.cdid.dao.oozie.OozieJobDao;
import com.cdid.dao.oozie.OozieJobLogDao;
import com.cdid.service.oozie.OozieJobService;
import com.cdid.service.oozie.util.OozieUtil;
import com.cdid.utils.StringUtil;
import org.apache.oozie.client.OozieClientException;
import org.apache.oozie.client.WorkflowJob;
import org.quartz.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.io.IOException;


@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class JobStatusUpdateService implements Job {

    public  static final String JOB_DATA_KEY="OOZIE_JOB_ID";

    @Autowired
    OozieJobLogDao logDao;

    @Autowired
    OozieJobDao jobDao;

    @Resource
    private Scheduler scheduler;

    @Autowired
    private OozieJobService jobService;

    public void execute(JobExecutionContext context) throws JobExecutionException {
        String oozieJobId=context.getJobDetail().getJobDataMap().getString(JOB_DATA_KEY);
        if(StringUtil.isEmpty(oozieJobId)){
            return;
        }
        WorkflowJob job=null;
        try {
             job= OozieUtil.getJob(oozieJobId);
             if(job==null){
                 return;
             }
            WorkflowJob.Status status=job.getStatus();
            try {
                jobService.upateJobStatus(oozieJobId,status.name(),job.getEndTime());
            } catch (Exception e) {
                e.printStackTrace();
            }
            if(!status.equals(WorkflowJob.Status.RUNNING)){
                try {
                    scheduler.deleteJob(JobKey.jobKey(oozieJobId));
                } catch (SchedulerException e) {
                    e.printStackTrace();
                }
            }
        } catch (OozieClientException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
