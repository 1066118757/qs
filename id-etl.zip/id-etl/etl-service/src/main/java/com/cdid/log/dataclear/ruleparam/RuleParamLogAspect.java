package com.cdid.log.dataclear.ruleparam;

import com.alibaba.fastjson.JSON;
import com.cdid.api.operate.operatelog.OperateLogService;
import com.cdid.api.operate.operatelog.vo.OperateLogAddVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.token.AccessTokenDao;
import com.cdid.log.GetUserIdUtil;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashSet;
import java.util.Set;

/**
 * @Author LQL
 * @CreateAt 2017/11/29
 */

@Aspect
@Component
public class RuleParamLogAspect {
    @Resource
    private OperateLogService operateLogService;
    @Resource
    private AccessTokenDao accessTokenDao;

    private static Logger logger = LoggerFactory.getLogger(RuleParamLogAspect.class);

    private Set<String> tableName = new HashSet();

    // controller层切点
    @Pointcut("(execution(public * com.cdid.api.dataclear.ruleparam.RuleParamService.*(..)))")
    public void ruleParamAspect() {
    }

    @Before("ruleParamAspect()")
    public void beforeRuleParam(JoinPoint joinPoint) {
        try {
            logger.info("=====beforeRuleParamAspect前置通知开始=====");
            logger.info("请求Param：" + joinPoint.getArgs());
            tableName.add(JSON.toJSONString(joinPoint.getArgs()[0]));
        } catch (Exception e) {
            logger.error("=====beforeRuleParamAspect前置异常通知====");
            logger.error(e.getMessage());
        }
    }

    @AfterReturning(pointcut = "ruleParamAspect()", returning = "retValue")
    public void afterRuleParam(JoinPoint joinPoint, Object retValue) {
        try {
            //从请求中获取userId
            String userId = GetUserIdUtil.getUserId();
            logger.info("=====afterRuleParam后置通知开始=====");
            String className = joinPoint.getTarget().getClass().getName();
            String methodName = joinPoint.getSignature().getName() + "()";
            logger.info("请求方法:" + className);
            logger.info("请求人:" + userId);
            Integer result=0;
            try{
                result  = ((ResultVo) retValue).getErrorCode();
            }catch (Exception e){
            }
            logger.info("返回值：" + result);
            //写入数据库
            logger.info("====写入operateAction====");
            OperateLogAddVo operateLogAddVo = new OperateLogAddVo();
            Integer actionId;
            switch (methodName){
                case "add()":actionId=701;break;
                case "update()":actionId=702;break;
                case "delete()":actionId=703;break;
                case "list()":actionId=704;break;
                case "ruleParamById()":actionId=705;break;
                case "deleteByRuleId()":actionId=706;break;
                case "listByRuleId()":actionId=707;break;
                default:actionId=700;
            }
            operateLogAddVo.setActionId(actionId);
            operateLogAddVo.setOperatorId(userId);
            operateLogAddVo.setResult(result);
            //操作表暂定为前接口对应表
            operateLogAddVo.setOperateTable("t_rule_param");
            operateLogService.add(operateLogAddVo);
            logger.info("====写入operateLog====");
            /*for (String table : tableName
                    ) {
                logger.info("操作表: " + table);
                operateLogAddVo.setOperateTable(table);
                operateLogService.add(operateLogAddVo);
                logger.info("====写入operateLog====");
            }*/
        } catch (Exception e) {
            logger.error("=====afterRuleParam后置异常通知====");
            logger.error(e.getMessage());
        } finally {
            tableName.clear();
        }
    }
}
