package com.cdid.service.oozie;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.cdid.api.common.IDGeneratorService;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.config.PropertyUtil;
import com.cdid.dao.oozie.*;
import com.cdid.dao.user.UsersDao;
import com.cdid.jooq.tables.*;
import com.cdid.jooq.tables.records.*;
import com.cdid.service.oozie.constant.ProgramType;
import com.cdid.service.oozie.util.HDFSIO;
import com.cdid.service.oozie.util.RunShellGenerator;
import com.cdid.service.oozie.vo.*;
import com.cdid.utils.StringUtil;
import com.cdid.utils.VoReTraversalUtil;
import com.cdid.utils.excel.ExcelUtils;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.jooq.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class ProgramService {

    @Autowired
    ProgramDao programDao;

    @Autowired
    UsersDao usersDao;

    @Autowired
    IDGeneratorService<Long> idService;

    @Autowired
    GroupDao groupDao;

    @Autowired
    GroupUserDao groupUserDao;

    @Autowired
    ShareDao shareDao;

    @Autowired
    TreeObjectDao treeObjectDao;

    @Autowired
    OozieObjectTreeService treeService;


    public ResultVo<BigDecimal> createOrUpdateProgram(ProgramVO programVO,String currentUserId) throws IOException {
        if(programVO==null||StringUtil.anyIsEmpty(programVO.getPersonalConf(),programVO.getName(),programVO.getPath())){
            return new ResultVo<>(ErrorCode.ParamError.getErrorCode());
        }
        TProgramRecord program=VoReTraversalUtil.traversalTo(programVO,TProgramRecord.class);
        program.setFilename(programVO.getFileName());
        if(program == null){
            return new ResultVo<>(ErrorCode.TransformFailed.getErrorCode());
        }
        program.setProgramtype(programVO.getProgramType());
        if(ProgramType.SHELL.name().equals(programVO.getProgramType())){
            String runShell=new RunShellGenerator().generate();
            HDFSIO.upload(programVO.getPath()+"/run.sh",runShell,true);
        }
        Timestamp now=new Timestamp(System.currentTimeMillis());
        TreeObjectVO objectVO=new TreeObjectVO();
        objectVO.setObjectType(TreeObjectVO.TreeObjectType.PROGRAM.toString());
        objectVO.setLeafObjectType(TreeObjectVO.LeafObjectType.PROGRAM.toString());
        objectVO.setParentType(TreeObjectVO.TreeParentType.SELF.toString());
        objectVO.setName(program.getName());
        objectVO.setParentId(programVO.getGroupId());
        if(program.getId() == null){
            program.setId(BigDecimal.valueOf(idService.id()));
            program.setCreateTime(now);
            program.setOwner(currentUserId);
            program.setUpdateTime(now);
            program.setParameters(JSON.toJSONString(programVO.getParameters()));
            programDao.insert(program);
            treeService.addTreeObject(objectVO,currentUserId, program.getId());
        }else{
            TProgramRecord dbProgram=programDao.findById(program.getId());
            if(dbProgram==null){
                return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
            }
            program.setCreateTime(dbProgram.getCreateTime());
            program.setUpdateTime(now);
            program.setOwner(dbProgram.getOwner());
            program.setParameters(JSON.toJSONString(programVO.getParameters()));
            treeService.updateTreeObject(objectVO,dbProgram.getName(),program.getId());
            programDao.update(program);
        }
        return new ResultVo<>(0,program.getId());
    }

    public ResultVo deleteProgram(List<BigDecimal> programIdList,boolean fullDelete){
        programDao.deleteById(programIdList);
        shareDao.deleteByConditions(Arrays.asList(TOozieShare.T_OOZIE_SHARE.SOURCE_OBJECT_ID.in(programIdList),TOozieShare.T_OOZIE_SHARE.SOURCE_OBJECT_TYPE.eq(OozieShareVO.SourceObjectType.PROGRAM.toString())));
        treeService.deleteTreeObjects(programIdList,TreeObjectVO.LeafObjectType.PROGRAM.toString());
        if(fullDelete){
            for(BigDecimal programId:programIdList){
                try {
                    HDFSIO.delete(getProgramPath(programId));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return new ResultVo();
    }

    public ResultVo<PageVo<ProgramListVO>> listProgram(ProgramQueryVO queryVO,int page,int size,String userId){
       List<Condition> conditionList=new ArrayList<>();
        if(!StringUtil.isEmpty(queryVO.getName())){
            conditionList.add(TProgram.T_PROGRAM.NAME.like("%"+queryVO.getName()+"%"));
        }
        if(queryVO.getDownloadable()!=null){
            conditionList.add(TProgram.T_PROGRAM.DOWNLOADABLE.eq(queryVO.getDownloadable()));
        }
        if(queryVO.getQueryType().equals(ProgramQueryVO.QueryType.MY.name())){
            conditionList.add(TProgram.T_PROGRAM.OWNER.eq(userId));
        }else if(queryVO.getQueryType().equals(ProgramQueryVO.QueryType.PUBLIC.name())){
            conditionList.add(TProgram.T_PROGRAM.IS_PUBLIC.eq(true));
            conditionList.add(TProgram.T_PROGRAM.OWNER.notEqual(userId));
        }else if(queryVO.getQueryType().equals(ProgramQueryVO.QueryType.SHARE.name())){
            List<String> groupIdList=groupUserDao.fetchFieldByConditions(MGroupUser.M_GROUP_USER.GROUP_ID, Arrays.asList(MGroupUser.M_GROUP_USER.USER_ID.eq(userId)));
            groupIdList.add(userId);
            List<Condition> conditions=Arrays.asList(TOozieShare.T_OOZIE_SHARE.DIST_OBJECT_ID.in(groupIdList),TOozieShare.T_OOZIE_SHARE.SOURCE_OBJECT_TYPE.eq(OozieShareVO.SourceObjectType.PROGRAM.name()));
            List<BigDecimal> programIdList=shareDao.fetchFieldByConditions(TOozieShare.T_OOZIE_SHARE.SOURCE_OBJECT_ID,conditions);
            if(programIdList.isEmpty()){
                return new ResultVo<>(0,new PageVo<>(0,new ArrayList<>()));
            }
            conditionList.add(TProgram.T_PROGRAM.ID.in(programIdList));
        }
        Collection<SortField<?>> sortList=new ArrayList<>();
        sortList.add(TProgram.T_PROGRAM.UPDATE_TIME.desc());
        PageVo<Record7<BigDecimal,String,Boolean,Boolean,String,String,Timestamp>> programPage=programDao.findByPage(conditionList,new OffsetPagingVo(page,size),sortList);
        List<ProgramListVO> content=programPage.getPageData().stream().map(record -> {
            ProgramListVO listVO=new ProgramListVO();
            listVO.setCreateTime(record.value7().getTime());
            listVO.setCreator(record.value6());
            listVO.setProgramType(record.value5());
            listVO.setDownloadable(record.value4());
            listVO.setIsPublic(record.value3());
            listVO.setName(record.value2());
            listVO.setId(record.value1());
            return listVO;

        }).collect(Collectors.toList());
        return new ResultVo<>(0,new PageVo<>(programPage.getTotalCount(),content));

    }

    public ResultVo<ProgramVO> findById(BigDecimal id){
        TProgramRecord record=programDao.findById(id);
        if(record == null){
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
        }
        return new ResultVo<>(0,ProgramVO.valueOf(record));
    }

    public String getProgramPath(BigDecimal programId){
        return PropertyUtil.getMergedProperty("hdfs.programPath","/PROGRAM/")+String.valueOf(programId);
    }

    public ResultVo<Boolean> setSystemProgram(BigDecimal programId,String operate,BigDecimal parentId){
        TProgramRecord dbProgram=programDao.findById(programId);
        if(dbProgram==null){
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
        }
        switch (operate){
            case "create" :
                dbProgram.setIsPublic(true);
                break;
            default:
                dbProgram.setIsPublic(false);
                break;
        }
        programDao.update(dbProgram);
        List<Condition> conditionList=new ArrayList<>();
        conditionList.add(TTreeObject.T_TREE_OBJECT.PARENT_TYPE.eq(TreeObjectVO.TreeParentType.SYSTEM.toString()));
        conditionList.add(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID.eq(programId));
        conditionList.add(TTreeObject.T_TREE_OBJECT.LEAF_OBJECT_TYPE.eq(TreeObjectVO.LeafObjectType.PROGRAM.toString()));
        treeObjectDao.deleteByConditions(conditionList);
        if(dbProgram.getIsPublic()){
            TreeObjectVO objectVO=new TreeObjectVO();
            objectVO.setObjectType(TreeObjectVO.TreeObjectType.PROGRAM.toString());
            objectVO.setLeafObjectType(TreeObjectVO.LeafObjectType.PROGRAM.toString());
            objectVO.setParentType(TreeObjectVO.TreeParentType.SYSTEM.toString());
            objectVO.setName(dbProgram.getName());
            objectVO.setParentId(parentId);
            treeService.addTreeObject(objectVO,"1",programId);
        }
        return new ResultVo<>(0,true);
    }

    public void importProgram(String programsPath,String excelPath,String userId) throws Exception {
        File programDir=new File(programsPath);
        File[] programs=programDir.listFiles();
        Map<String,String> programPathMap=new HashMap<>();
        Map<String,BigDecimal> groupNameIdMap=new HashMap();
        for(File programFile:programs){
            if(programFile.isFile()){
                BigDecimal programId=BigDecimal.valueOf(idService.id());
                String programPath= getProgramPath(programId);
                HDFSIO.uploadOverwrite(programFile.getAbsolutePath(),programPath,programFile.getName());
                unZipFiles(new FileInputStream(programFile),programPath);
                programPathMap.put(programFile.getName(),programPath);
            }
        }
        List<List<String>>  programList= ExcelUtils.getInstance().readExcel2List(excelPath,2);
        for(List<String> columns:programList ){
            String fileName=columns.get(2);
            String programPath=programPathMap.get(fileName);
            String groupName=columns.get(5);
            if(programPath == null){
                continue;
            }
            ProgramVO programVO=new ProgramVO();
            if(!StringUtil.isEmpty(groupName)){
                BigDecimal groupId=groupNameIdMap.get(groupName);
                if(groupId==null){
                    TreeObjectVO objectVO=new TreeObjectVO();
                    objectVO.setName(groupName);
                    objectVO.setLeafObjectType(TreeObjectVO.LeafObjectType.PROGRAM.toString());
                    objectVO.setObjectType(TreeObjectVO.TreeObjectType.PROGRAM.toString());
                    objectVO.setParentType(TreeObjectVO.TreeParentType.SELF.toString());
                    ResultVo<BigDecimal> result= treeService.saveTreeRootObject(objectVO,userId);
                    if(result.getData() !=null){
                        groupId= result.getData();
                        groupNameIdMap.put(groupName,result.getData());
                    }
                }
                programVO.setGroupId(groupId);
            }
            JSONArray parameters= JSON.parseArray(columns.get(3));
            List<com.cdid.service.oozie.command.Parameter> parameterList=new ArrayList<>();
            for(int i=0;i<parameters.size();i++){
                parameterList.add(JSON.toJavaObject(parameters.getJSONObject(i), com.cdid.service.oozie.command.Parameter.class));
            }
            programVO.setDescription(columns.get(1));
            programVO.setName(columns.get(0));
            programVO.setDownloadable(true);
            programVO.setFileName(fileName);
            programVO.setParameters(parameterList);
            programVO.setPath(programPath);
            programVO.setPersonalConf(columns.get(4));
            programVO.setProgramType(ProgramType.SHELL.toString());
            programVO.setSourceLink("");
            createOrUpdateProgram(programVO,userId);
        }

    }

    private  static void unZipFiles(InputStream inputStream, String rootPath)
            throws IOException {
        ZipArchiveInputStream zin = new ZipArchiveInputStream(inputStream);
        java.util.zip.ZipEntry entry = null;
        while ((entry = zin.getNextZipEntry()) != null) {
            String zipEntryName = entry.getName();
            String outPath = zipEntryName.replaceAll("\\*", "/");
            String path = "lib";
            path += zipEntryName.substring(zipEntryName.indexOf('/'), zipEntryName.length());
            if (!outPath.endsWith("/")) {
                InputStream in = zin;
                HDFSIO.uploadModel("/" + rootPath + "/" + path, in);
            }
        }
        zin.close();
    }

}
