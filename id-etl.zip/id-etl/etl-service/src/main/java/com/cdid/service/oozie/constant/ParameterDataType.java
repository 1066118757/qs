package com.cdid.service.oozie.constant;


public enum ParameterDataType {
    IN("in"),OUT("out"),STRING("string"),INT("int"),DOUBLE("double"),BOOL("bool");
     ParameterDataType(String name){
        this.name=name;
    }

    private String name;

    public String getName() {
        return name;
    }

    public static ParameterDataType toEnum(String name){
        return ParameterDataType.valueOf(name.toUpperCase());
    }

}
