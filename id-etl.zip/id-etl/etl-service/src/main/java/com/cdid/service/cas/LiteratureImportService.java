package com.cdid.service.cas;

import com.cdid.utils.jdbc.JDBCUtil;
import com.opencsv.CSVWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;


@Service
public class LiteratureImportService {

    private static final Logger logger = LoggerFactory.getLogger(LiteratureImportService.class);


    @Value("${dist.ip}")
    private String hiveHost;

    @Value("${dist.port}")
    private String hivePort;

    @Value("${dist.username}")
    private String userName;

    @Value("${dist.username}")
    private String password;

    public void parseLiteratureToCsv(InputStream is, String literatureType,String charSet, CSVWriter csvWriter) throws IOException {
        switch (literatureType) {
            case "ISI":
                LiteratureFileParser.parseWOS(is, charSet, csvWriter,literatureType);
                break;
            case "DW":
                LiteratureFileParser.parseWOS(is, charSet, csvWriter,literatureType);
                break;
            case "CNKI":
                LiteratureFileParser.parseCNKI(is, charSet, csvWriter);
                break;
            case "SCI":
                LiteratureFileParser.parseSCI(is, charSet, csvWriter);
                break;
            case "EI":
                LiteratureFileParser.parseEI(is, charSet, csvWriter);
                break;
            case "CSCD":
                LiteratureFileParser.parseCSCD(is,charSet,csvWriter);
                break;
            case "PUBM":
                LiteratureFileParser.parsePUBM(is,charSet,csvWriter);
                break;
            case "SCOPUS":
                break;
            default:
                break;
        }
    }

    public void loadCsvToHive(String hdfsCsvFilePath, String tableName) throws Exception {
        String driverClass="org.apache.hive.jdbc.HiveDriver";
        String url="jdbc:hive2://"+hiveHost+":"+hivePort;
        JDBCUtil.executeUpdate(constructLoadSql(hdfsCsvFilePath,tableName),driverClass,url,userName,password);
    }

    private String constructLoadSql(String localCsvFilePath, String tableName) {
        StringBuilder sql = new StringBuilder("LOAD DATA  INPATH ");
        sql.append("'")
                .append(localCsvFilePath.replace("\\", "/"))
                .append("' ")
                .append(" INTO TABLE ")
                .append(tableName);
        logger.info("load sql:"+sql.toString());
        return sql.toString();
    }
}
