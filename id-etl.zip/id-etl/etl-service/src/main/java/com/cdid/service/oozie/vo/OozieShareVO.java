package com.cdid.service.oozie.vo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class OozieShareVO {

    private BigDecimal sourceObjectId;

    private String sourceObjectName;

    private String sourceObjectType;

    private List<String> distObjectIdList=new ArrayList<>();

    private String distObjectType;


    public List<String> getDistObjectIdList() {
        return distObjectIdList;
    }

    public void setDistObjectIdList(List<String> distObjectIdList) {
        this.distObjectIdList = distObjectIdList;
    }

    public String getDistObjectType() {
        return distObjectType;
    }

    public void setDistObjectType(String distObjectType) {
        this.distObjectType = distObjectType;
    }

    public BigDecimal getSourceObjectId() {
        return sourceObjectId;
    }

    public void setSourceObjectId(BigDecimal sourceObjectId) {
        this.sourceObjectId = sourceObjectId;
    }

    public String getSourceObjectType() {
        return sourceObjectType;
    }

    public void setSourceObjectType(String sourceObjectType) {
        this.sourceObjectType = sourceObjectType;
    }

    public String getSourceObjectName() {
        return sourceObjectName;
    }

    public void setSourceObjectName(String sourceObjectName) {
        this.sourceObjectName = sourceObjectName;
    }

    public  enum SourceObjectType{
        TABLE,FILE,PROGRAM,OOZIE_JOB;
    }
    public  enum DistObjectType{
        GROUP,USER;
    }

}
