package com.cdid.service.storagedata;


import com.cdid.api.common.IDGeneratorService;
import com.cdid.api.common.RedisService;
import com.cdid.api.common.SmsService;
import com.cdid.api.file.FileService;
import com.cdid.api.file.vo.FileUploadRespVo;
import com.cdid.api.file.vo.FileVo;
import com.cdid.api.storagedata.StorageDataService;
import com.cdid.api.storagedata.vo.*;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.file.FileDao;
import com.cdid.dao.oozie.ShareDao;
import com.cdid.dao.storagedata.StorageDataManageDao;
import com.cdid.jooq.tables.TOozieShare;
import com.cdid.jooq.tables.records.TStorageDataRecord;
import com.cdid.service.oozie.OozieObjectTreeService;
import com.cdid.service.oozie.vo.OozieShareVO;
import com.cdid.service.oozie.vo.TreeObjectVO;
import com.cdid.utils.VoReTraversalUtil;
import org.jooq.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;


import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


import static com.cdid.jooq.tables.TStorageData.T_STORAGE_DATA;


@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class StorageDataServiceImpl implements StorageDataService {
    @Autowired
    StorageDataManageDao storageDataManageDao;
    @Autowired
    FileDao fileDao;
    @Autowired
    IDGeneratorService<Long> idGeneratorService;
    @Autowired
    FileService fileService;
    @Autowired
    SmsService smsService;
    @Autowired
    RedisService redisService;

    @Autowired
    OozieObjectTreeService treeService;

    @Autowired
    ShareDao shareDao;

    /**
     * 添加操作
     *
     * @return
     */
    @Override
    public ResultVo<List<FileUploadRespVo>> add(StorageDataAddVo storageDataAddVo, List<FileVo> fileVoList) throws Exception {
        for (FileVo fileVo : fileVoList) {
            TStorageDataRecord tStorageDataRecord = new TStorageDataRecord();
            tStorageDataRecord.setId(BigDecimal.valueOf(idGeneratorService.id()));
            tStorageDataRecord.setCreateTime(new Timestamp(System.currentTimeMillis()));
            // TODO: 2017/11/24 userId t_file
            String userId = storageDataAddVo.getUserId();
            tStorageDataRecord.setCreateUser(userId);
            tStorageDataRecord.setUploadUserId(userId);

            BigDecimal fileId = fileVo.getFileId();
            tStorageDataRecord.setFileId(fileId);

            String introduction = storageDataAddVo.getIntroduction();
            if (StringUtils.isEmpty(introduction)) {
                tStorageDataRecord.setIntroduction("");
            } else {
                tStorageDataRecord.setIntroduction(introduction);
            }
            String name = storageDataAddVo.getName();
            if (StringUtils.isEmpty(name)) {
                tStorageDataRecord.setName("");
            } else {
                tStorageDataRecord.setName(name);
            }
            if(storageDataAddVo.getIsPublic()==null){
                tStorageDataRecord.setIsPublic(false);
            }else{
                tStorageDataRecord.setIsPublic(storageDataAddVo.getIsPublic());
            }
            tStorageDataRecord.setStatus(1);
            tStorageDataRecord.setType(storageDataAddVo.getType());
            tStorageDataRecord.setUpdateUser(userId);
            tStorageDataRecord.setUploadTime(new Timestamp(System.currentTimeMillis()));
            storageDataManageDao.insert(tStorageDataRecord);
            TreeObjectVO treeObjectVO=new TreeObjectVO();
            treeObjectVO.setName(tStorageDataRecord.getName());
            treeObjectVO.setObjectType(TreeObjectVO.TreeObjectType.DATA.toString());
            treeObjectVO.setLeafObjectType(TreeObjectVO.LeafObjectType.FILE.toString());
            treeObjectVO.setParentType(TreeObjectVO.TreeParentType.SELF.toString());
            treeObjectVO.setParentId(storageDataAddVo.getGroupId());
            treeService.addTreeObject(treeObjectVO,userId, tStorageDataRecord.getId());
        }

        return fileService.saveFile(fileVoList);
    }

    /**
     * 删除操作
     *
     * @param id
     * @return
     */
    @Override
    public ResultVo<Object> delete(BigDecimal id) throws Exception {
        ResultVo<Object> resultVo = new ResultVo<>();
        TStorageDataRecord tStorageDataRecord = storageDataManageDao.findById(id);
        if (tStorageDataRecord == null) {
            resultVo.setErrorCode(ErrorCode.NotExists.getErrorCode());
            return resultVo;
        }
        BigDecimal fileId = tStorageDataRecord.getFileId();
        if (StringUtils.isEmpty(fileId)) {
            resultVo.setErrorCode(ErrorCode.NotExists.getErrorCode());
        } else {
            //关联删除
            fileService.deleteFile(fileId);
            storageDataManageDao.delete(tStorageDataRecord);
            shareDao.deleteByConditions(Arrays.asList(TOozieShare.T_OOZIE_SHARE.SOURCE_OBJECT_ID.eq(id),TOozieShare.T_OOZIE_SHARE.SOURCE_OBJECT_TYPE.eq(OozieShareVO.SourceObjectType.FILE.toString())));
            treeService.deleteTreeObjects(Arrays.asList(id),TreeObjectVO.LeafObjectType.FILE.toString());
            resultVo.setData(true);
        }
        return resultVo;
    }

    /**
     * 更新操作
     *
     * @param storageDataUpdateVo
     * @return
     */
    @Override
    public ResultVo<Object> update(StorageDataUpdateVo storageDataUpdateVo) {
        try {
            ResultVo<Object> resultVo = new ResultVo<>();
            BigDecimal id = storageDataUpdateVo.getId();
            if (StringUtils.isEmpty(id)) {
                resultVo.setErrorCode(ErrorCode.NotExists.getErrorCode());
                return resultVo;
            }
            String updateUserId = storageDataUpdateVo.getUploadUserId();
            if (StringUtils.isEmpty(updateUserId)) {
                resultVo.setErrorCode(ErrorCode.NotExists.getErrorCode());
                return resultVo;
            } else {
                // TStorageDataRecord tStorageDataRecord = storageDataManageDao.findById(id);
                TStorageDataRecord newRecord = VoReTraversalUtil.traversal(storageDataUpdateVo, TStorageDataRecord.class);
                newRecord.setUpdateTime(new Timestamp(System.currentTimeMillis()));
                storageDataManageDao.update(newRecord);
                treeService.updateName(newRecord.getId(),TreeObjectVO.LeafObjectType.FILE.toString(),newRecord.getName());
                resultVo.setErrorCode(0);
                resultVo.setData("success");
                return resultVo;

            }
        } catch (Exception e) {
            return new ResultVo<>(ErrorCode.UnknownError.getErrorCode(), e.getMessage());
        }

    }

    /**
     * 列表搜索操作
     *
     * @param storageDataQueryVo
     * @param pageNo
     * @param pageSize
     * @return
     */
    @Override
    public ResultVo<PageVo<StorageDataListVo>> list(StorageDataQueryVo storageDataQueryVo, Integer pageNo, Integer pageSize) {
        try {

            List<Condition> conditions = insertConditions(storageDataQueryVo);
            List<SortField<?>> sortList = insertSortList(storageDataQueryVo);
            PageVo<Record10<BigDecimal, String, String, Integer, BigDecimal, Timestamp, String, String, String,Boolean>> pageVo = storageDataManageDao.fetchPage(conditions, new OffsetPagingVo(pageNo, pageSize), sortList);
            ResultVo<PageVo<StorageDataListVo>> resultVo;
            resultVo = getResultVo(pageVo);
            return resultVo;

        } catch (Exception e) {
            return new ResultVo<>(ErrorCode.UnknownError.getErrorCode());
        }
    }

    /**
     * insert Conditions
     *
     * @param storageDataQueryVo
     * @return
     */
    private List<Condition> insertConditions(StorageDataQueryVo storageDataQueryVo) {
        List<Condition> conditions = new ArrayList<>();
        //根据name模糊搜索
        String name = storageDataQueryVo.getName();
        if (!StringUtils.isEmpty(name)) {
            conditions.add(T_STORAGE_DATA.NAME.like("%" + name + "%"));
        }
        //根据type区分图片与视频
        Integer type = storageDataQueryVo.getType();
        if (!StringUtils.isEmpty(type)) {
            conditions.add(T_STORAGE_DATA.TYPE.eq(type));
        }
        //根据上传者Id搜索
        String uploadUserId = storageDataQueryVo.getUploadUserId();
        if (!StringUtils.isEmpty(uploadUserId)) {
            conditions.add(T_STORAGE_DATA.UPLOAD_USER_ID.eq(uploadUserId));
        }
        return conditions;
    }

    /**
     * insert sortList
     *
     * @param storageDataQueryVo
     * @return
     */
    private List<SortField<?>> insertSortList(StorageDataQueryVo storageDataQueryVo) {
        List<SortField<?>> sortList = new ArrayList<>();
        //上传时间排序
        sortList.add(T_STORAGE_DATA.UPLOAD_TIME.desc());
        return sortList;
    }

    /**
     * 生成resultVo
     *
     * @param query
     * @return
     */
    private ResultVo<PageVo<StorageDataListVo>> getResultVo(PageVo<Record10<BigDecimal, String, String, Integer, BigDecimal, Timestamp, String,String, String,Boolean>> query) {
        try {
            ResultVo<PageVo<StorageDataListVo>> resultVo = new ResultVo<>();
            List<Record10<BigDecimal, String, String, Integer, BigDecimal, Timestamp, String,String, String,Boolean>> tInfoRecordsList = query.getPageData();
            List<StorageDataListVo> list = new ArrayList<>();

            for (Record10<BigDecimal, String, String, Integer, BigDecimal, Timestamp, String,String, String,Boolean> tStorageDataRecord : tInfoRecordsList) {
                StorageDataListVo storageDataListVo = dataFill(tStorageDataRecord);
                list.add(storageDataListVo);
            }
            PageVo<StorageDataListVo> result = new PageVo<>();
            result.setPageData(list);
            result.setTotalCount(query.getTotalCount());
            resultVo.setData(result);
            resultVo.setErrorCode(0);
            return resultVo;
        } catch (Exception e) {
            return new ResultVo<>(ErrorCode.UnknownError.getErrorCode());

        }

    }

    /**
     * record2vo
     *
     * @param tStorageDataRecord
     * @return
     */
    private StorageDataListVo dataFill(Record10<BigDecimal, String, String, Integer, BigDecimal, Timestamp, String,String, String,Boolean> tStorageDataRecord) throws Exception {
        StorageDataListVo storageDataListVo = new StorageDataListVo();
        BigDecimal id = tStorageDataRecord.value1();
        String name = tStorageDataRecord.value2();
        String introduction = tStorageDataRecord.value3();
        Integer type = tStorageDataRecord.value4();
        BigDecimal fileId = tStorageDataRecord.value5();
        Timestamp uploadTime = tStorageDataRecord.value6();
        String uploadUserId = tStorageDataRecord.value7();
        String uploadUserName=tStorageDataRecord.value8();
        String filePath = tStorageDataRecord.value9();
        storageDataListVo.setFileId(fileId);
        storageDataListVo.setId(id);
        storageDataListVo.setIntroduction(introduction);
        storageDataListVo.setName(name);
        storageDataListVo.setType(type);
        storageDataListVo.setUploadTime(uploadTime);
        storageDataListVo.setUploadUserId(uploadUserId);
        storageDataListVo.setUploadUserName(uploadUserName);
        storageDataListVo.setFilePath(filePath);
        storageDataListVo.setIsPublic(tStorageDataRecord.value10());
        return storageDataListVo;
    }

    /**
     * 根据id查询存储数据详情
     *
     * @param id
     * @return
     */
    @Override
    public ResultVo<StorageDataDetailVo> detailById(BigDecimal id) {
        try {
            ResultVo<StorageDataDetailVo> resultVo = new ResultVo<>();
            if (StringUtils.isEmpty(id)) {
                resultVo.setErrorCode(ErrorCode.NotExists.getErrorCode());
                return resultVo;
            }
            Record7<BigDecimal, String, String, String, Timestamp, String,String> record = storageDataManageDao.detailById(id);
            StorageDataDetailVo storageDataDetailVo = new StorageDataDetailVo();
            BigDecimal fileId = record.value1();
            String name = record.value2();
            String introduction = record.value3();
            String uploadUserId = record.value4();
            Timestamp uploadTime = record.value5();
            String filePath = record.value6();
            String uploadUserName = record.value7();

            storageDataDetailVo.setFileId(fileId);
            storageDataDetailVo.setName(name);
            storageDataDetailVo.setIntroduction(introduction);
            storageDataDetailVo.setUploadUserId(uploadUserId);
            storageDataDetailVo.setUploadTime(uploadTime);
            storageDataDetailVo.setFilePath(filePath);
            storageDataDetailVo.setUploadUserName(uploadUserName);
            resultVo.setData(storageDataDetailVo);
            resultVo.setErrorCode(0);
            return resultVo;
        } catch (Exception e) {
            return new ResultVo<>(ErrorCode.UnknownError.getErrorCode());
        }
    }
}
