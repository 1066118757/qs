package com.cdid.service.oozie.vo;

import java.math.BigDecimal;

public class TablePersistenceVO {

    private BigDecimal  themeId;

    private String tableName;

    private String sourceTableName;

    private BigDecimal groupId;

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public BigDecimal getThemeId() {
        return themeId;
    }

    public void setThemeId(BigDecimal themeId) {
        this.themeId = themeId;
    }

    public String getSourceTableName() {
        return sourceTableName;
    }

    public void setSourceTableName(String sourceTableName) {
        this.sourceTableName = sourceTableName;
    }

    public BigDecimal getGroupId() {
        return groupId;
    }

    public void setGroupId(BigDecimal groupId) {
        this.groupId = groupId;
    }
}
