
package com.cdid.service.oozie.workflow;

import com.cdid.service.oozie.command.Parameter;
import com.cdid.service.oozie.constant.ParameterDataType;
import com.cdid.service.oozie.constant.ParameterIOType;
import com.cdid.service.oozie.graph.OozieProgramNode;
import com.cdid.utils.StringUtil;
import org.dom4j.Element;
import org.dom4j.Namespace;
import org.dom4j.QName;

import java.util.List;


public class ShellActionNodeDef extends ActionNodeDef {

	public ShellActionNodeDef(OozieProgramNode program, String nodeId) {
		super(program, nodeId);
	}

	@Override
	public void generateActionXML(Element action) {
		Namespace xmlns = new Namespace("", "uri:oozie:shell-action:0.2"); // root namespace uri
		QName qName = QName.get("shell", xmlns); // your root element's name
		Element shell = action.addElement(qName);

		generateElement(shell, "job-tracker", "${jobTracker}");
		generateElement(shell, "name-node", "${nameNode}");

		Element configuration = shell.addElement("configuration");
		createProperty(configuration, "mapred.job.queue.name", "${queueName}");
		createProperty(configuration, "mapreduce.map.memeory.mb", "10240");
		generateElement(shell, "exec", "./run.sh");
		command2XMLforShell(shell);
		generateElement(shell, "file", "${nameNode}" + program.getProgramPath()
				+ "/run.sh");

		shell.addElement("capture-output");
	}

	private  void command2XMLforShell(Element shell) {
		generateElement(shell, "argument",appendParametersToCommandline(program.getPersonalConfig()));
		generateElement(shell, "argument", "${nameNode}" +program.getProgramPath()
				+ "/lib/");
		generateElement(shell, "argument", "${appPath}/"+nodeId);
	}

	private String  appendParametersToCommandline(String commandlinePrefix){
		StringBuilder cmd=new StringBuilder(commandlinePrefix);
		List<Parameter> parameters=program.getParams();
		for(Parameter parameter:parameters){
			String value=parameter.getParamValue();
			if((parameter.getDataType().equals(ParameterDataType.IN.getName())
					||parameter.getDataType().equals(ParameterDataType.OUT.getName()))&& ParameterIOType.FILE.name().equals(parameter.getIoType())){
				if(!StringUtil.isEmpty(value)&&!value.startsWith("/")){
					value="${appPath}/"+value;
				}
			}else{
				if(StringUtil.isEmpty(value)){
					value=parameter.getDefaultValue();
				}
			}
			if(StringUtil.isEmpty(value)){
				continue;
			}
			cmd.append(" --").append(parameter.getParamName())
					.append(" ").append(value);
		}
		return cmd.toString();
	}

}
