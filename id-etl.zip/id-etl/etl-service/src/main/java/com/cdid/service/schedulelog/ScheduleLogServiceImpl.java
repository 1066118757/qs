package com.cdid.service.schedulelog;

import com.cdid.api.common.IDGeneratorService;
import com.cdid.api.schedulelog.ScheduleLogService;
import com.cdid.api.schedulelog.vo.ScheduleLogAddVo;
import com.cdid.api.schedulelog.vo.ScheduleLogDetailVo;
import com.cdid.api.schedulelog.vo.ScheduleLogListVo;
import com.cdid.api.schedulelog.vo.ScheduleLogQueryVo;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.dict.JobState;
import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.job.JobDao;
import com.cdid.dao.schedulelog.SchedulelogDao;
import com.cdid.jooq.tables.records.TJobRecord;
import com.cdid.jooq.tables.records.TScheduleLogRecord;
import com.cdid.utils.VoReTraversalUtil;
import org.jooq.Condition;
import org.jooq.SortField;
import org.jooq.util.derby.sys.Sys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import static com.cdid.jooq.tables.TScheduleLog.T_SCHEDULE_LOG;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/02 15:20 
 */
@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class ScheduleLogServiceImpl implements ScheduleLogService{

    @Autowired
    IDGeneratorService<Long> idGeneratorService;

    @Autowired
    private SchedulelogDao schedulelogDao;
    @Autowired
    private JobDao jobDao;

    private static Logger logger = LoggerFactory.getLogger(ScheduleLogServiceImpl.class);

    @Override
    public ResultVo<BigDecimal> saveOrUpdate(ScheduleLogAddVo scheduleLogAddVo) throws Exception {
        if(scheduleLogAddVo.getJobId() == null){
            return new ResultVo<>(ErrorCode.ParamError.getErrorCode(),null,"Job id required!");
        }
        BigDecimal id = scheduleLogAddVo.getId();
        Timestamp scheduleStartTime = scheduleLogAddVo.getScheduleStarttime();
        if(id==null){
            TScheduleLogRecord latestLog=schedulelogDao.findJobLatestLog(scheduleLogAddVo.getJobId());
            if(latestLog ==null || JobState.Running.getValue() != latestLog.getScheduleState()){
                TScheduleLogRecord logRecord = VoReTraversalUtil.traversal(scheduleLogAddVo, TScheduleLogRecord.class);
                logRecord.setId(BigDecimal.valueOf(idGeneratorService.id()));
                logRecord.setScheduleStarttime(scheduleLogAddVo.getScheduleEndtime() == null?new Timestamp(System.currentTimeMillis()):new Timestamp(scheduleLogAddVo.getScheduleEndtime().getTime()-1000));
                schedulelogDao.insert(logRecord);
            }else{
                latestLog.setScheduleLog(scheduleLogAddVo.getScheduleLog());
                latestLog.setScheduleState(scheduleLogAddVo.getScheduleState());
                latestLog.setSuccessRows(scheduleLogAddVo.getSuccessRows());
                latestLog.setScheduleEndtime(scheduleLogAddVo.getScheduleEndtime() == null ?new Timestamp(System.currentTimeMillis()):scheduleLogAddVo.getScheduleEndtime());
                schedulelogDao.update(latestLog);
            }
        }else{
            TScheduleLogRecord logRecord= schedulelogDao.findById(id);
            if(logRecord==null){
                logRecord = VoReTraversalUtil.traversal(scheduleLogAddVo, TScheduleLogRecord.class);
                logRecord.setId(id);
                schedulelogDao.insert(logRecord);
            }else{
                logRecord.setScheduleEndtime(scheduleLogAddVo.getScheduleEndtime());
                logRecord.setScheduleLog(scheduleLogAddVo.getScheduleLog());
                logRecord.setScheduleState(scheduleLogAddVo.getScheduleState());
                logRecord.setSuccessRows(scheduleLogAddVo.getSuccessRows());
                scheduleStartTime=logRecord.getScheduleStarttime();
                schedulelogDao.update(logRecord);
            }
        }

        //
        BigDecimal jobId = scheduleLogAddVo.getJobId();
        Integer scheduleState = scheduleLogAddVo.getScheduleState();
        Long successRows = scheduleLogAddVo.getSuccessRows();
        String scheduleLog = scheduleLogAddVo.getScheduleLog();
        TJobRecord jobRecord = new TJobRecord();
        jobRecord.setId(jobId);
        jobRecord.setUpdateTime(new Timestamp(System.currentTimeMillis()));
        jobRecord.setUpdateUser("0");
        jobRecord.setLatestScheduleState(scheduleState);
        jobRecord.setLatestScheduleTime(scheduleStartTime ==null?new Timestamp(System.currentTimeMillis()):scheduleStartTime);
        jobRecord.setLatestSuccessRows(successRows);
        jobRecord.setLatestScheduleLog(scheduleLog);
        jobDao.update(jobRecord);
        return new ResultVo<>(0,id);
    }


    @Override
    public ResultVo<PageVo<ScheduleLogListVo>> list(ScheduleLogQueryVo scheduleLogQueryVo,Integer page,Integer size) throws Exception {
        List<Condition> conditions = new ArrayList<>();
        List<SortField<?>> sortList = new ArrayList<>();
        sortList.add(T_SCHEDULE_LOG.SCHEDULE_STARTTIME.desc());
        PageVo<TScheduleLogRecord> query = schedulelogDao.fetchByPage(conditions, new OffsetPagingVo(page, size), sortList);
        List<TScheduleLogRecord> records = query.getPageData();
        List<ScheduleLogListVo> list = new ArrayList<>();
        ScheduleLogListVo  vo = null;
        for (TScheduleLogRecord record : records) {
            vo = VoReTraversalUtil.traversal(record, ScheduleLogListVo.class);
            list.add(vo);
        }
        PageVo<ScheduleLogListVo> result = new PageVo<>();
        result.setPageData(list);
        result.setTotalCount(query.getTotalCount());
        return new ResultVo(0, result);
    }

    @Override
    public ResultVo<ScheduleLogDetailVo> findById(BigDecimal id) throws Exception {
        return null;
    }

    @Override
    public Boolean jobIsRunning(BigDecimal jobId) {
       TScheduleLogRecord logRecord= schedulelogDao.findJobLatestLog(jobId);
       boolean isRunning = logRecord!=null&&logRecord.getScheduleState()!=null&&logRecord.getScheduleState().equals(JobState.Running.getValue());

       if(isRunning && (System.currentTimeMillis()-logRecord.getScheduleStarttime().getTime()) < 3600*1000){
           return true;
       }else if(isRunning && (System.currentTimeMillis()-logRecord.getScheduleStarttime().getTime()) >= 3600*1000){
           //更新旧的记录为失败
           logRecord.setScheduleState(JobState.Fail.getValue());
           logRecord.setScheduleEndtime(new Timestamp(System.currentTimeMillis()));
           logRecord.setScheduleLog("超时");
           logRecord.setSuccessRows(0L);
           schedulelogDao.update(logRecord);
           return false;
       }else {
           return false;
       }

//       return logRecord!=null&&logRecord.getScheduleState()!=null&&logRecord.getScheduleState().equals(JobState.Running.getValue())
//               &&(System.currentTimeMillis()-logRecord.getScheduleStarttime().getTime())<3600*1000;
    }

    @Override
    public void deleteByJobId(BigDecimal jobId) {
        schedulelogDao.deleteByJobId(jobId);
    }

}
