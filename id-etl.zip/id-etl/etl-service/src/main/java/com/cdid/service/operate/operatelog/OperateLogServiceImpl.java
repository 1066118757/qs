package com.cdid.service.operate.operatelog;

import com.cdid.api.common.IDGeneratorService;
import com.cdid.api.operate.operatelog.OperateLogService;
import com.cdid.api.operate.operatelog.vo.OperateLogAddVo;
import com.cdid.api.operate.operatelog.vo.OperateLogListVo;
import com.cdid.api.operate.operatelog.vo.OperateLogQueryVo;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.operate.operatelog.OperateLogDao;
import com.cdid.jooq.tables.records.TOperateLogRecord;
import com.cdid.utils.VoReTraversalUtil;
import org.jooq.Condition;
import org.jooq.Record;
import org.jooq.SortField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.cdid.jooq.tables.TOperateLog.T_OPERATE_LOG;
import static com.cdid.jooq.tables.Users.USERS;

@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class OperateLogServiceImpl implements OperateLogService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private OperateLogDao operateLogDao;

    @Autowired
    private IDGeneratorService<Long> idGeneratorService;


    /**
     * 添加审计操作日志
     *
     * @param operateLogAddVo
     * @return
     */
    @Override
    public ResultVo<Object> add(OperateLogAddVo operateLogAddVo) {
        ResultVo<Object> resultVo = new ResultVo<Object>();
        try {
            TOperateLogRecord operateLogRecord = (TOperateLogRecord) VoReTraversalUtil.traversal(operateLogAddVo, TOperateLogRecord.class);
            operateLogRecord.setId(BigDecimal.valueOf(idGeneratorService.id()));
            operateLogRecord.setOperateTime(new Timestamp(System.currentTimeMillis()));
            operateLogDao.insert(operateLogRecord);
            resultVo.setData("success");
            return resultVo;
        } catch (Exception e) {
            e.printStackTrace();
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            return resultVo;
        }
    }

    /**
     * 为list添加条件字段的方法
     * @param operateLogQueryVo
     * @return
     */
    private List<Condition> innerAddListCondition(OperateLogQueryVo operateLogQueryVo){
        List<Condition> conditions = new ArrayList<>();
        // 根据用户id查询
        String operatorId = operateLogQueryVo.getOperatorId();
        if (!StringUtils.isEmpty(operatorId)) {
            conditions.add(T_OPERATE_LOG.OPERATOR_ID.eq(operatorId));
        }

        // 根据时间查询
        Timestamp operateTimeStart = operateLogQueryVo.getOperateTimeStart();
        if (!StringUtils.isEmpty(operateTimeStart)) {
            conditions.add(T_OPERATE_LOG.OPERATE_TIME.greaterOrEqual(operateTimeStart));
        }
        Timestamp operateTableEnd = operateLogQueryVo.getOperateTimeEnd();
        if (!StringUtils.isEmpty(operateTableEnd)) {
            conditions.add(T_OPERATE_LOG.OPERATE_TIME.lessOrEqual(operateTableEnd));
        }

        // 根据操作表查询
        String operateTable = operateLogQueryVo.getOperateTable();
        if (!StringUtils.isEmpty(operateTable)) {
            conditions.add(T_OPERATE_LOG.OPERATE_TABLE.like("%" + operateTable + "%") );
        }

        // 根据操作描述查询
        Integer actionId = operateLogQueryVo.getActionId();
        if (!StringUtils.isEmpty(actionId)) {
            conditions.add(T_OPERATE_LOG.ACTION_ID.eq(actionId));
        }

        // 根据操作结果查询
        Integer result = operateLogQueryVo.getResult();
        if(!StringUtils.isEmpty(result) && result==0) {
            conditions.add(T_OPERATE_LOG.RESULT.eq(result));
        }else if (!StringUtils.isEmpty(result) && result==-1){
            conditions.add(T_OPERATE_LOG.RESULT.notEqual(0));
        }
        //根据操作者名字查询
        String operatorName = operateLogQueryVo.getOperatorName();
        if (!StringUtils.isEmpty(operatorName)){
            conditions.add(USERS.LOGIN_ACCOUNT.like("%"+operatorName+"%"));
        }
        //根据是否系统操作查询
        Integer flag = operateLogQueryVo.getFlag();
        if (!StringUtils.isEmpty(flag)){
            if (flag==1){
                conditions.add(T_OPERATE_LOG.OPERATOR_ID.eq("0"));
            }else {
                conditions.add(T_OPERATE_LOG.OPERATOR_ID.notEqual("0"));
            }
        }
        return conditions;
    }

    /**
     * 日志分页查询
     * @param operateLogQueryVo
     * @param pageNo
     * @param pageSize
     * @return
     */
    @Override
    public ResultVo<PageVo<List<OperateLogListVo>>> list(OperateLogQueryVo operateLogQueryVo, Integer pageNo, Integer pageSize) {
        List<SortField<?>> sortList = new ArrayList<>();
        // 排序字段
        sortList.add(T_OPERATE_LOG.OPERATE_TIME.desc());
        // 条件字段
        List<Condition> conditions = innerAddListCondition(operateLogQueryVo);
        // 查询赋值返回
        Map<String, Object> map = operateLogDao.list(conditions, sortList, pageNo, pageSize);
        Record[] records = (Record[]) map.get("data");
        Integer total = (Integer) map.get("total");
        List<OperateLogListVo> list = getFindResult(records);

        PageVo<OperateLogListVo> result = new PageVo<>();
        result.setPageData(list);
        result.setTotalCount(total);
        logger.info("LoanInvitationServiceImpl-list:success");
        return new ResultVo(0, result);
    }

    /**
     * 将record-->vo
     * @param records
     * @return
     */
    private List<OperateLogListVo> getFindResult(Record[] records) {
        List<OperateLogListVo> list = new ArrayList<>();
        for (Record item : records) {
            OperateLogListVo operateLogListVo = new OperateLogListVo();
            //各种字段添加
            operateLogListVo.setId((BigDecimal) item.get("log_id"));
            operateLogListVo.setActionId((Integer) item.get("log_action_id"));
            operateLogListVo.setOperateTime((Timestamp)item.get("log_operate_time"));
            operateLogListVo.setOperateTable((String) item.get("log_operate_table"));
            operateLogListVo.setOperatorId((String) item.get("log_operator_id"));
            operateLogListVo.setResult((Integer) item.get("log_result"));
            Object actionDesc = item.get("action_desc");
            if (actionDesc!=null){
                operateLogListVo.setActionDesc((String)actionDesc);
            }
            Object name = item.get("operator_name");
            if (name!=null){
                operateLogListVo.setOperatorName((String)name);
            }
            Object type = item.get("operator_type");
            if (type!=null){
                operateLogListVo.setOperatorType((String)type);
            }
            Object account = item.get("operator_account");
            if (account!=null){
                operateLogListVo.setOperatorAccount((String)account);
            }
            list.add(operateLogListVo);
        }
        return list;
    }
}
