package com.cdid.service.dict;


import com.alibaba.fastjson.JSON;
import com.cdid.api.common.RedisService;
import com.cdid.api.dict.DictService;
import com.cdid.api.dict.vo.DictDetailVo;
import com.cdid.api.dict.vo.DictValueVo;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.constant.RedisKey;
import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.dict.DictMappingDao;
import com.cdid.dao.dict.DictTypeDao;
import com.cdid.jooq.tables.records.CDictMappingRecord;
import com.cdid.jooq.tables.records.CDictTypeRecord;
import com.cdid.service.common.RedisServiceImpl;
import com.cdid.utils.StringUtil;
import org.jooq.Record3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.cdid.jooq.tables.CDictMapping.C_DICT_MAPPING;

/**
 * @Author Froid_Li
 * @Email 269504518@qq.com
 * @Date 2017/8/31  17:45
 */
@Service
public class DictServiceImpl implements DictService {

    private static Logger logger = LoggerFactory.getLogger(DictServiceImpl.class);

    @Autowired
    private DictTypeDao dictTypeDao;

    /*@Autowired
    private SensitiveWordDao sensitiveWordDao;*/
    @Autowired
    RedisService redisService;

    @Autowired
    private DictMappingDao dictMappingDao;

    /**
     * @param ids
     * @param pageNo
     * @param pageSize
     * @return
     */
    @Override
    public ResultVo<PageVo> detail(List<Integer> ids, Integer pageNo, Integer pageSize) {
        String mappingId = getValueByMappingId(201);
        //根据id列表返回详细的码表信息
        List<Map> queryList = dictTypeDao.findByTypeIds(ids, new OffsetPagingVo(pageNo, pageSize));
        if (queryList.size() == 0) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), null);
        } else {
            List<DictDetailVo> list = new ArrayList<>();

            for (int i = 0; i < queryList.size(); i++) {
                DictDetailVo dictDetailVo = new DictDetailVo();
                dictDetailVo.setId((Integer) queryList.get(i).get("id"));
                dictDetailVo.setTypeName((String) queryList.get(i).get("typeName"));
                dictDetailVo.setTypeId((Integer) queryList.get(i).get("typeId"));
                dictDetailVo.setKey((Short) queryList.get(i).get("key"));
                dictDetailVo.setValue((String) queryList.get(i).get("value"));
                list.add(dictDetailVo);
            }
            PageVo<DictDetailVo> result = new PageVo<>();
            result.setPageData(list);
            result.setTotalCount(queryList.size());
            return new ResultVo<>(0, result);
        }


    }

    /**
     * @param id
     * @param key
     * @return
     */
    @Override
    public ResultVo<List<DictValueVo>> findValue(Integer id, Short key) {
        //根据id和key查询对应的码值
        List<Map> queryList = dictTypeDao.findValue(id, key);
        if (queryList.size() == 0) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), null);
        } else {
            List<DictValueVo> list = new ArrayList<>();

            for (int i = 0; i < queryList.size(); i++) {
                DictValueVo dictValueVo = new DictValueVo();
                dictValueVo.setId((Integer) queryList.get(i).get("id"));
                dictValueVo.setTypeName((String) queryList.get(i).get("typeName"));
                dictValueVo.setKey((Short) queryList.get(i).get("key"));
                dictValueVo.setValue((String) queryList.get(i).get("value"));
                list.add(dictValueVo);
            }
            return new ResultVo<>(0, list);
        }
    }

    @Override
    public List<DictValueVo> getMappingByTypeId(Integer typeId) {
        List<CDictMappingRecord> mappingRecords = dictMappingDao.fetch(C_DICT_MAPPING.TYPE_ID, typeId);
        CDictTypeRecord typeRecord = dictTypeDao.findById(BigDecimal.valueOf(typeId));
        String typeName = "";
        if (typeRecord != null) {
            typeName = typeRecord.getTypeName();
        }
        List<DictValueVo> list = new ArrayList<>();
        for (CDictMappingRecord mappingRecord : mappingRecords) {
            Integer id1 = mappingRecord.getId();
            Short key = mappingRecord.getKey();
            String value = mappingRecord.getValue();

            DictValueVo vo = new DictValueVo();
            vo.setId(id1);
            vo.setKey(key);
            vo.setValue(value);
            vo.setTypeName(typeName);
            list.add(vo);
        }
        return list;
    }

    /**
     * @param typeId
     * @param value
     * @param userId
     * @return
     */
    @Override
    public ResultVo<Boolean> add(Integer typeId, String value, BigDecimal userId) {
        //判断参数是否正确
        if (StringUtils.isEmpty(typeId)) {
            return new ResultVo<>(ErrorCode.ParamError.getErrorCode(), false);
        }
        logger.info("typeId: " + typeId);
        logger.info("value: " + value);
        //判断该typeId是否存在
        Record3<Integer, Integer, Short> record3 = dictMappingDao.findNextRecord(typeId);
        Short key;
        if (record3 == null) {
            key = 1;

        } else {
            //构造新数据
            key = record3.value3();
            key++;
        }
        Integer id = typeId * 100 + key;

        Short status = 1;
        CDictMappingRecord cDictMappingRecord = new CDictMappingRecord();
        cDictMappingRecord.setId(id);
        cDictMappingRecord.setTypeId(typeId);
        cDictMappingRecord.setKey(key);
        cDictMappingRecord.setValue(value);
        cDictMappingRecord.setStatus(status);
        cDictMappingRecord.setUpdateTime(new Timestamp(System.currentTimeMillis()));
        cDictMappingRecord.setUpdateUser(userId);
        dictMappingDao.insert(cDictMappingRecord);
        initDict();
        return new ResultVo<>(0, true);
    }

    /*@PostConstruct
    private void initSensitiveWordToRedis(){
        Map<String, String> map = sensitiveWordDao.findAll();
        SensitiveWordUtil.genRedis(map);
    }*/
//    @PostConstruct
    @Override
    public void initDict() {
        List<Map> all = dictTypeDao.findAll();
        for (Map data : all) {
            Integer id = (Integer) data.get("id");
            String typeName = (String) data.get("typeName");
            Integer mappingId = (Integer) data.get("mappingId");
            String value = (String) data.get("value");
            DictValueVo dictValueVo = new DictValueVo();
            dictValueVo.setId(id);
            dictValueVo.setTypeName(typeName);
            dictValueVo.setMappingId(mappingId);
            dictValueVo.setValue(value);
            String json = JSON.toJSONString(dictValueVo);
            redisService.mPut(RedisKey.DICT, mappingId.toString(), json);
        }
    }

    @Override
    public String getValueByMappingId(Integer mappingId) {
        if (mappingId == null) {
            return "";
        }
        String json = redisService.mGet(RedisKey.DICT, mappingId.toString());

        if (StringUtil.isEmpty(json)) {
            initDict();
            json = redisService.mGet(RedisKey.DICT, mappingId.toString());
        }

        Map map = JSON.parseObject(json, Map.class);
        if (map == null) {
            return mappingId + "对应码值不存在";
        }
        return String.valueOf(map.getOrDefault("value", ""));
    }

    @Override
    public List<String> getValuesByMappingIds(Integer[] mappingIdArr) {
        List<String> values = new ArrayList<>();
        if (mappingIdArr == null || mappingIdArr.length == 0) {
            return new ArrayList<>();
        }
        for (Integer mappingId : mappingIdArr) {
            values.add(getValueByMappingId(mappingId));
        }
        return values;
    }

    @Override
    public List<String> getValuesByKeys(Integer[] mappingIdArr) {
        List<String> values = new ArrayList<>();
        List<String> keys = new ArrayList<>();
        if (mappingIdArr == null || mappingIdArr.length == 0) {
            return new ArrayList<>();
        }
        for (Integer mappingId : mappingIdArr) {
            keys.add(mappingId.toString());
        }
        List<String> jsons = redisService.hmGet(RedisKey.DICT, keys.toArray(new String[keys.size()]));
        for (int i = 0; i < jsons.size(); i++) {
            String json = jsons.get(i);
            if (StringUtil.isEmpty(json)) {
                initDict();
                json = redisService.mGet(RedisKey.DICT, mappingIdArr[i].toString());
            }
            Map map = JSON.parseObject(json, Map.class);
            values.add(String.valueOf(map.getOrDefault("value", "")));
        }
        return values;
    }

    @Override
    public Map<Integer, String> get(Integer[] mappingIdArr) {
        Map<Integer, String> data = new HashMap<>();
        List<String> values = getValuesByKeys(mappingIdArr);
        for (int i = 0; i < mappingIdArr.length; i++) {
            data.put(mappingIdArr[i], values.get(i));
        }
        return data;
    }

    @Override
    public Map<Integer, String> getByTypeId(Integer typeId) {
        String dictMapStr = redisService.get(RedisKey.DICT_TYPE);
        if (StringUtil.isEmpty(dictMapStr)) {
            List<DictValueVo> voList = getMappingByTypeId(typeId);
            Map<Integer, String> dictMap = new HashMap<>();
            if (voList != null && !voList.isEmpty()) {
                for (DictValueVo valueVo : voList) {
                    dictMap.put(valueVo.getId(), valueVo.getValue());
                }
            }
            redisService.put(RedisKey.DICT_TYPE + typeId, JSON.toJSONString(dictMap));
            return dictMap;
        }
        Map<Integer, String> dictMap = JSON.parseObject(dictMapStr, Map.class);
        return dictMap;
    }

    @Override
    public Map<Integer, String> getByTypeIdList(List<Integer> typeIdList) {
        List<CDictMappingRecord> dictRecordList = dictMappingDao.fetch(C_DICT_MAPPING.TYPE_ID, typeIdList);
        Map<Integer, String> dictMap = new HashMap<>();
        for (CDictMappingRecord record : dictRecordList) {
            dictMap.put(record.getId(), record.getValue());
        }
        return dictMap;
    }
}
