/**
 * Copyright 2017 Institute of Computing Technology, Chinese Academy of Sciences.
 * Licensed under the terms of the Apache 2.0 license.
 * Please see LICENSE file in the project root for terms
 */
package com.cdid.service.oozie.util;

import com.cdid.config.PropertyUtil;
import org.apache.log4j.Logger;
import org.apache.oozie.client.OozieClient;
import org.apache.oozie.client.OozieClientException;
import org.apache.oozie.client.WorkflowJob;

import java.io.IOException;
import java.net.InetAddress;
import java.util.Date;
import java.util.Properties;

/**
 * Support some method to access oozie  
 */
public class OozieUtil {
	private static Logger logger = Logger.getLogger(OozieUtil.class
			.getName());

	private static final String QUEUE_NAME="default";
	private static final String OOZIE_SERVER=PropertyUtil.getMergedProperty("oozie.server","http://127.0.0.1:11000/oozie");
	private static final String NAME_NODE=HDFSIO.NAME_NODE;
	private static final String JOB_TRACKER= PropertyUtil.getMergedProperty("yarn","127.0.0.1:8050");
	private static OozieClient wc = new OozieClient(OOZIE_SERVER);

	/**
	 * Submit Oozie Job
	 *
	 * @param app_path
	 * @throws OozieClientException
	 * @throws IOException
	 */
	public static String submit(String app_path) throws OozieClientException,
	IOException {
		// create a workflow job configuration and set the workflow application path
		Properties conf = wc.createConfiguration();
		InetAddress addr = InetAddress.getLocalHost();
		String localAddress=addr.getHostAddress().toString();
		conf.setProperty(OozieClient.APP_PATH, app_path);
		conf.setProperty("oozie.wf.workflow.notification.url","http://"+localAddress+":18083/v1/ooziejob/notify?oozieJobId=$jobId&status=$status");
		// setting workflow parameters
		conf.setProperty("queueName", QUEUE_NAME);
		conf.setProperty("nameNode", NAME_NODE);
		conf.setProperty("jobTracker", JOB_TRACKER);
		conf.setProperty("user.name","root");
		conf.setProperty("appPath", app_path);
		conf.setProperty("oozie.libpath",app_path+"/lib");
		String jobId = wc.run(conf);
		logger.info("submit workflow job:" + jobId);

		return jobId;
	}

	/**
	 * Get job create time
	 *
	 * @param jobId job id
	 * @return create time of job
	 * @throws OozieClientException
	 * @author guotianyou
	 * @time 2015年12月6日上午11:43:22
	 */
	public static Date getCreateTime(String jobId) throws OozieClientException {
		return wc.getBundleJobInfo(jobId).getCreatedTime();
	}

	/**
	 * Consult Oozie job status
	 *
	 * @param jobID
	 * @throws OozieClientException
	 * @throws IOException
	 */
	public static WorkflowJob getJob(String jobID) throws OozieClientException,
	IOException {
		return wc.getJobInfo(jobID);
	}

	/**
	 * Kill oozie job
	 *
	 * @param  jobID
	 * @throws OozieClientException
	 * @throws IOException
	 */
	public static void kill(String jobID) throws OozieClientException,
	IOException {

		wc.kill(jobID);
		//TODO UPDATE JOB STATUS
	}

	/**
	 * Suspend oozie job
	 *
	 * @param jobID
	 * @throws OozieClientException
	 * @throws IOException
	 */
	public static void suspend(String jobID) throws OozieClientException,
	IOException {

		wc.suspend(jobID);
		//TODO UPDATE JOB STATUS

	}

	/**
	 * Rerun oozie job
	 *
	 * @param conf
	 * @throws OozieClientException
	 * @throws IOException
	 */
	/**
	 * Kill oozie job
	 *
	 * @throws OozieClientException
	 * @throws IOException
	 */
	public static void resume(String jobID) throws OozieClientException,
	IOException {

		wc.resume(jobID);
		//TODO UPDATE JOB STATUS

	}

	/**
	 * Kill oozie job
	 *
	 * @throws OozieClientException
	 * @throws IOException
	 */
	public static void start(String jobID) throws OozieClientException,
	IOException {
		wc.start(jobID);
		//TODO UPDATE JOB STATUS

	}

	/**
	 * Rerun oozie job
	 *
	 * @param jobID
	 * @throws OozieClientException
	 * @throws IOException
	 */

	public static void reRun(String jobID) throws OozieClientException,
	IOException {
		logger.info("rerun job:" + jobID);
		// create a workflow job configuration and set the workflow application path
		Properties conf = wc.createConfiguration();
		String app_path = wc.getJobInfo(jobID).getAppPath();
		conf.setProperty("oozie.wf.workflow.notification.url","http://192.168.101.226:18083/v1/ooziejob/notify?oozieJobId=$jobId&status=$status");
		// Need to analyze conf_o
		conf.setProperty(OozieClient.APP_PATH, app_path);
		conf.setProperty("queueName", QUEUE_NAME);
		conf.setProperty("nameNode", NAME_NODE);
		conf.setProperty("jobTracker", JOB_TRACKER);
		conf.setProperty("appPath", app_path);
		conf.setProperty("oozie.wf.rerun.failnodes", "false");
		wc.reRun(jobID, conf);
		//TODO UPDATE JOB STATUS


	}

	/**
	 * Get oozie's Url
	 *
	 * @param jobID
	 * @return url string
	 * @throws OozieClientException
	 * @throws IOException
	 */
	public static String getUrl(String jobID) throws OozieClientException,
	IOException {
		// get a OozieClient for local Oozie
		String url = wc.getJobInfo(jobID).getAppPath() + "/";
		return url;
	}




}
