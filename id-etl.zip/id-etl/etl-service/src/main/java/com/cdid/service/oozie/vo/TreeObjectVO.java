package com.cdid.service.oozie.vo;

import java.math.BigDecimal;

public class TreeObjectVO {

    private BigDecimal id;

    private String name;

    private String objectType;

    private String leafObjectType;

    private BigDecimal parentId;

    private BigDecimal sourceObjectId;

    private String parentType;

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getObjectType() {
        return objectType;
    }

    public void setObjectType(String objectType) {
        this.objectType = objectType;
    }

    public String getLeafObjectType() {
        return leafObjectType;
    }

    public void setLeafObjectType(String leafObjectType) {
        this.leafObjectType = leafObjectType;
    }

    public BigDecimal getParentId() {
        return parentId;
    }

    public void setParentId(BigDecimal parentId) {
        this.parentId = parentId;
    }

    public String getParentType() {
        return parentType;
    }

    public void setParentType(String parentType) {
        this.parentType = parentType;
    }

    public BigDecimal getSourceObjectId() {
        return sourceObjectId;
    }

    public void setSourceObjectId(BigDecimal sourceObjectId) {
        this.sourceObjectId = sourceObjectId;
    }

    public enum TreeParentType{
        SYSTEM,SHARE,SELF
    }

    public enum TreeObjectType{
        DATA,PROGRAM,OOZIE_JOB
    }

    public enum LeafObjectType{
        DATA,PROGRAM,TABLE,FILE
    }
}
