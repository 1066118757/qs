package com.cdid.service.job;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cdid.api.asynctask.vo.AsyncTaskConfigVo;
import com.cdid.api.dataimport.vo.*;
import com.cdid.api.jobconf.vo.JobConfAddVo;
import com.cdid.api.metadata.detail.vo.DetailAddVo;
import com.cdid.api.metadata.item.vo.ItemAddAllsVo;
import com.cdid.common.dict.DataSourceType;
import com.cdid.service.dataimport.ETLJobPreProcessor;
import com.cdid.utils.StringUtil;
import com.cdid.utils.jdbc.ConfKey;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.net.util.Base64;
import org.jooq.Record;
import org.jooq.Result;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/20 15:24  
 */
public class JobServiceUtil {

    public static final int IS_DB = 1;
    public static final int IS_WEBSERVICE = 2;
    public static final int IS_FILE = 3;

    public static final String TINYINT = "TINYINT";
    public static final String SMALLINT = "SMALLINT";
    public static final String INT = "INT";
    public static final String INTEGER = "INTEGER";
    public static final String BIGINT = "BIGINT";
    public static final String FLOAT = "FLOAT";
    public static final String DECIMAL = "DECIMAL";
    public static final String DOUBLE = "DOUBLE";

    public static final String BOOLEAN = "BOOLEAN";
    public static final String STRING = "STRING";
    public static final String BINARY = "BINARY";
    public static final String TIMESTAMP = "TIMESTAMP";
    public static final String CHAR = "CHAR";
    public static final String VARCHAR = "VARCHAR";
    public static final String DATE = "DATE";


    public static final String KAFAKA_TOPIC_DATACONFIG = "dataConfig";

    public static final String KAFAKA_TOPIC_CLEAR = "dataCleanResult";

    public static final String ETLRESULT = "ETLResult";

    public static final String FILE_ETL="FILE_ETL";

    public static final String DATABASE_ETL="DATABASE_ETL";

    public static final String WEBSERVICE_ETL="WEBSERVICE_ETL";

    public static int isDbType(Integer dbType){
        switch (dbType){
            case 601:
            case 602:
            case 603:
            case 604:
            case 605:
            case 606:
            case 607:
            case 613:
                return IS_DB;
            case 608:
                return IS_WEBSERVICE;
            case 609:
            case 610:
            case 611:
            case 612:
                return IS_FILE;
            default:
                return -1;
        }
    }

    public static Integer hiveFeildTypeConvert(String type){
        if(StringUtils.isEmpty(type)){
            return 301;
        }
        type = type.toUpperCase();
        switch (type){
            case TINYINT:
            case SMALLINT:
            case INT:
            case INTEGER:
            case BIGINT:
            case FLOAT:
            case DOUBLE:
            case DECIMAL: return 302;
            case BOOLEAN:
            case STRING:
            case BINARY:
            case TIMESTAMP:
            case CHAR:
            case VARCHAR:
            case DATE: return 301;
            default: return 301;
        }
    }

    public static ItemAddAllsVo getCreateTableVo(String distTable, BigDecimal logicPartitionId, List<JobConfAddVo> confs){
        String feildMappingJson = null;
        String metadataType = null;
        for(JobConfAddVo conf:confs){
            String key = conf.getKey();
            if(key.equals(ConfKey.FIELD_MAPPING)){
                feildMappingJson = conf.getValue();
            }

            if(key.equals(ConfKey.METADATA_TYPE)){
                metadataType = conf.getValue();
            }
        }
        List<ColumnMappingVo> columnMappingVos = JSONArray.parseArray(feildMappingJson, ColumnMappingVo.class);
        List<DetailAddVo> detailAddVos = new ArrayList<>();
        DetailAddVo detailAddVo = null;
        String distDataType = null;
        String dist = null;
        int index = 1;
        for(ColumnMappingVo columnMappingVo : columnMappingVos){
            detailAddVo = new DetailAddVo();
            distDataType = columnMappingVo.getDistDataType();
            dist = columnMappingVo.getDist();
            Integer colType = JobServiceUtil.hiveFeildTypeConvert(distDataType);
            detailAddVo.setMetadataItemId(logicPartitionId);
            detailAddVo.setColDisplayname(dist);
            detailAddVo.setColName(dist);
            detailAddVo.setColType(colType);
            detailAddVo.setIndex(index);
            detailAddVos.add(detailAddVo);
            index++;
        }

        //调用元数据接口创建表
        ItemAddAllsVo itemAddAllsVo = new ItemAddAllsVo();
        itemAddAllsVo.setThemeItemId(logicPartitionId);
        if(StringUtils.isEmpty(metadataType)){
            metadataType = "201";
        }
        itemAddAllsVo.setType(Integer.parseInt(metadataType));
        itemAddAllsVo.setDetailAddVoList(detailAddVos);
        itemAddAllsVo.setName(distTable);
        return itemAddAllsVo;
    }

    public static String convertJDBCType(Integer dbType){
        if(dbType == null){
            return "jdbc";
        }
        switch (dbType){
            case 613:return "hive";
            case 606:return "hbase";
            default:return "jdbc";
        }
    }

    public static String convertToStrDBType(Integer dbType){
        if(dbType == null){
            return "";
        }
        switch (dbType){
            case 601:return "mysql";
            case 602:return "oracle";
            case 603:return "sqlserver";
            case 604:return "infobright";
            case 605:return "postgresql";
            case 606:return "hbase";
            case 607:return "mongodb";
            default:return "hive";
        }
    }

    public static AsyncTaskConfigVo getAsyncTaskConfigVo(JobBaseConfigVo configVo){
        if(configVo==null){
            return null;
        }
        BigDecimal id = configVo.getTaskId();
        AsyncTaskConfigVo taskConfigVo = new AsyncTaskConfigVo();
        taskConfigVo.setTaskId(id);
        taskConfigVo.setPreProcessProcessor(new ETLJobPreProcessor());
        taskConfigVo.setTopic(JobServiceUtil.KAFAKA_TOPIC_DATACONFIG);
        taskConfigVo.setDependence(configVo.getDependence());
        JSONObject jsonObject = new JSONObject();
        JSONObject configJSON = new JSONObject();
        configJSON.put("target",constructDistConfig(configVo));
        if(configVo instanceof DatabaseJobConfigVo){
            jsonObject.put("etlType",DATABASE_ETL);
            DatabaseJobConfigVo dbConfigVo=(DatabaseJobConfigVo)configVo;
            JSONObject source=new JSONObject();
            Integer dbType = dbConfigVo.getDbType();
            source.put("type",convertJDBCType(dbType));
            source.put("dbType",convertToStrDBType(dbType));
            source.put("url",dbConfigVo.getJdbcUrl());
            source.put("user",dbConfigVo.getUserName());
            source.put("password",dbConfigVo.getPassword());
            source.put("tableName",dbConfigVo.getSourceTable());
            source.put("sql",StringUtils.isEmpty(dbConfigVo.getSql()) ? "" : dbConfigVo.getSql());
            source.put("db",dbConfigVo.getDistDataBase());
            boolean isLocal=false;
            if(StringUtil.isNotEmpty(dbConfigVo.getJdbcUrl()) && "hive".equals(convertJDBCType(dbType))){
                int sourcePortIndex=dbConfigVo.getJdbcUrl().indexOf(":10000");
                int distPortIndex=configVo.getDistJdbcUrl().indexOf(":10000");
                if(sourcePortIndex!=-1&&distPortIndex!=-1){
                    isLocal=dbConfigVo.getJdbcUrl().substring(0,sourcePortIndex).equalsIgnoreCase(configVo.getDistJdbcUrl().substring(distPortIndex));
                }
            }
            source.put("isLocal",String.valueOf(isLocal));
            if(dbType == DataSourceType.HBASE.getValue()){
                source.put("dbType","phoenix");
                source.put("url","jdbc:phoenix:"+dbConfigVo.getServerIp()+":"+dbConfigVo.getPort());
                String tableName=dbConfigVo.getSourceTable();
                if(!tableName.contains("\"") && tableName.contains(".")){
                    tableName=tableName.replace(".",".\"")+"\"";
                }else{
                    tableName="\""+tableName+"\"";
                }
                source.put("tableName",tableName);
            }
            configJSON.put("source",source);
            jsonObject.put("config", Base64.encodeBase64String(configJSON.toJSONString().getBytes()).replaceAll("\r\n",""));
//            jsonObject.put("colMapping",Base64.encodeBase64String(JSON.toJSONString(configVo.getColumnMappingVoList()).getBytes()).replaceAll("\r\n",""));
            jsonObject.put("colMapping",Base64.encodeBase64String(configVo.getColumnMapping().getBytes()).replaceAll("\r\n",""));

            taskConfigVo.setTaskParams(jsonObject);
            return taskConfigVo;
        }
        if(configVo instanceof FileJobConfigVo){
            jsonObject.put("etlType",FILE_ETL);
            FileJobConfigVo fileConfigVo=(FileJobConfigVo)configVo;
            JSONObject redisJsonObject = new JSONObject();
            redisJsonObject.put("redisKey",fileConfigVo.getRedisKey());
            redisJsonObject.put("redisHost",fileConfigVo.getRedisHost());
            redisJsonObject.put("redisPort",fileConfigVo.getRedisPort());
            redisJsonObject.put("redisIndex",fileConfigVo.getRedisIndex());
            configJSON.put("data",redisJsonObject);

            jsonObject.put("config",Base64.encodeBase64String(configJSON.toJSONString().getBytes()).replaceAll("\r\n",""));
            jsonObject.put("colMapping",Base64.encodeBase64String(configVo.getColumnMapping().getBytes()).replaceAll("\r\n",""));
//            System.out.println(jsonObject.getString("config"));
            taskConfigVo.setTaskParams(jsonObject);
            return taskConfigVo;
        }
        if(configVo instanceof WebServiceJobConfigVo){
            jsonObject.put("etlType",WEBSERVICE_ETL);
            WebServiceJobConfigVo wsConfigVo=(WebServiceJobConfigVo)configVo;
            JSONObject httpConf=new JSONObject();
            httpConf.put("url",wsConfigVo.getUrl());
            JSONArray headers=new JSONArray();
            if(wsConfigVo.getHeaders()!=null){
                for(Map.Entry<String,String> header:wsConfigVo.getHeaders().entrySet()){
                    JSONObject ele=new JSONObject();
                    ele.put("propName",header.getKey());
                    ele.put("propValue",header.getValue());
                    headers.add(ele);
                }
            }
            httpConf.put("headers",headers);
            httpConf.put("body",wsConfigVo.getBody().replaceAll("\n",""));
            httpConf.put("method",wsConfigVo.getMethod().toUpperCase());
            httpConf.put("sourceType",wsConfigVo.getRespContentType());
            httpConf.put("path",wsConfigVo.getDataPath());
            configJSON.put("httpConf",httpConf);

            jsonObject.put("config",Base64.encodeBase64String(configJSON.toJSONString().getBytes()).replaceAll("\r\n",""));
            jsonObject.put("colMapping",Base64.encodeBase64String(configVo.getColumnMapping().getBytes()).replaceAll("\r\n",""));
            taskConfigVo.setTaskParams(jsonObject);
            return taskConfigVo;
        }
        return null;

    }

    private static JSONObject constructDistConfig(JobBaseConfigVo configVo){
        JSONObject dist=new JSONObject();
        dist.put("type",convertJDBCType(configVo.getDistDbType()));
        dist.put("dbType",convertToStrDBType(configVo.getDistDbType()));
        dist.put("url",configVo.getDistJdbcUrl());
        dist.put("user",configVo.getDistUserName());
        dist.put("password",configVo.getDistPassword());
        dist.put("db",configVo.getDistDataBase());
        dist.put("tableName",configVo.getDistTable());
        dist.put("overwrite",configVo.getImportMode()==1);
        return dist;
    }

    public static Map<String,String> confToMap(Result<Record> records){
        Map<String, String> confMap = new HashMap<>();
        for (Record record : records) {
            confMap.put((String) record.get("key"), (String) record.get("value"));
        }
        return confMap;
    }

}
