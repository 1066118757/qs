package com.cdid.service.oozie.vo;

import java.math.BigDecimal;

public class OozieIdVO {

    private BigDecimal id;

    private String oozieJobId;

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getOozieJobId() {
        return oozieJobId;
    }

    public void setOozieJobId(String oozieJobId) {
        this.oozieJobId = oozieJobId;
    }

    public OozieIdVO() {
    }

    public OozieIdVO(BigDecimal id, String oozieJobId) {
        this.id = id;
        this.oozieJobId = oozieJobId;
    }
}
