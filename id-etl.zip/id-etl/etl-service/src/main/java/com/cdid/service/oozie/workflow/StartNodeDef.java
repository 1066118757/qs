
package com.cdid.service.oozie.workflow;

import org.dom4j.Element;

/**
 * The start node of Oozie start node
 */
public class StartNodeDef extends NodeDef {

	public StartNodeDef() {
		super("start");
	}

	@Override
	public void append2XML(Element root) {
		Element start = root.addElement("start");

		// assure that start node has only one out-path
		NodeDef nextNode = outNodes.iterator().next();
		start.addAttribute("to", nextNode.getName());
	}

}
