package com.cdid.service.oozie;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cdid.api.common.IDGeneratorService;
import com.cdid.api.datasource.JDBCService;
import com.cdid.api.metadata.item.vo.ItemDetailVo;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.dict.ItemSourceType;
import com.cdid.common.vo.JDBCVo;
import com.cdid.common.vo.ResponseVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.config.PropertyUtil;
import com.cdid.dao.file.FileDao;
import com.cdid.dao.metadata.detail.DetailDao;
import com.cdid.dao.metadata.item.ItemDao;
import com.cdid.dao.storagedata.StorageDataManageDao;
import com.cdid.jooq.tables.TMetadataItem;
import com.cdid.jooq.tables.records.TFileRecord;
import com.cdid.jooq.tables.records.TMetadataDetailRecord;
import com.cdid.jooq.tables.records.TMetadataItemRecord;
import com.cdid.jooq.tables.records.TStorageDataRecord;
import com.cdid.service.oozie.util.HDFSIO;
import com.cdid.service.oozie.vo.FilePersistenceVO;
import com.cdid.service.oozie.vo.TablePersistenceVO;
import com.cdid.service.oozie.vo.TreeObjectVO;
import com.cdid.utils.HttpClientUtil;
import com.cdid.utils.StringUtil;
import com.cdid.utils.jdbc.JDBCUtil;
import org.apache.commons.compress.compressors.FileNameUtil;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.*;

@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class ResultPersistenceService {

    private static final String CREATE_ANALYZE_TABLE_REST_PATH="/rest/hbase/sparksql/createUserAnalyzeTables";

    @Autowired
    FileDao fileDao;
    @Autowired
    StorageDataManageDao dataManageDao;

    @Autowired
    IDGeneratorService<Long> idService;

    @Autowired
    OozieObjectTreeService treeService;

    @Autowired
    JDBCService jdbcService;

    @Autowired
    ItemDao itemDao;

    @Autowired
    DetailDao detailDao;

    @Value("${hdfs.filePath}")
    private String HDFSPATH;

    @Value("${idmanager-server.baseUrl}")
    private String idmanagerBaseUrl;

    public ResultVo<BigDecimal> filePersist(FilePersistenceVO filePersistenceVO,String userId){
        String distDir=HDFSPATH+ RandomStringUtils.random(3,true,false)+System.currentTimeMillis();
        String distFilePath=null;
        try {
            distFilePath =HDFSIO.copyFile(filePersistenceVO.getSourcePath(),distDir);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResultVo<>(ErrorCode.FileNotFound.getErrorCode(),null,e.getMessage());
        }
        if(distFilePath == null){
            return new ResultVo<>(ErrorCode.FileNotFound.getErrorCode());
        }
        TFileRecord fileRecord=new TFileRecord();
        Timestamp now=new Timestamp(System.currentTimeMillis());
        fileRecord.setId(BigDecimal.valueOf(idService.id()));
        fileRecord.setCreateTime(now);
        fileRecord.setCreateUser(userId);
        if(StringUtil.isEmpty(filePersistenceVO.getExtension())){
            fileRecord.setFileType(FilenameUtils.getExtension(filePersistenceVO.getSourcePath()));
        }else{
            fileRecord.setFileType(filePersistenceVO.getExtension());
        }
        fileRecord.setName(FilenameUtils.getName(filePersistenceVO.getSourcePath()));
        fileRecord.setPath(distFilePath);
        TStorageDataRecord dataRecord=new TStorageDataRecord();
        dataRecord.setId(BigDecimal.valueOf(idService.id()));
        dataRecord.setCreateTime(now);
        dataRecord.setCreateUser(userId);
        dataRecord.setIntroduction(filePersistenceVO.getIntroduction());
        dataRecord.setFileId(fileRecord.getId());
        dataRecord.setName(filePersistenceVO.getName());
        dataRecord.setStatus(1);
        dataRecord.setType(filePersistenceVO.getType());
        dataRecord.setUpdateTime(now);
        dataRecord.setUpdateUser(userId);
        dataRecord.setUploadTime(now);
        dataRecord.setUploadUserId(userId);
        TreeObjectVO objectVO=new TreeObjectVO();
        objectVO.setLeafObjectType(TreeObjectVO.LeafObjectType.FILE.toString());
        objectVO.setObjectType(TreeObjectVO.TreeObjectType.DATA.toString());
        objectVO.setName(filePersistenceVO.getName());
        objectVO.setParentType(TreeObjectVO.TreeParentType.SELF.toString());
        objectVO.setParentId(filePersistenceVO.getGroupId());
        fileDao.insert(fileRecord);
        dataManageDao.insert(dataRecord);
        treeService.addTreeObject(objectVO,userId, dataRecord.getId());
        return new ResultVo<>(0,dataRecord.getId());
    }


    public ResultVo<String> tablePersist(TablePersistenceVO tableVo, String userId,String token){
        String hiveIP= PropertyUtil.getMergedProperty("dist.ip");
        String hivePort=PropertyUtil.getMergedProperty("dist.port");
        String userName=PropertyUtil.getMergedProperty("dist.username");
        String password=PropertyUtil.getProperty("dist.password");
        if(StringUtil.isEmpty(hiveIP)||StringUtil.isEmpty(hivePort)||StringUtil.isEmpty(userName)){
            return new ResultVo<>(ErrorCode.SystemConfigError.getErrorCode());
        }

        TMetadataItemRecord itemRecord=itemDao.findByName(tableVo.getTableName());
        if(itemRecord!=null){
            return new ResultVo<>(ErrorCode.Existed.getErrorCode());
        }
        itemRecord=new TMetadataItemRecord();
        Timestamp now=new Timestamp(System.currentTimeMillis());
        itemRecord.setAuditTime(now);
        itemRecord.setCreateTime(now);
        itemRecord.setCreateUser(userId);
        itemRecord.setId(BigDecimal.valueOf(idService.id()));
        itemRecord.setName(tableVo.getTableName());
        itemRecord.setPurpose("");
        itemRecord.setSourceType(ItemSourceType.MANAGER.getValue());
        itemRecord.setStatus((short)1);
        itemRecord.setThemeItemId(tableVo.getThemeId());
        itemRecord.setType(201);
        itemRecord.setUpdateTime(now);
        itemRecord.setUpdateUser(userId);
        List<TMetadataDetailRecord> columns=new ArrayList<>();
        List<JSONObject> requestColumns=new ArrayList<>();
        Connection connection=null;
        Statement statement=null;
        ResultSet rs=null;
        String jdbcUrl="jdbc:hive2://"+hiveIP+":"+hivePort;
        TMetadataDetailRecord  detailRecord;
        boolean success=false;
        try{
            connection=JDBCUtil.getConnection("org.apache.hive.jdbc.HiveDriver",jdbcUrl,userName,password);
            statement=connection.createStatement();
            rs=statement.executeQuery(" desc "+tableVo.getSourceTableName().toLowerCase());
            int index=0;
            while (rs.next()){
                String columnName=rs.getString("col_name");
                String dataType=rs.getString("data_type");
                if(StringUtil.isNotEmpty(columnName)){
                    detailRecord=new TMetadataDetailRecord();
                    detailRecord.setId(BigDecimal.valueOf(idService.id()));
                    detailRecord.setAuditTime(now);
                    detailRecord.setColComment("");
                    detailRecord.setColDisplayname(columnName);
                    detailRecord.setColName(columnName);
                    detailRecord.setColType(301);
                    detailRecord.setCreateTime(now);
                    detailRecord.setCreateUser(userId);
                    detailRecord.setIndex(index++);
                    detailRecord.setMetadataItemId(itemRecord.getId());
                    detailRecord.setStatus(itemRecord.getStatus());
                    detailRecord.setUpdateTime(now);
                    detailRecord.setUpdateUser(userId);
                    columns.add(detailRecord);
                    requestColumns.add(constructRequestColumn(columnName,dataType));
                }
            }
            String copyTableSql="CREATE TABLE "+tableVo.getTableName().toLowerCase()+" AS SELECT * FROM "+tableVo.getSourceTableName();
            statement.executeUpdate(copyTableSql);
            itemDao.insert(itemRecord);
            detailDao.insert(columns);
            TreeObjectVO objectVO=new TreeObjectVO();
            objectVO.setLeafObjectType(TreeObjectVO.LeafObjectType.TABLE.toString());
            objectVO.setObjectType(TreeObjectVO.TreeObjectType.DATA.toString());
            objectVO.setName(tableVo.getTableName());
            objectVO.setParentType(TreeObjectVO.TreeParentType.SELF.toString());
            objectVO.setParentId(tableVo.getGroupId());
            treeService.addTreeObject(objectVO,userId, itemRecord.getId());
            return createAnalyzeTable(tableVo.getTableName().toLowerCase(),requestColumns,userId,token);
        }catch (Exception e){
            e.printStackTrace();
            return  new ResultVo<>(ErrorCode.SystemConfigError.getErrorCode());
        }finally {
            JDBCUtil.releaseConn(connection,statement,rs);

        }

    }

    private ResultVo<String> createAnalyzeTable(String tableName,List<JSONObject> requestColumns,String userId,String token){
        JSONObject requestBody=new JSONObject();
        requestBody.put("cuids", Arrays.asList(userId));
        JSONObject table=new JSONObject();
        table.put("schema","default");
        table.put("tableName",tableName.toLowerCase());
        table.put("tableType",0);
        table.put("columns",requestColumns);
        requestBody.put("tables",Arrays.asList(table));
        String url=idmanagerBaseUrl+CREATE_ANALYZE_TABLE_REST_PATH;
        Map<String,String> headers=new HashMap<>();
        headers.put("Authorization",token);
        headers.put("Content-type","application/json");
        ResultVo<ResponseVo> resp=HttpClientUtil.doPostByJson(url,requestBody.toJSONString(),headers);
        if(resp.getData() == null||StringUtil.isEmpty(resp.getData().getData()) || resp.getData().getData().contains("error")){
            String errorMsg="resp is empty";
            if(resp.getData()!=null && resp.getData().getData()!=null){
                errorMsg=resp.getData().getData();
            }
            return new ResultVo<>(ErrorCode.CreateAnalyzeTableFail.getErrorCode(),null,errorMsg);
        }
        JSONArray analyzeTableIds= JSON.parseArray(resp.getData().getData());
        return new ResultVo<>(0,analyzeTableIds.getString(0));
    }

    private JSONObject constructRequestColumn(String columnName,String dataType){
        JSONObject requestColumn=new JSONObject();
        requestColumn.put("colName",columnName);
        requestColumn.put("colAnalyzeType",0);
        requestColumn.put("colDisplayName",columnName);
        requestColumn.put("colExp","");
        requestColumn.put("colDataType",0);
        requestColumn.put("dbType",dataType.toUpperCase());
        return requestColumn;
    }

}
