/**
 * Copyright 2017 Institute of Computing Technology, Chinese Academy of Sciences.
 * Licensed under the terms of the Apache 2.0 license.
 * Please see LICENSE file in the project root for terms
 */
package com.cdid.service.oozie.command;


public interface FileDescription {
	/**
	 * File store type:
	 * - SFile: local file
	 * - HFile: HDFS file
	 * - Directory: local/HDFS directory
	 */
	 enum StoreType {
		SFile("SFile"), HFile("HFile"), Directory("Directory"),None("None");

		private String name;

		StoreType(String name) {
			this.name = name;
		}

		public static StoreType get(String name) {
			if ("SFile".equals(name)) {
				return SFile;
			} else if ("HFile".equals(name)) {
				return HFile;
			} else if ("Directory".equals(name)) {
				return Directory;
			} else {
				return HFile;
			}
		}
		@Override
		public String toString() {
			return name;
		}
	}

	 String getContentType();
	 void setContentType(String contentType);

	 StoreType getStoreType();
	 void setStoreType(StoreType storeType);

	 String getPath();
	 void setPath(String path);

	 String getFileName();
	 void setFileName(String name);

	 String getDescription();
}

