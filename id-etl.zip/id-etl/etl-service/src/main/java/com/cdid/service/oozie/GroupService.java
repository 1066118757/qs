package com.cdid.service.oozie;

import com.cdid.api.common.IDGeneratorService;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.metadata.item.ItemDao;
import com.cdid.dao.oozie.*;
import com.cdid.dao.storagedata.StorageDataManageDao;
import com.cdid.dao.user.UsersDao;
import com.cdid.jooq.tables.*;
import com.cdid.jooq.tables.records.*;
import com.cdid.service.oozie.vo.GroupUserVO;
import com.cdid.service.oozie.vo.GroupVO;
import com.cdid.service.oozie.vo.OozieShareVO;
import com.cdid.service.oozie.vo.TreeObjectVO;
import com.cdid.utils.StringUtil;
import com.google.common.collect.Sets;
import org.jooq.Condition;
import org.jooq.Record2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class GroupService {

    @Autowired
    GroupDao groupDao;

    @Autowired
    ShareDao shareDao;

    @Autowired
    GroupUserDao groupUserDao;

    @Autowired
    ProgramDao programDao;

    @Autowired
    StorageDataManageDao storageDataManageDao;

    @Autowired
    ItemDao itemDao;

    @Autowired
    OozieObjectTreeService treeService;

    @Autowired
    TreeObjectDao treeObjectDao;

    @Autowired
    IDGeneratorService<Long> idService;

    @Autowired
    UsersDao usersDao;

    public ResultVo<String> saveOrUpdateGroup(GroupVO groupVO, String userId) {
        GroupRecord groupRecord;
        if (StringUtil.isEmpty(groupVO.getId())) {
            groupRecord = new GroupRecord();
            groupRecord.setId(UUID.randomUUID().toString());
            groupRecord.setCreateBy(userId);
            groupRecord.setName(groupVO.getName());
            groupRecord.setCreateAt(new Timestamp(System.currentTimeMillis()));
            groupRecord.setGroupType(groupVO.getGroupType().shortValue());
            groupDao.insert(groupRecord);
            return new ResultVo<>(0, groupRecord.getId());
        }
        groupRecord = groupDao.findById(groupVO.getId());
        if (groupRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
        }
        groupRecord.setName(groupVO.getName());
        groupDao.update(groupRecord);
        return new ResultVo<>(0, groupRecord.getId());
    }

    public ResultVo<Boolean> deleteGroup(String groupId) {
        List<String> deleteUserIdList = groupUserDao.fetchFieldByConditions(MGroupUser.M_GROUP_USER.USER_ID, Arrays.asList(MGroupUser.M_GROUP_USER.GROUP_ID.eq(groupId)));
        deleteTreeObjectOfGroup(groupId, deleteUserIdList);
        return new ResultVo<>(0, true);
    }

    public ResultVo<List<GroupVO>> listGroup(Integer groupType) {
        List<GroupRecord> groupRecordList = groupDao.fetch(Group.GROUP.GROUP_TYPE, groupType.shortValue());
        GroupVO groupVO = new GroupVO();
        List<GroupVO> groupVOList = new ArrayList<>();
        for (GroupRecord groupRecord : groupRecordList) {
            groupVO.setId(groupRecord.getId());
            groupVO.setName(groupRecord.getName());
            groupVO.setGroupType(groupType);
            groupVOList.add(groupVO);
        }
        return new ResultVo<>(0, groupVOList);
    }

    public ResultVo<Boolean> addUsers(String groupId, List<String> userIdList) {
        List<TOozieShareRecord> shareRecords = findShareList(groupId);
        if (!shareRecords.isEmpty()) {
            Map<String, List<TOozieShareRecord>> map = shareRecords.stream().collect(Collectors.groupingBy(a -> a.getSourceObjectType()));
            TreeObjectVO treeObjectVO;
            List<TTreeObjectRecord> treeObjectRecords = new ArrayList<>();
            Set<String> userIdSet=new HashSet<>(userIdList);
            for (Map.Entry<String, List<TOozieShareRecord>> entry : map.entrySet()) {
                Set<BigDecimal> sourceObjectIdSet = entry.getValue().stream().map(a -> a.getSourceObjectId()).collect(Collectors.toSet());
                List<Condition> conditionList=new ArrayList<>();
                conditionList.add(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID.in(sourceObjectIdSet));
                conditionList.add(TTreeObject.T_TREE_OBJECT.LEAF_OBJECT_TYPE.eq(entry.getKey()));
                conditionList.add(TTreeObject.T_TREE_OBJECT.PARENT_TYPE.eq(TreeObjectVO.TreeParentType.SHARE.toString()));
                Map<BigDecimal,Set<String>> sourceIdUserIdSetMap=listToMap(treeObjectDao.findByConditions(conditionList));
                if (entry.getKey().equals(OozieShareVO.SourceObjectType.PROGRAM.toString())) {
                    List<TProgramRecord> recordList = programDao.fetch(TProgram.T_PROGRAM.ID, sourceObjectIdSet);
                    for (TProgramRecord programRecord : recordList) {
                        treeObjectVO = new TreeObjectVO();
                        treeObjectVO.setName(programRecord.getName());
                        treeObjectVO.setObjectType(TreeObjectVO.TreeObjectType.PROGRAM.toString());
                        treeObjectVO.setLeafObjectType(TreeObjectVO.LeafObjectType.PROGRAM.toString());
                        treeObjectVO.setParentType(TreeObjectVO.TreeParentType.SHARE.toString());
                        treeObjectRecords.addAll(constructTreeObjects(programRecord.getId(),sourceIdUserIdSetMap,userIdSet,treeObjectVO));
                    }
                } else if (entry.getKey().equals(OozieShareVO.SourceObjectType.FILE.toString())) {
                    List<TStorageDataRecord> dataRecords = storageDataManageDao.fetch(TStorageData.T_STORAGE_DATA.ID, sourceObjectIdSet);
                    for (TStorageDataRecord dataRecord : dataRecords) {
                        treeObjectVO = new TreeObjectVO();
                        treeObjectVO.setName(dataRecord.getName());
                        treeObjectVO.setObjectType(TreeObjectVO.TreeObjectType.DATA.toString());
                        treeObjectVO.setLeafObjectType(TreeObjectVO.LeafObjectType.FILE.toString());
                        treeObjectVO.setParentType(TreeObjectVO.TreeParentType.SHARE.toString());
                        treeObjectRecords.addAll(constructTreeObjects(dataRecord.getId(),sourceIdUserIdSetMap,userIdSet,treeObjectVO));
                    }
                } else if (entry.getKey().equals(OozieShareVO.SourceObjectType.TABLE.toString())) {
                    List<TMetadataItemRecord> itemRecordList = itemDao.fetch(TMetadataItem.T_METADATA_ITEM.ID, sourceObjectIdSet);
                    for (TMetadataItemRecord itemRecord : itemRecordList) {
                        treeObjectVO = new TreeObjectVO();
                        treeObjectVO.setName(itemRecord.getName());
                        treeObjectVO.setObjectType(TreeObjectVO.TreeObjectType.DATA.toString());
                        treeObjectVO.setLeafObjectType(TreeObjectVO.LeafObjectType.TABLE.toString());
                        treeObjectVO.setParentType(TreeObjectVO.TreeParentType.SHARE.toString());
                        treeObjectRecords.addAll(constructTreeObjects(itemRecord.getId(),sourceIdUserIdSetMap,userIdSet,treeObjectVO));
                    }
                }
            }
            if (!treeObjectRecords.isEmpty()) {
                treeObjectDao.insert(treeObjectRecords);
            }
        }
        List<MGroupUserRecord> groupUserRecords = new ArrayList<>();
        MGroupUserRecord groupUserRecord;
        Timestamp now = new Timestamp(System.currentTimeMillis());
        for (String userId : userIdList) {
            groupUserRecord = new MGroupUserRecord();
            groupUserRecord.setId(BigDecimal.valueOf(idService.id()));
            groupUserRecord.setGroupId(groupId);
            groupUserRecord.setCreateTime(now);
            groupUserRecord.setUserId(userId);
            groupUserRecords.add(groupUserRecord);
        }
        deleteGroupUser(groupId, userIdList);
        groupUserDao.insert(groupUserRecords);
        return new ResultVo<>(0, true);
    }

    private  Map<BigDecimal,Set<String>> listToMap(List<TTreeObjectRecord> recordList){
        Map<BigDecimal,Set<String>> sourceObjectIdUsersMap=new HashMap<>();
        for(TTreeObjectRecord record:recordList){
            Set<String> userIdSet=sourceObjectIdUsersMap.get(record.getSourceObjectId());
            if(userIdSet == null){
                userIdSet=new HashSet<>();
            }
            userIdSet.add(record.getCreateUser());
            sourceObjectIdUsersMap.put(record.getSourceObjectId(),userIdSet);
        }
        return sourceObjectIdUsersMap;
    }

    public void removeGroupUser(String groupId, List<String> userIdList) {
        deleteGroupUser(groupId, userIdList);
        deleteTreeObjectOfGroup(groupId, userIdList);
    }

    private List<TTreeObjectRecord> constructTreeObjects(BigDecimal sourceObjectId,Map<BigDecimal,Set<String>> sourceIdUserIdSetMap,Set<String> userIdSet,TreeObjectVO treeObjectVO){
        Set<String> existedUserIdSet=sourceIdUserIdSetMap.get(sourceObjectId);
        if(existedUserIdSet!=null){
            return treeService.constructTreeObject(Sets.difference(userIdSet,existedUserIdSet), treeObjectVO, sourceObjectId);
        }
        return treeService.constructTreeObject(userIdSet,treeObjectVO,sourceObjectId);
    }

    public PageVo<GroupUserVO> findGroupUser(String groupId, int page, int size) {
        PageVo<Record2<String, String>> pageVo = usersDao.findGroupUserByPage(groupId, new OffsetPagingVo(page, size));
        List<GroupUserVO> content = pageVo.getPageData().stream().map(a -> {
            GroupUserVO groupUserVO = new GroupUserVO();
            groupUserVO.setUserId(a.value1());
            groupUserVO.setUserName(a.value2());
            return groupUserVO;
        }).collect(Collectors.toList());
        return new PageVo<>(pageVo.getTotalCount(), content);
    }

    private void deleteGroupUser(String groupId, List<String> userIdList) {
        List<Condition> deleteConditions = new ArrayList<>();
        deleteConditions.add(MGroupUser.M_GROUP_USER.GROUP_ID.eq(groupId));
        deleteConditions.add(MGroupUser.M_GROUP_USER.USER_ID.in(userIdList));
        groupUserDao.deleteByConditions(deleteConditions);
    }

    private void deleteTreeObjectOfGroup(String groupId, List<String> userIdList) {
        List<TOozieShareRecord> shareRecords = findShareList(groupId);
        Set<BigDecimal> sourceIdSet = shareRecords.stream().map(a -> a.getSourceObjectId()).collect(Collectors.toSet());
        userIdList.removeAll(getNotDeleteUserIdList(groupId, sourceIdSet));
        if (!userIdList.isEmpty()) {
            List<Condition> deleteConditionList = new ArrayList<>();
            deleteConditionList.add(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID.in(sourceIdSet));
            deleteConditionList.add(TTreeObject.T_TREE_OBJECT.CREATE_USER.in(userIdList));
        }
    }

    private List<TOozieShareRecord> findShareList(String groupId) {
        List<Condition> conditionList = new ArrayList<>();
        conditionList.add(TOozieShare.T_OOZIE_SHARE.DIST_OBJECT_ID.eq(groupId));
        conditionList.add(TOozieShare.T_OOZIE_SHARE.DIST_OBJECT_TYPE.eq(OozieShareVO.DistObjectType.GROUP.toString()));
        return shareDao.findByConditions(conditionList);
    }

    private List<String> getNotDeleteUserIdList(String groupId, Set<BigDecimal> shareSourceObjectIdSet) {
        List<String> notDeleteUserIdList = new ArrayList<>();
        List<Condition> conditionList = new ArrayList<>();
        conditionList.add(TOozieShare.T_OOZIE_SHARE.SOURCE_OBJECT_ID.in(shareSourceObjectIdSet));
        conditionList.add(TOozieShare.T_OOZIE_SHARE.DIST_OBJECT_ID.notEqual(groupId));
        List<TOozieShareRecord> otherShares = shareDao.findByConditions(conditionList);
        if (!otherShares.isEmpty()) {
            notDeleteUserIdList.addAll(otherShares.stream().filter(a -> a.getDistObjectType().equals(OozieShareVO.DistObjectType.USER.toString())).map(a -> a.getDistObjectId()).collect(Collectors.toList()));
            List<String> groupIdList = otherShares.stream().filter(a -> a.getDistObjectType().equals(OozieShareVO.DistObjectType.GROUP.toString())).map(a -> a.getDistObjectId()).collect(Collectors.toList());
            if (!groupIdList.isEmpty()) {
                notDeleteUserIdList.addAll(groupUserDao.fetchFieldByConditions(MGroupUser.M_GROUP_USER.USER_ID, Arrays.asList(MGroupUser.M_GROUP_USER.GROUP_ID.in(groupIdList))));
            }
        }
        return notDeleteUserIdList;
    }
}
