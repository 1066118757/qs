package com.cdid.service.oozie.vo;

public class ProgramQueryVO {

    private String name;

    //1:我自己的:my，2:别人公开的:public.3.别人分享的:shared,4:所有的:ALL
    private String queryType="MY";

    private Boolean downloadable;

    private String owner;

    public Boolean getDownloadable() {
        return downloadable;
    }

    public void setDownloadable(Boolean downloadable) {
        this.downloadable = downloadable;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getQueryType() {
        return queryType;
    }

    public void setQueryType(String queryType) {
        this.queryType = queryType;
    }

    public static enum QueryType{
        MY,PUBLIC,SHARE,ALL;
    }
}
