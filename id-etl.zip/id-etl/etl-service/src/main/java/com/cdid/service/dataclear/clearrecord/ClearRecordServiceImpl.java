package com.cdid.service.dataclear.clearrecord;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cdid.api.common.IDGeneratorService;
import com.cdid.api.common.RedisService;
import com.cdid.api.dataclear.clearrecord.ClearRecordService;
import com.cdid.api.dataclear.clearrecord.vo.*;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.dataclear.clearrecord.ClearRecordDao;
import com.cdid.dao.metadata.item.ItemDao;
import com.cdid.dao.user.UsersDao;
import com.cdid.jooq.tables.records.TClearRecordRecord;
import com.cdid.jooq.tables.records.TMetadataItemRecord;
import com.cdid.service.job.JobServiceUtil;
import com.cdid.utils.VoReTraversalUtil;
import org.jooq.Condition;
import org.jooq.SortField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import static com.cdid.jooq.tables.TClearRecord.T_CLEAR_RECORD;
/**
 * 数据整理记录的实现
 */
@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class ClearRecordServiceImpl implements ClearRecordService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ClearRecordDao clearRecordDao;
    @Autowired
    private IDGeneratorService<Long> idGeneratorService;
    @Autowired
    KafkaTemplate kafkaTemplate;
    @Autowired
    private ItemDao itemDao;
    @Autowired
    RedisService redisService;
    @Autowired
    private UsersDao usersDao;

    /**
     * 数据整理记录添加
     *
     * @param clearRecordAddVo
     * @param userId
     * @return
     */
    @Override
    public ResultVo<Object> add(ClearRecordAddVo clearRecordAddVo, String userId) {
        ResultVo<Object> resultVo = new ResultVo<Object>();
        try {
            //判断传入的itemId是否正确
            BigDecimal metadataItemId = clearRecordAddVo.getMetadataItemId();
            String handleCode = clearRecordAddVo.getHandleCode();
            if (handleCode==null || handleCode.equals("")){
                return new ResultVo<>(ErrorCode.ParamError.getErrorCode(),"必须传入正确的handleCode！");
            }
            TMetadataItemRecord itemRecord = itemDao.findById(metadataItemId);
            if (itemRecord==null){
                return new ResultVo<>(ErrorCode.ParamError.getErrorCode(),"传入的metadataItemId错误，没有该条Item记录，请重新传入正确参数！");
            }
            TClearRecordRecord tClearRecordRecord = (TClearRecordRecord) VoReTraversalUtil.traversalTwo(clearRecordAddVo, TClearRecordRecord.class);
            BigDecimal id = BigDecimal.valueOf(idGeneratorService.id());
            tClearRecordRecord.setId(id);
            //创建人，同时也是更新人
            tClearRecordRecord.setCreateUser(userId);
            tClearRecordRecord.setUpdateUser(userId);
            //插入表中
            clearRecordDao.insert(tClearRecordRecord);
            /*//获取规则实例化信息以及参数信息插入表中
            List<RuleInstanceAddVo> ruleInstanceAddVos = clearRecordAddVo.getRuleInstanceAddVos();
            //为ruleInstanceAddVos里面每个元素增加记录id字段
            for (RuleInstanceAddVo item:ruleInstanceAddVos) {
                item.setClearRecordId(id);
            }
            ruleInstanceService.add(ruleInstanceAddVos,userId);*/

            resultVo.setData(id.toString());
            return resultVo;
        } catch (Exception e) {
            e.printStackTrace();
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            return resultVo;
        }
    }

    /**
     * 数据整理记录更新
     *
     * @param clearRecordUpdateVo
     * @param userId
     * @return
     */
    @Override
    public ResultVo<Object> update(ClearRecordUpdateVo clearRecordUpdateVo, String userId) {
        ResultVo<Object> resultVo = new ResultVo<Object>();
        try {
            //从数据库查询出需要修改的信息
            TClearRecordRecord tClearRecordRecord = clearRecordDao.findById(clearRecordUpdateVo.getId());
            if (tClearRecordRecord == null) {
                return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
            }
            //调用方法设置值
            tClearRecordRecord = (TClearRecordRecord) VoReTraversalUtil.traversalTwo(clearRecordUpdateVo, TClearRecordRecord.class);
            //更新人
            tClearRecordRecord.setUpdateUser(userId);
            //更新时间
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            tClearRecordRecord.setUpdateTime(timestamp);
            clearRecordDao.update(tClearRecordRecord);
            /*//更新实例化信息，先删除在增加
            List<RuleInstanceAddVo> ruleInstanceAddVos = clearRecordUpdateVo.getRuleInstanceAddVos();
            //删除,先通过记录id查询出对应的所有实例化id
            BigDecimal recordId = clearRecordUpdateVo.getId();
            List<TRuleInstanceRecord> tRuleInstanceRecords = ruleInstanceDao.fetch(T_RULE_INSTANCE.CLEAR_RECORD_ID, recordId);
            for (TRuleInstanceRecord item:tRuleInstanceRecords) {
                ruleInstanceService.delete(item.getId());
            }
            //新增
            //为ruleInstanceAddVos里面每个元素增加记录id字段
            for (RuleInstanceAddVo item:ruleInstanceAddVos) {
                item.setClearRecordId(recordId);
            }
            ruleInstanceService.add(ruleInstanceAddVos,userId);*/
            resultVo.setData("success");
            return resultVo;
        } catch (Exception e) {
            e.printStackTrace();
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            return resultVo;
        }
    }

    /**
     * 数据整理记录删除
     *
     * @param id
     * @return
     */
    @Override
    public ResultVo<Object> delete(BigDecimal id) {
        //查询是否存在
        TClearRecordRecord tClearRecordRecord = clearRecordDao.findById(id);
        if (tClearRecordRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), false);
        }
        //判断，xxx情况不允许删除

        //删除
        List<BigDecimal> ids = new ArrayList<>();
        ids.add(id);
        clearRecordDao.deleteById(ids);
        //删除对应的规则实例化信息
        /*List<TRuleInstanceRecord> tRuleInstanceRecords = ruleInstanceDao.fetch(T_RULE_INSTANCE.CLEAR_RECORD_ID, id);
        for (TRuleInstanceRecord item:tRuleInstanceRecords) {
            ruleInstanceService.delete(item.getId());
        }*/
        return new ResultVo<>(0, true);

    }

    /**
     * 数据整理记录列表查询
     *
     * @param clearRecordQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    @Override
    public ResultVo<PageVo<List<ClearRecordListVo>>> list(ClearRecordQueryVo clearRecordQueryVo, String userId, Integer page, Integer size) {
        List<SortField<?>> sortList = new ArrayList<>();
        //添加排序字段
        sortList.add(T_CLEAR_RECORD.UPDATE_TIME.desc());
        //添加条件字段
        List<Condition> conditions = innerAddListCondition(clearRecordQueryVo);
        //增加权限判断，登录用户只能看到自己创建的记录信息
        if (userId!=null){
            conditions.add(T_CLEAR_RECORD.CREATE_USER.eq(userId));
        }
        //查询赋值返回
        PageVo<TClearRecordRecord> query = clearRecordDao.fetchByPage(conditions, new OffsetPagingVo(page, size), sortList);
        List<TClearRecordRecord> tClearRecordRecords;
        tClearRecordRecords = query.getPageData();
        List<ClearRecordListVo> list = new ArrayList<>();
        for (TClearRecordRecord tClearRecordRecord : tClearRecordRecords
                ) {
            ClearRecordListVo clearRecordListVo = (ClearRecordListVo) VoReTraversalUtil.traversalTwo(tClearRecordRecord, ClearRecordListVo.class);
            //查询操作表名
            BigDecimal itemId = tClearRecordRecord.getMetadataItemId();
            if (itemId!=null){
                TMetadataItemRecord record = itemDao.findById(itemId);
                if (record!=null){
                    String name = record.getName();
                    clearRecordListVo.setTableName(name);
                }
            }
            //查询规则实例化信息
            //List<RuleInstanceListVo> ruleInstanceListVos = ruleInstanceService.listByRecordId(tClearRecordRecord.getId(), userId);
            //设置进clearRuleListVo
            //clearRecordListVo.setRuleInstanceListVos(ruleInstanceListVos);
            //查询创建者名字
            String name = usersDao.getNameByUserId(tClearRecordRecord.getCreateUser());
            clearRecordListVo.setCreateUserName(name);
            list.add(clearRecordListVo);
        }
        PageVo<ClearRecordListVo> result = new PageVo<>();
        result.setPageData(list);
        result.setTotalCount(query.getTotalCount());
        return new ResultVo(0, result);
    }

    /**
     * 为list添加条件字段的方法
     *
     * @param clearRecordQueryVo
     * @return
     */
    private List<Condition> innerAddListCondition(ClearRecordQueryVo clearRecordQueryVo) {
        List<Condition> conditions = new ArrayList<>();
        //添加条件字段
        String name = clearRecordQueryVo.getName();
        if (name!=null){
            conditions.add(T_CLEAR_RECORD.NAME.like("%"+name+"%"));
        }
        return conditions;
    }

    /**
     * 数据整理记录详情查询
     *
     * @param id
     * @return
     */
    @Override
    public ResultVo<ClearRecordDetailVo> clearRecordById(BigDecimal id) {
        TClearRecordRecord tClearRecordRecord = clearRecordDao.findById(id);
        if (tClearRecordRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), null);
        }
        ClearRecordDetailVo clearRecordClearRecordVo = (ClearRecordDetailVo) VoReTraversalUtil.traversalTwo(tClearRecordRecord, ClearRecordDetailVo.class);
        //查询操作表名
        BigDecimal itemId = clearRecordClearRecordVo.getMetadataItemId();
        if (itemId!=null){
            TMetadataItemRecord record = itemDao.findById(itemId);
            if (record!=null){
                String name = record.getName();
                clearRecordClearRecordVo.setTableName(name);
            }
        }
        //查询规则实例化信息
        //List<RuleInstanceListVo> ruleInstanceListVos = ruleInstanceService.listByRecordId(tClearRecordRecord.getId(), BigDecimal.ZERO);
        //设置进clearRuleListVo
        //clearRecordClearRecordVo.setRuleInstanceListVos(ruleInstanceListVos);
        //查询创建者名字
        String name = usersDao.getNameByUserId(tClearRecordRecord.getCreateUser());
        clearRecordClearRecordVo.setCreateUserName(name);
        return new ResultVo<>(0, clearRecordClearRecordVo);
    }

    /**
     * 清洗结果预览
     * @param handleCode
     * @return
     */
    @Override
    public ResultVo clearResultPreview(String handleCode) {
        ResultVo<Object> resultVo = new ResultVo<>();
        JSONObject handleCodeJSON= JSON.parseObject(handleCode);
        long taskId =idGeneratorService.id();
        String redisKey="dataCleanPreviewResult_"+taskId;
        handleCodeJSON.put("taskId",String.valueOf(taskId));
        try {
            JSONObject jsonObject = new JSONObject();
            String message=new String(Base64.getEncoder().encode(handleCodeJSON.toJSONString().getBytes("UTF-8")),"UTF-8");
            jsonObject.put("config",message);
            jsonObject.put("businessType","dataCleanPreview");
            jsonObject.put("taskId",taskId);
            kafkaTemplate.send(JobServiceUtil.KAFAKA_TOPIC_DATACONFIG,jsonObject.toJSONString());
        } catch (Exception e) {
            logger.error(e.getMessage(),e);
            e.printStackTrace();
        }
        resultVo.setErrorCode(0);
        resultVo.setData(redisKey);
        return resultVo;
    }

    /**
     * 通过redisKey从Redis查询数据的方法
     * @param redisKey
     * @return
     */
    @Override
    public ResultVo getRedisData(String redisKey) {
        String jsonString = redisService.get(redisKey);
        return new ResultVo(0,jsonString);
    }
}
