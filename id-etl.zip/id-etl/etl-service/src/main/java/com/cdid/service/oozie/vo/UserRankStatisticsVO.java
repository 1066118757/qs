package com.cdid.service.oozie.vo;

import org.jooq.Record3;

public class UserRankStatisticsVO {

    private String id;

    private String name;

    private Integer count;

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public UserRankStatisticsVO() {
    }

    public UserRankStatisticsVO(Record3<String,String,Integer> record3) {
        this.id = record3.value1();
        this.name = record3.value2();
        this.count = record3.value3();
    }

    public UserRankStatisticsVO(Integer count, String id, String name) {
        this.count = count;
        this.id = id;
        this.name = name;
    }




}
