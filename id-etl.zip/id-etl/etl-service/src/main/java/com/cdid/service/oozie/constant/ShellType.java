package com.cdid.service.oozie.constant;

public enum ShellType {
}
