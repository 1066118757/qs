package com.cdid.service.oozie.exception;

public class BuildWorkFlowException extends Exception {

    public BuildWorkFlowException(String message) {
        super(message);
    }

    public BuildWorkFlowException(Throwable cause) {
        super(cause);
    }

    public BuildWorkFlowException() {
    }
}
