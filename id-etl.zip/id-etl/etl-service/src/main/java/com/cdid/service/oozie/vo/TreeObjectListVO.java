package com.cdid.service.oozie.vo;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;

public class TreeObjectListVO {

    private BigDecimal id;

    private String name;

    private String createUser;

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public TreeObjectListVO() {
    }

    public TreeObjectListVO(BigDecimal id, String name) {
        this.id = id;
        this.name = name;
    }
}
