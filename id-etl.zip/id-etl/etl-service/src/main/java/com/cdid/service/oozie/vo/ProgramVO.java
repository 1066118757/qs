package com.cdid.service.oozie.vo;

import com.alibaba.fastjson.JSON;
import com.cdid.jooq.tables.records.TProgramRecord;
import com.cdid.service.oozie.command.Parameter;
import com.cdid.utils.VoReTraversalUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class ProgramVO {

    private BigDecimal id;

    private String name;

    private String path;

    private String fileName;

    private String personalConf;

    private String programType="JAVA";

    private Boolean isPublic=false;

    private Boolean downloadable=false;

    private String label;

    private String description;

    private String sourceLink;

    private Long createTime;

    private Long updateTime;

    private BigDecimal groupId;

    private List<Parameter> parameters=new ArrayList<>();


    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getPersonalConf() {
        return personalConf;
    }

    public void setPersonalConf(String personalConf) {
        this.personalConf = personalConf;
    }

    public Boolean getIsPublic() {
        return isPublic;
    }

    public void setIsPublic(Boolean isPublic) {
        this.isPublic = isPublic;
    }

    public Boolean getDownloadable() {
        return downloadable;
    }

    public void setDownloadable(Boolean downloadable) {
        this.downloadable = downloadable;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSourceLink() {
        return sourceLink;
    }

    public void setSourceLink(String sourceLink) {
        this.sourceLink = sourceLink;
    }

    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    public Long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }

    public List<Parameter> getParameters() {
        return parameters;
    }

    public void setParameters(List<Parameter> parameters) {
        this.parameters = parameters;
    }

    public String getProgramType() {
        return programType;
    }

    public void setProgramType(String programType) {
        this.programType = programType;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public static ProgramVO valueOf(TProgramRecord record)  {
        ProgramVO programVO=VoReTraversalUtil.traversalTo(record,ProgramVO.class);
        programVO.setCreateTime(record.getCreateTime().getTime());
        programVO.setUpdateTime(record.getUpdateTime().getTime());
        programVO.setParameters(JSON.parseArray(record.getParameters(),Parameter.class));
        programVO.setFileName(record.getFilename());
        programVO.setProgramType(record.getProgramtype());
        return programVO;
    }

    public BigDecimal getGroupId() {
        return groupId;
    }

    public void setGroupId(BigDecimal groupId) {
        this.groupId = groupId;
    }
}
