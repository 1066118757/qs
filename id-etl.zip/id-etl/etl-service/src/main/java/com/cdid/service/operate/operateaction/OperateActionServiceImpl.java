package com.cdid.service.operate.operateaction;

import com.cdid.api.common.IDGeneratorService;
import com.cdid.api.operate.operateaction.OperateActionService;
import com.cdid.api.operate.operateaction.vo.OperateActionAddVo;
import com.cdid.api.operate.operateaction.vo.OperateActionQueryVo;
import com.cdid.api.operate.operateaction.vo.OperateActionVo;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.operate.operateaction.OperateActionDao;
import com.cdid.jooq.tables.records.TOperateActionRecord;
import com.cdid.utils.VoReTraversalUtil;
import org.jooq.Condition;
import org.jooq.SortField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static com.cdid.jooq.tables.TOperateAction.T_OPERATE_ACTION;

/**
 * @Author LQL
 * @CreateAt 2017/11/28
 */
@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class OperateActionServiceImpl implements OperateActionService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private OperateActionDao operateActionDao;
    @Autowired
    private IDGeneratorService<Long> idGeneratorService;

    /**
     * 添加操作日志描述
     * @param operateActionAddVo
     * @return
     */
    @Override
    public ResultVo<Object> add(OperateActionAddVo operateActionAddVo){
        ResultVo<Object> resultVo = new ResultVo<Object>();
        try {
            TOperateActionRecord operateActionRecord = new TOperateActionRecord();
            operateActionRecord.setId(operateActionAddVo.getId());
            operateActionRecord.setActionDesc(operateActionAddVo.getActionDesc());
            operateActionRecord.setScope(operateActionAddVo.getScope());
            operateActionDao.insert(operateActionRecord);
            resultVo.setData("success");
            return resultVo;
        } catch (Exception e) {
            e.printStackTrace();
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            return resultVo;
        }
    }

    /**
     * 更新操作日志描述
     * @param operateActionVo
     * @return
     */
    @Override
    public ResultVo<Object> update(OperateActionVo operateActionVo) {
        ResultVo<Object> resultVo = new ResultVo<>();
        try {
            Integer id = operateActionVo.getId();
            if (id == null) {
                resultVo.setErrorCode(ErrorCode.NotExists.getErrorCode());
                return resultVo;
            } else  {
                String actionDesc = operateActionVo.getActionDesc();
                TOperateActionRecord operateActionRecord = new TOperateActionRecord();
                operateActionRecord.setId(id);
                operateActionRecord.setActionDesc(actionDesc);
                operateActionDao.update(operateActionRecord);
                resultVo.setData("success");
                return resultVo;
            }
        } catch (Exception e) {
            e.printStackTrace();
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            return resultVo;
        }
    }

    /**
     * 删除操作描述
     *
     * @param id
     * @return
     */
    @Override
    public ResultVo<Object> delete(BigDecimal id) {
        ResultVo<Object> resultVo = new ResultVo<>();
        try{
            TOperateActionRecord tOperateActionRecord = operateActionDao.findById(id);
            if (tOperateActionRecord == null) {
                resultVo.setErrorCode(ErrorCode.NotExists.getErrorCode());
                return resultVo;
            } else  {
                operateActionDao.delete(tOperateActionRecord);
                resultVo.setData("success");
                return resultVo;
            }
        } catch (Exception e) {
            e.printStackTrace();
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            return resultVo;
        }
    }

    @Override
    public ResultVo<OperateActionVo> detailById(BigDecimal id) {
        ResultVo<OperateActionVo> resultVo = new ResultVo<>();
        try{
            TOperateActionRecord tOperateActionRecord = operateActionDao.findById(id);
            if (tOperateActionRecord == null) {
                resultVo.setErrorCode(ErrorCode.NotExists.getErrorCode());
                return resultVo;
            } else {
                OperateActionVo operateActionVo = new OperateActionVo();
                operateActionVo.setId(tOperateActionRecord.getId());
                operateActionVo.setActionDesc(tOperateActionRecord.getActionDesc());
                resultVo.setData(operateActionVo);
                return resultVo;
            }
        } catch (Exception e) {
            e.printStackTrace();
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            return resultVo;
        }
    }

    @Override
    public ResultVo<PageVo<List<OperateActionVo>>> list(OperateActionQueryVo operateActionQueryVo, String userId, Integer page, Integer size) {
        List<SortField<?>> sortList = new ArrayList<>();
        //添加排序字段
        sortList.add(T_OPERATE_ACTION.ID.asc());
        //添加条件字段
        List<Condition> conditions = innerAddListCondition(operateActionQueryVo);
        //查询赋值返回
        PageVo<TOperateActionRecord> query = operateActionDao.fetchByPage(conditions, new OffsetPagingVo(page, size), sortList);
        List<TOperateActionRecord> tMetadataItemRecords;
        tMetadataItemRecords=query.getPageData();
        List<OperateActionVo> list = new ArrayList<>();
        for (TOperateActionRecord item : tMetadataItemRecords
                ) {
            OperateActionVo  actionVo= (OperateActionVo) VoReTraversalUtil.traversalTwo(item, OperateActionVo.class);
            //查询创建者名字
            list.add(actionVo);
        }
        PageVo<OperateActionVo> result = new PageVo<>();
        result.setPageData(list);
        result.setTotalCount(query.getTotalCount());
        return new ResultVo(0, result);
    }

    /**
     * 为list添加条件字段的方法
     * @param operateActionQueryVo
     * @return
     */
    private List<Condition> innerAddListCondition(OperateActionQueryVo operateActionQueryVo){
        List<Condition> conditions = new ArrayList<>();
        //添加条件字段
        Integer id = operateActionQueryVo.getId();
        String actionDesc = operateActionQueryVo.getActionDesc();
        Integer scope = operateActionQueryVo.getScope();
        if (id!=null){
            conditions.add(T_OPERATE_ACTION.ID.eq(id));
        }
        if (actionDesc!=null){
            conditions.add(T_OPERATE_ACTION.ACTION_DESC.like("%"+actionDesc+"%"));
        }
        if (scope!=null){
            conditions.add(T_OPERATE_ACTION.SCOPE.eq(scope));
        }
        return conditions;
    }
}
