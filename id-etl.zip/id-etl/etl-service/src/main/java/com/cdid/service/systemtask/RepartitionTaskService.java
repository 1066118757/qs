package com.cdid.service.systemtask;

import com.alibaba.fastjson.JSONObject;
import com.cdid.common.constant.RecordStatus;
import com.cdid.config.PropertyUtil;
import com.cdid.dao.metadata.item.ItemDao;
import com.cdid.jooq.tables.TMetadataItem;
import com.cdid.service.job.JobServiceUtil;
import com.cdid.service.oozie.util.HDFSIO;
import com.cdid.utils.StringUtil;
import org.apache.hadoop.fs.Path;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class RepartitionTaskService implements Job {

    private static Logger logger = LoggerFactory.getLogger(RepartitionTaskService.class);

    @Value("${dist.ip}")
    private String distIp;
    @Value("${dist.port}")
    private String distPort;
    @Value("${dist.username}")
    private String distUserName;
    @Value("${dist.password}")
    private String distPassword;

    @Autowired
    KafkaTemplate kafkaTemplate;

    @Autowired
    ItemDao  itemDao;

    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        List<String> tables=itemDao.fetchFieldByConditions(TMetadataItem.T_METADATA_ITEM.NAME, Arrays.asList(TMetadataItem.T_METADATA_ITEM.STATUS.eq(RecordStatus.Effective.getStatus())));
        long blockSize_MB=Long.valueOf(PropertyUtil.getMergedProperty("repartition.block.size_mb","64"));
        long partitionSize=blockSize_MB*1024*1024;
        for(String table:tables){
            String tableName=table.toLowerCase();
            repartition(tableName,String.valueOf(partitionSize));
        }

    }


    public void repartition(String tableName,String partitionSize){
        try {
            List<Long> tableSize = HDFSIO.computePerFileSizeOfTable(tableName);
            boolean needRepartition=tableSize.stream().filter(a ->  a< Long.valueOf(partitionSize)).collect(Collectors.toList()).size()>2;
            if(!needRepartition){
                return;
            }
            JSONObject config=new JSONObject();
            config.put("tableName",tableName);
            config.put("tableSize",tableSize.stream().mapToLong(x -> x).sum());
            config.put("url","jdbc:hive2://"+distIp+":"+distPort);
            config.put("user",distUserName);
            config.put("password",distPassword);
            config.put("dbType","hive");
            config.put("businessType","repartition");
            if(StringUtil.isNotEmpty(partitionSize)){
                config.put("partitionSize",partitionSize);
            }
            logger.info("partition message:"+config.toJSONString());
            kafkaTemplate.send(JobServiceUtil.KAFAKA_TOPIC_DATACONFIG,config.toJSONString());
        } catch (IOException e) {
          logger.error(e.getMessage(),e);
        }
    }

    public void addColumns(String tableName, List<String> columns,Boolean updateColMappings){
        JSONObject config=new JSONObject();
        config.put("tableName",tableName);
        config.put("columns",columns);
        config.put("url","jdbc:hive2://"+distIp+":"+distPort);
        config.put("user",distUserName);
        config.put("password",distPassword);
        config.put("dbType","hive");
        config.put("businessType","addColumns");
        if(updateColMappings!=null){
            config.put("updateMappings",updateColMappings);
        }
        config.put("topic","addColumnsResult");
        kafkaTemplate.send(JobServiceUtil.KAFAKA_TOPIC_DATACONFIG,config.toJSONString());
    }

}
