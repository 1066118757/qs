package com.cdid.service.oozie.vo;

public class ShareListVO {

    private String distObjectId;

    private String distObjectName;

    private Long shareTime;

    private String distObjectType;

    public String getDistObjectId() {
        return distObjectId;
    }

    public void setDistObjectId(String distObjectId) {
        this.distObjectId = distObjectId;
    }

    public String getDistObjectName() {
        return distObjectName;
    }

    public void setDistObjectName(String distObjectName) {
        this.distObjectName = distObjectName;
    }

    public String getDistObjectType() {
        return distObjectType;
    }

    public void setDistObjectType(String distObjectType) {
        this.distObjectType = distObjectType;
    }

    public Long getShareTime() {
        return shareTime;
    }

    public void setShareTime(Long shareTime) {
        this.shareTime = shareTime;
    }
}
