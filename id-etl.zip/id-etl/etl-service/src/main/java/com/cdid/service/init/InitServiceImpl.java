package com.cdid.service.init;

import com.alibaba.fastjson.JSON;
import com.cdid.api.common.IDGeneratorService;
import com.cdid.api.common.RedisService;
import com.cdid.api.dataclear.cleartask.ClearTaskService;
import com.cdid.api.dataclear.cleartask.vo.ClearTaskBaseConfigVo;
import com.cdid.api.dataclear.cleartask.vo.ClearTaskDetailVo;
import com.cdid.api.dataimport.vo.JobBaseConfigVo;
import com.cdid.api.dict.DictService;
import com.cdid.api.job.JobService;
import com.cdid.api.job.vo.ScheduleJobEntity;
import com.cdid.common.constant.RedisKey;
import com.cdid.common.vo.ResultVo;
import com.cdid.config.PropertyUtil;
import com.cdid.dao.dataclear.clearrecord.ClearRecordDao;
import com.cdid.dao.dataclear.cleartask.ClearTaskDao;
import com.cdid.dao.job.JobDao;
import com.cdid.dao.leanmodel.LearningModelDeployDao;
import com.cdid.dao.metadata.item.ItemDao;
import com.cdid.jooq.tables.records.TClearRecordRecord;
import com.cdid.jooq.tables.records.TClearTaskRecord;
import com.cdid.service.job.JobServiceUtil;
import com.cdid.service.job.ScheduleUtils;
import com.cdid.service.systemtask.RepartitionTaskService;
import com.cdid.utils.DateUtils;
import com.cdid.utils.VoReTraversalUtil;
import com.cdid.utils.cron.CronTab;
import com.cdid.utils.cron.CronUtil;
import org.apache.commons.lang3.StringUtils;
import org.jooq.Record2;
import org.jooq.Result;
import org.quartz.SimpleScheduleBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import static com.cdid.jooq.tables.LearningModelDeploy.LEARNING_MODEL_DEPLOY;

@Service
public class InitServiceImpl {

    private static Logger logger = LoggerFactory.getLogger(InitServiceImpl.class);

    @Autowired
    private JobService jobService;
    @Autowired
    private JobDao jobDao;

    @Autowired
    private ScheduleUtils scheduleUtils;
    @Autowired
    private ClearTaskDao clearTaskDao;
    @Autowired
    private ClearRecordDao clearRecordDao;
    @Autowired
    private ClearTaskService clearTaskService;
    @Autowired
    private DictService dictService;
    @Autowired
    private RedisService redisService;
    @Autowired
    private LearningModelDeployDao learningModelDeployDao;
    @Autowired
    IDGeneratorService<Long> idGeneratorService;
    @Value("${job.res}")
    private String jobRes;

    @Autowired
    RepartitionTaskService repartitionTaskService;

    @Autowired
    ItemDao itemDao;

    @PostConstruct
    public void init() {
        logger.info("初始化任务开始！");
        //初始化码表
        dictService.initDict();
        //初始化引接任务
        initJob();
        //初始化清洗任务
        initClearJob();
        initLearningModel();
        initJobRes();
        if(Boolean.valueOf(PropertyUtil.getMergedProperty("clear-hdfs-temp-files.switch","false"))){
            initClearClusterExpiredData();
        }
        if(Boolean.valueOf(PropertyUtil.getMergedProperty("repartition.switch","true"))){
            initRepartitionTask();
        }
        logger.info("初始化任务结束!");
    }

    private void initLearningModel() {
        Result<Record2<String, String>> all = learningModelDeployDao.getAll();
        for (Record2<String, String> record : all) {
            String id = record.get(LEARNING_MODEL_DEPLOY.ID);
            String scheduleConfig = record.get(LEARNING_MODEL_DEPLOY.SCHEDULE_CONFIG);
            if (StringUtils.isEmpty(scheduleConfig)||"{}".equals(scheduleConfig)) {
                continue;
            }
            ScheduleJobEntity scheduleJobEntity = new ScheduleJobEntity();
            CronTab cronTab = JSON.parseObject(scheduleConfig, CronTab.class);
            String cronStr = null;
            try {
                cronStr = CronUtil.toCronString(cronTab);
            } catch (Exception e) {
                continue;
            }
            Set<String> crons = new HashSet<>();
            crons.add(cronStr);
            scheduleJobEntity.setCronExpressions(crons);
            scheduleJobEntity.setLearningModelDeployId(id);
            scheduleJobEntity.setJobId(BigDecimal.valueOf(idGeneratorService.id()));
            scheduleUtils.createScheduleJob(scheduleJobEntity);
        }

    }

    private void initJobRes() {
        redisService.put(RedisKey.JOB_RES, jobRes);
    }

    private void initJob() {
        logger.info("定时任务初始化");
        Result<Record2<BigDecimal, Integer>> all = jobDao.findAll();

        JobBaseConfigVo jobBaseConfigVo = null;
        BigDecimal jobId = null;
        Integer type = null;
        for (Record2<BigDecimal, Integer> job : all) {
            try {
                jobId = (BigDecimal) job.get("jobId");
                type = (Integer) job.get("dbType");
                jobBaseConfigVo = jobService.getJobConfigVo(jobId, JobServiceUtil.isDbType(type));
                if (jobBaseConfigVo == null) {
                    continue;
                }
                ScheduleJobEntity jobEntity = new ScheduleJobEntity();
                jobEntity.setTaskRequestVo(jobBaseConfigVo);
                jobEntity.setAsyncTaskConfigVo(JobServiceUtil.getAsyncTaskConfigVo(jobBaseConfigVo));
                jobEntity.setJobId(jobId);
                jobEntity.setPriority(jobBaseConfigVo.getPriority());
                //获取cron
                String cronStr = jobService.getCornStr(jobId, jobBaseConfigVo.getSyncStrategy());

                if (!StringUtils.isEmpty(cronStr)) {
                    Set<String> crons = new HashSet<>();
                    crons.add(cronStr);
                    jobEntity.setCronExpressions(crons);
                    scheduleUtils.createScheduleJob(jobEntity);
                    logger.info("======jobId:" + jobId + "\t 初始化成功！");
                }
            } catch (Exception e) {
                e.printStackTrace();
                continue;
            }
        }
        logger.info("定时任务初始化完成");
    }

    public void initClearJob() {
        logger.info("数据清洗定时任务初始化");
        TClearTaskRecord[] all = clearTaskDao.findAll();

        for (TClearTaskRecord item : all) {
            try {
                BigDecimal id = item.getId();
                BigDecimal recordId = item.getRecordId();
                Integer status = item.getStatus();
                //获取handleCode
                TClearRecordRecord recordRecord = clearRecordDao.findById(recordId);
                if (recordRecord == null || recordRecord.getHandleCode() == null) {
                    continue;
                }
                String handleCode = recordRecord.getHandleCode();
                //讲过Record转为detailVo
                ClearTaskDetailVo taskDetailVo = (ClearTaskDetailVo) VoReTraversalUtil.traversalTwo(item, ClearTaskDetailVo.class);
                //获取ScheduleJobEntity创建任务
                ResultVo resultVo1 = clearTaskService.initGetScheduleJobEntity(taskDetailVo, handleCode);
                if (resultVo1.getErrorCode() == 0) {
                    ScheduleJobEntity scheduleJobEntity = (ScheduleJobEntity) resultVo1.getData();
                    //创建定时任务
                    scheduleUtils.createScheduleJob(scheduleJobEntity);
                    //依据status判断该任务是否处于停止状态
                    if (status == 0) {
                        //暂停任务
                        scheduleUtils.pauseJob(id);
                    }
                    logger.info("======jobId:" + id + "\t 初始化成功！");
                } else {
                    continue;
                }
            } catch (Exception e) {
                e.printStackTrace();
                continue;
            }
        }
        logger.info("数据清洗定时任务初始化完成");
    }

    public void initClearClusterExpiredData() {
        scheduleUtils.schedule(com.cdid.service.oozie.task.ClearTaskService.class, "clearClusterExpiredData", SimpleScheduleBuilder.repeatHourlyForever(24),DateUtils.getDateATime(new Date(),1,0,0));
    }

    public void initRepartitionTask(){
        scheduleUtils.schedule(com.cdid.service.systemtask.RepartitionTaskService.class,"repartition_tables",SimpleScheduleBuilder.repeatHourlyForever(Integer.valueOf(PropertyUtil.getMergedProperty("repartition.frequency_hour","120"))), DateUtils.getDateATime(new Date(),18,20,0));
    }

}