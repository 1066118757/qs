package com.cdid.service.oozie.vo;

public class GroupVO {

    private String id;

    private String name;

    private Integer groupType;

    public Integer getGroupType() {
        return groupType;
    }

    public void setGroupType(Integer groupType) {
        this.groupType = groupType;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public enum GroupType{
        Table(1),Report(2),User(3);
        private Integer id;
         GroupType(Integer id){
             this.id=id;
         }
        public Integer getId(){
            return id;
        }
    }
}
