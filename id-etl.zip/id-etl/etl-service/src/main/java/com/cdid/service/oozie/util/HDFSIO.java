/**
 * Copyright 2017 Institute of Computing Technology, Chinese Academy of Sciences.
 * Licensed under the terms of the Apache 2.0 license.
 * Please see LICENSE file in the project root for terms
 */
package com.cdid.service.oozie.util;

import com.cdid.common.constant.ErrorCode;
import com.cdid.common.vo.ResultVo;
import com.cdid.config.PropertyUtil;
import org.apache.commons.fileupload.FileItem;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.permission.FsAction;
import org.apache.hadoop.fs.permission.FsPermission;
import org.apache.hadoop.io.IOUtils;
import org.apache.log4j.Logger;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Utility functions for HDFS
 */
public class HDFSIO {

	public  static final long MAX_DOWNLOADABLE_FILE_SIZE=200*1024*1024;
	private static Logger logger = Logger.getLogger(HDFSIO.class.getName());
	private static Configuration conf = new Configuration();
	private static FileSystem fs;
	public static final String NAME_NODE="hdfs://"+PropertyUtil.getMergedProperty("hdfs.ip","192.168.55.115") +":"+PropertyUtil.getMergedProperty("hdfs.port","8020");
	static {
		conf.set("fs.default.name", NAME_NODE);
		conf.setBoolean("fs.hdfs.impl.disable.cache", true);
		//Wheather client use hostname to visit datanode or not
		conf.set("dfs.client.use.datanode.hostname", "true");
		try {
			fs = FileSystem.get(conf);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Write a file in hdfs
	 *
	 * @param path target file path
	 * @param content file content
	 * @throws IOException
	 */
	public static void upload(String path, String content,boolean overwrite) throws IOException {
		Path fullPath = new Path(NAME_NODE + "/" + path);
		if (fs.exists(fullPath)){
			if(overwrite){
				fs.delete(fullPath, false);
			}
		}
		OutputStream out = fs.create(fullPath);
		InputStream rf = new ByteArrayInputStream(content.getBytes());
		IOUtils.copyBytes(rf, out, 4096, true);
		out.close();
	}

	public static void uploadOverwrite(String localPath,String distDir,String fileName)throws IOException{
		Path distHdfsDir=new Path(NAME_NODE+distDir);
		Path distFile=new Path(distHdfsDir,fileName);
		if(!fs.exists(distHdfsDir)){
			fs.mkdirs(distHdfsDir);
		}
		if(fs.exists(distFile)){
			fs.delete(distFile,false);
		}
		fs.copyFromLocalFile(new Path(localPath),distFile);
	}

	/**
	 * Create a new file on HDFS and add content,
	 * it should be noted that the file did not exist
	 *
	 * @param uri HDFS uri
	 * @param item InputStream item to upload
	 * @throws IOException
	 */
	public static void uploadModel(String uri, InputStream item)
			throws IOException {
		FSDataOutputStream out =
				fs.create(new Path(NAME_NODE + "/" + uri));
		// IOUtils.copyBytes method
		IOUtils.copyBytes(item, out, 4096, false);
		out.close();
	}

	/**
	 * Upload file to HDFS
	 * @param uri target file path
	 * @param item file to upload
	 * @param name name of the new file
	 * @throws IOException
	 */
	public static void uploadfile(String uri, FileItem item, String name)
			throws IOException {
		System.out.println("[dstPath]" + NAME_NODE + "/" + uri + name);
		FSDataOutputStream out = fs.create(new Path(NAME_NODE + uri
				+ name));
		IOUtils.copyBytes(item.getInputStream(), out, 4096, true);
	}

	public static void writeToOutputStream(String path,OutputStream os) throws Exception {
		String uri=NAME_NODE + path;
		Path sourcePath=new Path(uri);
		if(!fs.exists(sourcePath)){
			throw new IOException("Source file not found!");
		}
		if(HDFSIO.getFileSize(path)>MAX_DOWNLOADABLE_FILE_SIZE){
			throw new Exception("Exceed max downloadable size");
		}
		if(fs.isFile(sourcePath)){
			FSDataInputStream is=fs.open(sourcePath);
			IOUtils.copyBytes(is,os,4096,false);
			is.close();
			return;
		}
		FileStatus[] statuses = fs.listStatus(sourcePath);
		if(statuses.length ==0){
			throw new IOException("Source dir is empty");
		}
		FSDataInputStream is;
		for(FileStatus status:statuses){
			if(fs.isDirectory(status.getPath())|| !status.getPath().getName().startsWith("part-")){
				continue;
			}
			is=fs.open(status.getPath());
			IOUtils.copyBytes(is,os,4096,false);
			is.close();
		}
	}

	/**
	 * Delete file in HDFS
	 *
	 * @param filePath target file path
	 * @throws IOException
	 */
	public static void delete(String filePath) throws IOException {
		String url="";
		if(filePath.startsWith("/")){
			url=NAME_NODE+filePath;
		}else{
			url=NAME_NODE+"/"+filePath;
		}
		Path path = new Path(url);
		if(exist(url))
		{
			boolean ok = fs.delete(path, true);
			logger.info("delete path:" + path +" " + (ok?"successed":"failed"));
		}
	}

	public static void remove(Path path) throws IOException {
		fs.delete(path,true);
	}

	/**
	 * Cat method
	 *
	 * @param uri
	 * @return inputstream of cat file
	 * @throws Exception
	 */
	public static InputStream getInputStream(String uri) throws IOException {
		Path path = new Path(NAME_NODE + "/" + uri);
		if (!fs.exists(path))
			return null;
		if (fs.isDirectory(path)) {
			return searchFile(path);
		} else {
			InputStream in = fs.open(new Path(uri));
			return in;
		}
	}

	/**
	 * Download file in HDFS
	 *
	 * @param uri of file to download
	 * @return inputstream of the file to download
	 * @throws Exception
	 */
	public static InputStream downInputStream(String uri) throws IOException {
		Path path = new Path(uri);
		if (!fs.exists(path))
			return null;
		if (fs.isDirectory(path)) {
			return searchFile(path);
		} else {
			InputStream in = fs.open(new Path(uri));
			return in;
		}
	}

	/**
	 * Search File in HDFS
	 * @param path search path
	 * @return input stream
	 * @throws IOException
	 */
	private static InputStream searchFile(Path path) throws IOException {
		FileStatus[] status = fs.listStatus(path);
		InputStream in = null;
		if (status == null || status.length == 0)
			return null;

		path = status[0].getPath();
		for (FileStatus s : status) {
			if (!fs.isDirectory(s.getPath())) {
				if (!s.getPath().getName().equals("_SUCCESS")) {
					in = fs.open(s.getPath());
					return in;
				}
			} else {
				in = searchFile(s.getPath());
				if (in != null)
					return in;
			}

		}

		return null;
	}

	/**
	 * The same method as hdfs dfs -cat
	 * @param uri target file uri
	 * @return  content string in file
	 * @throws IOException
	 */
	public static String cat(String uri) throws IOException {
		InputStream in = getInputStream(uri);
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		IOUtils.copyBytes(in, out, 4096, true);
		return out.toString();
	}

	public static ResultVo<List<String>> readDir(String path,int lines) throws IOException {
		Path hdfsPath = new Path(NAME_NODE + "/" + path);
		if(!fs.exists(hdfsPath)){
			return new ResultVo<>(ErrorCode.FileNotFound.getErrorCode());
		}
		if(fs.isFile(hdfsPath)){
			return readLines(path,lines);
		}
		FileStatus[] status = fs.listStatus(hdfsPath);
		List<String> content=new ArrayList<>();
		int line=0;
		if (status == null || status.length == 0)
			return null;
		for (FileStatus s : status) {
			if(fs.isDirectory(s.getPath())|| !s.getPath().getName().startsWith("part-")){
				continue;
			}
			InputStream in=null;
			BufferedReader bufferedReader=null;
			try {
				in =fs.open(s.getPath());
				bufferedReader = new BufferedReader(new InputStreamReader(in));
				String lineTxt=null;
				while ((lineTxt = bufferedReader.readLine()) != null && line<=lines)
				{
					content.add(lineTxt);
					line++;
				}
			}catch (Exception e){
				logger.error(e.getMessage(),e);
			}finally {
				if(in!=null){
					try {
						in.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				if(bufferedReader!=null){
					try {
						bufferedReader.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
		return new ResultVo<>(0,content);
	}

	public static ResultVo<List<String>> readLines(String path, int lines)  {
		InputStream in=null;
		BufferedReader bufferedReader=null;
		try {
			in = getInputStream(path);
			bufferedReader = new BufferedReader(new InputStreamReader(in));
			String lineTxt=null;
			int  line=0;
			List<String> content = new ArrayList<>();
			while ((lineTxt = bufferedReader.readLine()) != null &&line<=lines)
            {
                content.add(lineTxt);
				line++;
            }
			return new ResultVo<>(0,content);
		}catch (Exception e){
			logger.error(e.getMessage(),e);
			return new ResultVo<>(ErrorCode.FileNotFound.getErrorCode());
		}finally {
			if(in!=null){
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if(bufferedReader!=null){
				try {
					bufferedReader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/** Return the paths of files under directory uri */
	public static Path[] list(String uri) throws IOException {

		Path path = new Path(uri);
		if (!fs.exists(path))
			return null;
		FileStatus[] status = fs.listStatus(new Path(uri));
		Path[] listedPaths = FileUtil.stat2Paths(status);
		return listedPaths;
	}

	/**
	 * Make directory in the uri position
	 * @param uri target position
	 * @return whether success or not
	 * @throws IOException
	 */
	public static boolean mkdirs(String uri) throws IOException {
		Path path = new Path(NAME_NODE + "/" + uri);
		System.out.println("[mkdirs]" + path.toString());

		FsPermission dirPerm = new FsPermission(FsAction.ALL, FsAction.ALL, FsAction.ALL);
		Boolean flag = fs.mkdirs(path);
		if( flag )
			fs.setPermission(path, new FsPermission(dirPerm));
		return flag;
	}

	/**
	 * Whether a file is exit or not
	 * @param uri target file uri
	 * @return true/false
	 * @throws IOException
	 */
	public static boolean exist(String uri) throws IOException {
		return fs.exists(new Path(uri));
	}

	/**
	 * Copy method
	 * @param src_uri Source file uri
	 * @param dst_uri destination uri
	 * @throws Exception
	 */
	public static void copy(String src_uri, String dst_uri) throws IOException {
		FileUtil.copy(fs, new Path(src_uri), fs, new Path(dst_uri), false, conf);
	}


	/**
	 * Rename a file in HDFS
	 * @param src target source file
	 * @param dst destination file
	 * @throws IOException
	 */
	public static void rename(String src, String dst) throws IOException {
		fs.rename(new Path(NAME_NODE + "/" + src),
				new Path(NAME_NODE + "/" + dst));
	}

	/**
	 * The same method as hdfs dfs -head
	 * @param uri target file url in HDFS
	 * @param n the position before you need
	 * @return
	 * @throws IOException
	 */
	public static String head(String uri, int n) throws IOException {
		Path[] paths = HDFSIO.list(uri);
		StringBuffer sb = new StringBuffer();
		int line = 0;
		String lineStr = null;
		for (Path temp : paths) {
			InputStream in = HDFSIO.downInputStream(temp.toString());
			if (in == null)
				continue;
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			while ( line ++ < n && ( lineStr = br.readLine() ) != null ) {
				if( lineStr.length() > 1024) lineStr = lineStr.substring(0, 1024) + "(...)";
				sb.append(lineStr);
				sb.append('\n');
			}
			br.close();
		}
		return sb.toString();
	}

	/**
	 * To determine whether the file directory
	 * @param path target file path
	 * @return
	 * @throws IOException 
	 */
	public static boolean isDirectory(Path path) throws IOException
	{
		return fs.isDirectory(path);
	}

	/**
	 * Read the file or directory size of a file under HDFS
	 * 
	 * @param sourceFile  target File or directory path
	 * @return   The total size of all file sizes in the file size or directory (in KB)
	 * @throws IOException
	 */
	public static long getFileSize(String sourceFile) throws IOException{
		Path path = new Path(sourceFile);
		long totalSize = 0;
		if(HDFSIO.isDirectory(path)) {
			FileStatus[] statuss = fs.listStatus(path);
			for(FileStatus status : statuss) {
				totalSize += getFileSize(status.getPath().toUri().getPath());
			}
		}else {
			FileStatus status = fs.getFileStatus(path);
			totalSize = status.getLen();
		}
		return totalSize;
	}

	public static String copyFile(String srcFile,String distDir) throws IOException {
		Path srcPath=new Path(NAME_NODE+srcFile);
		Path distPath=new Path(NAME_NODE+distDir);
		if(!fs.exists(srcPath)){
			return null;
		}
		if(fs.isDirectory(srcPath)){
			copyFiles(srcFile,distDir);
			return distDir;
		}
		if(!fs.exists(distPath)){
			HDFSIO.mkdirs(distDir);
		}
		Path distFilePath=new Path(distPath,srcPath.getName());
		FileUtil.copy(fs,srcPath,fs,distFilePath,false,conf);
		return distFilePath.toUri().getPath();
	}

	public static boolean copyFiles(String srcDir,String distDir) throws IOException {
		Path srcPath=new Path(NAME_NODE+srcDir);
		Path distPath=new Path(NAME_NODE+distDir);
		if(!fs.exists(srcPath) || !HDFSIO.isDirectory(srcPath)){
			return false;
		}
		if(!fs.exists(distPath)){
			HDFSIO.mkdirs(distDir);
		}
		if(!HDFSIO.isDirectory(distPath)){
			return false;
		}
		FileStatus contents[] = fs.listStatus(srcPath);
		for (int i = 0; i < contents.length; i++) {
			FileUtil.copy(fs, contents[i], fs,
					new Path(distPath, contents[i].getPath().getName()),
					false, true, conf);
		}
		return true;
	}

	public static List<Long> computePerFileSizeOfTable(String tableName) throws IOException {
		String uri=NAME_NODE+"/hive/warehouse/"+tableName;
		Path tablePath = new Path(uri);
		List<Long> fileSizes=new ArrayList<>();
		if(!fs.exists(tablePath)|| fs.isFile(tablePath)){
			return fileSizes;
		}
		FileStatus[] fileStatuses=fs.listStatus(tablePath);
		for(FileStatus f : fileStatuses)
		{
			if(fs.isFile(f.getPath())&& f.getPath().getName().startsWith("part-")){
				fileSizes.add(f.getLen());
			}
		}
		return fileSizes;
	}



}
