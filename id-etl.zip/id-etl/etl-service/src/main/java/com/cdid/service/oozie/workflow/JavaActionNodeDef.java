package com.cdid.service.oozie.workflow;

import com.cdid.service.oozie.command.Parameter;
import com.cdid.service.oozie.constant.ParameterDataType;
import com.cdid.service.oozie.constant.ParameterIOType;
import com.cdid.service.oozie.graph.OozieProgramNode;
import com.cdid.utils.StringUtil;
import org.dom4j.Element;

import java.util.List;

public class JavaActionNodeDef extends ActionNodeDef {

    public JavaActionNodeDef(OozieProgramNode program, String nodeId) {
        super(program, nodeId);
    }

    @Override
    public void generateActionXML(Element action) {
        Element javaElement = action.addElement("java");
        generateElement(javaElement, "job-tracker", "${jobTracker}");
        generateElement(javaElement, "name-node", "${nameNode}");

        Element configuration = javaElement.addElement("configuration");
        createProperty(configuration, "mapred.job.queue.name", "${queueName}");
        createProperty(configuration,"oozie.launcher.oozie.libpath",program.getProgramPath()+"/lib");
        generateElement(javaElement, "main-class", program.getPersonalConfig());
        generateElement(javaElement, "java-opts", "-DHADOOP_USER_NAME=root");
        generateArgElements(javaElement);
        //generateElement(javaElement, "archive", program.getProgramPath()+"/lib/IDCsvExporter.jar");
        javaElement.addElement("capture-output");
    }


    private void  generateArgElements(Element javaElement) {
        List<Parameter> parameters = program.getParams();
        for (Parameter parameter : parameters) {
            String value = parameter.getParamValue();
            if (parameter.getDataType().equals(ParameterDataType.IN.getName())
                    || parameter.getDataType().equals(ParameterDataType.OUT.getName())) {
                if (!StringUtil.isEmpty(value)) {
                    if(parameter.getIoType().equals(ParameterIOType.FILE.name())){
                        value = "${appPath}/" + value;
                    }
                }
            } else {
                if (StringUtil.isEmpty(value)) {
                    value = parameter.getDefaultValue();
                }
            }
            if (StringUtil.isEmpty(value)) {
                continue;
            }
            generateElement(javaElement, "arg", "--" + parameter.getParamName());
            generateElement(javaElement, "arg", value);
        }
    }
}
