package com.cdid.service.oozie;

import com.cdid.api.common.IDGeneratorService;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.metadata.item.ItemDao;
import com.cdid.dao.oozie.ProgramDao;
import com.cdid.dao.oozie.TreeObjectDao;
import com.cdid.dao.storagedata.StorageDataManageDao;
import com.cdid.dao.user.UsersDao;
import com.cdid.jooq.tables.TMetadataItem;
import com.cdid.jooq.tables.TProgram;
import com.cdid.jooq.tables.TStorageData;
import com.cdid.jooq.tables.TTreeObject;
import com.cdid.jooq.tables.records.TTreeObjectRecord;
import com.cdid.service.oozie.vo.*;
import com.cdid.utils.StringUtil;
import org.jooq.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class OozieObjectTreeService {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    TreeObjectDao treeObjectDao;

    @Autowired
    ProgramDao programDao;

    @Autowired
    IDGeneratorService<Long> idService;

    @Autowired
    UsersDao usersDao;

    @Autowired
    StorageDataManageDao dataManageDao;

    @Autowired
    ItemDao itemDao;


    public ResultVo<BigDecimal> saveTreeRootObject(TreeObjectVO objectVO, String userId){
       if(objectVO.getId()!=null){
           TTreeObjectRecord record= treeObjectDao.findById(objectVO.getId());
           if(record==null){
               return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
           }
           record.setName(objectVO.getName());
           treeObjectDao.update(record);
           return new ResultVo<>(0,record.getId());
       }
        TTreeObjectRecord record=new TTreeObjectRecord();
        if(objectVO.getParentId()!=null){
            TTreeObjectRecord parent= treeObjectDao.findById(objectVO.getParentId());
            if(!parent.getObjectType().equals(objectVO.getObjectType())){
                return new ResultVo<>(ErrorCode.ParamError.getErrorCode());
            }
        }
        Timestamp now=new Timestamp(System.currentTimeMillis());
        record.setId(BigDecimal.valueOf(idService.id()));
        record.setCreateTime(now);
        record.setCreateUser(userId);
        record.setName(objectVO.getName());
        record.setObjectType(objectVO.getObjectType());
        record.setParentType(objectVO.getParentType());
        record.setLeafObjectType(objectVO.getLeafObjectType());
        record.setParentObjectId(objectVO.getParentId());
        treeObjectDao.insert(record);
        return new ResultVo<>(0,record.getId());
    }

    public ResultVo<Boolean> deleteTreeObject(BigDecimal id){
        TTreeObjectRecord treeObject=treeObjectDao.findById(id);
        if(treeObject ==null){
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
        }
        TTreeObjectRecord child=treeObjectDao.findAnyByCondition(Arrays.asList(TTreeObject.T_TREE_OBJECT.PARENT_OBJECT_ID.eq(id)));
        if(child!=null){
            return new ResultVo<>(ErrorCode.ExistsChildren.getErrorCode());
        }
        treeObjectDao.deleteById(Arrays.asList(id));
        return new ResultVo<>(0,true);
    }

    public ResultVo<Boolean> updateParent(BigDecimal id,List<BigDecimal> childIdList){
        if(id!=null){
            TTreeObjectRecord record=treeObjectDao.findById(id);
            if(record==null){
                return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
            }
            List<BigDecimal> parentIdList=findParents(id,false).stream().map(a -> a.getId()).collect(Collectors.toList());
            int oldSize=parentIdList.size();
            parentIdList.removeAll(childIdList);
            int newSize=parentIdList.size();
            if(oldSize != newSize){
                return new ResultVo<>(ErrorCode.OperateIllegal.getErrorCode());
            }
        }
        List<Condition> conditionList=Arrays.asList(TTreeObject.T_TREE_OBJECT.ID.in(childIdList));
        treeObjectDao.update(conditionList,TTreeObject.T_TREE_OBJECT.PARENT_OBJECT_ID,id);
        return new ResultVo<>(0,true);
    }

    public ResultVo<PageVo<? super TreeObjectListVO>> queryChildren(BigDecimal parentId, String parentType, String leafObjectType,String userId, OffsetPagingVo pagingVo){
        List<Condition> conditionList=new ArrayList<>();
        if(parentId!=null){
            conditionList.add(TTreeObject.T_TREE_OBJECT.PARENT_OBJECT_ID.eq(parentId));
        }else{
            conditionList.add(TTreeObject.T_TREE_OBJECT.PARENT_OBJECT_ID.isNull());
        }
        conditionList.add(TTreeObject.T_TREE_OBJECT.LEAF_OBJECT_TYPE.eq(leafObjectType));
        conditionList.add(TTreeObject.T_TREE_OBJECT.PARENT_TYPE.eq(parentType));
        if(!parentType.equals(TreeObjectVO.TreeParentType.SYSTEM.toString())){
            conditionList.add(TTreeObject.T_TREE_OBJECT.CREATE_USER.eq(userId));
        }
        Integer total=treeObjectDao.queryTotalByCondition(conditionList);
        List<? super TreeObjectListVO> voList=new ArrayList<>();
        switch (leafObjectType){
            case "PROGRAM":
                List<org.jooq.Record9<BigDecimal, String, BigDecimal, String, Timestamp, String, Boolean, String,String>> recordList=treeObjectDao.queryProgramTree(conditionList,pagingVo);
                for(org.jooq.Record9<BigDecimal, String, BigDecimal, String, Timestamp, String, Boolean, String,String> record:recordList){
                    voList.add(recordToProgramListVO(record));
                }
                return new ResultVo<>(0,new PageVo(total,voList));
            case "FILE" :
                List<org.jooq.Record8<BigDecimal, String, BigDecimal, String, String, String,String,Timestamp>> fileTreeRecords=treeObjectDao.queryFileTree(conditionList,pagingVo);
                for(org.jooq.Record8<BigDecimal, String, BigDecimal, String, String, String,String,Timestamp> record:fileTreeRecords){
                    voList.add(recordToFileListVO(record));
                }
                return new ResultVo<>(0,new PageVo(total,voList));
            case "TABLE":
                List<org.jooq.Record6<BigDecimal, String, BigDecimal, String, Timestamp, String>> tableTreeRecords=treeObjectDao.queryTableTree(conditionList,pagingVo);
                for(org.jooq.Record6<BigDecimal, String, BigDecimal, String, Timestamp, String> record:tableTreeRecords){
                    voList.add(recordToTableListVO(record));
                }
                return new ResultVo<>(0,new PageVo(total,voList));
            default: return new ResultVo<>(0,new PageVo(0,voList));
        }
    }

    public ResultVo<PageVo<? super TreeObjectListVO>> queryLeafByPage( String parentType, String leafObjectType,String userId,TreeLeafQueryVO queryVO, OffsetPagingVo pagingVo){
        List<Condition> conditionList=new ArrayList<>();
        conditionList.add(TTreeObject.T_TREE_OBJECT.LEAF_OBJECT_TYPE.eq(leafObjectType));
        conditionList.add(TTreeObject.T_TREE_OBJECT.PARENT_TYPE.eq(parentType));
        if(!parentType.equals(TreeObjectVO.TreeParentType.SYSTEM.toString())){
            conditionList.add(TTreeObject.T_TREE_OBJECT.CREATE_USER.eq(userId));
        }
        if(StringUtil.isNotEmpty(queryVO.getName())){
            conditionList.add(TTreeObject.T_TREE_OBJECT.NAME.like("%"+queryVO.getName()+"%"));
        }
        if(StringUtil.isNotEmpty(queryVO.getCreateUser())){
            switch (leafObjectType){
                case "PROGRAM":
                    conditionList.add(TProgram.T_PROGRAM.OWNER.eq(queryVO.getCreateUser()));
                    break;
                case "FILE":
                    conditionList.add(TStorageData.T_STORAGE_DATA.CREATE_USER.eq(queryVO.getCreateUser()));
                    break;
                case "TABLE":
                    conditionList.add(TMetadataItem.T_METADATA_ITEM.CREATE_USER.eq(queryVO.getCreateUser()));
                    break;
                default:break;
            }
        }
        List<? super TreeObjectListVO> voList=new ArrayList<>();
        switch (leafObjectType){
            case "PROGRAM":
                PageVo<Record9<BigDecimal, String, BigDecimal, String, Timestamp, String, Boolean, String, String>> recordPage=treeObjectDao.queryPrograms(conditionList,pagingVo);
                voList=recordPage.getPageData().stream().map(r -> recordToProgramListVO(r)).collect(Collectors.toList());
                return new ResultVo<>(0,new PageVo(recordPage.getTotalCount(),voList));
            case "FILE" :
                PageVo<Record8<BigDecimal, String, BigDecimal, String, String, String,String,Timestamp>> filePage=treeObjectDao.queryFiles(conditionList,pagingVo);
                voList=filePage.getPageData().stream().map(f -> recordToFileListVO(f)).collect(Collectors.toList());
                return new ResultVo<>(0,new PageVo(filePage.getTotalCount(),voList));
            case "TABLE":
                PageVo<Record6<BigDecimal, String, BigDecimal, String, Timestamp, String>> tablePage=treeObjectDao.queryTables(conditionList,pagingVo);
                voList=tablePage.getPageData().stream().map(t -> recordToTableListVO(t)).collect(Collectors.toList());
                return new ResultVo<>(0,new PageVo(tablePage.getTotalCount(),voList));
            default: return new ResultVo<>(0,new PageVo(0,voList));
        }
    }

    private ProgramTreeListVO recordToProgramListVO(org.jooq.Record9<BigDecimal, String, BigDecimal, String, Timestamp, String, Boolean, String,String> record){
        ProgramTreeListVO listVO=new ProgramTreeListVO();
        listVO.setId(record.value1());
        listVO.setName(record.value2());
        listVO.setProgramId(record.value3());
        listVO.setProgramName(record.value4());
        if(record.value5() != null){
            listVO.setCreateTime(record.value5().getTime());
        }
        listVO.setCreateUser(record.value6());
        listVO.setDownloadable(record.value7());
        listVO.setProgramType(record.value8());
        listVO.setDescription(record.value9());
        return listVO;
    }

    private FileTreeListVO recordToFileListVO(org.jooq.Record8<BigDecimal, String, BigDecimal, String, String, String,String,Timestamp> record){
        FileTreeListVO listVO=new FileTreeListVO();
        listVO.setId(record.value1());
        listVO.setName(record.value2());
        listVO.setFileId(record.value3());
        listVO.setFileName(record.value4());
        listVO.setFilePath(record.value5());
        listVO.setFileType(record.value6());
        listVO.setCreateUser(record.value7());
        if(record.value8() != null){
            listVO.setCreateTime(record.value8().getTime());
        }
        return listVO;
    }

    private TableTreeListVO recordToTableListVO(org.jooq.Record6<BigDecimal, String, BigDecimal, String, Timestamp, String> record){
        TableTreeListVO listVO=new TableTreeListVO();
        listVO.setId(record.value1());
        listVO.setName(record.value2());
        listVO.setTableId(record.value3());
        listVO.setTableName(record.value4());
        if(record.value5()!=null){
            listVO.setCreateTime(record.value5().getTime());
        }
        listVO.setCreateUser(record.value6());
        return listVO;
    }

    public ResultVo<List<OozieTreeVO>> queryTree(BigDecimal parentId,Boolean containLeaf, String parentType, String leafObjectType,String userId){
         List<Condition> conditionList=new ArrayList<>();
        conditionList.add(TTreeObject.T_TREE_OBJECT.LEAF_OBJECT_TYPE.eq(leafObjectType));
        conditionList.add(TTreeObject.T_TREE_OBJECT.PARENT_TYPE.eq(parentType));
        if(!parentType.equals(TreeObjectVO.TreeParentType.SYSTEM.toString())){
            conditionList.add(TTreeObject.T_TREE_OBJECT.CREATE_USER.eq(userId));
        }
        if(!containLeaf){
            conditionList.add(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID.isNull());
        }
        List<TTreeObjectRecord> records=treeObjectDao.findByConditions(conditionList,Arrays.asList(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID.nvl2(1,0).asc(),TTreeObject.T_TREE_OBJECT.NAME.asc()));
        List<TTreeObjectRecord> rootChildren;
        if(parentId == null){
            rootChildren=records.stream().filter(r -> r.getParentObjectId() == null).collect(Collectors.toList());
        }else{
            rootChildren=records.stream().filter(r -> r.getParentObjectId().equals(parentId)).collect(Collectors.toList());
        }
        List<OozieTreeVO> voList=new ArrayList<>();
        OozieTreeVO rootChild;
        for(TTreeObjectRecord record:rootChildren){
            rootChild=toTreeVO(record);
            setChildren(rootChild,records);
            voList.add(rootChild);
        }
        return new ResultVo<>(0,voList);
    }

    private OozieTreeVO toTreeVO(TTreeObjectRecord record){
        OozieTreeVO oozieTreeVO=new OozieTreeVO();
        oozieTreeVO.setId(record.getId());
        oozieTreeVO.setName(record.getName());
        return oozieTreeVO;
    }

    public void setChildren(OozieTreeVO treeVO,List<TTreeObjectRecord> recordList){
       List<TTreeObjectRecord> children=recordList.stream().filter(r ->treeVO.getId().equals( r.getParentObjectId())).collect(Collectors.toList());
        if(children.isEmpty()){
            return;
        }
        OozieTreeVO child;
       for(TTreeObjectRecord record:children){
           child=toTreeVO(record);
           setChildren(child,recordList);
           treeVO.getChildren().add(child);
       }
    }





    public List<TreeObjectListVO> findParents(BigDecimal id,boolean containSelf){
        TTreeObjectRecord object=treeObjectDao.findById(id);
        List<TreeObjectListVO> parents=new ArrayList<>();
        if(object==null){
            return parents;
        }
        if(containSelf){
            parents.add(new TreeObjectListVO(id,object.getName()));
        }
        if(object.getParentObjectId()==null){
            return parents;
        }
        TTreeObjectRecord parent=treeObjectDao.findById(object.getParentObjectId());
        int maxLevel=20;
        int level=0;
        while(parent!=null){
            TreeObjectListVO listVO=new TreeObjectListVO();
            listVO.setId(parent.getId());
            listVO.setName(parent.getName());
            parents.add(listVO);
            if(parent.getParentObjectId()==null){
                parent=null;
            }else{
                parent=treeObjectDao.findById(parent.getParentObjectId());
            }
            level=level+1;
            if(level>maxLevel){
                logger.error("database contain error data,id="+id);
                break;
            }
        }
        return parents;
    }

    public void updateTreeObject(TreeObjectVO objectVO,String oldName,BigDecimal sourceObjectId){
        if(!oldName.equals(objectVO.getName())){
            List<Condition> updateConditionList=new ArrayList<>();
            updateConditionList.add(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID.eq(sourceObjectId));
            updateConditionList.add(TTreeObject.T_TREE_OBJECT.LEAF_OBJECT_TYPE.eq(objectVO.getLeafObjectType()));
            treeObjectDao.update(updateConditionList,TTreeObject.T_TREE_OBJECT.NAME,objectVO.getName());
        }
    }

    public void deleteTreeObjects(List<BigDecimal> sourceObjectIdList,String objectType){
        List<Condition> deleteConditionList=new ArrayList<>();
        deleteConditionList.add(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID.in(sourceObjectIdList));
        deleteConditionList.add(TTreeObject.T_TREE_OBJECT.LEAF_OBJECT_TYPE.eq(objectType));
        treeObjectDao.deleteByConditions(deleteConditionList);
    }

    public void deleteTreeObjects(List<BigDecimal> sourceObjectIdList,String objectType,List<String> userIdList){
        List<Condition> deleteConditionList=new ArrayList<>();
        deleteConditionList.add(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID.in(sourceObjectIdList));
        deleteConditionList.add(TTreeObject.T_TREE_OBJECT.LEAF_OBJECT_TYPE.eq(objectType));
        deleteConditionList.add(TTreeObject.T_TREE_OBJECT.CREATE_USER.in(userIdList));
        treeObjectDao.deleteByConditions(deleteConditionList);
    }

    public List<TTreeObjectRecord> constructTreeObject(Collection<String> userIdList,TreeObjectVO objectVO,BigDecimal sourceObjectId){
        List<TTreeObjectRecord> recordList=new ArrayList<>();
        TTreeObjectRecord objectRecord;
        Timestamp now=new Timestamp(System.currentTimeMillis());
        for(String id:userIdList){
            objectRecord=new TTreeObjectRecord();
            objectRecord.setId(BigDecimal.valueOf(idService.id()));
            objectRecord.setCreateTime(now);
            objectRecord.setCreateUser(id);
            objectRecord.setLeafObjectType(objectVO.getLeafObjectType());
            objectRecord.setName(objectVO.getName());
            objectRecord.setObjectType(objectVO.getObjectType());
            objectRecord.setParentObjectId(objectVO.getParentId());
            objectRecord.setSourceObjectId(sourceObjectId);
            objectRecord.setParentType(objectVO.getParentType());
            recordList.add(objectRecord);
        }
        return recordList;
    }


    public void addTreeObject(TreeObjectVO objectVO,String userId,BigDecimal sourceObjectId){
        List<TTreeObjectRecord> treeObjectRecordList= constructTreeObject(Arrays.asList(userId),objectVO,sourceObjectId);
        if(!treeObjectRecordList.isEmpty()){
            treeObjectDao.insert(treeObjectRecordList);
        }
    }

    public void updateName(BigDecimal sourceObjectId,String leafObjectType,String newName){
        List<Condition> updateConditionList=new ArrayList<>();
        updateConditionList.add(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID.eq(sourceObjectId));
        updateConditionList.add(TTreeObject.T_TREE_OBJECT.LEAF_OBJECT_TYPE.eq(leafObjectType));
        treeObjectDao.update(updateConditionList,TTreeObject.T_TREE_OBJECT.NAME,newName);
    }

    public void setSystemTreeObject(TreeObjectVO treeObject,String operate){
        List<Condition> conditionList=new ArrayList<>();
        conditionList.add(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID.eq(treeObject.getSourceObjectId()));
        conditionList.add(TTreeObject.T_TREE_OBJECT.PARENT_TYPE.eq(TreeObjectVO.TreeParentType.SYSTEM.toString()));
        boolean isSystem=(operate.equals("create"));
        switch (treeObject.getLeafObjectType()){
            case "PROGRAM" :
                programDao.update(Arrays.asList(TProgram.T_PROGRAM.ID.eq(treeObject.getSourceObjectId())),TProgram.T_PROGRAM.IS_PUBLIC,isSystem);
                break;
            case "FILE" :
                dataManageDao.update(Arrays.asList(TStorageData.T_STORAGE_DATA.ID.eq(treeObject.getSourceObjectId())),TStorageData.T_STORAGE_DATA.IS_PUBLIC,isSystem);
                break;
            default :
                itemDao.update(Arrays.asList(TMetadataItem.T_METADATA_ITEM.ID.eq(treeObject.getSourceObjectId())),TMetadataItem.T_METADATA_ITEM.IS_SYSTEM,isSystem);
                break;

        }
        if(!isSystem){
            treeObjectDao.deleteByConditions(conditionList);
            return;
        }
        TTreeObjectRecord record=treeObjectDao.findAnyByCondition(conditionList);
        if(record !=null ){
            record.setParentObjectId(treeObject.getParentId());
            treeObjectDao.update(record);
            return;
        }
        record=new TTreeObjectRecord();
        record.setId(new BigDecimal(idService.id()));
        record.setName(treeObject.getName());
        record.setCreateTime(new Timestamp(System.currentTimeMillis()));
        record.setCreateUser("1");
        record.setLeafObjectType(treeObject.getLeafObjectType());
        record.setObjectType(treeObject.getObjectType());
        record.setParentObjectId(treeObject.getParentId());
        record.setParentType(TreeObjectVO.TreeParentType.SYSTEM.toString());
        record.setSourceObjectId(treeObject.getSourceObjectId());
        treeObjectDao.insert(record);

    }

}
