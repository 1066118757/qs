package com.cdid.service.metadata.theme;

import com.cdid.api.common.IDGeneratorService;
import com.cdid.api.metadata.theme.ThemeService;
import com.cdid.api.metadata.theme.vo.*;
import com.cdid.api.metadata.themeitem.ThemeItemService;
import com.cdid.api.metadata.themeitem.vo.ThemeItemAddVo;
import com.cdid.api.metadata.themeitem.vo.ThemeItemListVo;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.metadata.item.ItemDao;
import com.cdid.dao.metadata.theme.ThemeDao;
import com.cdid.dao.metadata.themeitem.ThemeItemDao;
import com.cdid.dao.user.UsersDao;
import com.cdid.jooq.tables.records.TMetadataItemRecord;
import com.cdid.jooq.tables.records.TMetadataThemeItemRecord;
import com.cdid.jooq.tables.records.TMetadataThemeRecord;
import com.cdid.utils.VoReTraversalUtil;
import org.apache.commons.lang3.StringUtils;
import org.jooq.Condition;
import org.jooq.Record2;
import org.jooq.Result;
import org.jooq.SortField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import static com.cdid.jooq.tables.TMetadataItem.T_METADATA_ITEM;
import static com.cdid.jooq.tables.TMetadataTheme.T_METADATA_THEME;
import static com.cdid.jooq.tables.TMetadataThemeItem.T_METADATA_THEME_ITEM;

/**
 * 公司荣誉的实现
 */
@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class ThemeServiceImpl implements ThemeService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ThemeDao themeDao;
    @Autowired
    private ThemeItemDao themeItemDao;
    @Autowired
    private ItemDao itemDao;
    @Autowired
    private IDGeneratorService<Long> idGeneratorService;
    @Autowired
    private ThemeItemService themeItemService;
    @Autowired
    private UsersDao usersDao;
    
    /**
     * 元数据主题信息添加
     * @param themeAddVo
     * @param userId
     * @return
     */
    @Override
    public ResultVo<Object> add(ThemeAddVo themeAddVo, String userId) {
        ResultVo<Object> resultVo = new ResultVo<Object>();
        try {
            //对名字进行判重
            String name = themeAddVo.getName();
            TMetadataThemeRecord[] infoByName = themeDao.getInfoByName(name);
            if (infoByName!=null && infoByName.length>0){
                return new ResultVo<>(ErrorCode.ParamError.getErrorCode(),"当前逻辑分区的名字已经存在，请重新输入！");
            }
            TMetadataThemeRecord tThemeRecord =(TMetadataThemeRecord) VoReTraversalUtil.traversalTwo(themeAddVo, TMetadataThemeRecord.class);
            BigDecimal themeId = BigDecimal.valueOf(idGeneratorService.id());
            tThemeRecord.setId(themeId);
            //创建人，同时也是更新人
            tThemeRecord.setCreateUser(userId);
            tThemeRecord.setUpdateUser(userId);
            //插入表中
            themeDao.insert(tThemeRecord);
            //同时添加业务元数据以及任务元数据2个主题条目
            ThemeItemAddVo addVo = new ThemeItemAddVo();
            addVo.setThemeId(themeId);
            addVo.setName("业务元数据");
            themeItemService.add(addVo,userId);
            addVo.setName("任务元数据");
            themeItemService.add(addVo,userId);
            resultVo.setData("success");
            return resultVo;
        } catch (Exception e) {
            e.printStackTrace();
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            return resultVo;
        }
    }

    /**
     * 元数据主题信息更新
     * @param themeUpdateVo
     * @param userId
     * @return
     */
    @Override
    public ResultVo<Object> update(ThemeUpdateVo themeUpdateVo, String userId) {
        ResultVo<Object> resultVo = new ResultVo<Object>();
        BigDecimal id = themeUpdateVo.getId();
        if(BigDecimal.valueOf(100L).equals(id)){
           return new ResultVo<>(ErrorCode.ParamError.getErrorCode(), false,"不能编辑共享分区");
        }
        try {
            //从数据库查询出需要修改的信息
            TMetadataThemeRecord tMetadataThemeRecord = themeDao.findById(themeUpdateVo.getId());
            if (tMetadataThemeRecord == null) {
                return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
            }
            //判断，xxx情况不允许更新

            //调用方法设置值
            tMetadataThemeRecord = (TMetadataThemeRecord)VoReTraversalUtil.traversalTwo(themeUpdateVo, TMetadataThemeRecord.class);
            //更新人
            tMetadataThemeRecord.setUpdateUser(userId);
            //更新时间
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            tMetadataThemeRecord.setUpdateTime(timestamp);
            //审核人,有审核状态传入则表示审核
//            Integer state = themeUpdateVo.getState();
//            if (state!=null){
//                tMetadataThemeRecord.setAuditTime(timestamp);
//            }
            themeDao.update(tMetadataThemeRecord);
            resultVo.setData("success");
            return resultVo;
        } catch (Exception e) {
            e.printStackTrace();
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            return resultVo;
        }
    }

    /**
     * 元数据主题信息删除
     * @param id
     * @return
     */
    @Override
    public ResultVo<Object> delete(BigDecimal id) {
        if(BigDecimal.valueOf(100L).equals(id)){
           return new ResultVo<>(ErrorCode.ParamError.getErrorCode(), false,"不能删除共享分区");
        }
        //查询是否存在
        TMetadataThemeRecord tMetadataThemeRecord = themeDao.findById(id);
        if (tMetadataThemeRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), "记录不存在，无法删除！");
        }
        //查询下面是否还有元数据主题条目，有则不允许删除
        BigDecimal themeId = tMetadataThemeRecord.getId();
        List<TMetadataThemeItemRecord> fetch = themeItemDao.fetch(T_METADATA_THEME_ITEM.THEME_ID, themeId);
        //循环判断元数据下是否还有条目条目信息，若有，则不允许删除
        //定义标识符，判断主题条目下是否还有元数据条目,默认false
        Boolean flag=false;
        for (TMetadataThemeItemRecord item:fetch) {
            BigDecimal themeItemId = item.getId();
            List<TMetadataItemRecord> fetch2 = itemDao.fetch(T_METADATA_ITEM.THEME_ITEM_ID, themeItemId);
            if (fetch2.size()>0){
                flag=true;
            }
        }
        if (flag){
            return new ResultVo<>(ErrorCode.Invalid.getErrorCode(), "当前删除的主题中还有元数据条目信息，不允许删除，请先删除元数据条目信息！");
        }
        //判断，xxx情况不允许删除
        //删除
        List<BigDecimal> ids = new ArrayList<>();
        ids.add(id);
        themeDao.deleteById(ids);
        //删除关联的主题详情信息
        themeItemDao.deleteByThemeId(id);
        return new ResultVo<>(0, true);

    }

    /**
     * 元数据主题信息列表查询
     * @param themeQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    @Override
    public ResultVo<PageVo<List<ThemeListVo>>> list(ThemeQueryVo themeQueryVo, String userId, Integer page, Integer size) {
        List<SortField<?>> sortList = new ArrayList<>();

        /*TUserRecord tUserRecord = userDao.findById(userId);
        if (tUserRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), null);
        }*/

        //添加排序字段
        sortList.add(T_METADATA_THEME.UPDATE_TIME.desc());
        //添加条件字段
        List<Condition> conditions = innerAddListCondition(themeQueryVo);
        if(!StringUtils.isEmpty(userId)){
            conditions.add(T_METADATA_THEME.CREATE_USER.eq(userId).or(T_METADATA_THEME.ID.eq(BigDecimal.valueOf(100L))));
        }
        String name = themeQueryVo.getName();
        if(!StringUtils.isEmpty(name)){
            conditions.add(T_METADATA_THEME.NAME.like("%"+ name +"%"));
        }
        //查询赋值返回
        PageVo<TMetadataThemeRecord> query = themeDao.fetchByPage(conditions, new OffsetPagingVo(page, size), sortList);

        List<TMetadataThemeRecord> tMetadataThemeRecords;
        tMetadataThemeRecords=query.getPageData();
        List<ThemeListVo> list = new ArrayList<>();
        for (TMetadataThemeRecord tMetadataThemeRecord : tMetadataThemeRecords
                ) {
            ThemeListVo  themeListVo= (ThemeListVo)VoReTraversalUtil.traversalTwo(tMetadataThemeRecord, ThemeListVo.class);
            //查询创建者名字
            String name1 = usersDao.getNameByUserId(tMetadataThemeRecord.getCreateUser());
            themeListVo.setCreateUserName(name1);
            list.add(themeListVo);
        }
        PageVo<ThemeListVo> result = new PageVo<>();
        result.setPageData(list);
        result.setTotalCount(query.getTotalCount());
        return new ResultVo(0, result);
    }

    /**
     * 为list添加条件字段的方法
     * @param themeQueryVo
     * @return
     */
    private List<Condition> innerAddListCondition(ThemeQueryVo themeQueryVo){
        List<Condition> conditions = new ArrayList<>();
        //TODO 添加条件字段

        return conditions;
    }
    /**
     * 元数据主题信息详情查询
     * @param id
     * @return
     */
    @Override
    public ResultVo<ThemeDetailVo> detailById(BigDecimal id) {
        TMetadataThemeRecord tMetadataThemeRecord = themeDao.findById(id);
        if (tMetadataThemeRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), null);
        }
        ThemeDetailVo themeDetailVo =(ThemeDetailVo) VoReTraversalUtil.traversalTwo(tMetadataThemeRecord, ThemeDetailVo.class);
        //查询创建者名字
        String name1 = usersDao.getNameByUserId(tMetadataThemeRecord.getCreateUser());
        themeDetailVo.setCreateUserName(name1);
        return new ResultVo<>(0,themeDetailVo);
    }

    /**
     * 查询全部元数据主题信息
     * @return
     */
    @Override
    public ResultVo<List<ThemeAllListVo>> listAlls(String from,String userId) {
        List<ThemeAllListVo> listVos=new ArrayList<>();
        //元数据排序字段
        List<SortField<?>> sortList = new ArrayList<>();
        sortList.add(T_METADATA_THEME.UPDATE_TIME.desc());
        //元数据条目排序字段
        List<SortField<?>> sortItemList = new ArrayList<>();
        sortItemList.add(T_METADATA_THEME_ITEM.UPDATE_TIME.desc());
        //添加条件字段
        List<Condition> conditions = new ArrayList<>();
        if(!StringUtils.isEmpty(userId)){
            if(StringUtils.isEmpty(from)){
                conditions.add(T_METADATA_THEME.CREATE_USER.eq(userId));
            }else {
                conditions.add(T_METADATA_THEME.CREATE_USER.eq(userId).or(T_METADATA_THEME.ID.eq(BigDecimal.valueOf(100L))));
            }
        }
        //查询主题
        PageVo<TMetadataThemeRecord> query1 = themeDao.fetchByPage(conditions, new OffsetPagingVo(1, Integer.MAX_VALUE), sortList);
        List<TMetadataThemeRecord> tMetadataThemeRecords;
        tMetadataThemeRecords=query1.getPageData();
        for (TMetadataThemeRecord tMetadataThemeRecord : tMetadataThemeRecords
                ) {
            ThemeAllListVo allItem = innerThemeRecordToVo(tMetadataThemeRecord);
            //查询主题创建者名字
            String themeCrName = usersDao.getNameByUserId(tMetadataThemeRecord.getCreateUser());
            allItem.setCreateUserName(themeCrName);
            //准备条目查询条件
            List<Condition> conditionsItem=new ArrayList<>();
            conditionsItem.add(T_METADATA_THEME_ITEM.THEME_ID.eq(allItem.getId()));
            if(!StringUtils.isEmpty(userId)){
                conditionsItem.add(T_METADATA_THEME_ITEM.CREATE_USER.eq(userId).or(T_METADATA_THEME_ITEM.THEME_ID.eq(BigDecimal.valueOf(100L))));
            }
            //元数据条目查询数据返回
            PageVo<TMetadataThemeItemRecord> query = themeItemDao.fetchByPage(conditionsItem, new OffsetPagingVo(1, Integer.MAX_VALUE), sortItemList);
            List<TMetadataThemeItemRecord> tMetadataThemeItemRecords;
            tMetadataThemeItemRecords=query.getPageData();
            List<ThemeItemListVo> list = new ArrayList<>();
            for (TMetadataThemeItemRecord tMetadataThemeItemRecord : tMetadataThemeItemRecords
                    ) {
                ThemeItemListVo themeItemListVo = innerItemRecordToVo(tMetadataThemeItemRecord);
                list.add(themeItemListVo);
            }
            allItem.setThemeItemListVos(list);
            listVos.add(allItem);
        }
        return new ResultVo(0,listVos);
    }

    //record->vo
    private ThemeAllListVo innerThemeRecordToVo(TMetadataThemeRecord tMetadataThemeRecord){
        ThemeAllListVo allItem= new ThemeAllListVo();
        BigDecimal id = tMetadataThemeRecord.getId();
        if (id!=null){
            allItem.setId(id);
        }
        String name = tMetadataThemeRecord.getName();
        if (name!=null){
            allItem.setName(name);
        }
        String remark = tMetadataThemeRecord.getRemark();
        if (remark!=null){
            allItem.setRemark(remark);
        }
        Integer state = tMetadataThemeRecord.getState();
        if (state!=null){
            allItem.setState(state);
        }
        Timestamp auditTime = tMetadataThemeRecord.getAuditTime();
        if (auditTime!=null){
            allItem.setAuditTime(auditTime);
        }
        Short status = tMetadataThemeRecord.getStatus();
        if (status!=null){
            allItem.setStatus(status);
        }
        String createUser = tMetadataThemeRecord.getCreateUser();
        if (createUser!=null){
            allItem.setCreateUser(createUser);
        }
        Timestamp createTime = tMetadataThemeRecord.getCreateTime();
        if (createTime!=null){
            allItem.setCreateTime(createTime);
        }
        String updateUser = tMetadataThemeRecord.getUpdateUser();
        if (updateUser!=null){
            allItem.setUpdateUser(updateUser);
        }
        Timestamp updateTime = tMetadataThemeRecord.getUpdateTime();
        if (updateTime!=null){
            allItem.setUpdateTime(updateTime);
        }
        return allItem;
    }

    //record->vo
    private ThemeItemListVo innerItemRecordToVo(TMetadataThemeItemRecord tMetadataThemeRecord){
        ThemeItemListVo allItem= new ThemeItemListVo();
        BigDecimal id = tMetadataThemeRecord.getId();
        if (id!=null){
            allItem.setId(id);
        }
        String name = tMetadataThemeRecord.getName();
        if (name!=null){
            allItem.setName(name);
        }
        BigDecimal themeId = tMetadataThemeRecord.getThemeId();
        if (themeId!=null){
            allItem.setThemeId(themeId);
        }
        Integer state = tMetadataThemeRecord.getState();
        if (state!=null){
            allItem.setState(state);
        }
        Timestamp auditTime = tMetadataThemeRecord.getAuditTime();
        if (auditTime!=null){
            allItem.setAuditTime(auditTime);
        }
        Short status = tMetadataThemeRecord.getStatus();
        if (status!=null){
            allItem.setStatus(status);
        }
        String createUser = tMetadataThemeRecord.getCreateUser();
        if (createUser!=null){
            allItem.setCreateUser(createUser);
        }
        Timestamp createTime = tMetadataThemeRecord.getCreateTime();
        if (createTime!=null){
            allItem.setCreateTime(createTime);
        }
        String updateUser = tMetadataThemeRecord.getUpdateUser();
        if (updateUser!=null){
            allItem.setUpdateUser(updateUser);
        }
        Timestamp updateTime = tMetadataThemeRecord.getUpdateTime();
        if (updateTime!=null){
            allItem.setUpdateTime(updateTime);
        }
        return allItem;
    }

    /**
     * 查询逻辑分区列表
     * @return
     */
    @Override
    public ResultVo<List<ThemeMenuVo>> listMenu() {
        Result<Record2<BigDecimal, String>> record2s = themeItemDao.listMenu();
        List<ThemeMenuVo> dataList = new ArrayList<>();
        ThemeMenuVo themeMenuVo = null;
            for(Record2<BigDecimal, String> record : record2s){

                themeMenuVo = new ThemeMenuVo();
                themeMenuVo.setId((BigDecimal) record.get("id"));
                themeMenuVo.setName((String) record.get("name"));
                dataList.add(themeMenuVo);
            }
        return new ResultVo<>(0,dataList,"SUCCESS");
    }
}
