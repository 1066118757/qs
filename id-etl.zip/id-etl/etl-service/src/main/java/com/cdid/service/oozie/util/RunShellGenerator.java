
package com.cdid.service.oozie.util;


import com.cdid.service.oozie.command.CommandParseException;
import com.cdid.service.oozie.command.CommandParser;
import com.cdid.service.oozie.command.Commander;
import com.cdid.service.oozie.command.FileHolder;


public class RunShellGenerator {
	/**
	 * generate new cmdLine (content of run.sh)
	 * @return string of new cmdline
	 */
	public String generate() {
		StringBuffer sb = new StringBuffer("");
		sb.append("#! /bin/bash\n" +
				"#standalone\n" +
				"echo +++++++++++++log information+++++++++++\n" +
				"source /etc/profile\n" +
				"echo $PATH \n" +
				"exit_code=0\n\n" +
				"echo mk action-dir...\n" +
				"actionId=${3##*/}\n" +
				"mkdir $actionId\n" +
				"echo download libaries ...\n" +
				"$HADOOP_HOME/bin/hdfs dfs -get $2/* 1>>stdout 2>>stderr\n" +
				"#((exit_code=exit_code|$?))\n" +
				"chmod -R +x *\n" +
				"echo download input hdfs files ...\n");

		sb.append("\necho execute command line\n" +
				"echo $1 1>>stdout 2>>stderr\n" +
				"eval $1 1>>stdout 2>>stderr\n" +
				"((exit_code=exit_code|$?))\n\n");

		sb.append("mv stdout stderr $actionId\n" +
				"$HADOOP_HOME/bin/hdfs dfs -put $actionId $3\n" +
				"$HADOOP_HOME/bin/hdfs dfs -chmod -R 777 $3\n\n" +
				"exit $exit_code");

		System.out.print(sb.toString());
		return sb.toString();
	}
}
