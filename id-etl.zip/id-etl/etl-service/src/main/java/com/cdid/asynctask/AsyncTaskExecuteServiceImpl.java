package com.cdid.asynctask;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cdid.api.asynctask.AsyncTaskExecuteService;
import com.cdid.api.asynctask.vo.AsyncTaskConfigVo;
import com.cdid.api.dataclear.cleartask.ClearTaskService;
import com.cdid.api.dataclear.cleartask.vo.ClearTaskSubmitVo;
import com.cdid.api.dataclear.cleartask.vo.ClearTaskUpdateVo;
import com.cdid.api.dataclear.cleartasklog.ClearTaskLogService;
import com.cdid.api.dataclear.cleartasklog.vo.ClearTaskLogUpdateVo;
import com.cdid.api.sharedata.ShareDataService;
import com.cdid.common.dict.TaskResult;
import com.cdid.dao.dataclear.cleartask.ClearTaskDao;
import com.cdid.jooq.tables.records.TClearTaskRecord;
import com.cdid.service.common.KafkaConsumerListener;
import com.cdid.service.dataclear.ClearTaskPreProcessor;
import com.cdid.service.job.JobServiceUtil;
import com.cdid.service.job.ScheduleUtils;
import com.cdid.utils.HttpClientUtil;
import com.cdid.utils.StringUtil;
import com.cdid.utils.jdbc.SpringUtil;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

@Service
public class AsyncTaskExecuteServiceImpl implements AsyncTaskExecuteService,Job {
    private static final Logger logger = LoggerFactory.getLogger(AsyncTaskExecuteServiceImpl.class);
    private static final  String SPARK_JOB_SUBMIT="/rest/sparkJobDeploy/submit" ;

    private static final  String MODEL_SUBMITDEPLOY="/rest/model/submitDeploy/" ;

    @Value("${idmanager-server.baseUrl}")
    private String idmanagerBaseUrl;
    @Autowired
    private ClearTaskService clearTaskService;
    @Autowired
    private ClearTaskLogService clearTaskLogService;
    @Autowired
    private ClearTaskDao clearTaskDao;



    @Override
    public void execute(AsyncTaskConfigVo configVo,boolean isHand) throws Exception {
        if(configVo.getPreProcessProcessor()!=null && configVo.getTaskId()!=null){
            configVo.getPreProcessProcessor().preProcess(configVo,isHand);
        }
        if(StringUtil.isEmpty(configVo.getTopic())){
            throw new Exception("topic is null!");
        }
        if(configVo.getTaskParams()==null){
            throw new Exception("taks params is null!");
        }
        JSONObject taskParams=configVo.getTaskParams();
        KafkaTemplate template= SpringUtil.getBean(KafkaTemplate.class);
        taskParams.put("taskId",configVo.getTaskId());
        switch (configVo.getTopic()){
            case "dataCleanResult":
                taskParams.put("businessType","dataClean");
                taskParams.put("topic","dataCleanResult");
                break;
            default:
                taskParams.put("businessType","ETL");
                taskParams.put("topic","ETLResult");
                break;
        }
        logger.info("taskParams:"+taskParams.toJSONString());
        template.send(JobServiceUtil.KAFAKA_TOPIC_DATACONFIG,taskParams.toJSONString());
    }

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        Object configVo=context.getJobDetail().getJobDataMap().get(ScheduleUtils.JOB_CONFIG);
        Object clearTaskSubmitVo=context.getJobDetail().getJobDataMap().get(ScheduleUtils.CLEAR_TASK_SUBMIT);
        Object learningModelDeployId =context.getJobDetail().getJobDataMap().get(ScheduleUtils.LEARNING_MODEL_DEPLOY);

        if ((configVo==null || !(configVo instanceof AsyncTaskConfigVo))
                && (clearTaskSubmitVo==null || !(clearTaskSubmitVo instanceof ClearTaskSubmitVo))
                && (learningModelDeployId==null || !(learningModelDeployId instanceof String))){
            throw new JobExecutionException("configVo or clearTaskSubmitVo or learningModelDeployId is empty");
        }
        try {
            if(clearTaskSubmitVo!=null && clearTaskSubmitVo instanceof ClearTaskSubmitVo){
                execute((ClearTaskSubmitVo)clearTaskSubmitVo,false);
            }else if(learningModelDeployId!=null && learningModelDeployId instanceof String){
                execute((String)learningModelDeployId,false);
            }else{
                execute((AsyncTaskConfigVo)configVo,false);
            }
        } catch (Exception e) {
            logger.info(e.getMessage());
        }
    }


    @Override
    public void execute(String learningModelDeployId,boolean isHand) throws Exception {
        logger.info("learningModelDeployId :" +learningModelDeployId);
        Map<String,String> header = new HashMap<>();
        HttpClientUtil.sendGet(idmanagerBaseUrl+MODEL_SUBMITDEPLOY+learningModelDeployId,null,header);
    }

    @Override
    public void execute(ClearTaskSubmitVo clearTaskSubmitVo,boolean isHand) throws Exception {
        BigDecimal taskId = clearTaskSubmitVo.getTaskId();
        //代码提交前准备工作
        ClearTaskPreProcessor clearTaskPreProcessor = new ClearTaskPreProcessor();
        BigDecimal logId = clearTaskPreProcessor.submitPreProcess(taskId);
        if (StringUtils.isEmpty(taskId) || StringUtils.isEmpty(logId)){
            logger.info("taskId or logId is empty");
            throw new RuntimeException("taskId or logId is empty");
        }
        String muUrl=idmanagerBaseUrl+SPARK_JOB_SUBMIT;
        String response = HttpClientUtil.doPostByJson(muUrl, JSON.toJSONString(clearTaskSubmitVo));
        logger.info("submit spark job response:"+response);
        //更新log，task表对应信息
        ClearTaskLogUpdateVo updateVo = new ClearTaskLogUpdateVo();
        ClearTaskUpdateVo clearTaskUpdateVo = new ClearTaskUpdateVo();
        Timestamp currentTime = new Timestamp(System.currentTimeMillis());
        updateVo.setTaskId(taskId);
        updateVo.setId(logId);
        updateVo.setEndTime(currentTime);
        updateVo.setTaskLog("已提交！");
        updateVo.setResult(TaskResult.SUBMITED.getValue());
        //TODO batchId-->response
        if (response.equals("fail")){
            logger.info("提交任务失败！！！！！请检查接口是否可使用！！！！！！！！");
        }else {
            JSONObject jsonObject = JSONObject.parseObject(response);
            Object data = jsonObject.get("data");
            if (!StringUtils.isEmpty(data)){
                Object id = ((JSONObject)data).get("id");
                if (!StringUtils.isEmpty(id)){
                    updateVo.setSuccessRows(Long.valueOf((Integer)id));
                }
            }
        }
        clearTaskUpdateVo.setId(taskId);
        clearTaskUpdateVo.setNearEndTime(currentTime);
        clearTaskUpdateVo.setNearResult(TaskResult.SUBMITED.getValue());
        //查询任务信息发送短信或者email
        TClearTaskRecord taskRecord = clearTaskDao.findById(taskId);
        //发送邮件短信
        clearTaskService.sendEmailAndNote(taskRecord.getName(),taskRecord.getEmail(),taskRecord.getPhone(),"自定义算法已提交！",currentTime);
        clearTaskLogService.updateOrSave(updateVo, "0");
        clearTaskService.updateNearData(clearTaskUpdateVo);
    }
}
