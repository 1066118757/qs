package com.cdid.service.version;

import com.cdid.api.common.IDGeneratorService;
import com.cdid.api.version.VersionService;
import com.cdid.api.version.vo.*;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.version.VersionDao;
import com.cdid.jooq.tables.TVersion;
import com.cdid.jooq.tables.records.TVersionRecord;
import com.cdid.utils.VoReTraversalUtil;
import org.jooq.Condition;
import org.jooq.SortField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * 版本信息的实现
 */
@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class VersionServiceImpl implements VersionService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private VersionDao versionDao;
    @Autowired
    private IDGeneratorService<Long> idGeneratorService;

    /**
     * 版本信息添加
     *
     * @param versionAddVo
     * @param userId
     * @return
     */
    @Override
    public ResultVo<Object> add(VersionAddVo versionAddVo, String userId) {
        ResultVo<Object> resultVo = new ResultVo<Object>();
        Integer state = versionAddVo.getState();
        try {
            TVersionRecord tVersionRecord = (TVersionRecord) VoReTraversalUtil.traversalTwo(versionAddVo, TVersionRecord.class);
            BigDecimal id = BigDecimal.valueOf(idGeneratorService.id());
            tVersionRecord.setId(id);
            //创建人，同时也是更新人
            tVersionRecord.setCreateUser(userId);
            tVersionRecord.setUpdateUser(userId);
            //创建时间
            Timestamp currentTime=new Timestamp(System.currentTimeMillis());
            tVersionRecord.setCreateTime(currentTime);
            tVersionRecord.setUpdateTime(currentTime);
            tVersionRecord.setFlag((short)1);
            //插入表中
            versionDao.insert(tVersionRecord);
            //如果state为1，那么修改其他记录state为0
            if (state==1){
                versionDao.changeState(id);
            }
            resultVo.setData("success");
            return resultVo;
        } catch (Exception e) {
            e.printStackTrace();
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            return resultVo;
        }
    }

    /**
     * 版本信息更新
     *
     * @param versionUpdateVo
     * @param userId
     * @return
     */
    @Override
    public ResultVo<Object> update(VersionUpdateVo versionUpdateVo, String userId) {
        ResultVo<Object> resultVo = new ResultVo<Object>();
        Integer state = versionUpdateVo.getState();
        try {
            //从数据库查询出需要修改的信息
            TVersionRecord tVersionRecord = versionDao.findById(versionUpdateVo.getId());
            if (tVersionRecord == null) {
                return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
            }
            //调用方法设置值
            tVersionRecord = (TVersionRecord) VoReTraversalUtil.traversalTwo(versionUpdateVo, TVersionRecord.class);
            //更新人
            tVersionRecord.setUpdateUser(userId);
            //更新时间
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            tVersionRecord.setUpdateTime(timestamp);
            versionDao.update(tVersionRecord);
            //如果state为1，那么修改其他记录state为0
            if (state==1){
                versionDao.changeState(versionUpdateVo.getId());
            }
            resultVo.setData("success");
            return resultVo;
        } catch (Exception e) {
            e.printStackTrace();
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            return resultVo;
        }
    }

    /**
     * 版本信息删除
     *
     * @param id
     * @return
     */
    @Override
    public ResultVo<Object> delete(BigDecimal id) {
        //查询是否存在
        TVersionRecord tVersionRecord = versionDao.findById(id);
        if (tVersionRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), false);
        }
        //删除
        List<BigDecimal> ids = new ArrayList<>();
        ids.add(id);
        versionDao.deleteById(ids);
        return new ResultVo<>(0, true);
    }

    /**
     * 版本信息列表查询
     *
     * @param versionQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    @Override
    public ResultVo<PageVo<List<VersionListVo>>> list(VersionQueryVo versionQueryVo, String userId, Integer page, Integer size) {
        List<SortField<?>> sortList = new ArrayList<>();
        //添加排序字段
        sortList.add(TVersion.T_VERSION.UPDATE_TIME.desc());
        //添加条件字段
        List<Condition> conditions = innerAddListCondition(versionQueryVo);
        //查询赋值返回
        PageVo<TVersionRecord> query = versionDao.fetchByPage(conditions, new OffsetPagingVo(page, size), sortList);
        List<TVersionRecord> tVersionRecords;
        tVersionRecords = query.getPageData();
        List<VersionListVo> list = new ArrayList<>();
        for (TVersionRecord tVersionRecord : tVersionRecords
                ) {
            VersionListVo versionListVo = (VersionListVo) VoReTraversalUtil.traversalTwo(tVersionRecord, VersionListVo.class);
            list.add(versionListVo);
        }
        PageVo<VersionListVo> result = new PageVo<>();
        result.setPageData(list);
        result.setTotalCount(query.getTotalCount());
        return new ResultVo(0, result);
    }

    /**
     * 为list添加条件字段的方法
     *
     * @param versionQueryVo
     * @return
     */
    private List<Condition> innerAddListCondition(VersionQueryVo versionQueryVo) {
        List<Condition> conditions = new ArrayList<>();
        //添加条件字段
        String name = versionQueryVo.getName();
        String no = versionQueryVo.getNo();
        Integer state = versionQueryVo.getState();
        if (name!=null){
            conditions.add(TVersion.T_VERSION.NAME.like("%"+name+"%"));
        }
        if (no!=null){
            conditions.add(TVersion.T_VERSION.NO.like("%"+no+"%"));
        }
        if (state!=null){
            conditions.add(TVersion.T_VERSION.STATE.eq(state));
        }
        return conditions;
    }

    /**
     * 版本信息详情查询
     *
     * @param id
     * @return
     */
    @Override
    public ResultVo<VersionDetailVo> detailById(BigDecimal id) {
        TVersionRecord tVersionRecord = versionDao.findById(id);
        if (tVersionRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), null);
        }
        VersionDetailVo versionVersionVo = (VersionDetailVo) VoReTraversalUtil.traversalTwo(tVersionRecord, VersionDetailVo.class);
        return new ResultVo<>(0, versionVersionVo);
    }

    @Override
    public ResultVo<VersionDetailVo> getCurrentInfo() {
        VersionQueryVo versionQueryVo = new VersionQueryVo();
        versionQueryVo.setState(1);
        List<SortField<?>> sortList = new ArrayList<>();
        //添加排序字段
        sortList.add(TVersion.T_VERSION.UPDATE_TIME.desc());
        //添加条件字段
        List<Condition> conditions = innerAddListCondition(versionQueryVo);
        //查询赋值返回
        PageVo<TVersionRecord> query = versionDao.fetchByPage(conditions, new OffsetPagingVo(1, 5), sortList);
        List<TVersionRecord> tVersionRecords;
        tVersionRecords = query.getPageData();
        List<VersionListVo> list = new ArrayList<>();
        for (TVersionRecord tVersionRecord : tVersionRecords
                ) {
            VersionListVo versionListVo = (VersionListVo) VoReTraversalUtil.traversalTwo(tVersionRecord, VersionListVo.class);
            list.add(versionListVo);
        }
        if (list.size()==0){
            return new ResultVo(ErrorCode.NotExists.getErrorCode(),"当前无启用版本信息，请前往设置！");
        }
        return new ResultVo(0, list.get(0));
    }
}
