package com.cdid.service.oozie.vo;

import com.alibaba.fastjson.JSONObject;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class OozieTreeVO {

    private BigDecimal id;

    private String name;

    private List<OozieTreeVO> children=new ArrayList<>();

    public List<OozieTreeVO> getChildren() {
        return children;
    }

    public void setChildren(List<OozieTreeVO> children) {
        this.children = children;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static void main(String[] args) {
        JSONObject obj=new JSONObject();
        obj.put("config","{" +
                "\"script\": {" +
                "\"steps\": []" +
                "}," +
                "\"tableName\": \"learning_test\"," +
                "\"targetColumns\": \"score4\"," +
                "\"miningType\": \"prediction\"," +
                "\"algorithmConfig\": {" +
                "\"algorithms\": [{" +
                "\"name\": \"DecisionTreeRegressor\"," +
                "\"params\": {" +
                "\"maxDepth\": \"2,3,5\"," +
                "\"maxBins\": \"2,4,8\"" +
                "}" +
                "}]" +
                "}" +
                "}");
        System.out.println(obj.toJSONString());
    }
}
