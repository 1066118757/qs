package com.cdid.service.oozie.vo;

public class OozieJobStatisticsResultVO {

    private DimensionStatisticsVO jobStatusDimension;

    private DimensionStatisticsVO successFailDimension;

    private Integer total;


    public DimensionStatisticsVO getJobStatusDimension() {
        return jobStatusDimension;
    }

    public void setJobStatusDimension(DimensionStatisticsVO jobStatusDimension) {
        this.jobStatusDimension = jobStatusDimension;
    }

    public DimensionStatisticsVO getSuccessFailDimension() {
        return successFailDimension;
    }

    public void setSuccessFailDimension(DimensionStatisticsVO successFailDimension) {
        this.successFailDimension = successFailDimension;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }
}
