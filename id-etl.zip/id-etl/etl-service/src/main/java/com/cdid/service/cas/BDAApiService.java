package com.cdid.service.cas;

import com.cdid.dao.metadata.item.ItemDao;
import com.cdid.dao.user.UsersDao;
import com.cdid.jooq.tables.Users;
import com.cdid.jooq.tables.records.TMetadataItemRecord;
import com.cdid.jooq.tables.records.UsersRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class BDAApiService {

    @Autowired
    UsersDao usersDao;

    @Autowired
    ItemDao itemDao;

    public List<String> listUserTables(String loginAccount){
       Optional<UsersRecord> user=  usersDao.fetchOptional(Users.USERS.LOGIN_ACCOUNT,loginAccount);
        if(!user.isPresent()){
            return new ArrayList<>();
        }
        List<TMetadataItemRecord> tables=itemDao.fetchAll(user.get().getGuid());
        List<String> tableNames=new ArrayList<>();
        for(TMetadataItemRecord record:tables){
            tableNames.add(record.getName());
        }
        return tableNames;
    }
}
