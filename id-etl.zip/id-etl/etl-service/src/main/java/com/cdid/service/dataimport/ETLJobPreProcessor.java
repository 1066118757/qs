package com.cdid.service.dataimport;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cdid.api.asynctask.vo.AsyncTaskConfigVo;
import com.cdid.api.job.JobService;
import com.cdid.api.job.vo.JobFinishedResponseVO;
import com.cdid.api.schedulelog.ScheduleLogService;
import com.cdid.api.schedulelog.vo.ScheduleLogAddVo;
import com.cdid.common.dict.JobState;
import com.cdid.common.vo.ResultVo;
import com.cdid.service.common.AbstractTaskPreProcessor;
import com.cdid.utils.jdbc.SpringUtil;
import org.apache.commons.net.util.Base64;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class ETLJobPreProcessor extends AbstractTaskPreProcessor {

    @Override
    protected void jobExecuteFailedCallBack(BigDecimal taskId, String errorMessage) {
        JobService jobService=SpringUtil.getBean(JobService.class);
        JobFinishedResponseVO responseVO=new JobFinishedResponseVO();
        responseVO.setTaskId(String.valueOf(taskId));
        responseVO.setErrorMsg(errorMessage);
        responseVO.setSuccess(false);
        jobService.jobFinishedCallBack(responseVO);
    }


    @Override
    public void preProcess(AsyncTaskConfigVo configVo,boolean isHand) throws Exception {
        ScheduleLogService logService=SpringUtil.getBean(ScheduleLogService.class);
        if(logService.jobIsRunning(configVo.getTaskId())){
            throw new Exception("Job:"+configVo.getTaskId()+" is running");
        }
        if(isHand){
            processDependence(configVo,true);
        }
        ScheduleLogAddVo addVo = new ScheduleLogAddVo();
        addVo.setJobId(configVo.getTaskId());
        addVo.setScheduleStarttime(new Timestamp(System.currentTimeMillis()));
        addVo.setScheduleState(JobState.Running.getValue());
        ResultVo<BigDecimal> result = logService.saveOrUpdate(addVo);

        JSONObject taskParams = configVo.getTaskParams();
        String config = taskParams.getString("config");
        String configJson = new String(Base64.decodeBase64(config));
        JSONObject configJSON = JSON.parseObject(configJson);
        configJSON.put("logId",result.getData());
        taskParams.put("config",Base64.encodeBase64String(configJSON.toJSONString().getBytes()).replaceAll("\r\n",""));
        if(!isHand){
            processDependence(configVo,false);
        }
    }
}
