package com.cdid.service.metadata.detail;

import com.cdid.api.common.IDGeneratorService;
import com.cdid.api.dict.DictService;
import com.cdid.api.file.FileService;
import com.cdid.api.metadata.detail.DetailService;
import com.cdid.api.metadata.detail.vo.*;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.metadata.detail.DetailDao;
import com.cdid.dao.metadata.item.ItemDao;
import com.cdid.dao.user.UsersDao;
import com.cdid.jooq.tables.records.TMetadataDetailRecord;
import com.cdid.jooq.tables.records.TMetadataItemRecord;
import com.cdid.utils.CsvUtils;
import com.cdid.utils.VoReTraversalUtil;
import com.cdid.utils.excel.ExcelUtils;
import org.jooq.Condition;
import org.jooq.SortField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import static com.cdid.jooq.tables.TMetadataDetail.T_METADATA_DETAIL;


/**
 * 元数据条目详情的实现
 */
@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class DetailServiceImpl implements DetailService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private DetailDao detailDao;
    @Autowired
    private ItemDao itemDao;
    @Autowired
    private IDGeneratorService<Long> idGeneratorService;
    @Autowired
    private FileService fileService;
    @Value("${web.filePath}")
    private String FILEPATH;
    @Autowired
    private DictService dictService;
    @Autowired
    private UsersDao usersDao;

    /**
     * 元数据条目详情信息添加
     *
     * @param detailAddVo
     * @param userId
     * @return
     */
    @Override
    public ResultVo<Object> add(DetailAddVo detailAddVo, String userId) {
        ResultVo<Object> resultVo = new ResultVo<Object>();

        try {
            //判断是否有传元数据主题条目id，必须传入元数据主题条目id
            BigDecimal itemId = detailAddVo.getMetadataItemId();
            if (itemId == null) {
                return new ResultVo<>(ErrorCode.ParamError.getErrorCode(), "添加元数据详情必须传入对应的元数据条目id！");
            }
            //判断传入的元数据主题条目必须在数据库中存在
            TMetadataItemRecord itemRecord = itemDao.findById(itemId);
            if (itemRecord == null) {
                return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), "绑定的元数据条目id找不到记录，请从新传入正确的参数！");
            }
            TMetadataDetailRecord tDetailRecord = (TMetadataDetailRecord) VoReTraversalUtil.traversalTwo(detailAddVo, TMetadataDetailRecord.class);
            tDetailRecord.setId(BigDecimal.valueOf(idGeneratorService.id()));
            //创建人，同时也是更新人
            tDetailRecord.setCreateUser(userId);
            tDetailRecord.setUpdateUser(userId);
            //插入表中
            detailDao.insert(tDetailRecord);
            resultVo.setData("success");
            return resultVo;
        } catch (Exception e) {
            e.printStackTrace();
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            return resultVo;
        }
    }

    /**
     * 元数据条目详情信息更新
     *
     * @param detailUpdateVo
     * @param userId
     * @return
     */
    @Override
    public ResultVo<Object> update(DetailUpdateVo detailUpdateVo, String userId) {
        ResultVo<Object> resultVo = new ResultVo<Object>();
        try {
            //从数据库查询出需要修改的信息
            TMetadataDetailRecord tMetadataDetailRecord = detailDao.findById(detailUpdateVo.getId());
            if (tMetadataDetailRecord == null) {
                return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
            }
            //判断，xxx情况不允许更新

            //调用方法设置值
            tMetadataDetailRecord = (TMetadataDetailRecord) VoReTraversalUtil.traversalTwo(detailUpdateVo, TMetadataDetailRecord.class);
            //更新人
            tMetadataDetailRecord.setUpdateUser(userId);
            //更新时间
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            tMetadataDetailRecord.setUpdateTime(timestamp);
            //审核人,有审核状态传入则表示审核
            Integer state = detailUpdateVo.getState();
            if (state != null) {
                tMetadataDetailRecord.setAuditTime(timestamp);
            }
            detailDao.update(tMetadataDetailRecord);
            resultVo.setData("success");
            return resultVo;
        } catch (Exception e) {
            e.printStackTrace();
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            return resultVo;
        }
    }

    /**
     * 元数据条目详情信息删除
     *
     * @param id
     * @return
     */
    @Override
    public ResultVo<Object> delete(BigDecimal id) {
        //查询是否存在
        TMetadataDetailRecord tMetadataDetailRecord = detailDao.findById(id);
        if (tMetadataDetailRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), false);
        }
        //判断，xxx情况不允许删除

        //删除
        List<BigDecimal> ids = new ArrayList<>();
        ids.add(id);
        detailDao.deleteById(ids);
        return new ResultVo<>(0, true);

    }

    /**
     * 元数据条目详情信息列表查询
     *
     * @param detailQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    @Override
    public ResultVo<PageVo<List<DetailListVo>>> list(DetailQueryVo detailQueryVo, String userId, Integer page, Integer size) {
        List<SortField<?>> sortList = new ArrayList<>();
        //添加排序字段
        sortList.add(T_METADATA_DETAIL.INDEX.asc());
        System.out.println(dictService.getValueByMappingId(301));
        //添加条件字段
        List<Condition> conditions = innerAddListCondition(detailQueryVo);
        //只能查看自己创建的数据
        /*if(!StringUtils.isEmpty(userId)){
            conditions.add(T_METADATA_DETAIL.CREATE_USER.eq(userId));
        }*/
        //查询赋值返回
        PageVo<TMetadataDetailRecord> query = detailDao.fetchByPage(conditions, new OffsetPagingVo(page, size), sortList);
        List<TMetadataDetailRecord> tMetadataDetailRecords;
        tMetadataDetailRecords = query.getPageData();
        List<DetailListVo> list = new ArrayList<>();
        for (TMetadataDetailRecord tMetadataDetailRecord : tMetadataDetailRecords
                ) {
            DetailListVo detailListVo = (DetailListVo) VoReTraversalUtil.traversalTwo(tMetadataDetailRecord, DetailListVo.class);
            //查询创建者名字
            String name = usersDao.getNameByUserId(tMetadataDetailRecord.getCreateUser());
            detailListVo.setCreateUserName(name);
            list.add(detailListVo);
        }
        PageVo<DetailListVo> result = new PageVo<>();
        result.setPageData(list);
        result.setTotalCount(query.getTotalCount());
        return new ResultVo(0, result);
    }

    /**
     * 为list添加条件字段的方法
     *
     * @param detailQueryVo
     * @return
     */
    private List<Condition> innerAddListCondition(DetailQueryVo detailQueryVo) {
        List<Condition> conditions = new ArrayList<>();
        //TODO 添加条件字段
        BigDecimal metadataItemId = detailQueryVo.getMetadataItemId();
        if (metadataItemId != null) {
            conditions.add(T_METADATA_DETAIL.METADATA_ITEM_ID.eq(metadataItemId));
        }
        return conditions;
    }

    /**
     * 元数据条目详情信息详情查询
     *
     * @param id
     * @return
     */
    @Override
    public ResultVo<DetailDetailVo> detailById(BigDecimal id) {
        TMetadataDetailRecord tMetadataDetailRecord = detailDao.findById(id);
        if (tMetadataDetailRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), null);
        }
        DetailDetailVo detailDetailVo = (DetailDetailVo) VoReTraversalUtil.traversalTwo(tMetadataDetailRecord, DetailDetailVo.class);
        //查询创建者名字
        String name = usersDao.getNameByUserId(tMetadataDetailRecord.getCreateUser());
        detailDetailVo.setCreateUserName(name);
        return new ResultVo<>(0, detailDetailVo);
    }

    /**
     * 下载元数据模板
     *
     * @param type
     * @return
     */

    private ResultVo<Object> genTemplate(Integer type, String filePath) {
        if (StringUtils.isEmpty(type)) {
            return new ResultVo<>(ErrorCode.ParamError.getErrorCode());
        }
        try {
            //csv
            String fileName;
            String charset = "utf-8";
            List<DetailPassVo> detailPassVos = new ArrayList<>();
            if (type == 0) {
                detailPassVos.add(new DetailPassVo());
                new CsvUtils().writeObjects2Csv(filePath, detailPassVos, charset);

            } else if (type == 1) {
                ExcelUtils.getInstance().exportObjects2Excel(detailPassVos, DetailPassVo.class, true, null, true, filePath);
            }
        } catch (Exception e) {
            return new ResultVo<>(ErrorCode.UnknownError.getErrorCode(), "fail");
        }
        return new ResultVo<>(0, "success");
    }

    /**
     * @param type
     * @return
     */
    @Override
    public ResultVo<MetaTemplateVo> downloadTemplate(Integer type) {
        if (StringUtils.isEmpty(type)) {
            return new ResultVo<>(ErrorCode.ParamError.getErrorCode());
        }
        try {
            //csv
            ResultVo<MetaTemplateVo> resultVo = new ResultVo<>();
            MetaTemplateVo metaTemplateVo = new MetaTemplateVo();
            String fileName;
            List<DetailPassVo> detailPassVos = new ArrayList<>();
            //csv


            if (type == 0) {
                fileName = "template.csv";
                metaTemplateVo.setFileType("csv");
            }
            //excel
            else if (type == 1) {
                fileName = "template.xlsx";
                metaTemplateVo.setFileType("excel");

            } else {
                return new ResultVo<>(ErrorCode.FileTypeIllegal.getErrorCode());
            }
//            String filePath = new ClassPathResource(FILEPATH + fileName).getFile().getPath();

            String filePath = FILEPATH + fileName;
            genTemplate(type, filePath);
            byte[] data = fileService.read(filePath);
            metaTemplateVo.setData(data);
            metaTemplateVo.setName(fileName);
            resultVo.setErrorCode(0);
            resultVo.setData(metaTemplateVo);
            return resultVo;
        } catch (Exception e) {
            return new ResultVo<>(ErrorCode.UnknownError.getErrorCode());
        }
    }

    /**
     * 导出数据结构
     *
     * @param metadataItemId
     * @param fileType
     * @return
     */
    @Override
    public ResultVo<MetaTemplateVo> exportDataStructure(BigDecimal metadataItemId, Integer fileType) {
        //判断filepath是否存在，不存在创建
        File directory =new File(FILEPATH);
        //如果文件夹不存在则创建
        if  (!directory .exists()  && !directory .isDirectory()) {
            directory .mkdir();
        }

        List<SortField<?>> sortList = new ArrayList<>();

        //添加排序字段
        sortList.add(T_METADATA_DETAIL.UPDATE_TIME.desc());
        //添加条件字段
        List<Condition> conditions = new ArrayList<>();
        conditions.add(T_METADATA_DETAIL.METADATA_ITEM_ID.eq(metadataItemId));

        try {
            //查询赋值返回
            PageVo<TMetadataDetailRecord> query = detailDao.fetchByPage(conditions, new OffsetPagingVo(1, 1000), sortList);
            List<TMetadataDetailRecord> tMetadataDetailRecords;
            tMetadataDetailRecords = query.getPageData();
            List<DetailPassVo> detailPassVos = new ArrayList<>();
            for (TMetadataDetailRecord tMetadataDetailRecord : tMetadataDetailRecords
                    ) {
                DetailPassVo detailPassVo = new DetailPassVo();
                detailPassVo.setIndex(tMetadataDetailRecord.getIndex().toString());
                detailPassVo.setColName(tMetadataDetailRecord.getColName());
                detailPassVo.setColDisplayName(tMetadataDetailRecord.getColDisplayname());
                Integer colTypeKey = tMetadataDetailRecord.getColType();
                String colType = dictService.getValueByMappingId(colTypeKey);
                detailPassVo.setColType(colType);
                detailPassVo.setColComment(tMetadataDetailRecord.getColComment());
                detailPassVos.add(detailPassVo);
            }

            ResultVo<MetaTemplateVo> resultVo = new ResultVo<>();
            MetaTemplateVo metaTemplateVo = new MetaTemplateVo();
            //csv
//            String path = this.getClass().getResource("/").getPath() + "../resources/files/";
            String fileName;
            String filePath;
            String filePathName;
            if (fileType == 0) {
                fileName = "dataStructure.csv";
                filePathName="dataStructure_"+idGeneratorService.id()+".csv";
                filePath = FILEPATH + filePathName;
                //验证文件不存在则创建
                checkFile(filePath);
                String charset = "utf-8";
                new CsvUtils().writeObjects2Csv(filePath, detailPassVos, charset);

            }
            //excell
            else if (fileType == 1) {
                fileName = "dataStructure.xlsx";
                filePathName="dataStructure_"+idGeneratorService.id()+".xlsx";
                filePath = FILEPATH + filePathName;
                //验证文件不存在则创建
                checkFile(filePath);
                ExcelUtils.getInstance().exportObjects2Excel(detailPassVos, DetailPassVo.class, true, null, true, filePath);
            } else {
                return new ResultVo<>(ErrorCode.ParamError.getErrorCode());
            }
            byte[] data = fileService.read(filePath);
            metaTemplateVo.setData(data);
            metaTemplateVo.setName(fileName);
            resultVo.setErrorCode(0);
            resultVo.setData(metaTemplateVo);
            //删除临时文件
            deleteFile(filePath);
            return resultVo;
        } catch (Exception e) {
            return new ResultVo<>(ErrorCode.UnknownError.getErrorCode());
        }
    }

    /**
     * 验证文件路径文件是否存在，不存在则创建
     * @param filePath
     */
    private static void checkFile(String filePath){
        File file =new File(filePath);
        if(!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 验删除指定路径的文件
     * @param filePath
     */
    private static void deleteFile(String filePath){
        File file =new File(filePath);
        if(file.exists()) {
            try {
                file.delete();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        File directory =new File("C:\\demo\\tempFile");
        //如果文件夹不存在则创建
        if  (!directory .exists()  && !directory .isDirectory()) {
            directory .mkdir();
        }
//        File file =new File("C:\\demo\\tempFile\\dataStructure.xlsx");
//        if(!file.exists()) {
//            try {
//                file.createNewFile();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
        checkFile("C:\\demo\\tempFile\\dataStructure.xlsx");
        deleteFile("C:\\demo\\tempFile\\dataStructure.xlsx");
//        file.delete();
    }
}
