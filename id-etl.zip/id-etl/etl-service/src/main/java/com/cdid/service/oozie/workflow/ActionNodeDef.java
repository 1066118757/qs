/**
 * Copyright 2017 Institute of Computing Technology, Chinese Academy of Sciences.
 * Licensed under the terms of the Apache 2.0 license.
 * Please see LICENSE file in the project root for terms
 */
package com.cdid.service.oozie.workflow;

import com.cdid.service.oozie.graph.OozieProgramNode;
import com.cdid.service.oozie.vo.ProgramVO;
import org.dom4j.Element;

/**
 * Node definition for action node of oozie
 */
public abstract class ActionNodeDef extends NodeDef {
	/**
	 * the widget id this node respected to
	 */
	protected String nodeId;

	protected OozieProgramNode program;

	public ActionNodeDef(OozieProgramNode program, String nodeId) {
		super(nodeId);
		this.nodeId = nodeId;
		this.program = program;
	}

	/**
	 * This function will be called somewhere when generate oozie workflow. <br/>
	 * It append current Oozie Action workflow configuration to the workflow xml tree.
	 */
	@Override
	public void append2XML(Element root) {
		Element action = root.addElement("action");

		action.addAttribute("name", getName());

		generateActionXML(action);

		Element ok = action.addElement("ok");
		Element error = action.addElement("error");

		NodeDef toNode = outNodes.iterator().next();

		//when success, the next runnable action is configured by toNode
		ok.addAttribute("to", toNode.getName());
		error.addAttribute("to", "fail");
	}

	public abstract void generateActionXML(Element action) ;

	protected void generateElement(Element root, String tag, String content) {
		if(content == null) content = "";
		Element ele = root.addElement(tag);
		ele.addText(content);
	}

	protected void createProperty(Element root, String name, String value) {
		Element property = root.addElement("property");
		generateElement(property, "name", name);
		generateElement(property, "value", value);
	}


	public OozieProgramNode getProgram() {
		return program;
	}

	public void setProgram(OozieProgramNode program) {
		this.program = program;
	}
}
