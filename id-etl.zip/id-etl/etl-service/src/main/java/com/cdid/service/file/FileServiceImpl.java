package com.cdid.service.file;


import com.cdid.api.common.IDGeneratorService;
import com.cdid.api.file.FileService;
import com.cdid.api.file.vo.FileParseRespVo;
import com.cdid.api.file.vo.FileUploadRespVo;
import com.cdid.api.file.vo.FileVo;
import com.cdid.api.metadata.detail.vo.DetailPassVo;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.file.FileDao;
import com.cdid.jooq.tables.records.TFileRecord;
import com.cdid.service.oozie.util.HDFSIO;
import com.cdid.utils.CsvUtils;
import com.cdid.utils.excel.ExcelUtils;
import com.cdid.utils.hdfs.HdfsFileSystem;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.*;
import java.math.BigDecimal;
import java.net.URI;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * @Author Froid_Li
 * @Email 269504518@qq.com
 * @Date 2017/11/28  15:43
 */
@Service
public class FileServiceImpl implements FileService {
    @Autowired
    IDGeneratorService<Long> idGeneratorService;
    @Autowired
    FileDao fileDao;
    private static Logger logger = LoggerFactory.getLogger(FileServiceImpl.class);

    @Value("${web.filePath}")
    private String FILEPATH;
    @Value("${hdfs.ip}")
    private String IP;
    @Value("${hdfs.port}")
    private String PORT;
    @Value("${hdfs.filePath}")
    private String HDFSPATH;

    /**
     * @param fileVoList
     * @return
     */
    @Override
    public ResultVo<List<FileParseRespVo>> parseFile(List<FileVo> fileVoList) {
        List<TFileRecord> recordList = new ArrayList<>();
        List<FileParseRespVo> respVoList = new ArrayList<>();
        try {
            synchronized (this) {
                for (FileVo fileVo : fileVoList) {
                    byte[] data = fileVo.getData();
                    if (data == null || data.length == 0) {
                        continue;
                    }

                    String fileType = FilenameUtils.getExtension(fileVo.getName());
                    String filePath;
                    List<DetailPassVo> voList;
                    List<DetailPassVo> resVoList;
                    ResultVo<List<DetailPassVo>> res;
                    if (fileType.equals("csv")) {
                        filePath = "" + fileVo.getName();
                        save(filePath, data);
                        voList = new CsvUtils().readCsv2Objects(filePath, ',', DetailPassVo.class, new DetailPassVo().csvMap());
                        res = transform(voList);
                        resVoList = res.getData();
                    } else if (fileType.equals("xlsx")) {
                        filePath = "" + fileVo.getName();
                        save(filePath, data);
                        voList = ExcelUtils.getInstance().readExcel2Objects(filePath, DetailPassVo.class);
                        res = transform(voList);
                        resVoList = res.getData();
                    } else {
                        return new ResultVo<>(ErrorCode.FileTypeIllegal.getErrorCode());
                    }


                    TFileRecord fileRecord = new TFileRecord();
                    BigDecimal fileId = BigDecimal.valueOf(idGeneratorService.id());
                    fileRecord.setId(fileId);
                    fileRecord.setCreateTime(new Timestamp(System.currentTimeMillis()));
                    fileRecord.setCreateUser("1");
                    fileRecord.setFileType(fileType);
                    fileRecord.setName(fileVo.getName());
                    fileRecord.setPath(filePath);
                    fileRecord.setSize(fileVo.getSize());
                    recordList.add(fileRecord);
                    FileParseRespVo respVo = new FileParseRespVo();
                    respVo.setFileId(fileId);

                    respVo.setVoList(resVoList);
                    respVoList.add(respVo);

                    if (!recordList.isEmpty()) {
                        fileDao.insert(recordList);
                    }
                }
            }
            return new ResultVo<>(0, respVoList);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return new ResultVo<>(ErrorCode.UnknownError.getErrorCode(), null, e.getMessage());
        }

    }


    /**
     * @param fileId
     * @return
     * @throws Exception
     */
    @Override
    public ResultVo<String> deleteFile(BigDecimal fileId) throws Exception {
        ResultVo<String> resultVo = new ResultVo<>();
        TFileRecord tFileRecord = fileDao.findById(fileId);
        if (tFileRecord == null) {
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            throw new Exception();
        } else {
            String hdfsPath = tFileRecord.getPath();
            Configuration conf = new Configuration();
            conf.set("fs.defaultFS", "hdfs://" + IP + ":" + PORT);
            HdfsFileSystem.deleteFile(conf, constructHDFSURI(hdfsPath));
            fileDao.delete(tFileRecord);
        }
        resultVo.setMsg("success");
        return resultVo;
    }

    /**
     * @param fileVoList
     * @return
     */
    @Override
    public ResultVo<List<FileUploadRespVo>> saveFile(List<FileVo> fileVoList) throws Exception {
        List<TFileRecord> recordList = new ArrayList<>();
        List<FileUploadRespVo> respVoList = new ArrayList<>();
        for (FileVo fileVo : fileVoList) {
            if (fileVo.getData() == null || fileVo.getData().length == 0) {
                continue;
            }
            byte[] data = fileVo.getData();
            String fileName = fileVo.getName();
//              TODO: 2017/12/12 HDFS存储
//            String randomName = RandomStringUtils.randomAlphanumeric(12) + fileName;
            //文件上传时的文件名需要支持常见的特殊字符
            String randomName = RandomStringUtils.randomAlphanumeric(12);
            String filePath=HDFSPATH + randomName;
            String hdfsPath = "hdfs://" + IP + ":" + PORT + filePath;
            Configuration conf = new Configuration();
            conf.set("fs.defaultFS", "hdfs://" + IP + ":" + PORT);
            HdfsFileSystem.createFile(conf, data, hdfsPath);
            String fileType = FilenameUtils.getExtension(fileName);
            TFileRecord fileRecord = new TFileRecord();
            BigDecimal fileId = fileVo.getFileId();
            if(fileId == null){
                fileId=BigDecimal.valueOf(idGeneratorService.id());
            }
            fileRecord.setId(fileId);
            fileRecord.setCreateTime(new Timestamp(System.currentTimeMillis()));
            fileRecord.setCreateUser(fileVo.getCreateUser());
            fileRecord.setFileType(fileType);
            fileRecord.setName(fileVo.getName());
            fileRecord.setPath(filePath);
            fileRecord.setSize(fileVo.getSize());
            recordList.add(fileRecord);
            FileUploadRespVo respVo = new FileUploadRespVo();
            respVo.setFileId(fileId);
            respVo.setFilePath(filePath);
            respVo.setFileType(fileType);
            respVo.setName(fileName);
            respVoList.add(respVo);
        }
        if (!recordList.isEmpty()) {
            fileDao.insert(recordList);
        }
        return new ResultVo<>(0, respVoList);
    }


    /**
     * @param fileId
     * @return
     * @throws Exception
     */
    @Override
    public ResultVo<FileVo> getFile(BigDecimal fileId) throws Exception {
        TFileRecord fileRecord = fileDao.findById(fileId);
        if (fileRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
        }
        String filePath = fileRecord.getPath();
        if (StringUtils.isEmpty(filePath)) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
        }

        Configuration conf = new Configuration();
        conf.set("fs.defaultFS", "hdfs://" + IP + ":" + PORT);
        byte[] bytes = HdfsFileSystem.downloadFileToByte(constructHDFSURI(filePath), conf);

        FileVo fileVo = new FileVo();
        fileVo.setData(bytes);
        fileVo.setFileId(fileId);
        fileVo.setName(fileRecord.getName());
        fileVo.setSize(fileRecord.getSize());
        fileVo.setCreateTime(fileRecord.getCreateTime());
        return new ResultVo<>(0, fileVo);
    }

    @Override
    public void writeHdfsFileToOutputStream(String hdfsPath, OutputStream os) throws Exception {
        HDFSIO.writeToOutputStream(hdfsPath,os);
    }

    private String constructHDFSURI(String path){
        return "hdfs://"+IP+":"+PORT+path;
    }

    /**
     * @param filePath
     * @param data
     */
    private void save(String filePath, byte[] data) {
        try {
            File file = new File(filePath);
            FileOutputStream fos = new FileOutputStream(file);
            if (!file.exists()) {
                file.createNewFile();
            }
            fos.write(data);
            fos.flush();
            fos.close();
            logger.info("fileSave Done");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @param filePath
     * @return
     * @throws IOException
     */
    @Override
    public byte[] read(String filePath) throws IOException {
        File file = new File(filePath);
        if (!file.exists()) {
            throw new FileNotFoundException(filePath);
        }
        FileChannel channel = null;
        FileInputStream fis = new FileInputStream(file);
        try {

            channel = fis.getChannel();
            ByteBuffer byteBuffer = ByteBuffer.allocate((int) channel.size());
            while ((channel.read(byteBuffer)) > 0) ;
            return byteBuffer.array();
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            try {
                channel.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                fis.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * @param voList
     * @return
     */
    private ResultVo<List<DetailPassVo>> transform(List<DetailPassVo> voList) throws Exception {
        List<DetailPassVo> res = new ArrayList<>();
        ResultVo<List<DetailPassVo>> resultVo = new ResultVo<>();
        for (DetailPassVo detailPassVo : voList) {
            String colType = detailPassVo.getColType();
            String newColType = "";
            if (colType.startsWith("字段")) {
                continue;
            } else if (colType.equals("数值")) {
                newColType = "302";
            } else if (colType.equals("文本")) {
                newColType = "301";
            } else {
                throw new Exception("数据类型不合法");
            }
            detailPassVo.setColType(newColType);
            res.add(detailPassVo);
            resultVo.setData(res);
            resultVo.setErrorCode(0);
        }
        return resultVo;
    }

    @Override
    public String uploadToHDFS(String localFilePath) throws IOException {
        String path= HDFSPATH + UUID.randomUUID().toString()+"."+FilenameUtils.getExtension(localFilePath);
        String hdfsPath = "hdfs://" + IP + ":" + PORT +path;
        Configuration conf = new Configuration();
        conf.set("fs.defaultFS", "hdfs://" + IP + ":" + PORT);
        HdfsFileSystem.uploadFile(conf, localFilePath, hdfsPath);
        return path;
    }

    @Override
    public void uploadToHDFS(String localFilePath,String hdfsPath) throws IOException {
        String uri = "hdfs://" + IP + ":" + PORT + hdfsPath;
        Configuration conf = new Configuration();
        conf.set("fs.defaultFS", "hdfs://" + IP + ":" + PORT);
        HdfsFileSystem.uploadFile(conf, localFilePath, uri);
    }

    @Override
    public boolean deleteFromHDFS(String hdfsPath){
        Configuration conf = new Configuration();
        conf.set("fs.defaultFS", "hdfs://" + IP + ":" + PORT);
        try {
            HdfsFileSystem.deleteFile(conf,hdfsPath);
            return true;
        } catch (Exception e) {
            logger.error(e.getMessage(),e);
            return false;
        }
    }

}
