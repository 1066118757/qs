package com.cdid.service.oozie;

import com.cdid.api.common.IDGeneratorService;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.metadata.item.ItemDao;
import com.cdid.dao.oozie.*;
import com.cdid.dao.storagedata.StorageDataManageDao;
import com.cdid.dao.user.UsersDao;
import com.cdid.jooq.tables.*;
import com.cdid.jooq.tables.records.*;
import com.cdid.service.oozie.vo.OozieShareVO;
import com.cdid.service.oozie.vo.ShareListVO;
import com.cdid.service.oozie.vo.TreeObjectVO;
import com.cdid.utils.StringUtil;
import com.google.common.collect.Sets;
import org.jooq.Condition;
import org.jooq.SortField;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class ShareService {

    @Autowired
    IDGeneratorService<Long> idService;

    @Autowired
    ShareDao shareDao;

    @Autowired
    GroupDao groupDao;

    @Autowired
    UsersDao usersDao;

    @Autowired
    GroupUserDao groupUserDao;

    @Autowired
    OozieObjectTreeService treeService;

    @Autowired
    ProgramDao programDao;

    @Autowired
    ItemDao itemDao;

    @Autowired
    StorageDataManageDao storageDataManageDao;

    @Autowired
    OozieJobDao oozieJobDao;

    @Autowired
    TreeObjectDao treeObjectDao;

    public void share(List<OozieShareVO> shareVOList,boolean overwrite){
        List<TOozieShareRecord> shareRecordList=new ArrayList<>();
        TOozieShareRecord shareRecord;
        List<TTreeObjectRecord> treeObjectRecordList=new ArrayList<>();
        for(OozieShareVO shareVO:shareVOList){
            List<Condition> conditionList=new ArrayList<>();
            conditionList.add(TOozieShare.T_OOZIE_SHARE.SOURCE_OBJECT_ID.eq(shareVO.getSourceObjectId()));
            conditionList.add(TOozieShare.T_OOZIE_SHARE.SOURCE_OBJECT_TYPE.eq(shareVO.getSourceObjectType()));
            conditionList.add(TOozieShare.T_OOZIE_SHARE.DIST_OBJECT_TYPE.eq(shareVO.getDistObjectType()));
            if(!overwrite){
                conditionList.add(TOozieShare.T_OOZIE_SHARE.DIST_OBJECT_ID.in(shareVO.getDistObjectIdList()));
            }
            List<String> existedDistObjectList=shareDao.fetchFieldByConditions(TOozieShare.T_OOZIE_SHARE.DIST_OBJECT_ID,conditionList);
            if(overwrite){
                Set<String> needToDeleteDistObjectIdList=Sets.difference(new HashSet<>(existedDistObjectList),new HashSet<>(shareVO.getDistObjectIdList()));
                if(!needToDeleteDistObjectIdList.isEmpty()){
                    List<Condition> deleteConditionList=new ArrayList<>(conditionList);
                    deleteConditionList.add(TOozieShare.T_OOZIE_SHARE.DIST_OBJECT_ID.in(needToDeleteDistObjectIdList));
                    shareDao.deleteByConditions(deleteConditionList);
                    List<Condition> treeObjectDeleteConditionList=new ArrayList<>();
                    treeObjectDeleteConditionList.add(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID.eq(shareVO.getSourceObjectId()));
                    treeObjectDeleteConditionList.add(TTreeObject.T_TREE_OBJECT.CREATE_USER.in(needToDeleteDistObjectIdList));
                    treeObjectDeleteConditionList.add(TTreeObject.T_TREE_OBJECT.PARENT_TYPE.eq(TreeObjectVO.TreeParentType.SHARE.toString()));
                    treeObjectDao.deleteByConditions(treeObjectDeleteConditionList);
                }
            }
            shareVO.getDistObjectIdList().removeAll(existedDistObjectList);
            if(shareVO.getDistObjectIdList()!=null && !shareVO.getDistObjectIdList().isEmpty()){
                for(String distObjectId:shareVO.getDistObjectIdList()){
                    shareRecord=new TOozieShareRecord();
                    shareRecord.setId(BigDecimal.valueOf(idService.id()));
                    shareRecord.setSourceObjectId(shareVO.getSourceObjectId());
                    shareRecord.setSourceObjectType(shareVO.getSourceObjectType());
                    shareRecord.setDistObjectId(distObjectId);
                    shareRecord.setDistObjectType(shareVO.getDistObjectType());
                    shareRecord.setCreateTime(new Timestamp(System.currentTimeMillis()));
                    shareRecordList.add(shareRecord);
                }
                if(StringUtil.isNotEmpty(shareVO.getSourceObjectName())){
                    List<String> userIdList=getShareUserIdList(shareVO);
                    TreeObjectVO objectVO=new TreeObjectVO();
                    objectVO.setLeafObjectType(shareVO.getSourceObjectType());
                    if(shareVO.getSourceObjectType().equals(OozieShareVO.SourceObjectType.FILE.toString())||shareVO.getSourceObjectType().equals(OozieShareVO.SourceObjectType.TABLE.toString())){
                        objectVO.setObjectType(TreeObjectVO.TreeObjectType.DATA.toString());
                    }else{
                        objectVO.setObjectType(shareVO.getSourceObjectType());
                    }
                    objectVO.setName(shareVO.getSourceObjectName());
                    objectVO.setParentType(TreeObjectVO.TreeParentType.SHARE.toString());
                    treeObjectRecordList.addAll(treeService.constructTreeObject(userIdList,objectVO,shareVO.getSourceObjectId()));
                }
            }
        }
        if(!shareRecordList.isEmpty()){
            shareDao.insert(shareRecordList);
        }
        if(!treeObjectRecordList.isEmpty()){
            treeObjectDao.insert(treeObjectRecordList);
        }
    }

    public void cancel(BigDecimal sourceObjectId,String sourceObjectType){
        shareDao.deleteByConditions(Arrays.asList(TOozieShare.T_OOZIE_SHARE.SOURCE_OBJECT_ID.eq(sourceObjectId)));
        List<Condition> conditionList=new ArrayList<>();
        conditionList.add(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID.eq(sourceObjectId));
        conditionList.add(TTreeObject.T_TREE_OBJECT.LEAF_OBJECT_TYPE.eq(sourceObjectType));
        conditionList.add(TTreeObject.T_TREE_OBJECT.PARENT_TYPE.eq(TreeObjectVO.TreeParentType.SHARE.toString()));
        treeObjectDao.deleteByConditions(conditionList);

    }

    public void delete(OozieShareVO shareVO){
        List<Condition> conditionList=new ArrayList<>();
        conditionList.add(TOozieShare.T_OOZIE_SHARE.SOURCE_OBJECT_ID.eq(shareVO.getSourceObjectId()));
        conditionList.add(TOozieShare.T_OOZIE_SHARE.DIST_OBJECT_ID.in(shareVO.getDistObjectIdList()));
        shareDao.deleteByConditions(conditionList);
        List<String> userIdList=getShareUserIdList(shareVO);
        List<Condition> deleteConditionList=new ArrayList<>();
        deleteConditionList.add(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID.eq(shareVO.getSourceObjectId()));
        deleteConditionList.add(TTreeObject.T_TREE_OBJECT.LEAF_OBJECT_TYPE.eq(shareVO.getSourceObjectType()));
        deleteConditionList.add(TTreeObject.T_TREE_OBJECT.CREATE_USER.in(userIdList));
        deleteConditionList.add(TTreeObject.T_TREE_OBJECT.PARENT_TYPE.eq(TreeObjectVO.TreeParentType.SHARE.toString()));
        treeObjectDao.deleteByConditions(deleteConditionList);
    }

    public ResultVo<PageVo<ShareListVO>> queryShareDistByPage(int page, int size,BigDecimal sourceObjectId){
        List<Condition> conditionList=new ArrayList<>();
        if(sourceObjectId==null){
            return new ResultVo<>(ErrorCode.ParamError.getErrorCode());
        }
        conditionList.add(TOozieShare.T_OOZIE_SHARE.SOURCE_OBJECT_ID.eq(sourceObjectId));
        List<SortField<?>> sortFieldList=new ArrayList<>();
        sortFieldList.add(TOozieShare.T_OOZIE_SHARE.DIST_OBJECT_TYPE.asc());
        sortFieldList.add(TOozieShare.T_OOZIE_SHARE.CREATE_TIME.desc());
        PageVo<TOozieShareRecord>  pageVo=shareDao.fetchByPage(conditionList,new OffsetPagingVo(page,size),sortFieldList);
        List<TOozieShareRecord> recordList=pageVo.getPageData();
        Map<String,List<TOozieShareRecord>> typeSharesMap=recordList.stream().collect(Collectors.groupingBy(r -> r.getDistObjectType()));
        Map<String,String> idNameMap=new HashMap<>();
        for(Map.Entry<String,List<TOozieShareRecord>> ele:typeSharesMap.entrySet()){
            List<String> distIdList=ele.getValue().stream().map(a -> a.getDistObjectId()).collect(Collectors.toList());
            if(OozieShareVO.DistObjectType.GROUP.name().equals(ele.getKey())){
               List<GroupRecord> groupRecordList= groupDao.fetch(Group.GROUP.ID,distIdList);
               groupRecordList.forEach( a -> idNameMap.put(a.getId(),a.getName()));
            }else if(OozieShareVO.DistObjectType.USER.name().equals(ele.getKey())){
                List<UsersRecord> userList=usersDao.fetch(Users.USERS.GUID,distIdList);
                userList.forEach(u -> idNameMap.put(u.getGuid(),u.getFirstName()));
            }
        }
        List<ShareListVO> shareListVOList=new ArrayList<>();
        ShareListVO vo;
        for(TOozieShareRecord record:recordList){
            vo=new ShareListVO();
            vo.setDistObjectId(record.getDistObjectId());
            vo.setDistObjectName(idNameMap.get(record.getDistObjectId()));
            vo.setDistObjectType(record.getDistObjectType());
            vo.setShareTime(record.getCreateTime().getTime());
            shareListVOList.add(vo);
        }
        return new ResultVo<>(0,new PageVo<>(pageVo.getTotalCount(),shareListVOList));
    }

    private List<String> getShareUserIdList(OozieShareVO shareVO){
        if(shareVO.getDistObjectType().equals(OozieShareVO.DistObjectType.GROUP.toString())){
           return groupUserDao.fetchFieldByConditions(MGroupUser.M_GROUP_USER.USER_ID,Arrays.asList(MGroupUser.M_GROUP_USER.GROUP_ID.in(shareVO.getDistObjectIdList())));
        }
        return shareVO.getDistObjectIdList();
    }
}
