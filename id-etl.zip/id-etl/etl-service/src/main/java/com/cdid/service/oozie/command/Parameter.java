
package com.cdid.service.oozie.command;

import com.cdid.service.oozie.constant.ParameterDataType;
import com.cdid.utils.StringUtil;
import org.dom4j.Element;

import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.List;

public class Parameter {

    //形参名称
    private String paramName;
    //参数类型，请查看枚举类ParameterDataType
    private String dataType;
    //配置参数时label名称
    private String displayName;
    //该参数的控件类型
    private String widgetType;
    //该参数的值是否需要通过额外方式获取（如jdbc,rest 接口等）
    private Boolean needConfig;
    //获取该参数值的配置信息,其结构为json对象
    private String config;
    //实参
    private String paramValue;
    //默认值
    private String defaultValue;
    //输入输出类型,目前支持HDFSFile和HIVETable
    private String ioType;

    public Parameter() {

    }

    public String getParamName() {
        return paramName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getWidgetType() {
        return widgetType;
    }

    public void setWidgetType(String widgetType) {
        this.widgetType = widgetType;
    }

    public Boolean getNeedConfig() {
        return needConfig;
    }

    public void setNeedConfig(Boolean needConfig) {
        this.needConfig = needConfig;
    }

    public String getConfig() {
        return config;
    }

    public void setConfig(String config) {
        this.config = config;
    }

    public String getDefaultValue() {
        return defaultValue;
    }

    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }

    public String getParaName() {
        return paramName;
    }

    public void setParamName(String paraName) {
        this.paramName = paraName;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getParamValue() {
        return paramValue;
    }

    public void setParamValue(String value) {
        this.paramValue = value;
    }

    public String getIoType() {
        return ioType;
    }

    public void setIoType(String ioType) {
        this.ioType = ioType;
    }

    public String toXML() {
        StringBuilder xml = new StringBuilder();
        if (!StringUtil.isEmpty(config)) {
            String base64Config="";
            try {
                base64Config=Base64.getEncoder().encodeToString(config.getBytes("UTF-8"));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            xml.append("    <config>").append(base64Config).append("</config>\n");
        }
        append("paramName",paramName,xml);
        append("dataType",dataType,xml);
        append("ioType",ioType,xml);
        append("displayName",displayName,xml);
        append("widgetType",widgetType,xml);
        append("needConfig",needConfig.toString(),xml);
        append("paramValue",paramValue,xml);
        append("defaultValue",defaultValue,xml);
        return xml.toString();
    }

    private void append(String tagName,String value,StringBuilder xml){
        if(!StringUtil.isEmpty(value)){
            xml.append("    <").append(tagName).append(">").append(value).append("</").append(tagName).append(">\n");
        }
    }

    public static Parameter valueOf(Element xml_node) {
        List<Element> childNodes = xml_node.elements();
        Parameter parameter = new Parameter();
        for (Element child : childNodes) {
            String value = child.getText();
            String name = child.getName();
            if ("config".equals(name))
                parameter.setConfig(value);
            else if ("dataType".equals(name))
                parameter.setDataType(value);
            else if ("displayName".equals(name))
                parameter.setDisplayName(value);
            else if ("widgetType".equals(name))
                parameter.setWidgetType(value);
            else if ("needConfig".equals(name))
                parameter.setNeedConfig(Boolean.valueOf(value));
            else if ("paramValue".equals(name))
                parameter.setParamValue(value);
            else if ("paramName".equals(name)) {
                parameter.setParamName(value);
            }else if ("ioType".equals(name)) {
                parameter.setIoType(value);
            } else {
                parameter.setDefaultValue(value);
            }
        }
        return parameter;
    }
}
