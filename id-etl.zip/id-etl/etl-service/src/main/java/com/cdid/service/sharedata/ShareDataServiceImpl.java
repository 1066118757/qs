package com.cdid.service.sharedata;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cdid.api.common.RedisService;
import com.cdid.api.metadata.item.ItemService;
import com.cdid.api.sharedata.ShareDataService;
import com.cdid.common.constant.RedisKey;
import com.cdid.common.vo.ResponseVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.metadata.item.ItemDao;
import com.cdid.dao.user.UsersDao;
import com.cdid.jooq.tables.records.UsersRecord;
import com.cdid.utils.HttpClientUtil;
import com.cdid.utils.RSACoder;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.net.util.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.*;
import java.security.Key;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2018/1/11 13:46  
 */
@Service
public class ShareDataServiceImpl implements ShareDataService {

    private static Logger logger = LoggerFactory.getLogger(ShareDataServiceImpl.class);

//    idmanager-server:
//    baseUrl: http://192.168.55.10:9000

    @Value("${idmanager-server.baseUrl}")
    private String baseUrl;
    @Value("${idmanager-admin.account}")
    private String account;
    @Value("${idmanager-admin.password}")
    private String password;

    private static final String DATA_API = "/rest/hbase/sparksql/query";

    private static final String Login_API = "/rest/oauth2/access_token";

    @Autowired
    private ItemDao itemDao;
    @Autowired
    private RedisService redisService;
    @Autowired
    private UsersDao usersDao;

    @Override
    public String getCsvDataByTableName(String tableName, Integer limit,String authorization) {

        String dataJson = getData(tableName,authorization);
        JSONObject dataJsonObj = JSONObject.parseObject(dataJson);
        JSONArray columnInfos = dataJsonObj.getJSONArray("columnInfos");
        JSONArray rowDataSet = dataJsonObj.getJSONArray("RowDataSet");
        int colimnSize = columnInfos.size();
        int rowDataSize = rowDataSet.size();
        StringBuffer buffer = new StringBuffer();
        if(colimnSize > 0 && rowDataSize > 0){
            for(int i = 0 ; i < colimnSize ; i++){
                JSONObject jsonObject = columnInfos.getJSONObject(i);
                String columnName = jsonObject.getString("columnName");
                buffer.append(columnName);
                buffer.append(",");
            }

            buffer.deleteCharAt(buffer.lastIndexOf(","));
            buffer.append("\r\n");

            for(int i = 0 ; i < rowDataSize ; i++){
                JSONArray jsonArray = rowDataSet.getJSONArray(i);
                int size = jsonArray.size();
                for(int j = 0 ; j < size ; j++){
                    String data = jsonArray.getString(j);
                    buffer.append(data);
                    buffer.append(",");
                }
                buffer.deleteCharAt(buffer.lastIndexOf(","));
                buffer.append("\r\n");
            }
        }
        return buffer.toString();
    }

    private String getData(String tableName,String authorization){
        String url = baseUrl + DATA_API;
        JSONObject body = new JSONObject();
        body.put("tableName",tableName);

        Map<String,String> header = new HashMap<>();
        header.put("Content-Type","application/json");
//        header.put("Authorization","Bearer MjhmZjFhMmQtNWQwYy00MGFiLWIwMzEtZWM1YzVlNWVjMWEw");
        header.put("Authorization",authorization);

        ResultVo<ResponseVo> responseVoResultVo = HttpClientUtil.doPostByJson(url, body.toJSONString(), header);
        String dataJson = responseVoResultVo.getData().getData();
        return dataJson;
    }



    @Override
    public String getDataByTableName(String tableName) {

        //调用登录接口获取tonken
//        baseUrl + Login_API

        String token = getToken();
        String data = getData(tableName, token);
        return data;

    }

    @Override
    public String getToken() {

        String admintoken = redisService.get(RedisKey.ADMIN_TOKEN);
        if(!StringUtils.isEmpty(admintoken)){
            return admintoken;
        }

        Map<String,String> param = new HashMap<>();
        param.put("grant_type","password");
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("username",account);
        jsonObject.put("password", Base64.encodeBase64String(password.getBytes()).replaceAll("\r\n",""));
        param.put("jwt",Base64.encodeBase64String(jsonObject.toJSONString().getBytes()).replaceAll("\r\n",""));

        String loginResult = HttpClientUtil.doGet(baseUrl + Login_API, param);
        JSONObject loginJsonObj = JSONObject.parseObject(loginResult);
        String access_token = loginJsonObj.getString("access_token");
        String token_type = loginJsonObj.getString("token_type");
        Long expires_in = loginJsonObj.getLong("expires_in");
        String token = token_type + " " +access_token;
        redisService.put(RedisKey.ADMIN_TOKEN,token,expires_in - 10);
        return token;
    }

    @Override
    public String getResultData(String tableName, String priKey){

        String userId = itemDao.fetchCreateUserByName(tableName.substring(tableName.indexOf(".")+1));
        UsersRecord usersRecord = usersDao.findByGuId(userId);
        String publicKey = usersRecord.getPublicKey();
        String privateKey = usersRecord.getPrivateKey();

        String data = getDataByTableName(tableName);
        String content = "";
        byte[] encryptByPublicKey = null;
        byte[] decryptByPrivateKey = null;
        //加密
        try {
            logger.info("publicKey   "+publicKey);
            logger.info("privateKey   "+privateKey);
            encryptByPublicKey = RSACoder.encryptByPublicKey(data,publicKey);
            //通过prikey解密
            decryptByPrivateKey = RSACoder.decryptByPrivateKey(encryptByPublicKey,priKey);
            return new String(decryptByPrivateKey);
        }catch (Exception e){
            e.printStackTrace();
            content = new String(encryptByPublicKey);
        }
        return content;
    }

    @Override
    public String getPrivateKey(String userId) {
        UsersRecord usersRecord = usersDao.findByGuId(userId);
        String privateKey = usersRecord.getPrivateKey();
        try {
            if(StringUtils.isEmpty(privateKey)){
                Map<String, Key> keyMap = RSACoder.initKey();
                String publicKey = RSACoder.getPublicKey(keyMap);
                privateKey = RSACoder.getPrivateKey(keyMap);
                usersDao.updatePriKeyAndPubKey(userId,publicKey,privateKey);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return privateKey;
    }
}
