package com.cdid.service.common;


import com.cdid.api.common.RedisService;
import com.cdid.api.common.SmsService;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.constant.SmsConfig;
import com.cdid.common.vo.ResultVo;
import com.qcloud.sms.SmsSingleSender;
import com.qcloud.sms.SmsSingleSenderResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Random;

/**
 * Froid_Li
 * 2017/12/27  21:00
 */
@Service
public class SmsServiceImpl implements SmsService {

    @Autowired
    RedisService redisService;

    /**
     * 短信验证通知
     *
     * @param phoneNumber
     * @return
     */
    @Override
    public ResultVo<String> sendVerifyCode(String phoneNumber) {
        ResultVo<String> verifyResult = new ResultVo();
        SmsSingleSenderResult result;
        try {
            Integer appid = SmsConfig.APPID;
            String appKey = SmsConfig.APPKEY;
            int tmplId = SmsConfig.VERIFYTMPLID;

            SmsSingleSender singleSender = new SmsSingleSender(appid, appKey);

            String verifyNum = getRandomNumber();

            ArrayList<String> params = new ArrayList<String>();
            params.add(verifyNum);
            result = singleSender.sendWithParam("86", phoneNumber, tmplId, params, "金控征信大数据平台", "", "");
            if (result.errMsg.equals("OK")) {
                String key = "phone:" + phoneNumber;
                redisService.put(key, verifyNum, SmsConfig.CACHEEXPIRETIME);
            }

            verifyResult.setData(verifyNum);
            verifyResult.setMsg(result.errMsg);

        } catch (Exception e) {
            verifyResult.setErrorCode(ErrorCode.UnknownError.getErrorCode());
        }
        return verifyResult;
    }


    /**
     * 数据引接任务通知
     *
     * @param phoneNumber
     * @param endTime
     * @param jobResult
     * @param count
     * @return
     */
    @Override
    public ResultVo<String> sendETLJobNotice(String phoneNumber, String jobName, String endTime, String jobResult, String count) {
        ResultVo<String> result = new ResultVo<>();
        SmsSingleSenderResult senderResult;
        try {
            Integer appid = SmsConfig.APPID;
            String appKey = SmsConfig.APPKEY;
            int tmplId = SmsConfig.jOBTMPID;
            SmsSingleSender singleSender = new SmsSingleSender(appid, appKey);
            ArrayList<String> params = new ArrayList<>();
            params.add(jobName);
            params.add(endTime);
            params.add(jobResult);
            params.add(count);
            senderResult = singleSender.sendWithParam("86", phoneNumber, tmplId, params, "", "", "");
            if (senderResult.errMsg.equals("OK")) {
                result.setData("success");
            }
        } catch (Exception e) {
            result.setErrorCode(ErrorCode.UnknownError.getErrorCode());
        }
        return result;
    }

    /** 数据整合任务通知
     * @param phoneNumber
     * @param endTime
     * @param jobResult
     * @return
     */
    @Override
    public ResultVo<String> sendClearJobNotice(String phoneNumber, String jobName, String endTime, String jobResult) {
        ResultVo<String> result = new ResultVo<>();
        SmsSingleSenderResult senderResult;
        try {
            Integer appid = SmsConfig.APPID;
            String appKey = SmsConfig.APPKEY;
            int tmplId = SmsConfig.ETLJOBTMPID;
            SmsSingleSender singleSender = new SmsSingleSender(appid, appKey);
            ArrayList<String> params = new ArrayList<>();
            params.add(jobName);
            params.add(endTime);
            params.add(jobResult);
            senderResult = singleSender.sendWithParam("86", phoneNumber, tmplId, params, "", "", "");
            if (senderResult.errMsg.equals("OK")) {
                result.setData("success");
            }
        } catch (Exception e) {
            result.setErrorCode(ErrorCode.UnknownError.getErrorCode());
        }
        return result;
    }


    /**
     * @return
     */
    private String getRandomNumber() {
        Random rad = new Random();
        String result = rad.nextInt(1000000) + "";

        if (result.length() != 6) {
            return getRandomNumber();
        }
        return result;
    }

}
