package com.cdid.service.common;


import com.cdid.api.common.RedisService;
import com.lambdaworks.redis.RedisClient;
import com.lambdaworks.redis.RedisURI;
import com.lambdaworks.redis.api.StatefulRedisConnection;
import com.lambdaworks.redis.resource.DefaultClientResources;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.Map;

@Service
public class RedisServiceImpl implements RedisService {


    @Value("${redis.host}")
    private String redisHost;
    @Value("${redis.port}")
    private String port;
    @Value("${redis.index}")
    private String index;

    private static StatefulRedisConnection<String, String> connection = null;


    @PostConstruct
    public void init() {
        RedisURI redisUri = RedisURI.Builder.redis(redisHost).withPort(Integer.valueOf(port)).withDatabase(Integer.valueOf(index))
                .build();
        RedisClient client = RedisClient.create(DefaultClientResources.create(), redisUri);
        connection = client.connect();
    }

    @Override
    public boolean delete(String redisKey) {
        return connection.sync().del(redisKey) != 0;
    }

    @Override
    public boolean hdel(String redisKey) {
        return connection.sync().hdel(redisKey) != 0;
    }

    @Override
    public String get(String redisKey) {
        return connection.sync().get(redisKey);
    }

    @Override
    public boolean exists(String redisKey) {
        return connection.sync().exists(new String[]{redisKey}) != 0;
    }

    @Override
    public boolean put(String redisKey, String value) {
        connection.sync().set(redisKey, value);
        return true;
    }

    @Override
    public boolean hmput(String redisKey, Map<String, String> value) {
        connection.sync().hmset(redisKey, value);
        return true;
    }

    @Override
    public boolean mPut(String redisKey, String mapKey, String value) {
        return connection.sync().hset(redisKey, mapKey, value);
    }

    @Override
    public String mGet(String redisKey, String mapKey) {
        return connection.sync().hget(redisKey, mapKey);
    }

    @Override
    public List<String> hmGet(String redisKey, String... mapKey) {
        return connection.sync().hmget(redisKey, mapKey);
    }

    @Override
    public Map<String, String> hmGetAll(String redisKey) {
        return connection.sync().hgetall(redisKey);
    }

    @Override
    public boolean put(String redisKey, String value, long expireSeconds) {
        connection.sync().set(redisKey, value);
        connection.sync().expire(redisKey, expireSeconds);
        return true;
    }

    @Override
    public List<String> keys(String pattern) {
        return connection.sync().keys(pattern);
    }

    @Override
    public Long getExpireTime(String key) {
        return connection.sync().ttl(key);
    }

    @Override
    public void batchDelete(String... keys) {
        connection.sync().del(keys);
    }

    @Override
    public void incr(String key) {
        connection.sync().incr(key);
    }

    @Override
    public void decr(String key) {
        connection.sync().decr(key);
    }

    @Override
    public void batchDelete(int dbIndex,String... keys){
        connection.sync().select(dbIndex);
        connection.sync().del(keys);
        connection.sync().select(Integer.valueOf(index));
    }
}
