package com.cdid.service.oozie.vo;

import java.math.BigDecimal;

public class OozieJobLogVO {

    private String oozieJobId;

    private Long startTime;

    private Long endTime;

    private String status;

    public Long getEndTime() {
        return endTime;
    }

    public void setEndTime(Long endTime) {
        this.endTime = endTime;
    }

    public String getOozieJobId() {
        return oozieJobId;
    }

    public void setOozieJobId(String oozieJobId) {
        this.oozieJobId = oozieJobId;
    }

    public Long getStartTime() {
        return startTime;
    }

    public void setStartTime(Long startTime) {
        this.startTime = startTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
