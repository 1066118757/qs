package com.cdid.service.dataclear;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cdid.api.asynctask.vo.AsyncTaskConfigVo;
import com.cdid.api.dataclear.cleartask.ClearTaskService;
import com.cdid.api.dataclear.cleartask.vo.ClearTaskFinishedResponseVO;
import com.cdid.api.dataclear.cleartask.vo.ClearTaskUpdateVo;
import com.cdid.api.dataclear.cleartasklog.ClearTaskLogService;
import com.cdid.api.dataclear.cleartasklog.vo.ClearTaskLogUpdateVo;
import com.cdid.common.dict.TaskResult;
import com.cdid.common.vo.ResultVo;
import com.cdid.jooq.tables.TClearTaskLog;
import com.cdid.jooq.tables.records.TClearTaskLogRecord;
import com.cdid.service.common.AbstractTaskPreProcessor;
import com.cdid.utils.jdbc.SpringUtil;
import org.apache.commons.net.util.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class ClearTaskPreProcessor extends AbstractTaskPreProcessor {

    private static final Logger logger = LoggerFactory.getLogger(ClearTaskPreProcessor.class);

    @Override
    protected void jobExecuteFailedCallBack(BigDecimal taskId, String errorMessage) {
        ClearTaskService taskService = SpringUtil.getBean(ClearTaskService.class);
        ClearTaskFinishedResponseVO responseVO=new ClearTaskFinishedResponseVO();
        responseVO.setErrorMsg(errorMessage);
        responseVO.setTaskId(String.valueOf(taskId));
        taskService.clearTaskFinished(responseVO);
    }

    @Override
    public void preProcess(AsyncTaskConfigVo configVo,boolean isHand) throws Exception {
        //获取日志以及任务服务
        ClearTaskLogService logService = SpringUtil.getBean(ClearTaskLogService.class);
        ClearTaskService taskService = SpringUtil.getBean(ClearTaskService.class);
        if(logService.taskIsRunning(configVo.getTaskId())){
            throw new Exception("Task:"+configVo.getTaskId()+" is running");
        }
        if(isHand){
            processDependence(configVo,true);
        }
        //new 出修改对象
        ClearTaskLogUpdateVo addVo = new ClearTaskLogUpdateVo();
        ClearTaskUpdateVo clearTaskUpdateVo = new ClearTaskUpdateVo();
        //设置对应值
        Timestamp startTime = new Timestamp(System.currentTimeMillis());
        BigDecimal taskId = configVo.getTaskId();
        addVo.setTaskId(taskId);
        clearTaskUpdateVo.setId(taskId);
        addVo.setStartTime(startTime);
        clearTaskUpdateVo.setNearStartTime(startTime);
        addVo.setResult(TaskResult.RUNNING.getValue());
        clearTaskUpdateVo.setNearResult(TaskResult.RUNNING.getValue());
        //执行日志以及任务表相关字段更新
        taskService.updateNearData(clearTaskUpdateVo);
        logger.info("log record:updateOrSave");
        ResultVo<BigDecimal> result = logService.updateOrSave(addVo,"0");

        JSONObject taskParams = configVo.getTaskParams();
        String config = taskParams.getString("config");
        String configJson = new String(Base64.decodeBase64(config));
        JSONObject configJSON = JSON.parseObject(configJson);
        configJSON.put("logId",result.getData());
        configJSON.put("taskId",taskId);
        taskParams.put("config",Base64.encodeBase64String(configJSON.toJSONString().getBytes()).replaceAll("\r\n",""));
        if(!isHand){
            processDependence(configVo,false);
        }
    }

    public BigDecimal submitPreProcess(BigDecimal taskId) throws Exception {
        //获取日志以及任务服务
        ClearTaskLogService logService = SpringUtil.getBean(ClearTaskLogService.class);
        ClearTaskService taskService = SpringUtil.getBean(ClearTaskService.class);
        if(logService.taskIsRunning(taskId)){
            throw new Exception("Task:"+taskId+" is running");
        }
        //new 出修改对象
        ClearTaskLogUpdateVo addVo = new ClearTaskLogUpdateVo();
        ClearTaskUpdateVo clearTaskUpdateVo = new ClearTaskUpdateVo();
        //设置对应值
        Timestamp startTime = new Timestamp(System.currentTimeMillis());
        addVo.setTaskId(taskId);
        clearTaskUpdateVo.setId(taskId);
        addVo.setStartTime(startTime);
        clearTaskUpdateVo.setNearStartTime(startTime);
        addVo.setResult(TaskResult.SUBMITING.getValue());
        clearTaskUpdateVo.setNearResult(TaskResult.SUBMITING.getValue());
        //执行日志以及任务表相关字段更新
        taskService.updateNearData(clearTaskUpdateVo);
        logger.info("log record:updateOrSave");
        ResultVo<BigDecimal> result = logService.updateOrSave(addVo,"0");
        if (result.getErrorCode()==0){
            return result.getData();
        }
        return null;
    }


}
