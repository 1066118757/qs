package com.cdid.log;

import com.cdid.api.common.TokenService;
import com.cdid.utils.jdbc.SpringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

/**
 * @author OuZhiCheng
 * @create 创建时间：2018/1/9
 */
public class GetUserIdUtil {
    private static Logger logger = LoggerFactory.getLogger(GetUserIdUtil.class);
    public static String getUserId(){
        String userId="0";
        //获取request
        RequestAttributes ra = RequestContextHolder.getRequestAttributes();
        ServletRequestAttributes sra = (ServletRequestAttributes) ra;
        if (sra!=null){
            HttpServletRequest request = sra.getRequest();
            //获取用户id
            TokenService tokenService = SpringUtil.getBean(TokenService.class);
            try{
                userId = tokenService.getUserId(request);
            }catch (Exception e){
                logger.info("获取userId异常："+e.getMessage());
            }
        }
        return userId;
    }
}
