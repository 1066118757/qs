/**
 * Copyright 2017 Institute of Computing Technology, Chinese Academy of Sciences.
 * Licensed under the terms of the Apache 2.0 license.
 * Please see LICENSE file in the project root for terms
 */
package com.cdid.service.oozie.graph;


import com.cdid.utils.StringUtil;
import org.dom4j.Element;

import java.util.List;

/**
 * Edge of a Oozie workflow graph
 */
public class OozieEdge{

	/** id of the source node */
	private String src;
	/** id of the target node */
	private String dst;

	private int srcIndex;

	private int distIndex;

	private String data;

	public OozieEdge(){}

	public void init(String src, String dst) {
		this.setSrc(src);
		this.setDst(dst);
	}

	public String getSrc() {
		return src;
	}

	public String getDst() {
		return dst;
	}

	public int getDistIndex() {
		return distIndex;
	}

	public void setDistIndex(int distIndex) {
		this.distIndex = distIndex;
	}

	public int getSrcIndex() {
		return srcIndex;
	}

	public void setSrcIndex(int srcIndex) {
		this.srcIndex = srcIndex;
	}

	/** Generate a XML string for the edge */
	public String toXML() {
		StringBuffer sb = new StringBuffer(200);
		sb.append("<edge>\n");
		sb.append("  <source>" + src + "</source>\n");
		sb.append("  <sourceIndex>" + srcIndex + "</sourceIndex>\n");
		sb.append("  <destination>" + dst + "</destination>\n");
		sb.append("  <destIndex>" + distIndex + "</destIndex>\n");
		sb.append("  <data>" + data + "</data>\n");
		sb.append("</edge>\n");
		return sb.toString();
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public void setSrc(String src) {
		this.src = src;
	}

	public void setDst(String dst) {
		this.dst = dst;
	}

	@Override
	public String toString() {
		return "OozieEdge [src=" + src + ", dst=" + dst +"]";
	}

	public static OozieEdge valueOf(Element enode){
		String src = "";
		String dst = "";
		int srcIndex=0;
		int distIndex=0;
		String config="";
		List<Element> children = enode.elements();
		for( Element child: children){
			if ("source".equals(child.getName())) {
				src = child.getText();
			} else if ("destination".equals(child.getName())) {
				dst = child.getText();
			}else if("sourceIndex".equals(child.getName())){
				String srcIndexText=child.getText();
				if(!StringUtil.isEmpty(srcIndexText)){
					srcIndex=Integer.valueOf(srcIndex);
				}
			}else if("data".equals(child.getName())){
				String frontConfigText=child.getText();
				if(!StringUtil.isEmpty(frontConfigText)){
					config=frontConfigText;
				}
			}else{
				String distIndexText=child.getText();
				if(!StringUtil.isEmpty(distIndexText)){
					distIndex=Integer.valueOf(distIndexText);
				}
			}
		}
		if (src.isEmpty() || dst.isEmpty()) {
			return null;
		}
		OozieEdge edge = new OozieEdge();
		edge.init(src, dst);
		edge.setSrcIndex(srcIndex);
		edge.setDistIndex(distIndex);
		edge.setData(config);
		return edge;
	}
}