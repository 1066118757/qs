package com.cdid.service.oozie;

import com.cdid.api.common.IDGeneratorService;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.config.PropertyUtil;
import com.cdid.dao.oozie.*;
import com.cdid.jooq.tables.*;
import com.cdid.jooq.tables.records.MOoziejobNodeRecord;
import com.cdid.jooq.tables.records.TOozieJobLogRecord;
import com.cdid.jooq.tables.records.TOozieJobRecord;
import com.cdid.service.oozie.exception.BuildWorkFlowException;
import com.cdid.service.oozie.graph.OozieGraph;
import com.cdid.service.oozie.graph.OozieProgramNode;
import com.cdid.service.oozie.util.HDFSIO;
import com.cdid.service.oozie.util.OozieUtil;
import com.cdid.service.oozie.vo.*;
import com.cdid.service.oozie.workflow.WFBuilder;
import com.cdid.utils.CollectionUtil;
import com.cdid.utils.StringUtil;
import org.apache.oozie.client.OozieClientException;
import org.apache.oozie.client.WorkflowAction;
import org.apache.oozie.client.WorkflowJob;
import org.dom4j.DocumentException;
import org.jooq.Condition;
import org.jooq.Record2;
import org.jooq.Record3;
import org.jooq.SortField;
import org.quartz.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;

import javax.annotation.Resource;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class OozieJobService {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    IDGeneratorService<Long> idService;

    @Autowired
    OozieJobDao jobDao;

    @Autowired
    OozieJobLogDao jobLogDao;

    @Value("${hdfs.ip}")
    private String IP;

    @Value("${hdfs.port}")
    private String PORT;

    @Resource
    Scheduler scheduler;

    @Autowired
    GroupUserDao groupUserDao;

    @Autowired
    ShareDao shareDao;

    @Autowired
    OozieJobNodeDao jobNodeDao;


    public ResultVo<BigDecimal> saveOrUpdate(OozieGraph graph, String userId) {
        if (graph == null || graph.getPnodes().isEmpty()) {
            return new ResultVo<>(ErrorCode.ParamError.getErrorCode());
        }
        TOozieJobRecord record = saveOrUpdateRecord(graph, userId);
        if (record != null) {
            return new ResultVo<>(0, record.getId());
        }
        return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
    }

    private TOozieJobRecord saveOrUpdateRecord(OozieGraph graph, String userId) {
        BigDecimal jobId = graph.getId();
        if (graph.getId() == null) {
            jobId = BigDecimal.valueOf(idService.id());
            TOozieJobRecord jobRecord = new TOozieJobRecord();
            jobRecord.setCreateTime(new Timestamp(System.currentTimeMillis()));
            jobRecord.setId(jobId);
            jobRecord.setCreateUser(userId);
            jobRecord.setDescription(graph.getDescription());
            jobRecord.setName(graph.getName());
            jobRecord.setGraphXml(graph.toXML());
            jobRecord.setTimeout(graph.getTimeout());
            jobRecord.setUpdateTime(jobRecord.getCreateTime());
            jobRecord.setLatestStatus(WorkflowJob.Status.PREP.toString());
            jobDao.insert(jobRecord);
            saveJobNodeRecords(graph,jobId,true);
            return jobRecord;
        }
        TOozieJobRecord record = jobDao.findById(jobId);
        if (record == null) {
            return null;
        }
        if (!record.getCreateUser().equals(userId)) {
            return null;
        }
        record.setName(graph.getName());
        record.setDescription(graph.getDescription());
        record.setGraphXml(graph.toXML());
        record.setUpdateTime(new Timestamp(System.currentTimeMillis()));
        record.setTimeout(graph.getTimeout());
        jobDao.update(record);
        saveJobNodeRecords(graph,jobId,false);
        return record;
    }

    public ResultVo<OozieIdVO> submitJob(BigDecimal jobId) throws DocumentException, IOException, BuildWorkFlowException, OozieClientException {
        TOozieJobRecord jobRecord = jobDao.findById(jobId);
        if (jobRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
        }
        OozieGraph graph = OozieGraph.valueOf(jobRecord.getGraphXml());
        return submitJob(graph, jobRecord, true);
    }

    private ResultVo<OozieIdVO> submitJob(OozieGraph graph, TOozieJobRecord jobRecord, boolean isUpdate) throws IOException, BuildWorkFlowException, OozieClientException {
        List<String> tempTableNames=graph.initProgramWorkPathAndOutPutParameters();
        String appPath = PropertyUtil.getMergedProperty("oozie.app.path", "/EML/oozie") + "/" + UUID.randomUUID().toString();
        HDFSIO.mkdirs(appPath);
        WFBuilder wfBuilder = new WFBuilder();
        try {
            wfBuilder.buildFromOozieGraph(graph);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BuildWorkFlowException(e.getMessage());
        }
        String workflow = wfBuilder.asWFGraph().toWorkflow(graph.getName());
        HDFSIO.upload(appPath + "/workflow.xml", workflow, true);
        String oozJobId = OozieUtil.submit(appPath);
        TOozieJobLogRecord logRecord = new TOozieJobLogRecord();
        logRecord.setId(BigDecimal.valueOf(idService.id()));
        logRecord.setJobId(jobRecord.getId());
        logRecord.setOozieJobId(oozJobId);
        logRecord.setStartTime(new Timestamp(System.currentTimeMillis()));
        logRecord.setStatus(WorkflowJob.Status.RUNNING.toString());
        logRecord.setAppPath(appPath);
        jobRecord.setLatestStatus(logRecord.getStatus());
        jobRecord.setLatestOozieJobId(oozJobId);
        jobRecord.setPath(appPath);
        jobRecord.setLatestStartTime(logRecord.getStartTime());
        jobRecord.setGraphXml(graph.toXML());
        if(!tempTableNames.isEmpty()){
            logRecord.setTempTables(CollectionUtil.mkString(tempTableNames,","));
            logRecord.setCleared(false);
        }else{
            logRecord.setCleared(true);
        }
        if (isUpdate) {
            jobDao.update(jobRecord);
        } else {
            jobDao.insert(jobRecord);
        }
        jobLogDao.insert(logRecord);
        saveJobNodeRecords(graph,jobRecord.getId(),!isUpdate);
        return new ResultVo<>(0, new OozieIdVO(jobRecord.getId(),oozJobId));
    }

    public ResultVo<OozieIdVO> submitJob(OozieGraph graph, String userId) throws OozieClientException, BuildWorkFlowException, IOException {
        TOozieJobRecord jobRecord = null;
        boolean isUpdate = (graph.getId() != null);
        if (isUpdate) {
            jobRecord = jobDao.findById(graph.getId());
        } else {
            jobRecord = new TOozieJobRecord();
            jobRecord.setCreateTime(new Timestamp(System.currentTimeMillis()));
            jobRecord.setId(BigDecimal.valueOf(idService.id()));
            jobRecord.setCreateUser(userId);
        }
        jobRecord.setName(graph.getName());
        jobRecord.setDescription(graph.getDescription());
        jobRecord.setTimeout(graph.getTimeout());
        jobRecord.setUpdateTime(jobRecord.getCreateTime());
        return submitJob(graph, jobRecord, isUpdate);
    }

    public ResultVo<Boolean> changeJobStatus(BigDecimal jobId, String status) throws IOException, OozieClientException {
        TOozieJobRecord record = jobDao.findById(jobId);
        if (record == null || StringUtil.isEmpty(record.getLatestOozieJobId())) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
        }
        if("RERUN".equals(status)){
            OozieUtil.reRun(record.getLatestOozieJobId());
            return new ResultVo<>(0,true);
        }
        if (!statusIsAllowed(record.getLatestStatus(), status)) {
            return new ResultVo<>(ErrorCode.StatusIllegal.getErrorCode());
        }
        String latestJobId = record.getLatestOozieJobId();
        WorkflowJob.Status eStatus = WorkflowJob.Status.valueOf(status);
        switch (eStatus) {
            case RUNNING:
                OozieUtil.resume(latestJobId);
                upateJobStatus(latestJobId, status, null);
                break;
            case KILLED:
                OozieUtil.kill(record.getLatestOozieJobId());
                upateJobStatus(latestJobId, status, new Date());
                break;
            case SUSPENDED:
                OozieUtil.suspend(record.getLatestOozieJobId());
                upateJobStatus(latestJobId, status, null);
                break;
        }
        return new ResultVo<>(0, true);
    }

    public ResultVo<PageVo<OozieJobListVO>> list(OozieJobQueryVO queryVO, int page, int size, String userId) {
        if(StringUtil.isEmpty(queryVO.getQueryType())){
            queryVO.setQueryType(OozieJobQueryVO.QueryType.MY.toString());
        }
        List<Condition> conditions = constructConditions(queryVO,userId);
        List<SortField<?>> sortFields = new ArrayList<>();
        sortFields.add(TOozieJob.T_OOZIE_JOB.LATEST_START_TIME.desc());
        PageVo<TOozieJobRecord> result = jobDao.fetchByPage(conditions, new OffsetPagingVo(page, size), sortFields);
        List<OozieJobListVO> pageData = result.getPageData().stream().map(j -> {
            OozieJobListVO vo = new OozieJobListVO();
            vo.setId(j.getId());
            if (j.getLatestEndTime() != null) {
                vo.setEndTime(j.getLatestEndTime().getTime());
            }
            if (j.getLatestStartTime() != null) {
                vo.setStartTime(j.getLatestStartTime().getTime());
            }
            vo.setName(j.getName());
            vo.setStatus(j.getLatestStatus());
            vo.setOozieJobId(j.getLatestOozieJobId());
            vo.setCreateTime(j.getCreateTime().getTime());
            vo.setIsSystem(j.getIsSystem());
            return vo;
        }).collect(Collectors.toList());

        return new ResultVo<>(0, new PageVo<>(result.getTotalCount(), pageData));
    }

    private List<Condition> constructConditions(OozieJobQueryVO queryVO,String userId){
        List<Condition> conditions = new ArrayList<>();
        if (OozieJobQueryVO.QueryType.MY.name().equals(queryVO.getQueryType())) {
            conditions.add(TOozieJob.T_OOZIE_JOB.CREATE_USER.eq(userId));
        }else if(OozieJobQueryVO.QueryType.SHARE.name().equals(queryVO.getQueryType())){
            List<String> groupIdList=groupUserDao.fetchFieldByConditions(MGroupUser.M_GROUP_USER.GROUP_ID, Arrays.asList(MGroupUser.M_GROUP_USER.USER_ID.eq(userId)));
            groupIdList.add(userId);
            List<Condition> conditionList=Arrays.asList(TOozieShare.T_OOZIE_SHARE.DIST_OBJECT_ID.in(groupIdList),TOozieShare.T_OOZIE_SHARE.SOURCE_OBJECT_TYPE.eq(OozieShareVO.SourceObjectType.OOZIE_JOB.name()));
            List<BigDecimal> oozieJobIdList=shareDao.fetchFieldByConditions(TOozieShare.T_OOZIE_SHARE.SOURCE_OBJECT_ID,conditionList);
            if(oozieJobIdList.isEmpty()){
                return conditions;
            }
            conditions.add(TOozieJob.T_OOZIE_JOB.ID.in(oozieJobIdList));
        }else if(OozieJobQueryVO.QueryType.SYSTEM.name().equals(queryVO.getQueryType())){
            conditions.add(TOozieJob.T_OOZIE_JOB.IS_SYSTEM.eq(true));
        }
        if(StringUtil.isNotEmpty(queryVO.getCreateUser())){
            conditions.add(TOozieJob.T_OOZIE_JOB.CREATE_USER.eq(queryVO.getCreateUser()));
        }
        if (!StringUtil.isEmpty(queryVO.getName())) {
            conditions.add(TOozieJob.T_OOZIE_JOB.NAME.like("%" + queryVO.getName() + "%"));
        }
        if (!StringUtil.isEmpty(queryVO.getStatus())) {
            conditions.add(TOozieJob.T_OOZIE_JOB.LATEST_STATUS.eq(queryVO.getStatus()));
        }
        if(queryVO.getCreateTimeStart()!=null){
            conditions.add(TOozieJob.T_OOZIE_JOB.CREATE_TIME.gt(new Timestamp(queryVO.getCreateTimeStart())));
        }
        if(queryVO.getCreateTimeEnd()!=null){
            conditions.add(TOozieJob.T_OOZIE_JOB.CREATE_TIME.lt(new Timestamp(queryVO.getCreateTimeEnd())));
        }
        return conditions;
    }

    public ResultVo<OozieGraph> findById(BigDecimal id) throws DocumentException {
        TOozieJobRecord record = jobDao.findById(id);
        if (record == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
        }
        OozieGraph oozieGraph = OozieGraph.valueOf(record.getGraphXml());
        oozieGraph.setId(id);
        oozieGraph.setAppPath(record.getPath());
        oozieGraph.setDescription(record.getDescription());
        oozieGraph.setName(record.getName());
        oozieGraph.setTimeout(record.getTimeout());
        oozieGraph.setOozieJobId(record.getLatestOozieJobId());
        return new ResultVo<>(0, oozieGraph);
    }

    public void upateJobStatus(String oozieJobId, String status, Date endTime) {
        Optional<TOozieJobRecord> optionalJob = jobDao.fetchOptional(TOozieJob.T_OOZIE_JOB.LATEST_OOZIE_JOB_ID, oozieJobId);
        List<String> unFinishedStatusList = Arrays.asList(WorkflowJob.Status.RUNNING.toString(), WorkflowJob.Status.SUSPENDED.toString());
        if (optionalJob.isPresent()) {
            TOozieJobRecord job = optionalJob.get();
            job.setLatestStatus(status);
            if (!unFinishedStatusList.contains(status)) {
                if (endTime != null) {
                    job.setLatestEndTime(new Timestamp(endTime.getTime()));
                }
            }
            jobDao.update(job);
        }
        Optional<TOozieJobLogRecord> optionalLogRecord = jobLogDao.fetchOptional(TOozieJobLog.T_OOZIE_JOB_LOG.OOZIE_JOB_ID, oozieJobId);
        if (optionalLogRecord.isPresent()) {
            TOozieJobLogRecord log = optionalLogRecord.get();
            log.setStatus(status);
            if (!unFinishedStatusList.contains(status)) {
                if (endTime != null) {
                    log.setEndTime(new Timestamp(endTime.getTime()));
                }
            }
            jobLogDao.update(log);
        }
    }

    public List<OozieActionVO> listAction(String oozieJobId) {
        WorkflowJob job = null;
        try {
            job = OozieUtil.getJob(oozieJobId);
        } catch (OozieClientException e) {
            logger.error(e.getErrorCode(), e);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }
        OozieActionVO actionVO;
        List<OozieActionVO> actionVOList = new ArrayList<>();
        if (job != null) {
            List<WorkflowAction> actions = job.getActions();
            for (WorkflowAction action : actions) {
                actionVO = new OozieActionVO();
                actionVO.setActionName(action.getName());
                if (action.getEndTime() != null) {
                    actionVO.setEndTime(action.getEndTime().getTime());
                }
                if (action.getStartTime() != null) {
                    actionVO.setStartTime(action.getStartTime().getTime());
                }
                actionVO.setErrorCode(action.getErrorCode());
                actionVO.setErrorMsg(action.getErrorMessage());
                actionVO.setType(action.getType());
                actionVO.setStatus(action.getStatus().toString());
                actionVOList.add(actionVO);
            }
        }
        return actionVOList;
    }

    public ResultVo<Boolean> deleteJobs(List<BigDecimal> jobIdList, boolean fullDelete) {
        if (fullDelete) {
            deleteRelativeData(jobIdList);
        }
        jobDao.deleteById(jobIdList);
        jobNodeDao.deleteByConditions(Arrays.asList(MOoziejobNode.M_OOZIEJOB_NODE.OOZIE_JOB_ID.in(jobIdList)));
        shareDao.deleteByConditions(Arrays.asList(TOozieShare.T_OOZIE_SHARE.SOURCE_OBJECT_ID.in(jobIdList),TOozieShare.T_OOZIE_SHARE.SOURCE_OBJECT_TYPE.eq(OozieShareVO.SourceObjectType.OOZIE_JOB.toString())));
        return new ResultVo<>();
    }

    private void deleteRelativeData(List<BigDecimal> jobIdList) {
    }

    private boolean statusIsAllowed(String oldStatus, String newStatus) {
        WorkflowJob.Status status = WorkflowJob.Status.valueOf(oldStatus);
        switch (status) {
            case PREP:
                return false;
            case FAILED:
                return false;
            case SUCCEEDED:
                return false;
            case KILLED:
                return false;
            case RUNNING:
                return Arrays.asList(WorkflowJob.Status.SUSPENDED.name(), WorkflowJob.Status.KILLED.name()).contains(newStatus);
            default:
                return WorkflowJob.Status.RUNNING.name().equals(newStatus);
        }
    }


    public void jobStatusChangeNotify(String oozieJobId, String status) {
        if (!status.equals(WorkflowJob.Status.RUNNING.toString())) {
            upateJobStatus(oozieJobId, status, new Date());
        }
    }

    public void actionStatusChangeNotify(String oozieJobId, String actionName, String status) {
        logger.info("oozieJobId=" + oozieJobId + ",actionName=" + actionName + ",status=" + status);
    }

    public ResultVo<List<String>> getLog(String oozieJobId, String actionId, String type,Integer endLine) {
        Optional<TOozieJobLogRecord> logRecord = jobLogDao.fetchOptional(TOozieJobLog.T_OOZIE_JOB_LOG.OOZIE_JOB_ID, oozieJobId);
        if (!logRecord.isPresent()) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
        }
        String appPath = logRecord.get().getAppPath();
        String logPath = appPath + "/" + actionId +"/" + type;
        boolean logFileExists = false;
        try {
            logFileExists = HDFSIO.exist(logPath);
            if (!logFileExists) {
                logPath= appPath + "/" + actionId +"/" +actionId +"/"+ type;
                logFileExists= HDFSIO.exist(logPath);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(!logFileExists){
            return new ResultVo<>(ErrorCode.FileNotFound.getErrorCode());
        }
        return HDFSIO.readLines(logPath,endLine);
    }

    public PageVo<OozieJobLogVO> listLog(OozieJobLogQueryVO queryVO, int page, int size) {
        List<Condition> conditionList = new ArrayList<>();
        if(null != queryVO.getJobId()){
            conditionList.add(TOozieJobLog.T_OOZIE_JOB_LOG.JOB_ID.eq(queryVO.getJobId()));
        }
        if(queryVO.getStartTime() != null){
            conditionList.add(TOozieJobLog.T_OOZIE_JOB_LOG.START_TIME.greaterThan(new Timestamp(queryVO.getStartTime())));
        }
        if(queryVO.getEndTime()!=null){
            conditionList.add(TOozieJobLog.T_OOZIE_JOB_LOG.START_TIME.lessThan(new Timestamp(queryVO.getEndTime())));
        }
        List<SortField<?>> sortFields = new ArrayList<>();
        sortFields.add(TOozieJobLog.T_OOZIE_JOB_LOG.START_TIME.desc());
        PageVo<TOozieJobLogRecord> recordPage = jobLogDao.fetchByPage(conditionList, new OffsetPagingVo(page, size), sortFields);
        List<OozieJobLogVO> content = recordPage.getPageData().stream().map(r -> {
            OozieJobLogVO logVO = new OozieJobLogVO();
            logVO.setOozieJobId(r.getOozieJobId());
            if (r.getStartTime() != null) {
                logVO.setStartTime(r.getStartTime().getTime());
            }
            if (r.getEndTime() != null) {
                logVO.setEndTime(r.getEndTime().getTime());
            }
            logVO.setStatus(r.getStatus());
            return logVO;
        }).collect(Collectors.toList());
        return new PageVo<>(recordPage.getTotalCount(), content);
    }

    public ResultVo<String> getJobStatus(String oozieJobId){
        Optional<TOozieJobLogRecord> record=jobLogDao.fetchOptional(TOozieJobLog.T_OOZIE_JOB_LOG.OOZIE_JOB_ID,oozieJobId);
        if(!record.isPresent()){
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
        }
        return  new ResultVo<>(0,record.get().getStatus());
    }


    public ResultVo<List<String>> readOutFile(String oozieJobId,String path,Integer endLine) throws IOException {
        Optional<TOozieJobLogRecord> record=jobLogDao.fetchOptional(TOozieJobLog.T_OOZIE_JOB_LOG.OOZIE_JOB_ID,oozieJobId);
        if(!record.isPresent()){
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
        }
        String appPath=record.get().getAppPath();
        if(StringUtil.isEmpty(appPath)){
            return new ResultVo<>(ErrorCode.FileNotFound.getErrorCode());
        }
        String fullPath=appPath+"/"+path;
       return  HDFSIO.readDir(fullPath,endLine);
    }

    public void downloadOutFile(String oozieJobId, String path, OutputStream os) throws Exception {
        Optional<TOozieJobLogRecord> record=jobLogDao.fetchOptional(TOozieJobLog.T_OOZIE_JOB_LOG.OOZIE_JOB_ID,oozieJobId);
        if(!record.isPresent()){
            throw new Exception("job not found");
        }
        String appPath=record.get().getAppPath();
        if(StringUtil.isEmpty(appPath)){
            throw new Exception("file not found");
        }
        String fullPath=appPath+"/"+path;
        HDFSIO.writeToOutputStream(fullPath,os);
    }

    public OozieJobStatisticsResultVO summaryStatistics(OozieJobQueryVO queryVO,String userId){
        List<Condition> conditionList=constructConditions(queryVO,userId);
        List<Record2<String,Integer>> statusDimensionResults=jobDao.statisticsByStatus(conditionList);
        List<StatisticsResultSimpleVO> simpleVOList = new ArrayList<>();
        int total = 0 ;
        for(Record2<String,Integer> record:statusDimensionResults){
            StatisticsResultSimpleVO simpleVO=new StatisticsResultSimpleVO(record.value1(),record.value2());
            total=total+record.value2();
            simpleVOList.add(simpleVO);
        }
        DimensionStatisticsVO statusDimension=new DimensionStatisticsVO("status",simpleVOList);
        List<Record2<String,Integer>> logStatusDimensionResults=jobLogDao.statisticsByStatus(conditionList);
        int success=0;
        int fail=0;
        for(Record2<String,Integer> record:logStatusDimensionResults){
           if(WorkflowJob.Status.SUCCEEDED.toString().equals(record.value1())){
               success=success+record.value2();
           }else if(WorkflowJob.Status.FAILED.toString().equals(record.value1())||WorkflowJob.Status.KILLED.toString().equals(record.value1())){
               fail=fail+record.value2();
           }
        }
        DimensionStatisticsVO successFailDimension=new DimensionStatisticsVO("success-fail",Arrays.asList(new StatisticsResultSimpleVO("SUCCESS",success),new StatisticsResultSimpleVO("FAIL",fail)));
        OozieJobStatisticsResultVO resultVO=new OozieJobStatisticsResultVO();
        resultVO.setJobStatusDimension(statusDimension);
        resultVO.setSuccessFailDimension(successFailDimension);
        resultVO.setTotal(total);
        return resultVO;
    }

    public List<UserRankStatisticsVO> userRankStatistics(OozieJobQueryVO queryVO,String userId){
        List<Condition> conditionList=constructConditions(queryVO,userId);
        List<Record3<String,String,Integer>> records=jobDao.statisticsByCreateUser(conditionList);
        return records.stream().map(r -> new UserRankStatisticsVO(r)).collect(Collectors.toList());
    }

    public void setSystem(BigDecimal id,String operate){
        jobDao.update(Arrays.asList(TOozieJob.T_OOZIE_JOB.ID.eq(id)),TOozieJob.T_OOZIE_JOB.IS_SYSTEM,operate.equals("create"));
    }

    public ResultVo<BigDecimal> clone(OozieJobCloneVO cloneVO,String userId) throws DocumentException {
        TOozieJobRecord jobRecord = jobDao.findById(cloneVO.getSourceId());
        if (jobRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
        }
        OozieGraph graph = OozieGraph.valueOf(jobRecord.getGraphXml());
        graph.initProgramWorkPathAndOutPutParameters();
        TOozieJobRecord cloneRecord=new TOozieJobRecord();
        cloneRecord.setId(BigDecimal.valueOf(idService.id()));
        cloneRecord.setCreateTime(new Timestamp(System.currentTimeMillis()));
        cloneRecord.setCreateUser(userId);
        cloneRecord.setDescription(cloneVO.getDescription());
        cloneRecord.setGraphXml(graph.toXML());
        cloneRecord.setIsSystem(false);
        cloneRecord.setName(cloneVO.getName());
        cloneRecord.setLatestStatus(WorkflowJob.Status.PREP.toString());
        cloneRecord.setUpdateTime(cloneRecord.getCreateTime());
        jobDao.insert(cloneRecord);
        return new ResultVo<>(0,cloneRecord.getId());
    }

    private void saveJobNodeRecords(OozieGraph graph,BigDecimal jobId,boolean isCreate){
        if(!isCreate){
            jobNodeDao.deleteByConditions(Arrays.asList(MOoziejobNode.M_OOZIEJOB_NODE.OOZIE_JOB_ID.eq(jobId)));
        }
        Set<BigDecimal> programIdSet=graph.getPnodes().stream().map(a -> new BigDecimal(a.getModuleId())).collect(Collectors.toSet());
        Set<BigDecimal> dataIdSet = graph.getDnodes().stream().map(d -> new BigDecimal(d.getModuleId())).collect(Collectors.toSet());
        List<MOoziejobNodeRecord> recordList=constructOozieJobNodeRecords(programIdSet,"PROGRAM",jobId);
        recordList.addAll(constructOozieJobNodeRecords(dataIdSet,"DATA",jobId));
        if(!recordList.isEmpty()){
            jobNodeDao.insert(recordList);
        }

    }

    private List<MOoziejobNodeRecord> constructOozieJobNodeRecords(Set<BigDecimal> nodeIdSet,String nodeType,BigDecimal id){
        List<MOoziejobNodeRecord> jobNodeList=new ArrayList<>();
        MOoziejobNodeRecord record;
        Timestamp now =new Timestamp(System.currentTimeMillis());
        for(BigDecimal nodeId:nodeIdSet){
            record=new MOoziejobNodeRecord();
            record.setId(BigDecimal.valueOf(idService.id()));
            record.setNodeId(nodeId);
            record.setOozieJobId(id);
            record.setNodeType(nodeType);
            record.setCreateTime(now);
            jobNodeList.add(record);
        }
        return jobNodeList;
    }

    public List<BigDecimal> queryReferedNodeIdList(List<BigDecimal> idList,String nodeType){
        return jobNodeDao.fetchFieldByConditions(MOoziejobNode.M_OOZIEJOB_NODE.NODE_ID,Arrays.asList(MOoziejobNode.M_OOZIEJOB_NODE.NODE_ID.in(idList),MOoziejobNode.M_OOZIEJOB_NODE.NODE_TYPE.eq(nodeType)));
    }

}
