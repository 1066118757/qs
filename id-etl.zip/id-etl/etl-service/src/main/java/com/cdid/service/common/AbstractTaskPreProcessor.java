package com.cdid.service.common;

import com.alibaba.fastjson.JSON;
import com.cdid.api.asynctask.vo.AsyncTaskConfigVo;
import com.cdid.api.common.RedisService;
import com.cdid.api.dataclear.cleartasklog.ClearTaskLogService;
import com.cdid.api.jupyter.TaskPreProcessProcessor;
import com.cdid.api.jupyter.vo.DependenceVO;
import com.cdid.config.PropertyUtil;
import com.cdid.dao.dataclear.cleartasklog.ClearTaskLogDao;
import com.cdid.dao.job.JobDao;
import com.cdid.dao.schedulelog.SchedulelogDao;
import com.cdid.jooq.tables.records.TClearTaskLogRecord;
import com.cdid.jooq.tables.records.TScheduleLogRecord;
import com.cdid.utils.StringUtil;
import com.cdid.utils.jdbc.SpringUtil;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.Date;

public abstract class AbstractTaskPreProcessor implements TaskPreProcessProcessor {


    protected abstract void jobExecuteFailedCallBack(BigDecimal taskId, String errorMessage);


    public boolean dependenceFinished(AsyncTaskConfigVo taskConfigVo){
        String dependence=taskConfigVo.getDependence();
        if(StringUtil.isEmpty(dependence)){
            return true;
        }
        DependenceVO dependenceVO= JSON.parseObject(dependence,DependenceVO.class);
        if(dependenceVO.getEtlJobs().isEmpty()&&dependenceVO.getClearJobs().isEmpty()){
            return true;
        }
        SchedulelogDao schedulelogDao = SpringUtil.getBean(SchedulelogDao.class);
        for(BigDecimal jobId:dependenceVO.getEtlJobs()){
           TScheduleLogRecord latestLog=schedulelogDao.findJobLatestLog(jobId);
            if(latestLog == null||latestLog.getScheduleState() != 2 || (latestLog.getScheduleEndtime()!=null && !DateUtils.isSameDay(latestLog.getScheduleEndtime(),new Date()))){
                return false;
            }
        }
        ClearTaskLogDao clearTaskLogDao=SpringUtil.getBean(ClearTaskLogDao.class);
        for(BigDecimal jobId:dependenceVO.getClearJobs()){
            TClearTaskLogRecord latestLog=clearTaskLogDao.findTaskLatestLog(jobId);
            if(latestLog == null||latestLog.getResult() != 2 || (latestLog.getEndTime()!=null && !DateUtils.isSameDay(latestLog.getEndTime(),new Date()))){
                return false;
            }
        }
        return true;

    }

    public void processDependence(AsyncTaskConfigVo configVo,boolean isHand) throws Exception {
        if(isHand){
            if(!dependenceFinished(configVo)){
                throw new Exception("依赖任务未完成！");
            }
        }
        if(!isHand){
            int retryTimes=0;
            int maxRetryTimes=Integer.valueOf(PropertyUtil.getMergedProperty("job.max.retry.times","5"));
            int retryFrequency_minute=Integer.valueOf(PropertyUtil.getMergedProperty("retry.frequency_minute","20"));
            boolean finished=dependenceFinished(configVo);
            while (retryTimes <=maxRetryTimes && !finished){
                Thread.sleep(retryFrequency_minute*60*1000);
                retryTimes=retryTimes+1;
                finished=dependenceFinished(configVo);
            }
            if(!finished){
                jobExecuteFailedCallBack(configVo.getTaskId(),"已重试"+maxRetryTimes+"次,依赖任务依然未运行完成!");
                throw new Exception("依赖任务未完成！");
            }
        }
    }
 }
