package com.cdid.service.oozie.vo;

import java.math.BigDecimal;

public class ProgramTreeListVO extends TreeObjectListVO {

    private BigDecimal programId;

    private String programName;

    private Long createTime;

    private Boolean downloadable;

    private String programType;

    private String description;

    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    public Boolean getDownloadable() {
        return downloadable;
    }

    public void setDownloadable(Boolean downloadable) {
        this.downloadable = downloadable;
    }

    public BigDecimal getProgramId() {
        return programId;
    }

    public void setProgramId(BigDecimal programId) {
        this.programId = programId;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public String getProgramType() {
        return programType;
    }

    public void setProgramType(String programType) {
        this.programType = programType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
