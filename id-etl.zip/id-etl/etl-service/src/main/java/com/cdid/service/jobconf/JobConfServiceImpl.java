package com.cdid.service.jobconf;

import com.cdid.api.common.IDGeneratorService;
import com.cdid.api.jobconf.JobConfService;
import com.cdid.api.jobconf.vo.*;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.jobconf.JobConfDao;
import com.cdid.jooq.tables.records.TJobConfRecord;
import com.cdid.utils.VoReTraversalUtil;
import org.jooq.Result;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/02 15:20 
 */
@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class JobConfServiceImpl implements JobConfService{

    @Autowired
    IDGeneratorService<Long> idGeneratorService;

    @Autowired
    JobConfDao jobConfDao;

    private static Logger logger = LoggerFactory.getLogger(JobConfServiceImpl.class);


    @Override
    public ResultVo<String> add(JobConfAddVo jobConfAddVo,String userId) throws Exception {
        return null;
    }

    @Override
    public ResultVo<String> batchAdd(List<JobConfAddVo> jobConfAddVos,String userId) throws Exception {
        List<TJobConfRecord> records = new ArrayList<>();
        TJobConfRecord record = null;
        BigDecimal confId = null;
        for(JobConfAddVo vo: jobConfAddVos){
            record = VoReTraversalUtil.traversal(vo, TJobConfRecord.class);
            confId = BigDecimal.valueOf(idGeneratorService.id());
            record.setId(confId);
            record.setCreateUser(userId);
            record.setUpdateUser(userId);
            records.add(record);
        }
        jobConfDao.insert(records);
        return new ResultVo<>(0,null,"SUCCESS");
    }

    @Override
    public ResultVo<String> delete(List<BigDecimal> ids) throws Exception {
        jobConfDao.deleteById(ids);
        return new ResultVo<>(0,null,"SUCCESS");
    }

    @Override
    public ResultVo<String> deleteByRefId(BigDecimal refId) throws Exception {
        jobConfDao.deleteByRefId(refId);
        return new ResultVo<>(0,null,"SUCCESS");
    }

    @Override
    public ResultVo<String> update(JobConfUpdateVo jobConfUpdateVo,String userId) throws Exception {

        return null;
    }

    @Override
    public ResultVo<PageVo<JobConfListVo>> list(JobConfQueryVo dataSourceQueryVo) throws Exception {
        return null;
    }

    @Override
    public ResultVo<JobConfDetailVo> findById(BigDecimal id) throws Exception {
        return null;
    }

    @Override
    public List<JobConfDetailVo> findByRefId(BigDecimal refId,Integer ... type) throws Exception {
        Result<TJobConfRecord> records = jobConfDao.findByRefId(refId, type);
        JobConfDetailVo vo = null;
        List<JobConfDetailVo> vos = new ArrayList<>();
        for(TJobConfRecord record:records){
            vo = VoReTraversalUtil.traversal(record,JobConfDetailVo.class);
            vos.add(vo);
        }
        return vos;
    }
}
