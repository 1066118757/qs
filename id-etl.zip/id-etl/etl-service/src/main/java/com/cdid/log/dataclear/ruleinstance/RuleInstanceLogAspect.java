package com.cdid.log.dataclear.ruleinstance;

import com.alibaba.fastjson.JSON;
import com.cdid.api.operate.operatelog.OperateLogService;
import com.cdid.api.operate.operatelog.vo.OperateLogAddVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.token.AccessTokenDao;
import com.cdid.log.GetUserIdUtil;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashSet;
import java.util.Set;

/**
 * @Author LQL
 * @CreateAt 2017/11/29
 */

@Aspect
@Component
public class RuleInstanceLogAspect {
    @Resource
    private OperateLogService operateLogService;
    @Resource
    private AccessTokenDao accessTokenDao;

    private static Logger logger = LoggerFactory.getLogger(RuleInstanceLogAspect.class);

    private Set<String> tableName = new HashSet();

    // controller层切点
    @Pointcut("(execution(public * com.cdid.api.dataclear.ruleinstance.RuleInstanceService.*(..)))")
    public void ruleInstanceAspect() {
    }

    @Before("ruleInstanceAspect()")
    public void beforeRuleInstance(JoinPoint joinPoint) {
        try {
            logger.info("=====beforeRuleInstanceAspect前置通知开始=====");
            logger.info("请求Param：" + joinPoint.getArgs());
            tableName.add(JSON.toJSONString(joinPoint.getArgs()[0]));
        } catch (Exception e) {
            logger.error("=====beforeRuleInstanceAspect前置异常通知====");
            logger.error(e.getMessage());
        }
    }

    @AfterReturning(pointcut = "ruleInstanceAspect()", returning = "retValue")
    public void afterRuleInstance(JoinPoint joinPoint, Object retValue) {
        try {
            //从请求中获取userId
            String userId = GetUserIdUtil.getUserId();
            logger.info("=====afterRuleInstance后置通知开始=====");
            String className = joinPoint.getTarget().getClass().getName();
            String methodName = joinPoint.getSignature().getName() + "()";
            logger.info("请求方法:" + className);
            logger.info("请求人:" + userId);
            Integer result=0;
            try{
                result  = ((ResultVo) retValue).getErrorCode();
            }catch (Exception e){
            }
            logger.info("返回值：" + result);
            //写入数据库
            logger.info("====写入operateAction====");
            OperateLogAddVo operateLogAddVo = new OperateLogAddVo();
            Integer actionId;
            switch (methodName){
                case "add()":actionId=501;break;
                case "update()":actionId=502;break;
                case "delete()":actionId=503;break;
                case "list()":actionId=504;break;
                case "ruleInstanceById()":actionId=505;break;
                case "listByRecordId()":actionId=506;break;
                default:actionId=500;
            }
            operateLogAddVo.setActionId(actionId);
            operateLogAddVo.setOperatorId(userId);
            operateLogAddVo.setResult(result);
            //操作表暂定为前接口对应表
            operateLogAddVo.setOperateTable("t_rule_instance");
            operateLogService.add(operateLogAddVo);
            logger.info("====写入operateLog====");
            /*for (String table : tableName
                    ) {
                logger.info("操作表: " + table);
                operateLogAddVo.setOperateTable(table);
                operateLogService.add(operateLogAddVo);
                logger.info("====写入operateLog====");
            }*/
        } catch (Exception e) {
            logger.error("=====afterRuleInstance后置异常通知====");
            logger.error(e.getMessage());
        } finally {
            tableName.clear();
        }
    }
}
