
package com.cdid.service.oozie.command;

public class CommandParseException extends Exception {

	public CommandParseException(String message) {
		super(message);
	}
}
