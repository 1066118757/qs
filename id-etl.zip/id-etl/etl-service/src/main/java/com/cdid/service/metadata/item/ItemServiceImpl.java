package com.cdid.service.metadata.item;

import com.alibaba.fastjson.JSON;
import com.cdid.api.common.IDGeneratorService;
import com.cdid.api.metadata.detail.vo.DetailAddVo;
import com.cdid.api.metadata.item.ItemService;
import com.cdid.api.metadata.item.vo.*;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.dict.ColType;
import com.cdid.common.dict.ItemSourceType;
import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.metadata.detail.DetailDao;
import com.cdid.dao.metadata.item.ItemDao;
import com.cdid.dao.metadata.themeitem.ThemeItemDao;
import com.cdid.dao.oozie.ShareDao;
import com.cdid.dao.user.UsersDao;
import com.cdid.jooq.tables.TOozieShare;
import com.cdid.jooq.tables.records.TMetadataDetailRecord;
import com.cdid.jooq.tables.records.TMetadataItemRecord;
import com.cdid.jooq.tables.records.TMetadataThemeItemRecord;
import com.cdid.service.oozie.OozieObjectTreeService;
import com.cdid.service.oozie.vo.OozieShareVO;
import com.cdid.service.oozie.vo.TreeObjectVO;
import com.cdid.utils.HttpClientUtil;
import com.cdid.utils.VoReTraversalUtil;
import org.apache.commons.lang3.StringUtils;
import org.jooq.Condition;
import org.jooq.SortField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.cdid.jooq.tables.TMetadataItem.T_METADATA_ITEM;


/**
 * 元数据条目的实现
 */
@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class ItemServiceImpl implements ItemService {
    public static final TreeObjectVO TREE_OBJECT_VO = new TreeObjectVO();
    public static final TreeObjectVO TREE_OBJECT_VO1 = new TreeObjectVO();
    public static final TreeObjectVO TREE_OBJECT_VO2 = new TreeObjectVO();
    public static final TreeObjectVO TREE_OBJECT_VO3 = new TreeObjectVO();
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    private static final  String REST_FOR_CREATE_TABLE="/rest/hbase/sparksql/createTable" ;
    private static final  String REST_FOR_EXISTS_DATA="/rest/hbase/sparksql/table/existsData" ;
    private static final String REST_FOR_DELETE_TABLE="/rest/hbase/sparksql/excuteDelete/";

    @Autowired
    private ItemDao itemDao;
    @Autowired
    private ThemeItemDao themeItemDao;
    @Autowired
    private DetailDao detailDao;
    @Autowired
    private IDGeneratorService<Long> idGeneratorService;

    @Autowired
    OozieObjectTreeService treeService;

    @Value("${idmanager-server.baseUrl}")
    private String idmanagerBaseUrl;
    @Autowired
    private UsersDao usersDao;

    @Autowired
    private ShareDao shareDao;

    /**
     * 元数据条目信息添加
     * @param itemAddVo
     * @param userId
     * @return
     */
    @Override
    public ResultVo<Object> add(ItemAddVo itemAddVo, String userId) {
        ResultVo<Object> resultVo = new ResultVo<Object>();

        try {
            //判断是否有传元数据主题条目id，必须传入元数据主题条目id
            BigDecimal themeItemId = itemAddVo.getThemeItemId();
            if (themeItemId==null){
                return new ResultVo<>(ErrorCode.ParamError.getErrorCode(),"添加元数据条目必须传入对应的元数据主题条目id！");
            }
            //判断传入的元数据主题条目必须在数据库中存在
            TMetadataThemeItemRecord itemRecord = themeItemDao.findById(themeItemId);
            if (itemRecord==null){
                return new ResultVo<>(ErrorCode.NotExists.getErrorCode(),"绑定的元数据主题条目id找不到记录，请从新传入正确的参数！");
            }
            TMetadataItemRecord tItemRecord = (TMetadataItemRecord) VoReTraversalUtil.traversalTwo(itemAddVo, TMetadataItemRecord.class);
            tItemRecord.setId(BigDecimal.valueOf(idGeneratorService.id()));
            //创建人，同时也是更新人
            tItemRecord.setCreateUser(userId);
            tItemRecord.setUpdateUser(userId);
            //插入表中
            itemDao.insert(tItemRecord);
            TreeObjectVO treeObjectVO=new TreeObjectVO();
            treeObjectVO.setName(itemAddVo.getName());
            treeObjectVO.setObjectType(TreeObjectVO.TreeObjectType.DATA.toString());
            treeObjectVO.setLeafObjectType(TreeObjectVO.LeafObjectType.TABLE.toString());
            treeObjectVO.setParentType(TreeObjectVO.TreeParentType.SELF.toString());
            treeService.addTreeObject(treeObjectVO,userId, tItemRecord.getId());
            resultVo.setData("success");
            return resultVo;
        } catch (Exception e) {
            e.printStackTrace();
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            return resultVo;
        }
    }

    /**
     * 元数据条目信息更新
     * @param itemUpdateVo
     * @param userId
     * @return
     */
    @Override
    public ResultVo<Object> update(ItemUpdateVo itemUpdateVo, String userId) {
        ResultVo<Object> resultVo = new ResultVo<Object>();
        try {
            //从数据库查询出需要修改的信息
            TMetadataItemRecord tMetadataItemRecord = itemDao.findById(itemUpdateVo.getId());
            if (tMetadataItemRecord == null) {
                return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
            }
            //判断，xxx情况不允许更新

            //调用方法设置值
            tMetadataItemRecord = (TMetadataItemRecord) VoReTraversalUtil.traversalTwo(itemUpdateVo, TMetadataItemRecord.class);
            //更新人
            tMetadataItemRecord.setUpdateUser(userId);
            //更新时间
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            tMetadataItemRecord.setUpdateTime(timestamp);
            //审核人,有审核状态传入则表示审核
            Integer state = itemUpdateVo.getState();
            if (state!=null){
                tMetadataItemRecord.setAuditTime(timestamp);
            }
            itemDao.update(tMetadataItemRecord);
            resultVo.setData("success");
            return resultVo;
        } catch (Exception e) {
            e.printStackTrace();
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            return resultVo;
        }
    }

    /**
     * 元数据条目信息删除
     * @param id
     * @return
     */
    @Override
    public ResultVo<Object> delete(BigDecimal id,String accessToken) {
        //查询是否存在
        TMetadataItemRecord tMetadataItemRecord = itemDao.findById(id);
        if (tMetadataItemRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), false);
        }
        //判断，xxx情况不允许删除
        //删除
        List<BigDecimal> ids = new ArrayList<>();
        ids.add(id);

        String deleteUrl=idmanagerBaseUrl+REST_FOR_DELETE_TABLE+"default/"+tMetadataItemRecord.getName();
        RestTemplate restTemplate= new RestTemplate();
        try {
            HttpHeaders requestHeaders = new HttpHeaders();
            //requestHeaders.setContentType(MediaType.APPLICATION_JSON);
            requestHeaders.set("Authorization",accessToken);
            HttpEntity<String> requestEntity = new HttpEntity<String>(null, requestHeaders);
            ResponseEntity<String> responseEntity = restTemplate.exchange(deleteUrl, HttpMethod.DELETE, requestEntity, String.class);
            HttpStatus code = responseEntity.getStatusCode();
            if (code.toString().equals("200")){
                //关联删除详情信息
                detailDao.deleteByItemId(tMetadataItemRecord.getId());
                itemDao.deleteById(ids);
                shareDao.deleteByConditions(Arrays.asList(TOozieShare.T_OOZIE_SHARE.SOURCE_OBJECT_ID.eq(id),TOozieShare.T_OOZIE_SHARE.SOURCE_OBJECT_TYPE.eq(OozieShareVO.SourceObjectType.TABLE.toString())));
                treeService.deleteTreeObjects(ids,TreeObjectVO.LeafObjectType.TABLE.toString());
                return new ResultVo<>(0, true);
            }
            return new ResultVo<>(0, false);
        } catch (RestClientException e) {
            logger.error(e.getMessage(),e);
            e.printStackTrace();
            return new ResultVo<>(0, false);
        }
    }

    /**
     * 元数据条目信息列表查询
     * @param itemQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    @Override
    public ResultVo<PageVo<List<ItemListVo>>> list(ItemQueryVo itemQueryVo,boolean isAdmin, String userId, Integer page, Integer size) {
        List<SortField<?>> sortList = new ArrayList<>();

        //添加排序字段
        sortList.add(T_METADATA_ITEM.UPDATE_TIME.desc());
        //添加条件字段
        List<Condition> conditions = innerAddListCondition(itemQueryVo);
        if(StringUtils.isNotEmpty(userId) && !isAdmin){
            conditions.add(T_METADATA_ITEM.CREATE_USER.eq(userId));
        }
        //查询赋值返回
        PageVo<TMetadataItemRecord> query = itemDao.fetchByPage(conditions, new OffsetPagingVo(page, size), sortList);
        List<TMetadataItemRecord> tMetadataItemRecords;
        tMetadataItemRecords=query.getPageData();
        List<ItemListVo> list = new ArrayList<>();
        for (TMetadataItemRecord tMetadataItemRecord : tMetadataItemRecords
                ) {
            ItemListVo  itemListVo= (ItemListVo) VoReTraversalUtil.traversalTwo(tMetadataItemRecord, ItemListVo.class);
            //查询创建者名字
            String name = usersDao.getNameByUserId(tMetadataItemRecord.getCreateUser());
            itemListVo.setCreateUserName(name);
            itemListVo.setIsSystem(tMetadataItemRecord.getIsSystem());
            list.add(itemListVo);
        }
        PageVo<ItemListVo> result = new PageVo<>();
        result.setPageData(list);
        result.setTotalCount(query.getTotalCount());
        return new ResultVo(0, result);
    }

    /**
     * 为list添加条件字段的方法
     * @param itemQueryVo
     * @return
     */
    private List<Condition> innerAddListCondition(ItemQueryVo itemQueryVo){
        List<Condition> conditions = new ArrayList<>();
        //添加条件字段
        String name = itemQueryVo.getName();
        BigDecimal themeItemId = itemQueryVo.getThemeItemId();
        Integer type = itemQueryVo.getType();
        if (name!=null){
            conditions.add(T_METADATA_ITEM.NAME.like("%"+name+"%"));
        }
        if (themeItemId!=null){
            conditions.add(T_METADATA_ITEM.THEME_ITEM_ID.eq(themeItemId));
        }
        if (type!=null){
            conditions.add(T_METADATA_ITEM.TYPE.eq(type));
        }
        if(itemQueryVo.getSourceType()!=null){
            conditions.add(T_METADATA_ITEM.SOURCE_TYPE.eq(itemQueryVo.getSourceType()));
        }
        return conditions;
    }
    /**
     * 元数据条目信息详情查询
     * @param id
     * @return
     */
    @Override
    public ResultVo<ItemDetailVo> detailById(BigDecimal id) {
        TMetadataItemRecord tMetadataItemRecord = itemDao.findById(id);
        if (tMetadataItemRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), null);
        }
        ItemDetailVo itemDetailVo = (ItemDetailVo) VoReTraversalUtil.traversalTwo(tMetadataItemRecord, ItemDetailVo.class);
        //查询创建者名字
        String name = usersDao.getNameByUserId(tMetadataItemRecord.getCreateUser());
        itemDetailVo.setCreateUserName(name);
        return new ResultVo<>(0,itemDetailVo);
    }

    /**
     * 元数据条目添加(批量添加详情)
     * @param itemAddAllsVo
     * @param userId
     * @return
     */
    @Override
    public ResultVo<Object> addAlls(ItemAddAllsVo itemAddAllsVo, String userId,boolean isISI) {
        ResultVo<Object> resultVo = new ResultVo<Object>();
        try {//对name进行判重
            String name = itemAddAllsVo.getName();
            List<TMetadataItemRecord> fetch = itemDao.fetch(T_METADATA_ITEM.NAME, name);
            if (fetch.size()>0){
                return new ResultVo<>(ErrorCode.Existed.getErrorCode(),"添加的元数据条目名字已经存在，请重新输入正确名字!");
            }
            //判断是否有传元数据主题条目id，必须传入元数据主题条目id
            BigDecimal themeItemId = itemAddAllsVo.getThemeItemId();
            if (themeItemId==null){
                return new ResultVo<>(ErrorCode.ParamError.getErrorCode(),"添加元数据条目必须传入对应的元数据主题条目id！");
            }
            //判断传入的元数据主题条目必须在数据库中存在
            TMetadataThemeItemRecord itemRecord = themeItemDao.findById(themeItemId);
            if (itemRecord==null){
                return new ResultVo<>(ErrorCode.NotExists.getErrorCode(),"绑定的元数据主题条目id找不到记录，请从新传入正确的参数！");
            }
            TMetadataItemRecord tItemRecord = (TMetadataItemRecord) VoReTraversalUtil.traversalTwo(itemAddAllsVo, TMetadataItemRecord.class);
            //判断，如果传入了id就用id，如果没有那么就使用随机数生成
            BigDecimal id = itemAddAllsVo.getId();
            if (id!=null){
                tItemRecord.setId(id);
            }else {
                tItemRecord.setId(BigDecimal.valueOf(idGeneratorService.id()));
            }
            if(isISI){
                tItemRecord.setSourceType(ItemSourceType.ISI.getValue());
            }
            BigDecimal metaItemId = tItemRecord.getId();
            //创建人，同时也是更新人
            tItemRecord.setCreateUser(userId);
            tItemRecord.setUpdateUser(userId);
            //同时获取对应详情信息插入到详情表中
            Boolean flag = itemAddAllsVo.getFlag();
            List<DetailAddVo> detailAddVoList = itemAddAllsVo.getDetailAddVoList();
            if (!flag || (detailAddVoList==null || detailAddVoList.size()==0 ) ){
            }else{
                //准备参数，在仓库创建表以及分析表
                CreateHiveTableVo createHiveTableVo = new CreateHiveTableVo();
                createHiveTableVo.setTableName(tItemRecord.getName());
                //别名暂时使用表名
                createHiveTableVo.setDisplayName(tItemRecord.getName());
                createHiveTableVo.setCreated_uuid(tItemRecord.getCreateUser().toString());
                List<CreateHiveColVo> colVos=new ArrayList<>();
                //循环准备col集合
                for (DetailAddVo item:detailAddVoList) {
                    CreateHiveColVo colVo = new CreateHiveColVo();
                    colVo.setColName(item.getColName());
                    Integer colType = item.getColType();
                    String colTypeValue="";
                    if (colType== ColType.TEXT.getValue()){
                        colTypeValue="varchar";
                    }else {
                        colTypeValue="double";
                    }
                    colVo.setDbType(colTypeValue);
                    colVo.setColDisplayName(item.getColDisplayname());
                    colVos.add(colVo);
                }
                createHiveTableVo.setColumns(colVos);
                //调用强制建表得接口执行
                String muUrl=idmanagerBaseUrl+REST_FOR_CREATE_TABLE+"?force=true&isCsv="+isISI;
                String patch = HttpClientUtil.doPostByJson(muUrl, JSON.toJSONString(createHiveTableVo));
                if (patch.equals("fail")){
                    return new ResultVo<>(ErrorCode.UnknownError.getErrorCode(),"向仓库添加表失败！");
                }
            }
            if (detailAddVoList!=null || detailAddVoList.size()>0){
                resultVo= innerAddDetails(detailAddVoList, metaItemId,userId);
            }
            //插入表中
            itemDao.insert(tItemRecord);
            TreeObjectVO treeObjectVO=new TreeObjectVO();
            treeObjectVO.setName(tItemRecord.getName());
            treeObjectVO.setObjectType(TreeObjectVO.TreeObjectType.DATA.toString());
            treeObjectVO.setLeafObjectType(TreeObjectVO.LeafObjectType.TABLE.toString());
            treeObjectVO.setParentType(TreeObjectVO.TreeParentType.SELF.toString());
            treeService.addTreeObject(treeObjectVO,userId, tItemRecord.getId());
            return resultVo;
        } catch (Exception e) {
            e.printStackTrace();
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            return resultVo;
        }
    }

    private ResultVo innerAddDetails(List<DetailAddVo> detailAddVoList,BigDecimal metaItemId,String userId){
        try{
            List<TMetadataDetailRecord> recordList=new ArrayList<>();
            //循环将vo的数据放入record中
            for (DetailAddVo item:detailAddVoList) {
                TMetadataDetailRecord record = (TMetadataDetailRecord)VoReTraversalUtil.traversalTwo(item, TMetadataDetailRecord.class);
                BigDecimal id = BigDecimal.valueOf(idGeneratorService.id());
                record.setId(id);
                record.setMetadataItemId(metaItemId);
                //创建人，同时也是更新人
                record.setCreateUser(userId);
                record.setUpdateUser(userId);
                recordList.add(record);
            }
            //插入数据库
            detailDao.insert(recordList);
            return new ResultVo(0,"success");
        }catch (Exception e){
            e.printStackTrace();
            return new ResultVo(9999);
        }
    }

    @Override
    public ResultVo<Object> updateAlls(ItemAddAllsVo itemUpdateAllsVo, String userId,String accessToken) {
        BigDecimal id = itemUpdateAllsVo.getId();
        String name = itemUpdateAllsVo.getName();
        String schema = itemUpdateAllsVo.getSchema();
        ExistDataQueryVo existDataQueryVo = new ExistDataQueryVo();
        existDataQueryVo.setSchema(schema);
        existDataQueryVo.setTableName(name);
        //去仓库查询是否存在数据
        String patch = HttpClientUtil.doPostByJson(idmanagerBaseUrl+REST_FOR_EXISTS_DATA, JSON.toJSONString(existDataQueryVo));
        if (patch.equals("fail")){
            return new ResultVo<>(ErrorCode.UnknownError.getErrorCode(),"向仓库查询当前需要修改结构的表数据失败！");
        }
        if (!patch.equals("false")){
            return new ResultVo<>(ErrorCode.ParamError.getErrorCode(),"当前修改结构的表在仓库中已经存在数据，不允许在修改结构！");
        }
        if (id==null){
            return new ResultVo<>(ErrorCode.ParamError.getErrorCode(),"需要传入需要修改的数据id！");
        }
        //去数据库查询是否拥有该条信息
        TMetadataItemRecord itemRecord = itemDao.findById(id);
        if (itemRecord==null){
            return new ResultVo<>(ErrorCode.ParamError.getErrorCode(),"需要编辑的id不存在，请重新输入正确的id参数！");
        }
        //先删除当前id关联的信息
        delete(id,accessToken);
        //添加传入的信息
        ResultVo<Object> resultVo = addAlls(itemUpdateAllsVo, userId,false);
        return resultVo;
    }

    @Override
    public boolean isShareTable(String tableName) {
        return itemDao.isShare(tableName);
    }
}
