package com.cdid.service.oozie.vo;

import java.math.BigDecimal;

public class OozieJobListVO {

    private BigDecimal id;

    private String name;

    private String status;

    private Long startTime;

    private Long endTime;

    private String oozieJobId;

    private Long createTime;

    private Boolean isSystem;


    public Long getEndTime() {
        return endTime;
    }

    public void setEndTime(Long endTime) {
        this.endTime = endTime;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getStartTime() {
        return startTime;
    }

    public void setStartTime(Long startTime) {
        this.startTime = startTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getOozieJobId() {
        return oozieJobId;
    }

    public void setOozieJobId(String oozieJobId) {
        this.oozieJobId = oozieJobId;
    }

    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    public Boolean getIsSystem() {
        return isSystem;
    }

    public void setIsSystem(Boolean system) {
        isSystem = system;
    }
}
