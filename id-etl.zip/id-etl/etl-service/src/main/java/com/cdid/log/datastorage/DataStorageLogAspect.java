package com.cdid.log.datastorage;

import com.alibaba.fastjson.JSON;
import com.cdid.api.operate.operatelog.OperateLogService;
import com.cdid.api.operate.operatelog.vo.OperateLogAddVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.token.AccessTokenDao;
import com.cdid.log.GetUserIdUtil;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashSet;
import java.util.Set;

/**
 * @Author LQL
 * @CreateAt 2017/11/29
 */

@Aspect
@Component
public class DataStorageLogAspect {
    @Resource
    private OperateLogService operateLogService;
    @Resource
    private AccessTokenDao accessTokenDao;

    private static Logger logger = LoggerFactory.getLogger(DataStorageLogAspect.class);

    private Set<String> tableName = new HashSet();

    // controller层切点
    @Pointcut("(execution(public * com.cdid.api.datastorage.DataStorageService.*(..)))")
    public void dataStorageAspect() {
    }

    @Before("dataStorageAspect()")
    public void beforeDataStorage(JoinPoint joinPoint) {
        try {
            logger.info("=====beforeDataStorage前置通知开始=====");
            logger.info("请求Param：" + joinPoint.getArgs());
            tableName.add(JSON.toJSONString(joinPoint.getArgs()[0]));
        } catch (Exception e) {
            logger.error("=====beforeDataStorage前置异常通知====");
            logger.error(e.getMessage());
        }
    }

    @AfterReturning(pointcut = "dataStorageAspect()", returning = "retValue")
    public void afterDataStorage(JoinPoint joinPoint, Object retValue) {
        try {
            //从请求中获取userId
            String userId = GetUserIdUtil.getUserId();
            logger.info("=====afterDataStorage后置通知开始=====");
            String className = joinPoint.getTarget().getClass().getName();
            String methodName = joinPoint.getSignature().getName() + "()";
            logger.info("请求方法:" + className);
            logger.info("请求人:" + userId);
            Integer result=0;
            try{
                result  = ((ResultVo) retValue).getErrorCode();
            }catch (Exception e){
            }
            logger.info("返回值：" + result);
            //写入数据库
            logger.info("====写入operateAction====");
            OperateLogAddVo operateLogAddVo = new OperateLogAddVo();
            Integer actionId;
            switch (methodName){
                case "findLogicList()":actionId=1301;break;
                case "findLogicItemList()":actionId=1302;break;
                case "additional()":actionId=1303;break;
                case "findFileData()":actionId=1304;break;
                case "loadOrShare()":actionId=1305;break;
                case "getResult()":actionId=1306;break;
                default:actionId=1300;
            }
            operateLogAddVo.setActionId(actionId);
            operateLogAddVo.setOperatorId(userId);
            operateLogAddVo.setResult(result);
            //操作表暂定为前接口对应表（无操作表）
            operateLogAddVo.setOperateTable("");
            operateLogService.add(operateLogAddVo);
            logger.info("====写入operateLog====");
            /*for (String table : tableName
                    ) {
                logger.info("操作表: " + table);
                operateLogAddVo.setOperateTable(table);
                operateLogService.add(operateLogAddVo);
                logger.info("====写入operateLog====");
            }*/
        } catch (Exception e) {
            logger.error("=====afterDataStorage后置异常通知====");
            logger.error(e.getMessage());
        } finally {
            tableName.clear();
        }
    }
}
