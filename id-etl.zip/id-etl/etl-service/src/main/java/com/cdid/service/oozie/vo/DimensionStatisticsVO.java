package com.cdid.service.oozie.vo;

import java.util.List;

public class DimensionStatisticsVO {

    private String dimension;

    private List<StatisticsResultSimpleVO> resultList;

    public String getDimension() {
        return dimension;
    }

    public void setDimension(String dimension) {
        this.dimension = dimension;
    }

    public List<StatisticsResultSimpleVO> getResultList() {
        return resultList;
    }

    public void setResultList(List<StatisticsResultSimpleVO> resultList) {
        this.resultList = resultList;
    }

    public DimensionStatisticsVO() {
    }

    public DimensionStatisticsVO(String dimension, List<StatisticsResultSimpleVO> resultList) {
        this.dimension = dimension;
        this.resultList = resultList;
    }
}
