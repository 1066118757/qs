package com.cdid.service.datasource;

import com.cdid.api.datasource.JDBCService;
import com.cdid.api.datasource.vo.FieldsVo;
import com.cdid.api.datasource.vo.TableAndFieldVo;
import com.cdid.api.datasource.vo.TablesVo;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.dict.DataSourceType;
import com.cdid.common.vo.JDBCVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.utils.StringUtil;
import com.cdid.utils.jdbc.JDBCUtil;
import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.apache.phoenix.util.SchemaUtil;
import org.bson.Document;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.util.*;

/**
 *  @author         ouzhicheng  
 *  @version        V1.0   
 *  @date           2017/12/06 15:59 
 */
@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class JDBCServiceImpl implements JDBCService {

    @Override
    public ResultVo<Boolean> connectTest(JDBCVo jdbcVo) {
        Boolean flag = false;
        String msg = null;
        //调用服务测试连接
        Integer type = jdbcVo.getType();
        String databaseName = jdbcVo.getDatabaseName();
        //mongodb测试
        if (type == DataSourceType.MONGODB.getValue()) {
            MongoClient mongoClient = null;
            try {
                mongoClient = innerGetMongoDBCon(jdbcVo);
                mongoClient.getDB(databaseName);
                flag = true;
            } catch (Exception e) {
                msg = e.getMessage();
            } finally {
                if (mongoClient != null) {
                    mongoClient.close();
                }
            }
            Integer errcode = flag ? 0 : ErrorCode.UnknownError.getErrorCode();
            return new ResultVo<>(errcode, flag, msg);
        }
       /* if (type == DataSourceType.HBASE.getValue()) {
            return HbaseUtil.connectionTest(jdbcVo);
        }*/
        return JDBCUtil.connectionTest(jdbcVo);
    }

    @Override
    public ResultVo<List<TablesVo>> queryTableName(JDBCVo jdbcVo) {
        Integer type = jdbcVo.getType();
        String databaseName = jdbcVo.getDatabaseName();
        List<TablesVo> list = new ArrayList<>();
        if (type == DataSourceType.MONGODB.getValue()) {
            MongoClient mongoClient = null;
            try {
                mongoClient = innerGetMongoDBCon(jdbcVo);
                DB mongoDatabase = mongoClient.getDB(databaseName);
                //获取集合名
                Set<String> names = mongoDatabase.getCollectionNames();
                for (String name : names) {
                    TablesVo tablesVo = new TablesVo();
                    tablesVo.setTableName(name);
                    list.add(tablesVo);
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (mongoClient != null) {
                    mongoClient.close();
                }
            }
            return new ResultVo<>(0, list);
        }
        if (type == DataSourceType.HBASE.getValue()) {
            Connection connection = null;
            ResultSet rs=null;
            //获取连接
            try {
                connection = JDBCUtil.getConnection(jdbcVo);
                DatabaseMetaData metaData=connection.getMetaData();
                String schema=jdbcVo.getDatabaseName();
                if(StringUtil.isEmpty(schema)){
                    schema=null;
                }
                rs= metaData.getTables(null,schema,null,null);
                TablesVo tablesVo;
                while (rs.next()){
                    tablesVo = new TablesVo();
                    String schemaName = rs.getString("TABLE_SCHEM");
                    String tableName = rs.getString("TABLE_NAME");
                    if(!schemaName.equals("SYSTEM")){
                        tablesVo.setTableName(SchemaUtil.getTableName(schemaName,tableName));
                        list.add(tablesVo);
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            } finally {
               JDBCUtil.releaseConn(connection,null,rs);
            }
            return new ResultVo<>(0, list);
        }
        String nameSql = innerGetTableNameSql(jdbcVo);
        List<Map<String, Object>> result = JDBCUtil.findResult(nameSql, jdbcVo);
        for (Map map : result) {
            TablesVo tablesVo = new TablesVo();
            //hive数据库单独处理
            if (type == DataSourceType.HIVE.getValue()) {
                String tableName = (String) map.get("tableName");
                tablesVo.setTableName(tableName);
            } else {
                for (Object value : map.values()) {
                    String tableName = (String) value;
                    tablesVo.setTableName(tableName);
                }
            }
            list.add(tablesVo);
        }
        return new ResultVo<>(0, list);
    }

    @Override
    public ResultVo<List<TableAndFieldVo>> queryTableFilelds(JDBCVo jdbcVo) {
        try {
            Integer type = jdbcVo.getType();
            List<TableAndFieldVo> list = new ArrayList<>();
            TableAndFieldVo tableAndFieldVo = new TableAndFieldVo();
            tableAndFieldVo.setTableName(jdbcVo.getTableName());
            List<FieldsVo> fields = new ArrayList<>();
            //mongodb单独处理
            if (type == DataSourceType.MONGODB.getValue()) {
                fields = getMongoDBFileds(jdbcVo);
            } else if (type == DataSourceType.HBASE.getValue()) {
                fields = getHBaseFields(jdbcVo);
            } else {
                String nameSql = innerGetFieldNameSql(jdbcVo);
                //执行查询
                List<Map<String, Object>> result = JDBCUtil.findResult(nameSql, jdbcVo);
                for (Map map : result) {
                    FieldsVo fieldsVo = new FieldsVo();
                    //hive数据库需要单独处理
                    if (type == DataSourceType.HIVE.getValue()) {
                        String columnName = (String) map.get("col_name");
                        String dataType = (String) map.get("data_type");
                        fieldsVo.setFieldType(dataType);
                        fieldsVo.setFieldName(columnName);
                    } else {
                        for (Object value : map.values()) {
                            if (fieldsVo.getFieldName() == null) {
                                String columnName = (String) value;
                                fieldsVo.setFieldName(columnName);
                            } else {
                                String columnType = (String) value;
                                fieldsVo.setFieldType(columnType);
                            }
                        }
                    }
                    fields.add(fieldsVo);
                }
            }
            FieldsVo fieldsVo = new FieldsVo();
            fieldsVo.setFieldName("id_import_time");
            fields.remove(fieldsVo);
            tableAndFieldVo.setFields(fields);
            list.add(tableAndFieldVo);
            return new ResultVo<>(0, list);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResultVo<>(ErrorCode.UnknownError.getErrorCode());
        }
    }

    private List<FieldsVo> getMongoDBFileds(JDBCVo jdbcVo) {
        MongoClient mongoClient = null;
        List<FieldsVo> fields = new ArrayList<>();
        try {
            mongoClient = innerGetMongoDBCon(jdbcVo);
            MongoDatabase mongoDatabase = mongoClient.getDatabase(jdbcVo.getDatabaseName());
            //获取集合名
            MongoCollection<Document> collection = mongoDatabase.getCollection(jdbcVo.getTableName());
            FindIterable<Document> documents = collection.find();
            //返回Document里面的key
            for (Document item : documents) {
                String json = item.toJson();
                JSONObject jsonObject = new JSONObject(json);
                Iterator keys = jsonObject.keys();
                while (keys.hasNext()) {
                    FieldsVo fieldsVo = new FieldsVo();
                    String keyName = keys.next().toString();
                    fieldsVo.setFieldName(keyName);
                    fields.add(fieldsVo);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (mongoClient != null) {
                mongoClient.close();
            }
        }
        return fields;
    }

    private List<FieldsVo> getHBaseFields(JDBCVo jdbcVo) {
        Connection connection = null;
        ResultSet rs=null;
        List<FieldsVo> fieldsVoList = new ArrayList<>();
        if(StringUtil.isEmpty(jdbcVo.getTableName())){
            return fieldsVoList;
        }
        try {
            connection = JDBCUtil.getConnection(jdbcVo);
            DatabaseMetaData metaData=connection.getMetaData();
            String schema=jdbcVo.getDatabaseName();
            if(StringUtil.isEmpty(schema)){
                schema=null;
            }
            String tableName=jdbcVo.getTableName();
            int index=tableName.indexOf(".");
            if(index!=-1){
                tableName=tableName.substring(index+1,tableName.length());
            }
            rs= metaData.getColumns(null,schema,tableName,"%");
            FieldsVo fieldsVo;
            while(rs.next()){
                fieldsVo=new FieldsVo();
                String columnName=rs.getString("COLUMN_NAME");
                fieldsVo.setFieldName(columnName);
                fieldsVo.setFieldType(rs.getString("TYPE_NAME"));
                if(!"id_import_time".equalsIgnoreCase(columnName)){
                    fieldsVoList.add(fieldsVo);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.releaseConn(connection,null,rs);
        }
        return fieldsVoList;
    }

    /**
     * 依据不同数据库获取查询表名的不同sql
     *
     * @param jdbcVo
     * @return
     */
    private String innerGetTableNameSql(JDBCVo jdbcVo) {
        Integer type = jdbcVo.getType();
        String databaseName = jdbcVo.getDatabaseName();
        if (type == DataSourceType.MYSQL.getValue()
                || type == DataSourceType.INFO_BRIGHT.getValue()) {
            String baseSql = "select table_name from information_schema.tables where table_schema='DATASOURCE' and table_type='base table'";
            baseSql = baseSql.replaceAll("DATASOURCE", databaseName);
            return baseSql;
        }
        if (type == DataSourceType.ORACLE.getValue()) {
            String baseSql = "select table_name from user_tables";
            return baseSql;
        }
        if (type == DataSourceType.POSTGRE_SQL.getValue()) {
            String baseSql = "select table_name from information_schema.tables where table_schema='DATASOURCE'";
            baseSql = baseSql.replaceAll("DATASOURCE", databaseName);
            return baseSql;
        }
        if (type == DataSourceType.SQL_SERVER.getValue()) {
            //String baseSql = "SELECT name FROM SysObjects Where XType='U' ORDER BY Name";
            String baseSql = "SELECT name FROM dbo.sysobjects Where XType='U' ORDER BY Name";
            //baseSql = baseSql.replaceAll("DATASOURCE", databaseName);
            return baseSql;
        }
        if (type == DataSourceType.HIVE.getValue()) {
            String baseSql = "show tables";
            //baseSql = baseSql.replaceAll("DATASOURCE", databaseName);
            return baseSql;
        }
        return null;
    }

    /**
     * 依据不同数据库以及表获取查询字段名的不同sql
     *
     * @param jdbcVo
     * @return
     */
    private String innerGetFieldNameSql(JDBCVo jdbcVo) {
        Integer type = jdbcVo.getType();
        String databaseName = jdbcVo.getDatabaseName();
        String tableName = jdbcVo.getTableName();
        if (type == DataSourceType.MYSQL.getValue()
                || type == DataSourceType.INFO_BRIGHT.getValue()
                || type == DataSourceType.POSTGRE_SQL.getValue()) {
            String baseSql = "select column_name,data_type from information_schema.columns where table_schema='DATABASENAME' and table_name='TABLENAME'";
            baseSql = baseSql.replaceAll("DATABASENAME", databaseName);
            baseSql = baseSql.replaceAll("TABLENAME", tableName);
            return baseSql;
        }
        if (type == DataSourceType.ORACLE.getValue()) {
            String baseSql = "select   column_name,data_type   from   user_tab_columns   where   table_name='TABLENAME'";
            baseSql = baseSql.replaceAll("TABLENAME", tableName);
            return baseSql;
        }
        if (type == DataSourceType.SQL_SERVER.getValue()) {
            String baseSql = "select COLUMN_NAME,DATA_TYPE  from INFORMATION_SCHEMA.COLUMNS " +
                    "where TABLE_NAME in  ( select name from sysobjects where type = 'U') " +
                    "and table_name='TABLENAME'";
            baseSql = baseSql.replaceAll("TABLENAME", tableName);
            return baseSql;
        }
        if (type == DataSourceType.HIVE.getValue()) {
            String baseSql = "desc TABLENAME";
            baseSql = baseSql.replaceAll("TABLENAME", tableName);
            return baseSql;
        }
        return null;
    }

    private MongoClient innerGetMongoDBCon(JDBCVo jdbcVo) {
        String url = jdbcVo.getUrl();
        String port = jdbcVo.getPort();
        MongoClient mongoClient = new MongoClient(url, Integer.valueOf(port));
        return mongoClient;
    }
}
