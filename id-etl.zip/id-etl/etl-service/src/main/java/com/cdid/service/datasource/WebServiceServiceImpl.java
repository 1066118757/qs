package com.cdid.service.datasource;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONPObject;
import com.cdid.api.datasource.DataSourceService;
import com.cdid.api.datasource.WebServiceService;
import com.cdid.api.datasource.vo.DataSourceDetailVo;
import com.cdid.api.datasource.vo.WebServiceVo;
import com.cdid.api.jobconf.vo.JobConfDetailVo;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.dict.DataSourceType;
import com.cdid.common.vo.ResponseVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.utils.HttpClientUtil;
import com.cdid.utils.jdbc.ConfKey;
import io.swagger.models.auth.In;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/06 15:59 
 */
@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class WebServiceServiceImpl implements WebServiceService{

    @Autowired
    private DataSourceService dataSourceService;
    @Override
    public ResultVo<ResponseVo> connectTest(WebServiceVo webServiceVo) {
        //调用服务测试连接
//        Boolean flag = Boolean.FALSE;

        String requestMethod = webServiceVo.getRequestMethod();
        String requestUrl = webServiceVo.getRequestUrl();
        if(StringUtils.isEmpty(requestUrl) || StringUtils.isEmpty(requestMethod)){
            return new ResultVo<>(ErrorCode.ParamError.getErrorCode(),null,"requestUrl,requestMethod不能为null");
        }

        ResultVo<ResponseVo> resultVo = getResponseStr(webServiceVo);
        return resultVo;
//        if(resultVo != null && resultVo.getErrorCode() == 0){
//            flag = Boolean.TRUE;
//            return new ResultVo<>(0,resultVo.getData());
//        }else {
//            flag = Boolean.FALSE;
//            return new ResultVo<>(ErrorCode.UnknownError.getErrorCode(),resultVo.getData());
//        }
    }


    private ResultVo<ResponseVo> getResponseStr(WebServiceVo webServiceVo){
        String body = webServiceVo.getBody();
        Map<String, String> headers = (Map<String, String>)JSONArray.parse(webServiceVo.getHeaders());
        String requestMethod = webServiceVo.getRequestMethod();
        String requestUrl = webServiceVo.getRequestUrl();

        String responseStr = null;

        ResultVo<ResponseVo> resultVo = new ResultVo<>();

        if(!StringUtils.isEmpty(requestMethod) && "get".equals(requestMethod.toLowerCase())){
            if(StringUtils.isEmpty(body)){
                resultVo = HttpClientUtil.sendGet(requestUrl,null,headers);
                return resultVo;
            }else {
                resultVo = HttpClientUtil.sendGet(requestUrl,JSON.parseObject(body, Map.class),headers);
                return resultVo;
            }
        }
        String contentType = headers.get("Content-Type");
        contentType = contentType == null ? headers.get("content-type") : contentType;
        if(!StringUtils.isEmpty(requestMethod) && "post".equals(requestMethod.toLowerCase()) && contentType.contains("application/json")){
            resultVo = HttpClientUtil.doPostByJson(requestUrl,body,headers);
            return resultVo;
        }
        if(!StringUtils.isEmpty(requestMethod) && "post".equals(requestMethod.toLowerCase()) && !contentType.contains("application/json")){
            if(StringUtils.isEmpty(body)){
                resultVo = HttpClientUtil.doPostByFrom(requestUrl,null,headers);
                return resultVo;
            }else {
                resultVo = HttpClientUtil.doPostByFrom(requestUrl, JSON.parseObject(body, Map.class),headers);
                return resultVo;
            }
        }
        return null;
    }


    @Override
    public ResultVo<ResponseVo> getResponse(WebServiceVo webServiceVo) {
        BigDecimal dataSourceId = webServiceVo.getDataSourceId();
        ResultVo<ResponseVo> responseVoResultVo = new ResultVo();
        if(dataSourceId == null){
            String requestMethod = webServiceVo.getRequestMethod();
            String requestUrl = webServiceVo.getRequestUrl();
            if(StringUtils.isEmpty(requestUrl) || StringUtils.isEmpty(requestMethod)){
                return new ResultVo<>(ErrorCode.ParamError.getErrorCode(),null,"requestUrl,requestMethod不能为null");
            }
            return getResponseStr(webServiceVo);
        }else {
            ResultVo<DataSourceDetailVo> dataSourceDetailVoResultVo = null;
            try {
                dataSourceDetailVoResultVo = dataSourceService.findById(dataSourceId);
                DataSourceDetailVo data = dataSourceDetailVoResultVo.getData();
                Map<String,String> confMap = new HashMap<>();
                List<JobConfDetailVo> confs = data.getConfs();
                for(JobConfDetailVo conf:confs){
                    confMap.put(conf.getKey(),conf.getValue());
                }//获取请求方式
                String requestMethod = confMap.get(ConfKey.REQUEST_METHOD);
                String requestUrl = confMap.get(ConfKey.REQUEST_URL);
                String headers = confMap.get(ConfKey.HEADERS);
                String body = confMap.get(ConfKey.BODY);
                webServiceVo = new WebServiceVo();
                webServiceVo.setBody(body);
                webServiceVo.setHeaders(headers);
                webServiceVo.setRequestMethod(requestMethod);
                webServiceVo.setRequestUrl(requestUrl);
                responseVoResultVo = getResponseStr(webServiceVo);
            }catch (Exception e){
                e.printStackTrace();
                responseVoResultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            }
            return responseVoResultVo;
        }
    }
}
