/**
 * Copyright 2017 Institute of Computing Technology, Chinese Academy of Sciences.
 * Licensed under the terms of the Apache 2.0 license.
 * Please see LICENSE file in the project root for terms
 */
package com.cdid.service.oozie.workflow;

import com.cdid.service.oozie.command.Parameter;
import org.dom4j.*;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

import java.io.StringWriter;
import java.util.*;

/**
 * The workflow graph description
 */
public class WFGraph {

    protected Map<String, NodeDef> nodeMap = new HashMap<String, NodeDef>();

    protected NodeDef start = new StartNodeDef();
    protected NodeDef end = new EndNodeDef();

    /**
     * nodes that will be execute in the Oozie Job
     *
     * @param action the action added to Oozie
     * @throws Exception
     */
    public void addActionNode(NodeDef action) throws Exception {
        nodeMap.put(action.getName(), action);
    }

    /**
     * Add edge from source node to destination node
     *
     * @param srcNodeId   the source node id
     * @param dstNodeId   the destination node id
     */
    public void addEdge(String srcNodeId, String dstNodeId) {
        NodeDef srcNode = nodeMap.get(srcNodeId);
        NodeDef dstNode = nodeMap.get(dstNodeId);
        if (srcNode != null && dstNode != null) {
            srcNode.addOutNode(dstNode);
            dstNode.addInNode(srcNode);
        }
    }

    /**
     * Transform the Graph into an workflow xml definition
     *
     * @param jobname the job name of Oozie job, can't be null
     * @return workflow xml
     */
    public String toWorkflow(String jobname) {
        Namespace xmlns = new Namespace("", "uri:oozie:workflow:0.4"); // root namespace uri
        QName qName = QName.get("workflow-app", xmlns); // your root element's name
        Element workflow = DocumentHelper.createElement(qName);
        Document xmldoc = DocumentHelper.createDocument(workflow);
        // Create workflow root
        workflow.addAttribute("xmlns", "uri:oozie:workflow:0.4");
        // <workflow-app name='xxx'></workflow-app>
        if (jobname == null || "".equals(jobname))
            workflow.addAttribute("name", "Not specified");
        else
            workflow.addAttribute("name", jobname);

        Queue<NodeDef> que = new LinkedList<NodeDef>();
        que.add(start);

        while (!que.isEmpty()) {
            NodeDef cur = que.remove();

            cur.append2XML(workflow);

            for (NodeDef toNode : cur.getOutNodes()) {
                toNode.delInNode(cur);
                if (toNode.getInDegree() == 0)
                    que.add(toNode);
            }
        }

        // Set XML document format
        OutputFormat outputFormat = OutputFormat.createPrettyPrint();
        // Set XML encoding, use the specified encoding to save the XML document to the string, it can be specified GBK or ISO8859-1
        outputFormat.setEncoding("UTF-8");
        outputFormat.setSuppressDeclaration(true); // Whether generate xml header
        outputFormat.setIndent(true); // Whether set indentation
        outputFormat.setIndent("    "); // Implement indentation with four spaces
        outputFormat.setNewlines(true); // Set whether to wrap

        try {
            // stringWriter is used to save xml document
            StringWriter stringWriter = new StringWriter();
            // xmlWriter is used to write XML document to string(tool)
            XMLWriter xmlWriter = new XMLWriter(stringWriter, outputFormat);

            // Write the created XML document into the string
            xmlWriter.write(xmldoc);

            xmlWriter.close();

            System.out.println(stringWriter.toString().trim());
            // Print the string, that is, the XML document
            return stringWriter.toString().trim();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }


}
