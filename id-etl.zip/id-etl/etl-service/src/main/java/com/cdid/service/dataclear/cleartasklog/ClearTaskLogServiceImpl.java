package com.cdid.service.dataclear.cleartasklog;

import com.cdid.api.common.IDGeneratorService;
import com.cdid.api.dataclear.cleartasklog.ClearTaskLogService;
import com.cdid.api.dataclear.cleartasklog.vo.*;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.dict.TaskResult;
import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.dataclear.cleartask.ClearTaskDao;
import com.cdid.dao.dataclear.cleartasklog.ClearTaskLogDao;
import com.cdid.dao.user.UsersDao;
import com.cdid.jooq.tables.records.TClearTaskLogRecord;
import com.cdid.jooq.tables.records.TClearTaskRecord;
import com.cdid.utils.VoReTraversalUtil;
import org.jooq.Condition;
import org.jooq.SortField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import static com.cdid.jooq.tables.TClearTaskLog.T_CLEAR_TASK_LOG;

/**
 * 数据整理任务日志的实现
 */
@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class ClearTaskLogServiceImpl implements ClearTaskLogService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ClearTaskLogDao clearTaskLogDao;
    @Autowired
    private IDGeneratorService<Long> idGeneratorService;
    @Autowired
    private UsersDao usersDao;

    @Autowired
    private ClearTaskDao clearTaskDao;

    /**
     * 数据整理任务日志添加
     *
     * @param clearTaskLogAddVo
     * @param userId
     * @return
     */
    @Override
    public ResultVo<Object> add(ClearTaskLogAddVo clearTaskLogAddVo, String userId) {
        ResultVo<Object> resultVo = new ResultVo<Object>();
        try {
            TClearTaskLogRecord tClearTaskLogRecord = (TClearTaskLogRecord) VoReTraversalUtil.traversalTwo(clearTaskLogAddVo, TClearTaskLogRecord.class);
            tClearTaskLogRecord.setId(BigDecimal.valueOf(idGeneratorService.id()));
            //创建人，同时也是更新人
            tClearTaskLogRecord.setCreateUser(userId);
            //插入表中
            clearTaskLogDao.insert(tClearTaskLogRecord);
            resultVo.setData("success");
            return resultVo;
        } catch (Exception e) {
            e.printStackTrace();
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            return resultVo;
        }
    }

    /**
     * 数据整理任务日志更新
     *
     * @param clearTaskLogUpdateVo
     * @param userId
     * @return
     */
    @Override
    public ResultVo<Object> update(ClearTaskLogUpdateVo clearTaskLogUpdateVo, String userId) {
        ResultVo<Object> resultVo = new ResultVo<Object>();
        try {
            //从数据库查询出需要修改的信息
            TClearTaskLogRecord tClearTaskLogRecord = clearTaskLogDao.findById(clearTaskLogUpdateVo.getId());
            if (tClearTaskLogRecord == null) {
                return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
            }
            //判断，xxx情况不允许更新

            //调用方法设置值
            tClearTaskLogRecord = (TClearTaskLogRecord) VoReTraversalUtil.traversalTwo(clearTaskLogUpdateVo, TClearTaskLogRecord.class);
            clearTaskLogDao.update(tClearTaskLogRecord);
            resultVo.setData("success");
            return resultVo;
        } catch (Exception e) {
            e.printStackTrace();
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            return resultVo;
        }
    }

    /**
     * 数据整理任务日志删除
     *
     * @param id
     * @return
     */
    @Override
    public ResultVo<Object> delete(BigDecimal id) {
        //查询是否存在
        TClearTaskLogRecord tClearTaskLogRecord = clearTaskLogDao.findById(id);
        if (tClearTaskLogRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), false);
        }
        //判断，xxx情况不允许删除

        //删除
        List<BigDecimal> ids = new ArrayList<>();
        ids.add(id);
        clearTaskLogDao.deleteById(ids);
        return new ResultVo<>(0, true);

    }

    /**
     * 数据整理任务日志列表查询
     *
     * @param clearTaskLogQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    @Override
    public ResultVo<PageVo<List<ClearTaskLogListVo>>> list(ClearTaskLogQueryVo clearTaskLogQueryVo, String userId, Integer page, Integer size) {
        List<SortField<?>> sortList = new ArrayList<>();
        //添加排序字段
        sortList.add(T_CLEAR_TASK_LOG.START_TIME.desc());
        //添加条件字段
        List<Condition> conditions = innerAddListCondition(clearTaskLogQueryVo);
        //查询赋值返回
        PageVo<TClearTaskLogRecord> query = clearTaskLogDao.fetchByPage(conditions, new OffsetPagingVo(page, size), sortList);
        List<TClearTaskLogRecord> tClearTaskLogRecords;
        tClearTaskLogRecords = query.getPageData();
        List<ClearTaskLogListVo> list = new ArrayList<>();
        for (TClearTaskLogRecord tClearTaskLogRecord : tClearTaskLogRecords
                ) {
            ClearTaskLogListVo clearTaskLogListVo = (ClearTaskLogListVo) VoReTraversalUtil.traversalTwo(tClearTaskLogRecord, ClearTaskLogListVo.class);
            //查询创建者名字
            String name = usersDao.getNameByUserId(tClearTaskLogRecord.getCreateUser());
            clearTaskLogListVo.setCreateUserName(name);
            list.add(clearTaskLogListVo);
        }
        PageVo<ClearTaskLogListVo> result = new PageVo<>();
        result.setPageData(list);
        result.setTotalCount(query.getTotalCount());
        return new ResultVo(0, result);
    }

    /**
     * 为list添加条件字段的方法
     *
     * @param clearTaskLogQueryVo
     * @return
     */
    private List<Condition> innerAddListCondition(ClearTaskLogQueryVo clearTaskLogQueryVo) {
        List<Condition> conditions = new ArrayList<>();
        //添加条件字段
        BigDecimal taskId = clearTaskLogQueryVo.getTaskId();
        if (taskId!=null){
            conditions.add(T_CLEAR_TASK_LOG.TASK_ID.eq(taskId));
        }
        return conditions;
    }

    /**
     * 数据整理任务日志详情查询
     *
     * @param id
     * @return
     */
    @Override
    public ResultVo<ClearTaskLogDetailVo> clearTaskLogById(BigDecimal id) {
        TClearTaskLogRecord tClearTaskLogRecord = clearTaskLogDao.findById(id);
        if (tClearTaskLogRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), null);
        }
        ClearTaskLogDetailVo clearTaskLogClearTaskLogVo = (ClearTaskLogDetailVo) VoReTraversalUtil.traversalTwo(tClearTaskLogRecord, ClearTaskLogDetailVo.class);
        //查询创建者名字
        String name = usersDao.getNameByUserId(tClearTaskLogRecord.getCreateUser());
        clearTaskLogClearTaskLogVo.setCreateUserName(name);
        return new ResultVo<>(0, clearTaskLogClearTaskLogVo);
    }

    /**
     * 数据整理任务日志依据是否有id更新或者保存
     * @param clearTaskLogUpdateVo
     * @param userId
     * @return
     */
    @Override
    public ResultVo<BigDecimal> updateOrSave(ClearTaskLogUpdateVo clearTaskLogUpdateVo, String userId) {
        ResultVo<BigDecimal> resultVo = new ResultVo<BigDecimal>();
        try {
            BigDecimal id = clearTaskLogUpdateVo.getId();
            if (id!=null){
                //从数据库查询出需要修改的信息
                TClearTaskLogRecord tClearTaskLogRecord = clearTaskLogDao.findById(clearTaskLogUpdateVo.getId());
                if (tClearTaskLogRecord == null) {
                    return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
                }
                //调用方法设置值
                tClearTaskLogRecord = (TClearTaskLogRecord) VoReTraversalUtil.traversalTwo(clearTaskLogUpdateVo, TClearTaskLogRecord.class);
                clearTaskLogDao.update(tClearTaskLogRecord);
                resultVo.setData(id);
            }else {
                TClearTaskLogRecord tClearTaskLogRecord = (TClearTaskLogRecord) VoReTraversalUtil.traversalTwo(clearTaskLogUpdateVo, TClearTaskLogRecord.class);
                id = BigDecimal.valueOf(idGeneratorService.id());
                tClearTaskLogRecord.setId(id);
                //创建人，同时也是更新人
                tClearTaskLogRecord.setCreateUser(userId);
                //插入表中
                clearTaskLogDao.insert(tClearTaskLogRecord);
                resultVo.setData(id);
            }
            return resultVo;
        } catch (Exception e) {
            e.printStackTrace();
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            return resultVo;
        }
    }

    @Override
    public Boolean taskIsRunning(BigDecimal taskId) {
        TClearTaskLogRecord logRecord= clearTaskLogDao.findTaskLatestLog(taskId);
        return logRecord!=null&&logRecord.getResult()!=null
                && (logRecord.getResult().equals(TaskResult.RUNNING.getValue()) || logRecord.getResult().equals(TaskResult.SUBMITING.getValue()))
                &&(System.currentTimeMillis()-logRecord.getStartTime().getTime())<3600*1000;
    }

    @Override
    public BigDecimal lastLogIdByTaskId(BigDecimal taskId) {
        TClearTaskLogRecord logRecord= clearTaskLogDao.findTaskLatestLog(taskId);
        if (logRecord!=null){
            return logRecord.getId();
        }
        return null;
    }

    @Override
    public void taskScheduleFail(BigDecimal taskId, String errorMessage) {
        TClearTaskLogRecord logRecord= clearTaskLogDao.findTaskLatestLog(taskId);
        if(logRecord!=null &&logRecord.getResult() !=null && logRecord.getResult().equals(TaskResult.RUNNING.getValue())){
            logRecord.setEndTime(new Timestamp(System.currentTimeMillis()));
            logRecord.setResult(TaskResult.FAIL.getValue());
            logRecord.setTaskLog(errorMessage);
            clearTaskLogDao.update(logRecord);
        }else{
            logRecord=new TClearTaskLogRecord();
            logRecord.setId(BigDecimal.valueOf(idGeneratorService.id()));
            logRecord.setTaskId(taskId);
            logRecord.setStartTime(new Timestamp(System.currentTimeMillis()));
            logRecord.setEndTime(new Timestamp(System.currentTimeMillis()));
            logRecord.setTaskLog(errorMessage);
            logRecord.setResult(TaskResult.FAIL.getValue());
            clearTaskLogDao.insert(logRecord);
        }
        TClearTaskRecord taskRecord=clearTaskDao.findById(taskId);
        taskRecord.setNearEndTime(new Timestamp(System.currentTimeMillis()));
        taskRecord.setNearResult(TaskResult.FAIL.getValue());
        clearTaskDao.update(taskRecord);
    }
}
