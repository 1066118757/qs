package com.cdid.service.dataclear.clearrule;

import com.cdid.api.common.IDGeneratorService;
import com.cdid.api.dataclear.clearrule.ClearRuleService;
import com.cdid.api.dataclear.clearrule.vo.*;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.dataclear.clearrule.ClearRuleDao;
import com.cdid.dao.user.UsersDao;
import com.cdid.jooq.tables.records.TClearRuleRecord;
import com.cdid.utils.VoReTraversalUtil;
import org.jooq.Condition;
import org.jooq.SortField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import static com.cdid.jooq.tables.TClearRule.T_CLEAR_RULE;

/**
 * 数据整理规则的实现
 */
@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class ClearRuleServiceImpl implements ClearRuleService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ClearRuleDao clearRuleDao;
    @Autowired
    private IDGeneratorService<Long> idGeneratorService;
    @Autowired
    private UsersDao usersDao;

    /**
     * 数据整理规则添加
     *
     * @param clearRuleAddVo
     * @param userId
     * @return
     */
    @Override
    public ResultVo<Object> add(ClearRuleAddVo clearRuleAddVo, String userId) {
        ResultVo<Object> resultVo = new ResultVo<Object>();
        try {
            TClearRuleRecord tClearRuleRecord = (TClearRuleRecord) VoReTraversalUtil.traversalTwo(clearRuleAddVo, TClearRuleRecord.class);
            BigDecimal id = BigDecimal.valueOf(idGeneratorService.id());
            tClearRuleRecord.setId(id);
            //创建人，同时也是更新人
            tClearRuleRecord.setCreateUser(userId);
            tClearRuleRecord.setUpdateUser(userId);
            //插入表中
            clearRuleDao.insert(tClearRuleRecord);
            //获取参数集合并且插入规则参数表
            /*List<RuleParamAddVo> ruleParamAddVos = clearRuleAddVo.getRuleParamAddVos();
            for (RuleParamAddVo item:ruleParamAddVos) {
                item.setClearRuleId(id);
            }
            ruleParamService.add(ruleParamAddVos,userId);*/
            resultVo.setData("success");
            return resultVo;
        } catch (Exception e) {
            e.printStackTrace();
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            return resultVo;
        }
    }

    /**
     * 数据整理规则更新
     *
     * @param clearRuleUpdateVo
     * @param userId
     * @return
     */
    @Override
    public ResultVo<Object> update(ClearRuleUpdateVo clearRuleUpdateVo, String userId) {
        ResultVo<Object> resultVo = new ResultVo<Object>();
        try {
            //从数据库查询出需要修改的信息
            TClearRuleRecord tClearRuleRecord = clearRuleDao.findById(clearRuleUpdateVo.getId());
            if (tClearRuleRecord == null) {
                return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
            }
            //判断，xxx情况不允许更新

            //调用方法设置值
            tClearRuleRecord = (TClearRuleRecord) VoReTraversalUtil.traversalTwo(clearRuleUpdateVo, TClearRuleRecord.class);
            //更新人
            tClearRuleRecord.setUpdateUser(userId);
            //更新时间
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            tClearRuleRecord.setUpdateTime(timestamp);
            clearRuleDao.update(tClearRuleRecord);
            //获取参数集合，先删除参数集合在增加
            //删除
            /*ruleParamService.deleteByRuleId(clearRuleUpdateVo.getId());
            //新增
            List<RuleParamAddVo> ruleParamAddVos = clearRuleUpdateVo.getRuleParamAddVos();
            for (RuleParamAddVo item:ruleParamAddVos) {
                item.setClearRuleId(clearRuleUpdateVo.getId());
            }
            ruleParamService.add(ruleParamAddVos,userId);*/
            resultVo.setData("success");
            return resultVo;
        } catch (Exception e) {
            e.printStackTrace();
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            return resultVo;
        }
    }

    /**
     * 数据整理规则删除
     *
     * @param id
     * @return
     */
    @Override
    public ResultVo<Object> delete(BigDecimal id) {
        //查询是否存在
        TClearRuleRecord tClearRuleRecord = clearRuleDao.findById(id);
        if (tClearRuleRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), false);
        }
        //判断，xxx情况不允许删除

        //删除
        List<BigDecimal> ids = new ArrayList<>();
        ids.add(id);
        clearRuleDao.deleteById(ids);
        return new ResultVo<>(0, true);

    }

    /**
     * 数据整理规则列表查询
     *
     * @param clearRuleQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    @Override
    public ResultVo<PageVo<List<ClearRuleListVo>>> list(ClearRuleQueryVo clearRuleQueryVo, String userId, Integer page, Integer size) {
        List<SortField<?>> sortList = new ArrayList<>();
        //添加排序字段
        sortList.add(T_CLEAR_RULE.UPDATE_TIME.desc());
        //添加条件字段
        List<Condition> conditions = innerAddListCondition(clearRuleQueryVo);
        //权限限制，只能看到自己创建的规则
        /*if (userId!=null){
            conditions.add(T_CLEAR_RULE.CREATE_USER.eq(userId));
        }*/
        //查询赋值返回
        PageVo<TClearRuleRecord> query = clearRuleDao.fetchByPage(conditions, new OffsetPagingVo(page, size), sortList);
        List<TClearRuleRecord> tClearRuleRecords;
        tClearRuleRecords = query.getPageData();
        List<ClearRuleListVo> list = new ArrayList<>();
        for (TClearRuleRecord tClearRuleRecord : tClearRuleRecords
                ) {
            ClearRuleListVo clearRuleListVo = (ClearRuleListVo) VoReTraversalUtil.traversalTwo(tClearRuleRecord, ClearRuleListVo.class);
            //查询创建者姓名
            String name = usersDao.getNameByUserId(tClearRuleRecord.getCreateUser());
            clearRuleListVo.setCreateUserName(name);
            list.add(clearRuleListVo);
        }
        PageVo<ClearRuleListVo> result = new PageVo<>();
        result.setPageData(list);
        result.setTotalCount(query.getTotalCount());
        return new ResultVo(0, result);
    }

    /**
     * 为list添加条件字段的方法
     *
     * @param clearRuleQueryVo
     * @return
     */
    private List<Condition> innerAddListCondition(ClearRuleQueryVo clearRuleQueryVo) {
        List<Condition> conditions = new ArrayList<>();
        //添加条件字段
        String name = clearRuleQueryVo.getName();
        Integer ruleType = clearRuleQueryVo.getRuleType();
        Integer state = clearRuleQueryVo.getState();
        if (name!=null){
            conditions.add(T_CLEAR_RULE.NAME.like("%"+name+"%"));
        }
        if (ruleType!=null){
            conditions.add(T_CLEAR_RULE.RULE_TYPE.eq(ruleType));
        }
        if (state!=null){
            conditions.add(T_CLEAR_RULE.STATE.eq(state));
        }
        String summary = clearRuleQueryVo.getSummary();
        Integer scriptType = clearRuleQueryVo.getScriptType();
        String scriptCode = clearRuleQueryVo.getScriptCode();
        if (summary!=null){
            conditions.add(T_CLEAR_RULE.SUMMARY.like("%"+summary+"%"));
        }
        if (scriptType!=null){
            conditions.add(T_CLEAR_RULE.SCRIPT_TYPE.eq(scriptType));
        }
        if (scriptCode!=null){
            conditions.add(T_CLEAR_RULE.SCRIPT_CODE.like("%"+scriptCode+"%"));
        }
        return conditions;
    }

    /**
     * 数据整理规则详情查询
     *
     * @param id
     * @return
     */
    @Override
    public ResultVo<ClearRuleDetailVo> clearRuleById(BigDecimal id) {
        TClearRuleRecord tClearRuleRecord = clearRuleDao.findById(id);
        if (tClearRuleRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), null);
        }
        ClearRuleDetailVo clearRuleClearRuleVo = (ClearRuleDetailVo) VoReTraversalUtil.traversalTwo(tClearRuleRecord, ClearRuleDetailVo.class);
        //查询创建者姓名
        String name = usersDao.getNameByUserId(tClearRuleRecord.getCreateUser());
        clearRuleClearRuleVo.setCreateUserName(name);
        return new ResultVo<>(0, clearRuleClearRuleVo);
    }

}
