package com.cdid.service.metadata.themeitem;

import com.cdid.api.common.IDGeneratorService;
import com.cdid.api.metadata.themeitem.ThemeItemService;
import com.cdid.api.metadata.themeitem.vo.*;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.metadata.item.ItemDao;
import com.cdid.dao.metadata.theme.ThemeDao;
import com.cdid.dao.metadata.themeitem.ThemeItemDao;
import com.cdid.jooq.tables.records.TMetadataThemeItemRecord;
import com.cdid.jooq.tables.records.TMetadataThemeRecord;
import com.cdid.utils.VoReTraversalUtil;
import org.apache.commons.lang3.StringUtils;
import org.jooq.Condition;
import org.jooq.SortField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import static com.cdid.jooq.tables.TMetadataItem.T_METADATA_ITEM;
import static com.cdid.jooq.tables.TMetadataThemeItem.T_METADATA_THEME_ITEM;

/**
 * 元数据主题条目的实现
 */
@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class ThemeItemServiceImpl implements ThemeItemService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ThemeItemDao themeItemDao;
    @Autowired
    private ItemDao itemDao;
    @Autowired
    private ThemeDao themeDao;
    @Autowired
    private IDGeneratorService<Long> idGeneratorService;

    /**
     * 元数据主题条目信息添加
     * @param themeItemAddVo
     * @param userId
     * @return
     */
    @Override
    public ResultVo<Object> add(ThemeItemAddVo themeItemAddVo, String userId) {
        ResultVo<Object> resultVo = new ResultVo<Object>();

        try {
            //判断是否有传主题id，必须传入主题id
            BigDecimal themeId = themeItemAddVo.getThemeId();
            if (themeId==null){
                return new ResultVo<>(ErrorCode.ParamError.getErrorCode(),"添加元数据主题条目必须传入对应的主题id！");
            }
            //判断传入的主题id必须在数据库中存在
            TMetadataThemeRecord themeRecord = themeDao.findById(themeId);
            if (themeRecord==null){
                return new ResultVo<>(ErrorCode.NotExists.getErrorCode(),"绑定的主题id找不到记录，请从新传入正确的参数！");
            }
            TMetadataThemeItemRecord tThemeItemRecord = (TMetadataThemeItemRecord) VoReTraversalUtil.traversalTwo(themeItemAddVo, TMetadataThemeItemRecord.class);
            tThemeItemRecord.setId(BigDecimal.valueOf(idGeneratorService.id()));
            //创建人，同时也是更新人
            tThemeItemRecord.setCreateUser(userId);
            tThemeItemRecord.setUpdateUser(userId);
            //插入表中
            themeItemDao.insert(tThemeItemRecord);
            resultVo.setData("success");
            return resultVo;
        } catch (Exception e) {
            e.printStackTrace();
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            return resultVo;
        }
    }

    /**
     * 元数据主题条目信息更新
     * @param themeItemUpdateVo
     * @param userId
     * @return
     */
    @Override
    public ResultVo<Object> update(ThemeItemUpdateVo themeItemUpdateVo, String userId) {
        ResultVo<Object> resultVo = new ResultVo<Object>();
        try {
            //从数据库查询出需要修改的信息
            TMetadataThemeItemRecord tMetadataThemeItemRecord = themeItemDao.findById(themeItemUpdateVo.getId());
            if (tMetadataThemeItemRecord == null) {
                return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
            }
            //判断，xxx情况不允许更新

            //调用方法设置值
            tMetadataThemeItemRecord = (TMetadataThemeItemRecord) VoReTraversalUtil.traversalTwo(themeItemUpdateVo, TMetadataThemeItemRecord.class);
            //更新人
            tMetadataThemeItemRecord.setUpdateUser(userId);
            //更新时间
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            tMetadataThemeItemRecord.setUpdateTime(timestamp);
            //审核人,有审核状态传入则表示审核
            Integer state = themeItemUpdateVo.getState();
            if (state!=null){
                tMetadataThemeItemRecord.setAuditTime(timestamp);
            }
            themeItemDao.update(tMetadataThemeItemRecord);
            resultVo.setData("success");
            return resultVo;
        } catch (Exception e) {
            e.printStackTrace();
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            return resultVo;
        }
    }

    /**
     * 元数据主题条目信息删除
     * @param id
     * @return
     */
    @Override
    public ResultVo<Object> delete(BigDecimal id) {
        //查询是否存在
        TMetadataThemeItemRecord tMetadataThemeItemRecord = themeItemDao.findById(id);
        if (tMetadataThemeItemRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), "当前需要删除的元数据主题条目不存在，无法删除！");
        }
        //查询下面是否还有元数据条目，有则不允许删除
        BigDecimal themeItemId = tMetadataThemeItemRecord.getId();
        List<TMetadataThemeItemRecord> fetch = themeItemDao.fetch(T_METADATA_ITEM.THEME_ITEM_ID, themeItemId);
        if (fetch.size()>0){
            return new ResultVo<>(ErrorCode.Invalid.getErrorCode(), "当前删除的元数据主题条目中还有元数据条目信息，不允许删除，请先删除元数据条目信息！");
        }
        //判断，xxx情况不允许删除

        //删除
        List<BigDecimal> ids = new ArrayList<>();
        ids.add(id);
        themeItemDao.deleteById(ids);
        return new ResultVo<>(0, true);

    }

    /**
     * 元数据主题条目信息列表查询
     * @param themeItemQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    @Override
    public ResultVo<PageVo<List<ThemeItemListVo>>> list(ThemeItemQueryVo themeItemQueryVo, String userId, Integer page, Integer size) {
        List<SortField<?>> sortList = new ArrayList<>();

        /*TUserRecord tUserRecord = userDao.findById(userId);
        if (tUserRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), null);
        }*/

        //添加排序字段
        sortList.add(T_METADATA_THEME_ITEM.UPDATE_TIME.desc());
        //添加条件字段
        List<Condition> conditions = innerAddListCondition(themeItemQueryVo);
        if(!StringUtils.isEmpty(userId)){
            conditions.add(T_METADATA_THEME_ITEM.CREATE_USER.eq(userId));
        }
        String name = themeItemQueryVo.getName();
        if(!StringUtils.isEmpty(name)){
            conditions.add(T_METADATA_THEME_ITEM.NAME.like("%" +name+ "%"));
        }
        BigDecimal themeId = themeItemQueryVo.getThemeId();
        if(themeId!=null){
            conditions.add(T_METADATA_THEME_ITEM.THEME_ID.eq(themeId));
        }
        //查询赋值返回
        PageVo<TMetadataThemeItemRecord> query = themeItemDao.fetchByPage(conditions, new OffsetPagingVo(page, size), sortList);
        List<TMetadataThemeItemRecord> tMetadataThemeItemRecords;
        tMetadataThemeItemRecords=query.getPageData();
        List<ThemeItemListVo> list = new ArrayList<>();
        for (TMetadataThemeItemRecord tMetadataThemeItemRecord : tMetadataThemeItemRecords
                ) {
            ThemeItemListVo  themeItemListVo= (ThemeItemListVo) VoReTraversalUtil.traversalTwo(tMetadataThemeItemRecord, ThemeItemListVo.class);

            list.add(themeItemListVo);
        }
        PageVo<ThemeItemListVo> result = new PageVo<>();
        result.setPageData(list);
        result.setTotalCount(query.getTotalCount());
        return new ResultVo(0, result);
    }


    /**
     * 为list添加条件字段的方法
     * @param themeItemQueryVo
     * @return
     */
    private List<Condition> innerAddListCondition(ThemeItemQueryVo themeItemQueryVo){
        List<Condition> conditions = new ArrayList<>();
        //TODO 添加条件字段
        return conditions;
    }
    /**
     * 元数据主题条目信息详情查询
     * @param id
     * @return
     */
    @Override
    public ResultVo<ThemeItemDetailVo> detailById(BigDecimal id) {
        TMetadataThemeItemRecord tMetadataThemeItemRecord = themeItemDao.findById(id);
        if (tMetadataThemeItemRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), null);
        }
        ThemeItemDetailVo themeItemDetailVo = (ThemeItemDetailVo) VoReTraversalUtil.traversalTwo(tMetadataThemeItemRecord, ThemeItemDetailVo.class);

        return new ResultVo<>(0,themeItemDetailVo);
    }
}
