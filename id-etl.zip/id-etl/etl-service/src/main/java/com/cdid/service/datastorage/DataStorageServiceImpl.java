package com.cdid.service.datastorage;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.cdid.api.asynctask.AsyncTaskExecuteService;
import com.cdid.api.asynctask.vo.AsyncTaskConfigVo;
import com.cdid.api.common.IDGeneratorService;
import com.cdid.api.common.RedisService;
import com.cdid.api.dataimport.vo.ColumnMappingVo;
import com.cdid.api.dataimport.vo.DatabaseJobConfigVo;
import com.cdid.api.dataimport.vo.FileJobConfigVo;
import com.cdid.api.datastorage.DataStorageService;
import com.cdid.api.datastorage.vo.*;
import com.cdid.api.job.JobService;
import com.cdid.api.jupyter.defaultimpl.DefaultTaskPreProcessor;
import com.cdid.api.metadata.detail.vo.DetailAddVo;
import com.cdid.api.metadata.item.ItemService;
import com.cdid.api.metadata.item.vo.ItemAddAllsVo;
import com.cdid.api.metadata.item.vo.ItemListVo;
import com.cdid.api.metadata.theme.ThemeService;
import com.cdid.api.metadata.theme.vo.ThemeListVo;
import com.cdid.api.metadata.theme.vo.ThemeQueryVo;
import com.cdid.api.metadata.themeitem.ThemeItemService;
import com.cdid.api.schedulelog.vo.ScheduleLogAddVo;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.constant.RedisKey;
import com.cdid.common.dict.JobState;
import com.cdid.common.vo.JDBCVo;
import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.metadata.item.ItemDao;
import com.cdid.dao.metadata.themeitem.ThemeItemDao;
import com.cdid.dao.user.UsersDao;
import com.cdid.jooq.tables.records.TMetadataItemRecord;
import com.cdid.jooq.tables.records.TMetadataThemeItemRecord;
import com.cdid.jooq.tables.records.UsersRecord;
import com.cdid.service.job.JobServiceUtil;
import com.cdid.utils.DbTypeUtil;
import com.cdid.utils.RSACoder;
import com.cdid.utils.VoReTraversalUtil;
import com.cdid.utils.jdbc.JDBCUtil;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.jooq.Condition;
import org.jooq.Record2;
import org.jooq.Result;
import org.jooq.SortField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.security.Key;
import java.util.*;

import static com.cdid.jooq.tables.TMetadataItem.T_METADATA_ITEM;
import static com.cdid.jooq.tables.TMetadataThemeItem.T_METADATA_THEME_ITEM;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/13 11:02  
 */
@Service
public class DataStorageServiceImpl implements DataStorageService{

    private static final Logger logger = LoggerFactory.getLogger(DataStorageServiceImpl.class);

    @Value("${dist.ip}")
    private String distIp;
    @Value("${dist.port}")
    private String distPort;
    @Value("${dist.database}")
    private String distDatabase;
    @Value("${dist.username}")
    private String distUserName;
    @Value("${dist.password}")
    private String distPassword;
    @Value("${dist.dbtype}")
    private String distdbtype;
    @Value("${dist.schema}")
    private String distSchema;

    @Value("${redis.host}")
    private String redisHost;
    @Value("${redis.port}")
    private String redisPort;
    @Value("${redis.index}")
    private String redisIndex;


    @Autowired
    private ItemDao itemDao;
    @Autowired
    private ItemService itemService;
    @Autowired
    private ThemeService themeService;
    @Autowired
    private ThemeItemService themeItemService;
    @Autowired
    private ThemeItemDao themeItemDao;
    @Autowired
    private IDGeneratorService<Long> idGeneratorService;

    @Autowired
    private AsyncTaskExecuteService asyncTaskExecuteService;
    @Autowired
    private JobService jobService;
    @Autowired
    RedisService redisService;
    @Autowired
    UsersDao usersDao;

    @Override
    public ResultVo<PageVo<List<ThemeListVo>>> findLogicList(LogicQueryVo logicQueryVo,String userId ,int page, int size) {
        ThemeQueryVo queryVo = VoReTraversalUtil.traversal(logicQueryVo, ThemeQueryVo.class);
        ResultVo<PageVo<List<ThemeListVo>>> list = themeService.list(queryVo, userId, page, size);
        return list;
    }

    @Override
    public ResultVo<PageVo<List<ItemListVo>>> findLogicItemList(LogicItemQueryVo logicItemQueryVo, String userId,int page, int size) {

        BigDecimal themeId = logicItemQueryVo.getThemeId();
        String name = logicItemQueryVo.getName();
        List<TMetadataThemeItemRecord> themeItemRecords
                = themeItemDao.fetch(T_METADATA_THEME_ITEM.THEME_ID, themeId);
        List<BigDecimal> themeItemIds = new ArrayList<>();
        for(TMetadataThemeItemRecord record:themeItemRecords){
            if(!StringUtils.isEmpty(userId)){
                if(BigDecimal.valueOf(100L).equals(record.getThemeId()) || userId.equals(record.getCreateUser())){
                    themeItemIds.add(record.getId());
                }
            }else {
                themeItemIds.add(record.getId());
            }
        }
        List<SortField<?>> sortList = new ArrayList<>();

        //添加排序字段
        sortList.add(T_METADATA_ITEM.UPDATE_TIME.desc());
        //添加条件字段
        List<Condition> conditions = new ArrayList<>();
        if(!StringUtils.isEmpty(name)){
            conditions.add(T_METADATA_ITEM.NAME.like("%"+name+"%"));
        }
        if(themeItemIds.size() > 0){
            conditions.add(T_METADATA_ITEM.THEME_ITEM_ID.in(themeItemIds));
        }
        if(!StringUtils.isEmpty(userId)){
            conditions.add(T_METADATA_ITEM.CREATE_USER.eq(userId));
        }

        //查询赋值返回
        PageVo<TMetadataItemRecord> query = itemDao.fetchByPage(conditions, new OffsetPagingVo(page, size), sortList);
        List<TMetadataItemRecord> tMetadataItemRecords;
        tMetadataItemRecords=query.getPageData();
        List<ItemListVo> list = new ArrayList<>();
        Set<String> userIds = new HashSet<>();
        for (TMetadataItemRecord tMetadataItemRecord : tMetadataItemRecords
                ) {
            userIds.add(tMetadataItemRecord.getCreateUser());
        }
        Map<String, Result<Record2<String, String>>> nameByUserIds = usersDao.getNameByUserIds(userIds.toArray(new String[userIds.size()]));

        for (TMetadataItemRecord tMetadataItemRecord : tMetadataItemRecords
                ) {
            ItemListVo itemListVo= (ItemListVo) VoReTraversalUtil.traversalTwo(tMetadataItemRecord, ItemListVo.class);

            Result<Record2<String, String>> record2s = nameByUserIds.get(tMetadataItemRecord.getCreateUser());
            if(record2s != null && record2s.size() > 0){
                itemListVo.setCreateUserName(record2s.get(0).value1());
            }

            list.add(itemListVo);
        }
        PageVo<ItemListVo> result = new PageVo<>();
        result.setPageData(list);
        result.setTotalCount(query.getTotalCount());
        return new ResultVo(0, result);
    }

    @Override
    public ResultVo<Object> findListData(BigDecimal itemId, int page, int size) {

        return null;
    }

    @Override
    public ResultVo<String> additional(AdditionalVo additionalVo) {
        List<ColumnMappingVo> columnMappingVoList =
                additionalVo.getColumnMappingVoList();
        ResultVo<String> resultVo = new ResultVo<>();
        String redisKey = additionalVo.getRedisKey();
        String tableName = additionalVo.getTableName();
        if(StringUtils.isEmpty(redisKey) || StringUtils.isEmpty(tableName) ){
            return new ResultVo<>(ErrorCode.ParamError.getErrorCode(),null,"redisKey,tableNae不能为null");
        }
//        String json = redisService.get(redisKey);
//        List<List<String>> data = (List<List<String>>) JSONArray.parse(json);
        FileJobConfigVo fileJobConfigVo = new FileJobConfigVo();
        BigDecimal id = BigDecimal.valueOf(idGeneratorService.id());
        fileJobConfigVo.setTaskId(id);
//        fileJobConfigVo.setData(data);
        fileJobConfigVo.setRedisHost(redisHost);
        fileJobConfigVo.setRedisPort(redisPort);
        fileJobConfigVo.setRedisIndex(redisIndex);
        fileJobConfigVo.setRedisKey(redisKey);
//        fileJobConfigVo.setColumnMappingVoList(columnMappingVoList);
        fileJobConfigVo.setColumnMapping(JSON.toJSONString(columnMappingVoList));

        //设置目标数据库jdbcUrl
        String distUrl = getDistDatabaseUrl();
        fileJobConfigVo.setDistDbType(DbTypeUtil.getTypeByDb(distdbtype));
        fileJobConfigVo.setDistTable(tableName);
        fileJobConfigVo.setDistJdbcUrl(distUrl);
        fileJobConfigVo.setDistUserName(distUserName);
        fileJobConfigVo.setDistPassword(distPassword);
        fileJobConfigVo.setDistSchema(distSchema);
        fileJobConfigVo.setImportMode(2);//更新
        fileJobConfigVo.setDistDataBase(distDatabase);
        fileJobConfigVo.setPreProcessProcessor(new DefaultTaskPreProcessor());
        AsyncTaskConfigVo asyncTaskConfigVo = JobServiceUtil.getAsyncTaskConfigVo(fileJobConfigVo);
        try {
            asyncTaskExecuteService.execute(asyncTaskConfigVo,true);
            resultVo.setData(RedisKey.DATASTORAGE_RESULT + id);
        }catch (Exception e){
            logger.info(e.getMessage());
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            resultVo.setData(null);
        }
        return resultVo;
    }

    private String getDistDatabaseUrl(){
        JDBCVo distjdbcVo = new JDBCVo();
        distjdbcVo.setType(DbTypeUtil.getTypeByDb(distdbtype));
        distjdbcVo.setDatabaseName(distDatabase);
        distjdbcVo.setPassword(distPassword);
        distjdbcVo.setUserName(distUserName);
        distjdbcVo.setPort(distPort);
        distjdbcVo.setUrl(distIp);
        String distUrl = (String) JDBCUtil.getDriverAndUrl(distjdbcVo).get("jdbcUrl");
        return distUrl;
    }

    @Override
    public ResultVo<List<List<String>>> findFileData(String redisKey) {
        List<List<String>> data = new ArrayList<>();
        if(StringUtils.isEmpty(redisKey)){
            return new ResultVo<>(ErrorCode.ParamError.getErrorCode(),data,"redisKey 不能为null");
        }
        String json = redisService.get(redisKey);
        data = (List<List<String>>) JSONArray.parse(json);
        return new ResultVo<>(0,data,"SUCCESS");
    }

    private ItemAddAllsVo getItemAddAllsVo(String distTableName,Integer metadataType,BigDecimal logicPartitionId,List<ColumnMappingVo> columnMappingVos){
        List<DetailAddVo> detailAddVos = new ArrayList<>();
        DetailAddVo detailAddVo = null;
        String distDataType = null;
        String dist = null;
        int index = 1;
        for(ColumnMappingVo columnMappingVo : columnMappingVos){
            detailAddVo = new DetailAddVo();
            distDataType = columnMappingVo.getDistDataType();
            dist = columnMappingVo.getDist();
            Integer colType = JobServiceUtil.hiveFeildTypeConvert(distDataType);
            detailAddVo.setMetadataItemId(logicPartitionId);
            detailAddVo.setColDisplayname(dist);
            detailAddVo.setColName(dist);
            detailAddVo.setColType(colType);
            detailAddVo.setIndex(index);
            detailAddVos.add(detailAddVo);
            index++;
        }

        //调用元数据接口创建表
        ItemAddAllsVo itemAddAllsVo = new ItemAddAllsVo();
        itemAddAllsVo.setThemeItemId(logicPartitionId);
        itemAddAllsVo.setType(metadataType);
        itemAddAllsVo.setDetailAddVoList(detailAddVos);
        itemAddAllsVo.setName(distTableName);
        return itemAddAllsVo;
    }

    @Override
    public ResultVo<String> loadOrShare(LoadOrShareVo loadOrShareVo,String userId) throws Exception{
        String distTableName = loadOrShareVo.getDistTableName();
        String srcTableName = loadOrShareVo.getSrcTableName();
        Integer distTableSource = loadOrShareVo.getDistTableSource();
        Integer metadataType = loadOrShareVo.getMetadataType();
        BigDecimal logicPartitionId = loadOrShareVo.getLogicPartitionId();
        String sql = loadOrShareVo.getSql();
        BigDecimal[] logicPartitionIds = {BigDecimal.valueOf(1001L),BigDecimal.valueOf(1002L)};
        //分享
        if(ArrayUtils.contains(logicPartitionIds,logicPartitionId)){
            //查询用户的私钥公钥
            UsersRecord usersRecord = usersDao.findByGuId(userId);
            if(usersRecord == null){
                return new ResultVo<>(ErrorCode.ParamError.getErrorCode(),null,"该用户不存在");
            }
            if(StringUtils.isEmpty(usersRecord.getPrivateKey()) || StringUtils.isEmpty(usersRecord.getPublicKey())){
                //生成公钥私钥
                Map<String, Key> keyMap = RSACoder.initKey();
                String publicKey = RSACoder.getPublicKey(keyMap);
                String privateKey = RSACoder.getPrivateKey(keyMap);
                //更新用户的公钥私钥
                boolean isSuccess = usersDao.updatePriKeyAndPubKey(userId, publicKey, privateKey);
                if(!isSuccess){
                    return new ResultVo<>(ErrorCode.UnknownError.getErrorCode(),null,"更新私钥公钥失败");
                }
            }
        }


        List<ColumnMappingVo> columnMappingVoList = loadOrShareVo.getColumnMappingVoList();
        if(StringUtils.isEmpty(distTableName) || StringUtils.isEmpty(srcTableName)){
            return new ResultVo<>(ErrorCode.ParamError.getErrorCode(),null,"distTableName,srcTableName 不能为null");
        }

        //新建目标表
        if(distTableSource == 1){
            ItemAddAllsVo itemAddAllsVo = getItemAddAllsVo(distTableName,metadataType,logicPartitionId,columnMappingVoList);
            ResultVo<Object> objectResultVo = itemService.addAlls(itemAddAllsVo, userId,false);
            if(objectResultVo.getErrorCode() != 0){
                return new ResultVo<>(ErrorCode.UnknownError.getErrorCode(),null,objectResultVo.getData().toString());
            }
        }

        ResultVo<String> resultVo = new ResultVo<>();
        DatabaseJobConfigVo databaseJobConfigVo = new DatabaseJobConfigVo();
        BigDecimal id = BigDecimal.valueOf(idGeneratorService.id());
        databaseJobConfigVo.setTaskId(id);

        String distDatabaseUrl = getDistDatabaseUrl();
        databaseJobConfigVo.setDistJdbcUrl(distDatabaseUrl);
        databaseJobConfigVo.setDistDbType(DbTypeUtil.getTypeByDb(distdbtype));
        databaseJobConfigVo.setDistTable(distTableName);
        databaseJobConfigVo.setDistUserName(distUserName);
        databaseJobConfigVo.setDistPassword(distPassword);
        databaseJobConfigVo.setDistSchema(distSchema);

        databaseJobConfigVo.setSourceTable(srcTableName);
        databaseJobConfigVo.setDbType(DbTypeUtil.getTypeByDb(distdbtype));
        databaseJobConfigVo.setJdbcUrl(distDatabaseUrl);
        databaseJobConfigVo.setUserName(distUserName);
        databaseJobConfigVo.setPassword(distPassword);
        databaseJobConfigVo.setColumnMapping(JSON.toJSONString(columnMappingVoList));
        databaseJobConfigVo.setImportMode(2);
        databaseJobConfigVo.setDistDataBase(distDatabase);
        databaseJobConfigVo.setPreProcessProcessor(new DefaultTaskPreProcessor());
        if(!StringUtils.isEmpty(sql)){
            databaseJobConfigVo.setSql(sql);
        }
        AsyncTaskConfigVo asyncTaskConfigVo = JobServiceUtil.getAsyncTaskConfigVo(databaseJobConfigVo);



        try {
            asyncTaskExecuteService.execute(asyncTaskConfigVo,true);
            resultVo.setData(RedisKey.DATASTORAGE_RESULT + id);
        }catch (Exception e){
            logger.info(e.getMessage());
            resultVo.setErrorCode(ErrorCode.UnknownError.getErrorCode());
            resultVo.setData(null);
        }
        return resultVo;
    }

    @Override
    public ResultVo<Boolean> executeSql(ExecuteSqlVo executeSqlVo) {
        String sql = executeSqlVo.getSql();
        String tableName = executeSqlVo.getTableName();
//        ResultVo<>
        if(StringUtils.isEmpty(sql) || StringUtils.isEmpty(tableName)){
            return new ResultVo<>(ErrorCode.ParamError.getErrorCode(),Boolean.FALSE,"tableName,sql不能为null");
        }

//        JDBCUtil.updateByPreparedStatement();

        return null;
    }

    @Override
    public ResultVo<ScheduleLogAddVo> getResult(String redisKey) {
        String json = redisService.get(redisKey);
        if(StringUtils.isEmpty(json)){
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(),null);
        }
        ScheduleLogAddVo scheduleLogAddVo = JSON.parseObject(json, ScheduleLogAddVo.class);
        if(scheduleLogAddVo.getScheduleState() == JobState.Success.getValue()){
            return new ResultVo<>(0,scheduleLogAddVo,"SUCCESS");
        }else {
            return new ResultVo<>(ErrorCode.UnknownError.getErrorCode(),scheduleLogAddVo,scheduleLogAddVo.getScheduleLog());
        }
    }
}
