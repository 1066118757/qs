/**
 * Copyright 2017 Institute of Computing Technology, Chinese Academy of Sciences.
 * Licensed under the terms of the Apache 2.0 license.
 * Please see LICENSE file in the project root for terms
 */
package com.cdid.service.oozie.workflow;


import com.cdid.service.oozie.command.Parameter;
import com.cdid.service.oozie.constant.ParameterDataType;
import com.cdid.service.oozie.constant.ProgramType;
import com.cdid.service.oozie.graph.*;
import com.cdid.utils.StringUtil;

import java.util.*;
import java.util.stream.Collectors;

/**
 * The workflow graph builder
 */
public class WFBuilder {

    WFGraph wfGraph = new WFGraph();

    /**
     * A {@link WFGraph} should be built from an {@link OozieGraph}
     */
    public void buildFromOozieGraph(OozieGraph graph) throws Exception {
        //first load all program nodes into the WFGraph,
        //and built relations between program nodes
        //according to the edges in OoziGrpah
        loadGraph(graph);

        //insert start node and end node for Oozie workflow into the DAG
        insertStartAndEnd();

        //insert Fork and Join Action for parallel
        insertForkAndJoin();
    }

    /**
     * Wrap a {@link OozieProgramNode} as {@link NodeDef}
     *
     * @param node
     * @return
     * @throws Exception
     */
    private ActionNodeDef wrapAsNodeDef(OozieProgramNode node) throws Exception {
        ActionNodeDef action = null;
        if (node.getProgramType().equals(ProgramType.JAVA.name())) {
            action = new JavaActionNodeDef(node, node.getId());
        } else {
            action = new ShellActionNodeDef(node, node.getId());
        }
        return action;
    }


    /**
     * Add all {@link OozieProgramNode} in {@link OozieGraph} into {@link WFGraph},
     * parse all file dependencies according to the edges in {@link OozieProgramNode}
     *
     * @param graph the DAG graph
     * @throws Exception
     */
    private void loadGraph(OozieGraph graph) throws Exception {
        Map<String,ActionNodeDef> actionNodeMap=new HashMap<>();
        for (OozieProgramNode node : graph.getPnodes()) {
            if (graph.isActiveNode(node.getId())) {
                ActionNodeDef action = wrapAsNodeDef(node);
                wfGraph.addActionNode(action);
                actionNodeMap.put(node.getId(),action);
            }
        }
        Map<String, OozieNode> nodeMap = new HashMap<String, OozieNode>();
        for (OozieDatasetNode node : graph.getDnodes()) {
            nodeMap.put(node.getId(), node);
        }
        for (OozieProgramNode node : graph.getPnodes()) {
            nodeMap.put(node.getId(), node);
        }
        for (OozieEdge edge : graph.getEdges()) {
            OozieNode srcNode = nodeMap.get(edge.getSrc());
            if (srcNode == null)
                continue;
            wfGraph.addEdge(edge.getSrc(), edge.getDst());
            if(edge.getSrcIndex()!=-1){
                if (srcNode instanceof OozieDatasetNode){
                    OozieDatasetNode node = ((OozieDatasetNode) srcNode);
                    ActionNodeDef distActionNode=actionNodeMap.get(edge.getDst());
                    List<Parameter> inParameters=distActionNode.getProgram().getParams().stream().filter(p -> p.getDataType().equals(ParameterDataType.IN.getName())).collect(Collectors.toList());
                    if(inParameters.size()>=(edge.getDistIndex()+1)){
                        inParameters.get(edge.getDistIndex()).setParamValue(node.getFilePath());
                    }
                } else{
                    OozieProgramNode node = ((OozieProgramNode) srcNode);
                    ActionNodeDef distActionNode=actionNodeMap.get(edge.getDst());
                    List<Parameter> srcOutParameters=node.getParams().stream().filter(p -> p.getDataType().equals(ParameterDataType.OUT.getName())).collect(Collectors.toList());
                    if(srcOutParameters.size()>=(edge.getSrcIndex()+1)){
                        List<Parameter> distParameters=distActionNode.getProgram().getParams();
                        int distInIndex=0;
                        for(Parameter parameter:distParameters){
                            if(parameter.getDataType().equals(ParameterDataType.IN.getName())){
                                if(distInIndex == edge.getDistIndex()){
                                    String outParameterValue=srcOutParameters.get(edge.getSrcIndex()).getParamValue();
                                    if(!StringUtil.isEmpty(outParameterValue)){
                                        parameter.setParamValue(outParameterValue);
                                    }
                                }
                                distInIndex=distInIndex+1;
                            }
                        }
                    }

                }
            }
        }
    }

    private void insertStartAndEnd() {
        for (NodeDef node : wfGraph.nodeMap.values()) {
            if (node.getInDegree() == 0) {
                wfGraph.start.addOutNode(node);
                node.addInNode(wfGraph.start);
            }
            if (node.getOutDegree() == 0) {
                node.addOutNode(wfGraph.end);
                wfGraph.end.addInNode(node);
            }
        }

        if (wfGraph.start.getOutDegree() == 0 && wfGraph.end.getInDegree() == 0) {
            wfGraph.start.addOutNode(wfGraph.end);
            wfGraph.end.addInNode(wfGraph.start);
        }
    }

    private void insertForkAndJoin() {
        NodeDef start = wfGraph.start;
        NodeDef end = wfGraph.end;
        Queue<NodeDef> que = new LinkedList<NodeDef>();
        // Insert fork and join node
        NodeDef cur_node = start;
        int count = 0;
        do {
            if (count++ > 10)
                break;
            for (NodeDef suc_node : cur_node.getOutNodes()) {
                suc_node.delInNode(cur_node);
                if (suc_node.getInDegree() == 0) {
                    que.add(suc_node);
                }
            }

            cur_node.clearOutNodes();

            if (que.size() > 1) {// If the out degree greater than 1, then need to insert fork/join node（the node should be used in pair）
                // A fork node splits one path of execution into multiple
                // concurrent
                // paths of execution.
                // A join node waits until every concurrent execution path of a
                // previous
                // fork node arrives to it.
                // The fork and join nodes must be used in pairs. The join node
                // assumes
                // concurrent execution paths
                // are children of the same fork node.
                String uuid = UUID.randomUUID().toString();
                NodeDef fork = new ForkNodeDef("fork-" + uuid);
                NodeDef join = new JoinNodeDef("join-" + uuid);

                // Modify cur_node descent node  to fork node
                buildLink(cur_node, fork);

                while (!que.isEmpty()) {
                    buildLink(fork, que.remove());
                }

                //Insert join node between pre_node and suc_node node
                for (NodeDef pre_node : fork.getOutNodes()) {// For children node of fork node
                    for (NodeDef suc_node : pre_node.getOutNodes()) {// Insert join node between pre_node and suc_node
                        suc_node.delInNode(pre_node);
                        join.addOutNode(suc_node);// Point the join node to suc_node
                    }

                    //Modify pre_node descent node which only include join node
                    pre_node.clearOutNodes();
                    buildLink(pre_node, join);
                }

                // Modify the join descent node's father node to join node
                for (NodeDef suc_node : join.getOutNodes()) {
                    suc_node.addInNode(join);
                }
                cur_node = join;
            } else {
                buildLink(cur_node, que.peek());
                cur_node = que.remove();
            }
        } while (cur_node != end);

    }

    /**
     * build link between to nodes
     *
     * @param pre_node the previous node
     * @param suc_node the successor node
     */
    private void buildLink(NodeDef pre_node, NodeDef suc_node) {
        pre_node.addOutNode(suc_node);
        suc_node.addInNode(pre_node);
    }

    public WFGraph asWFGraph() {
        return this.wfGraph;
    }


}
