package com.cdid.service.dataclear.cleartask;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cdid.api.asynctask.vo.AsyncTaskConfigVo;
import com.cdid.api.common.IDGeneratorService;
import com.cdid.api.common.SmsService;
import com.cdid.api.dataclear.cleartask.ClearTaskService;
import com.cdid.api.dataclear.cleartask.vo.*;
import com.cdid.api.dataclear.cleartasklog.ClearTaskLogService;
import com.cdid.api.dataclear.cleartasklog.vo.ClearTaskLogUpdateVo;
import com.cdid.api.job.JobService;
import com.cdid.api.job.vo.ScheduleJobEntity;
import com.cdid.api.metadata.detail.DetailService;
import com.cdid.api.metadata.detail.vo.DetailAddVo;
import com.cdid.api.metadata.item.vo.CreateHiveColVo;
import com.cdid.api.metadata.item.vo.CreateHiveTableVo;
import com.cdid.api.metadata.item.vo.ItemAddVo;
import com.cdid.asynctask.AsyncTaskExecuteServiceImpl;
import com.cdid.common.constant.ErrorCode;
import com.cdid.common.dict.ItemSourceType;
import com.cdid.common.dict.RuleType;
import com.cdid.common.dict.ScriptType;
import com.cdid.common.dict.TaskResult;
import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.dao.dataclear.clearrecord.ClearRecordDao;
import com.cdid.dao.dataclear.clearrule.ClearRuleDao;
import com.cdid.dao.dataclear.cleartask.ClearTaskDao;
import com.cdid.dao.dataclear.cleartasklog.ClearTaskLogDao;
import com.cdid.dao.metadata.detail.DetailDao;
import com.cdid.dao.metadata.item.ItemDao;
import com.cdid.dao.user.UsersDao;
import com.cdid.jooq.tables.records.*;
import com.cdid.service.dataclear.ClearTaskPreProcessor;
import com.cdid.service.job.ScheduleUtils;
import com.cdid.service.oozie.OozieObjectTreeService;
import com.cdid.service.oozie.vo.TreeObjectVO;
import com.cdid.utils.HttpClientUtil;
import com.cdid.utils.StringUtil;
import com.cdid.utils.VoReTraversalUtil;
import com.cdid.utils.cron.CronTab;
import com.cdid.utils.cron.CronUtil;
import com.cdid.utils.email.EmailUtil;
import org.apache.commons.net.util.Base64;
import org.jooq.Condition;
import org.jooq.SortField;
import org.quartz.TriggerUtils;
import org.quartz.impl.triggers.CronTriggerImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.*;

import static com.cdid.jooq.tables.TClearTask.T_CLEAR_TASK;
import static com.cdid.jooq.tables.TMetadataItem.T_METADATA_ITEM;
import static com.cdid.service.job.JobServiceUtil.KAFAKA_TOPIC_CLEAR;

/**
 * 数据整理任务的实现
 */
@Service
@Transactional(rollbackFor = {Exception.class, RuntimeException.class})
public class ClearTaskServiceImpl implements ClearTaskService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ClearTaskDao clearTaskDao;
    @Autowired
    private IDGeneratorService<Long> idGeneratorService;
    @Autowired
    private UsersDao usersDao;
    @Autowired
    private ItemDao itemDao;

    @Autowired
    private ClearRecordDao clearRecordDao;
    @Autowired
    private ClearTaskLogDao clearTaskLogDao;
    @Autowired
    private ScheduleUtils scheduleUtils;
    @Autowired
    private ClearRuleDao clearRuleDao;

    @Autowired
    OozieObjectTreeService treeService;

    @Autowired
    JobService jobService;

    @Autowired
    SmsService smsService;

    @Autowired
    ClearTaskLogService logService;

    @Value("${idmanager-server.baseUrl}")
    private String idmanagerBaseUrl;

    @Autowired
    DetailService detailService;

    @Autowired
    DetailDao detailDao;

    private static final String REST_FOR_CREATE_TABLE = "/rest/hbase/sparksql/createTable";

    /**
     * 数据整理任务添加
     *
     * @param clearTaskAddVo
     * @param userId
     * @return
     */
    @Override
    public ResultVo<Object> add(ClearTaskAddVo clearTaskAddVo, String userId) {
        try {
            ResultVo<Object> resultVo = new ResultVo<Object>();
            String inItemName = clearTaskAddVo.getInItemName();
            String outItemName = clearTaskAddVo.getOutItemName();
            BigDecimal ThemeItemIdFlag = clearTaskAddVo.getOutThemeItemId();
            //依据outThemeItemId是否为空判断是否是自定义算法数据清洗任务
            if (StringUtils.isEmpty(ThemeItemIdFlag)) {
                //自定义算法数据清洗任务
                List<TMetadataItemRecord> records = itemDao.fetch(T_METADATA_ITEM.NAME, outItemName);
                TMetadataItemRecord record = records.get(0);
                clearTaskAddVo.setOutThemeItemId(record.getThemeItemId());
                clearTaskAddVo.setOutItemType(record.getType());
                //判重
                if (inItemName.equals(outItemName)) {
                    return new ResultVo<>(ErrorCode.ParamError.getErrorCode(), "传入参数错误，输入表与输出表重复!");
                }
                List<TClearTaskRecord> fetch = clearTaskDao.fetch(T_CLEAR_TASK.IN_ITEM_NAME, inItemName);
                if (fetch.size() > 0) {
                    return new ResultVo<>(ErrorCode.ParamError.getErrorCode(), "传入参数错误，当前输入表已经存在任务，不可重复添加!");
                }
                List<TClearTaskRecord> fetch1 = clearTaskDao.fetch(T_CLEAR_TASK.OUT_ITEM_NAME, outItemName);
                if (fetch1.size() > 0) {
                    return new ResultVo<>(ErrorCode.ParamError.getErrorCode(), "传入参数错误，当前输出表已经存在任务，不可重复添加!");
                }
            } else {
                //对输入输出表判重，同一个输入表或者输出表只能对应一个任务,输出表名不能是已有表表名
                List<TClearTaskRecord> fetch = clearTaskDao.fetch(T_CLEAR_TASK.IN_ITEM_NAME, inItemName);
                if (fetch.size() > 0) {
                    return new ResultVo<>(ErrorCode.ParamError.getErrorCode(), "传入参数错误，当前输入表已经存在任务，不可重复添加!");
                }
                List<TClearTaskRecord> fetch1 = clearTaskDao.fetch(T_CLEAR_TASK.OUT_ITEM_NAME, outItemName);
                if (fetch1.size() > 0) {
                    return new ResultVo<>(ErrorCode.ParamError.getErrorCode(), "传入参数错误，当前输出表已经存在任务，不可重复添加!");
                }
                List<TMetadataItemRecord> fetch2 = itemDao.fetch(T_METADATA_ITEM.NAME, outItemName);
                if (fetch2.size() > 0) {
                    return new ResultVo<>(ErrorCode.ParamError.getErrorCode(), "传入参数错误，当前输出表名与已有表名重复!");
                }
            }
            TClearTaskRecord tClearTaskRecord = (TClearTaskRecord) VoReTraversalUtil.traversalTwo(clearTaskAddVo, TClearTaskRecord.class);
            BigDecimal taskId = BigDecimal.valueOf(idGeneratorService.id());
            tClearTaskRecord.setId(taskId);
            //创建人，同时也是更新人
            tClearTaskRecord.setCreateUser(userId);
            tClearTaskRecord.setUpdateUser(userId);
            //先获取输出表信息创建输出表
            ItemAddVo itemAddVo = new ItemAddVo();
            itemAddVo.setName(clearTaskAddVo.getOutItemName());
            itemAddVo.setPurpose(clearTaskAddVo.getOutItemPurpose());
            BigDecimal outThemeItemId = clearTaskAddVo.getOutThemeItemId();
            if (outThemeItemId != null) {
                itemAddVo.setThemeItemId(outThemeItemId);
            }
            //itemAddVo.setThemeItemId(themeItemId);
            itemAddVo.setType(clearTaskAddVo.getOutItemType());
            //设置来源为数据清洗
            itemAddVo.setSourceType(ItemSourceType.DATA_CLEAR.getValue());
            TMetadataItemRecord tItemRecord = (TMetadataItemRecord) VoReTraversalUtil.traversalTwo(itemAddVo, TMetadataItemRecord.class);
            BigDecimal outItemId = BigDecimal.valueOf(idGeneratorService.id());
            tItemRecord.setId(outItemId);
            //创建人，同时也是更新人
            tItemRecord.setCreateUser(userId);
            tItemRecord.setUpdateUser(userId);
            //设置outItemId到tClearTaskRecord
            tClearTaskRecord.setOutItemId(outItemId);
            //插入流程整合任务表中
            tClearTaskRecord.setNearResult(1004);
            //丰富TClearTaskRecord的时间字段
            String cronCode = clearTaskAddVo.getCronCode();
            TClearTaskRecord taskRecord = richTClearTaskRecord(tClearTaskRecord, cronCode);
            clearTaskDao.insert(taskRecord);
            //插入表中
            if (!StringUtils.isEmpty(ThemeItemIdFlag)) {
                itemDao.insert(tItemRecord);
                TreeObjectVO treeObjectVO = new TreeObjectVO();
                treeObjectVO.setName(itemAddVo.getName());
                treeObjectVO.setObjectType(TreeObjectVO.TreeObjectType.DATA.toString());
                treeObjectVO.setLeafObjectType(TreeObjectVO.LeafObjectType.TABLE.toString());
                treeObjectVO.setParentType(TreeObjectVO.TreeParentType.SELF.toString());
                treeService.addTreeObject(treeObjectVO, userId, tItemRecord.getId());
            }
            //查询记录信息获取handleCode
            BigDecimal recordId = tClearTaskRecord.getRecordId();
            TClearRecordRecord recordRecord = clearRecordDao.findById(recordId);
            String handleCode = recordRecord.getHandleCode();
            //获取ClearTaskDetailVo用于创建定时任务
            ClearTaskDetailVo taskDetailVo = (ClearTaskDetailVo) VoReTraversalUtil.traversalTwo(tClearTaskRecord, ClearTaskDetailVo.class);

            ResultVo resultVo1 = getScheduleJobEntity(taskDetailVo, handleCode);
            if (resultVo1.getErrorCode() == 0) {
                ScheduleJobEntity scheduleJobEntity = (ScheduleJobEntity) resultVo1.getData();
                //创建定时任务
                scheduleUtils.createScheduleJob(scheduleJobEntity);
            } else {
                return resultVo1;
            }
            resultVo.setData("success");
            resultVo.setErrorCode(0);
            return resultVo;
        } catch (Exception e) {
            e.printStackTrace();
            return new ResultVo<>(ErrorCode.UnknownError.getErrorCode());
        }
    }

    private TClearTaskRecord richTClearTaskRecord(TClearTaskRecord tClearTaskRecord, String cronCode) throws Exception {
        //设置启动时间以及停止时间，启动时间计算得出，停止时间初始化默认为：1970/1/1 8:0:0 =0
        tClearTaskRecord.setNearEndTime(new Timestamp(0));
        //从cronCode计算启动时间
        //[{\"month\":1,\"monthType\":\"EVERY\",\"day\":1,\"hour\":0,\"minute\":0,\"second\":0},{\"time\":1517392149222}]
        String s = "/";
        cronCode = cronCode.replace(s, "");
        JSONArray jsonArray = JSON.parseArray(cronCode);

        Long currentTime = System.currentTimeMillis();
        Timestamp timestamp = new Timestamp(currentTime);
        List<Long> dValue = new ArrayList<>();
        for (Object item : jsonArray) {
            JSONObject jsonObject = (JSONObject) item;
            Object time = jsonObject.get("time");
            if (time != null) {
                Long value = (Long) time - currentTime;
                dValue.add(value);
            } else {
                Object secondType = jsonObject.get("secondType");
                Object minuteType = jsonObject.get("minuteType");
                Object hourType = jsonObject.get("hourType");
                Object dayType = jsonObject.get("dayType");
                Object weekType = jsonObject.get("weekType");
                Object monthType = jsonObject.get("monthType");
                Object yearType = jsonObject.get("yearType");
                //查询时间差值
                CronTab cronTab = JSON.parseObject(jsonObject.toJSONString(), CronTab.class);
                String cronString = CronUtil.toCronString(cronTab);
                //定时执行的时间
                CronTriggerImpl cronTriggerImpl = new CronTriggerImpl();
                cronTriggerImpl.setCronExpression(cronString);

                Calendar calendar = Calendar.getInstance();
                Date now = calendar.getTime();
                if (secondType != null) {
                    // 把统计的区间段设置为从现在到60秒后
                    calendar.add(Calendar.SECOND, 60);
                } else if (minuteType != null) {
                    // 把统计的区间段设置为从现在到60分钟后
                    calendar.add(Calendar.MINUTE, 60);
                } else if (hourType != null) {
                    // 把统计的区间段设置为从现在到24小时后
                    calendar.add(Calendar.HOUR_OF_DAY, 24);
                } else if (dayType != null) {
                    // 把统计的区间段设置为从现在到31天后
                    calendar.add(Calendar.DAY_OF_MONTH, 31);
                } else if (weekType != null) {
                    // 把统计的区间段设置为从现在到31天后
                    calendar.add(Calendar.DAY_OF_WEEK, 7);
                } else if (monthType != null) {
                    // 把统计的区间段设置为从现在到31天后
                    calendar.add(Calendar.MONTH, 13);
                } else if (yearType != null) {
                    // 把统计的区间段设置为从现在到31天后
                    calendar.add(Calendar.YEAR, 10);
                }
                // 这里的时间是根据corn表达式算出来的值
                List<Date> dates = TriggerUtils.computeFireTimesBetween(
                        cronTriggerImpl, null, now,
                        calendar.getTime());
                Long value = dates.get(0).getTime() - currentTime;
                dValue.add(value);
            }
        }
        //获取最小值
        Long min = Collections.min(dValue);
        Timestamp startTime = new Timestamp(currentTime + min);
        //设置进record
        tClearTaskRecord.setNearStartTime(startTime);
        tClearTaskRecord.setCreateTime(timestamp);
        tClearTaskRecord.setUpdateTime(timestamp);
        return tClearTaskRecord;
    }

    @Override
    public ResultVo getScheduleJobEntity(ClearTaskDetailVo taskDetailVo, String handleCode) {
        ResultVo<Object> resultVo = new ResultVo<>();
        //创建定时任务,jobId,cronExpression，taskRequestVo
        AsyncTaskConfigVo asyncTaskConfigVo = new AsyncTaskConfigVo();
        BigDecimal taskId = taskDetailVo.getId();
        asyncTaskConfigVo.setTaskId(taskId);
        asyncTaskConfigVo.setPreProcessProcessor(new ClearTaskPreProcessor());
        asyncTaskConfigVo.setTopic(KAFAKA_TOPIC_CLEAR);
        asyncTaskConfigVo.setDependence(taskDetailVo.getDependence());
        //ScheduleJobEntity
        ScheduleJobEntity scheduleJobEntity = new ScheduleJobEntity();
        scheduleJobEntity.setJobId(taskDetailVo.getId());
        //将handleCode转为json对象
        JSONObject jsonStringOne = JSON.parseObject(handleCode);
        String steps = jsonStringOne.getString("steps");
        String frontend = jsonStringOne.getString("frontend");
        JSONObject stepsJsonObject = JSON.parseObject(steps);
        JSONArray frontendJsonArray = JSON.parseArray(frontend);
        //构建"target_table":"test2","overwrite":"true","dbName":"default"格式
        if (taskDetailVo != null) {
            stepsJsonObject.put("target_table", taskDetailVo.getOutItemName());
            stepsJsonObject.put("overwrite", "true");
            stepsJsonObject.put("dbName", "default");
            //根据frontendJsonArray中的第一个信息的ruleType是否为806（自定义）判断是否是自定义算法清洗任务
            if (frontendJsonArray.size() > 0) {
                JSONObject jsonObjectOne = frontendJsonArray.getJSONObject(0);
                Integer ruleType = jsonObjectOne.getInteger("ruleType");
                if (ruleType == RuleType.USER_DEFINED.getValue()) {
                    String outItemName = taskDetailVo.getOutItemName();
                    ClearTaskSubmitVo clearTaskSubmitVo = getClearTaskSubmitVo(stepsJsonObject, frontendJsonArray, taskId, outItemName);
                    scheduleJobEntity.setClearTaskSubmitVo(clearTaskSubmitVo);
                }
            }
        }
        JSONObject taskParams = new JSONObject();
        taskParams.put("config", Base64.encodeBase64String(stepsJsonObject.toJSONString().getBytes()).replaceAll("\r\n", ""));
        asyncTaskConfigVo.setTaskParams(taskParams);

        //获取croncode并转为cron表达式
        String cronCode = taskDetailVo.getCronCode();
        //List<CronTab> cronTabs = JSON.parseArray(cronCode, CronTab.class);
        JSONArray jsonArray = JSON.parseArray(cronCode);
        //设置进scheduleJobEntity
        Set<String> crons = new HashSet<>();
        for (Object object : jsonArray) {
            JSONObject item = (JSONObject) (object);
            Object time = item.get("time");
            try {
                if (time == null) {
                    CronTab cronTab = JSON.parseObject(item.toJSONString(), CronTab.class);
                    String cronString = CronUtil.toCronString(cronTab);
                    crons.add(cronString);
                } else {
                    long cronlong = Long.valueOf(String.valueOf(time)).longValue();
                    //判断当前时间是否已经超过该定时时间，超过则不启动该定时任务
                    long currentTimeMillis = System.currentTimeMillis();
                    if (cronlong > currentTimeMillis) {
                        String cronString = CronUtil.toCronString(cronlong);
                        crons.add(cronString);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        scheduleJobEntity.setCronExpressions(crons);
        scheduleJobEntity.setAsyncTaskConfigVo(asyncTaskConfigVo);
        scheduleJobEntity.setPriority(taskDetailVo.getPriority());

        resultVo.setData(scheduleJobEntity);
        resultVo.setErrorCode(0);
        return resultVo;
    }

    @Override
    public ResultVo initGetScheduleJobEntity(ClearTaskDetailVo taskDetailVo, String handleCode) throws Exception {
        ResultVo<Object> resultVo = new ResultVo<>();
        //创建定时任务,jobId,cronExpression，taskRequestVo
        AsyncTaskConfigVo asyncTaskConfigVo = new AsyncTaskConfigVo();
        BigDecimal taskId = taskDetailVo.getId();
        asyncTaskConfigVo.setTaskId(taskId);
        asyncTaskConfigVo.setPreProcessProcessor(new ClearTaskPreProcessor());
        asyncTaskConfigVo.setTopic(KAFAKA_TOPIC_CLEAR);
        asyncTaskConfigVo.setDependence(taskDetailVo.getDependence());
        //ScheduleJobEntity
        ScheduleJobEntity scheduleJobEntity = new ScheduleJobEntity();
        scheduleJobEntity.setJobId(taskDetailVo.getId());
        //将handleCode转为json对象
        JSONObject jsonStringOne = JSON.parseObject(handleCode);
        String steps = jsonStringOne.getString("steps");
        String frontend = jsonStringOne.getString("frontend");
        JSONObject stepsJsonObject = JSON.parseObject(steps);
        JSONArray frontendJsonArray = JSON.parseArray(frontend);
        //构建"target_table":"test2","overwrite":"true","dbName":"default"格式
        if (taskDetailVo != null) {
            stepsJsonObject.put("target_table", taskDetailVo.getOutItemName());
            stepsJsonObject.put("overwrite", "true");
            stepsJsonObject.put("dbName", "default");
            //根据frontendJsonArray中的第一个信息的ruleType是否为806（自定义）判断是否是自定义算法清洗任务
            if (frontendJsonArray.size() > 0) {
                JSONObject jsonObjectOne = frontendJsonArray.getJSONObject(0);
                Integer ruleType = jsonObjectOne.getInteger("ruleType");
                if (ruleType == RuleType.USER_DEFINED.getValue()) {
                    String outItemName = taskDetailVo.getOutItemName();
                    ClearTaskSubmitVo clearTaskSubmitVo = new ClearTaskSubmitVo();
                    //获取scriptType,mainClass,filePath（目前只支持一个自定义算法，所以frontendJsonObject中最多只有一个算法信息）
                    if (frontendJsonArray.size() > 0) {
                        JSONObject clearRuleObject = frontendJsonArray.getJSONObject(0);
                        BigDecimal ruleId = clearRuleObject.getBigDecimal("id");
                        TClearRuleRecord ruleRecord = clearRuleDao.findById(ruleId);
                        if (ruleRecord == null) {
                            logger.info("任务id：" + taskId + "查询初始化定时任务失败，对应的记录中handleCode中frontend中的规则id:" + ruleId + "查询不出记录！");
                            return new ResultVo(ErrorCode.NotExists.getErrorCode(), "规则id查询不出记录");
                        }
                        //构建args,(目前只支持一个自定义算法，所以steps.script.steps中最多只有一个param信息)
                        StringBuffer argsBuffer = new StringBuffer();
                        String inTableName = stepsJsonObject.getString("tableName");
                        argsBuffer.append(inTableName).append(",").append(outItemName);
                        JSONArray stepsJsonArray = stepsJsonObject.getJSONObject("script").getJSONArray("steps");
                        if (stepsJsonArray.size() > 0) {
                            JSONObject param = stepsJsonArray.getJSONObject(0).getJSONObject("param");
                            Collection<Object> values = param.values();
                            for (Object item : values) {
                                argsBuffer.append(",").append(item);
                            }
                        }
                        clearTaskSubmitVo.setCodeType(ScriptTypeToCodeType(ruleRecord.getScriptType()));
                        clearTaskSubmitVo.setMainClass(ruleRecord.getMainClass());
                        clearTaskSubmitVo.setFilePath(ruleRecord.getFilePath());
                        clearTaskSubmitVo.setArgs(argsBuffer.toString());
                    }
                    clearTaskSubmitVo.setTaskId(taskId);
                    clearTaskSubmitVo.setDependence(taskDetailVo.getDependence());
                    scheduleJobEntity.setClearTaskSubmitVo(clearTaskSubmitVo);
                }
            }
        }
        JSONObject taskParams = new JSONObject();
        taskParams.put("config", Base64.encodeBase64String(stepsJsonObject.toJSONString().getBytes()).replaceAll("\r\n", ""));
        asyncTaskConfigVo.setTaskParams(taskParams);

        //获取croncode并转为cron表达式
        String cronCode = taskDetailVo.getCronCode();
        //List<CronTab> cronTabs = JSON.parseArray(cronCode, CronTab.class);
        JSONArray jsonArray = JSON.parseArray(cronCode);
        //设置进scheduleJobEntity
        Set<String> crons = new HashSet<>();
        for (Object object : jsonArray) {
            JSONObject item = (JSONObject) (object);
            Object time = item.get("time");
            try {
                if (time == null) {
                    CronTab cronTab = JSON.parseObject(item.toJSONString(), CronTab.class);
                    String cronString = CronUtil.toCronString(cronTab);
                    crons.add(cronString);
                } else {
                    long cronlong = Long.valueOf(String.valueOf(time)).longValue();
                    //判断当前时间是否已经超过该定时时间，超过则不启动该定时任务
                    long currentTimeMillis = System.currentTimeMillis();
                    if (cronlong > currentTimeMillis) {
                        String cronString = CronUtil.toCronString(cronlong);
                        crons.add(cronString);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        scheduleJobEntity.setCronExpressions(crons);
        scheduleJobEntity.setAsyncTaskConfigVo(asyncTaskConfigVo);
        scheduleJobEntity.setPriority(taskDetailVo.getPriority());
        resultVo.setData(scheduleJobEntity);
        resultVo.setErrorCode(0);
        return resultVo;
    }


    /**
     * 传入jsonObject对象中获取ClearTaskSubmitVo信息并构建它
     *
     * @param stepsJsonObject
     * @param frontendJsonArray
     * @param taskId
     * @param outTableName
     * @return
     */
    private ClearTaskSubmitVo getClearTaskSubmitVo(JSONObject stepsJsonObject, JSONArray frontendJsonArray, BigDecimal taskId, String outTableName) {
        ClearTaskSubmitVo clearTaskSubmitVo = new ClearTaskSubmitVo();
        //获取scriptType,mainClass,filePath（目前只支持一个自定义算法，所以frontendJsonObject中最多只有一个算法信息）
        if (frontendJsonArray.size() > 0) {
            JSONObject clearRuleObject = frontendJsonArray.getJSONObject(0);
            BigDecimal ruleId = clearRuleObject.getBigDecimal("id");
            TClearRuleRecord ruleRecord = clearRuleDao.findById(ruleId);
            //构建args,(目前只支持一个自定义算法，所以steps.script.steps中最多只有一个param信息)
            StringBuffer argsBuffer = new StringBuffer();
            String inTableName = stepsJsonObject.getString("tableName");
            argsBuffer.append(inTableName).append(",").append(outTableName);
            JSONArray stepsJsonArray = stepsJsonObject.getJSONObject("script").getJSONArray("steps");
            if (stepsJsonArray.size() > 0) {
                JSONObject param = stepsJsonArray.getJSONObject(0).getJSONObject("param");
                Collection<Object> values = param.values();
                for (Object item : values) {
                    argsBuffer.append(",").append(item);
                }
            }
            clearTaskSubmitVo.setCodeType(ScriptTypeToCodeType(ruleRecord.getScriptType()));
            clearTaskSubmitVo.setMainClass(ruleRecord.getMainClass());
            clearTaskSubmitVo.setFilePath(ruleRecord.getFilePath());
            clearTaskSubmitVo.setArgs(argsBuffer.toString());
        }
        clearTaskSubmitVo.setTaskId(taskId);
        return clearTaskSubmitVo;
    }

    private String ScriptTypeToCodeType(Integer scriptType) {
        if (scriptType == ScriptType.R.getValue()) {
            return "R";
        } else if (scriptType == ScriptType.PYTHON.getValue()) {
            return "python";
        } else {
            return "java";
        }
    }

    /**
     * 数据整理任务更新
     *
     * @param clearTaskUpdateVo
     * @param userId
     * @return
     */
    @Override
    public ResultVo<Object> update(ClearTaskUpdateVo clearTaskUpdateVo, String userId) {
        ResultVo<Object> resultVo = new ResultVo<Object>();
        //从数据库查询出需要修改的信息
        TClearTaskRecord tClearTaskRecord = clearTaskDao.findById(clearTaskUpdateVo.getId());
        if (tClearTaskRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode());
        }
        //获取old输出表名
        String oldOutItemName = tClearTaskRecord.getOutItemName();
        //调用方法设置值
        tClearTaskRecord = (TClearTaskRecord) VoReTraversalUtil.traversalTwo(clearTaskUpdateVo, TClearTaskRecord.class);
        //更新人
        tClearTaskRecord.setUpdateUser(userId);
        //更新时间
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        tClearTaskRecord.setUpdateTime(timestamp);
        //TODO 获取输出表信息创建输出表(输出表默认以为新建)
        //先获取输出表信息创建输出表
        ItemAddVo itemAddVo = new ItemAddVo();
        //对表名进行判重
        String newOutItemName = clearTaskUpdateVo.getOutItemName();
        //判断，若输出表名没有进行修改，那么不判重，反之则判重
        if (newOutItemName != null && !oldOutItemName.equals(newOutItemName)) {
            List<TClearTaskRecord> fetch1 = clearTaskDao.fetch(T_CLEAR_TASK.OUT_ITEM_NAME, newOutItemName);
            if (fetch1.size() > 0) {
                return new ResultVo<>(ErrorCode.ParamError.getErrorCode(), "传入参数错误，当前输出表已经存在任务，不可重复添加!");
            }
            List<TMetadataItemRecord> fetch2 = itemDao.fetch(T_METADATA_ITEM.NAME, newOutItemName);
            if (fetch2.size() > 0) {
                return new ResultVo<>(ErrorCode.ParamError.getErrorCode(), "传入参数错误，当前输出表名与已有表名重复!");
            }
            itemAddVo.setName(newOutItemName);
            itemAddVo.setPurpose(clearTaskUpdateVo.getOutItemPurpose());
            //设置默分区到输入表下的分区一致
            BigDecimal outThemeItemId = clearTaskUpdateVo.getOutThemeItemId();
            if (outThemeItemId != null) {
                itemAddVo.setThemeItemId(outThemeItemId);
            }
            //itemAddVo.setThemeItemId(themeItemId);
            itemAddVo.setType(clearTaskUpdateVo.getOutItemType());
            //设置来源为数据清洗
            itemAddVo.setSourceType(ItemSourceType.DATA_CLEAR.getValue());
            TMetadataItemRecord tItemRecord = (TMetadataItemRecord) VoReTraversalUtil.traversalTwo(itemAddVo, TMetadataItemRecord.class);
            BigDecimal outItemId = BigDecimal.valueOf(idGeneratorService.id());
            tItemRecord.setId(outItemId);
            tClearTaskRecord.setOutItemId(outItemId);
            //创建人，同时也是更新人
            tItemRecord.setCreateUser(userId);
            tItemRecord.setUpdateUser(userId);
            //插入表中
            itemDao.insert(tItemRecord);
        }

        //插入流程整合任务表中
        clearTaskDao.update(tClearTaskRecord);
        //同步处理定时任务
        ClearTaskDetailVo taskDetailVo = (ClearTaskDetailVo) VoReTraversalUtil.traversalTwo(tClearTaskRecord, ClearTaskDetailVo.class);
        //查询记录信息获取handleCode
        BigDecimal recordId = tClearTaskRecord.getRecordId();
        TClearRecordRecord recordRecord = clearRecordDao.findById(recordId);
        String handleCode = recordRecord.getHandleCode();
        //判断statue是否改变
        Boolean flag = clearTaskUpdateVo.getStatus().equals(tClearTaskRecord.getStatus()) ? false : true;
        if (flag) {
            Integer status = tClearTaskRecord.getStatus();
            //执行
            if (status == 1) {
                //恢复任务
                scheduleUtils.resumeJob(tClearTaskRecord.getId());
            } else {//停止
                //暂停任务
                scheduleUtils.pauseJob(tClearTaskRecord.getId());
            }
            resultVo.setData("success");
            return resultVo;
        }
        //更新定时任务
        ResultVo resultVo1 = getScheduleJobEntity(taskDetailVo, handleCode);
        if (resultVo1.getErrorCode() == 0) {
            ScheduleJobEntity scheduleJobEntity = (ScheduleJobEntity) resultVo1.getData();
            scheduleUtils.createScheduleJob(scheduleJobEntity);
//                scheduleUtils.updateScheduleJob(scheduleJobEntity);
        } else {
            return resultVo1;
        }
        resultVo.setData("success");
        return resultVo;
    }

    /**
     * 数据整理任务删除
     *
     * @param id
     * @return
     */
    @Override
    public ResultVo<Object> delete(BigDecimal id) {
        //查询是否存在
        TClearTaskRecord tClearTaskRecord = clearTaskDao.findById(id);
        if (tClearTaskRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), false);
        }
        List<BigDecimal> ids = new ArrayList<>();
        ids.add(id);
        //删除日志记录以及任务
        clearTaskLogDao.deleteByTaskId(id);
        clearTaskDao.deleteById(ids);
        return new ResultVo<>(0, true);

    }

    /**
     * 数据整理任务列表查询
     *
     * @param clearTaskQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    @Override
    public ResultVo<PageVo<List<ClearTaskListVo>>> list(ClearTaskQueryVo clearTaskQueryVo, String userId, Integer page, Integer size) {
        List<SortField<?>> sortList = new ArrayList<>();
        //添加排序字段
        sortList.add(T_CLEAR_TASK.UPDATE_TIME.desc());
        //添加条件字段
        List<Condition> conditions = innerAddListCondition(clearTaskQueryVo);
        //权限限制，只能看到自己创建的任务
        if (userId != null) {
            conditions.add(T_CLEAR_TASK.CREATE_USER.eq(userId));
        }
        //查询赋值返回
        PageVo<TClearTaskRecord> query = clearTaskDao.fetchByPage(conditions, new OffsetPagingVo(page, size), sortList);
        List<TClearTaskRecord> tClearTaskRecords;
        tClearTaskRecords = query.getPageData();
        List<ClearTaskListVo> list = new ArrayList<>();
        for (TClearTaskRecord tClearTaskRecord : tClearTaskRecords
                ) {
            ClearTaskListVo clearTaskListVo = (ClearTaskListVo) VoReTraversalUtil.traversalTwo(tClearTaskRecord, ClearTaskListVo.class);
            //查询创建者名字
            String name = usersDao.getNameByUserId(tClearTaskRecord.getCreateUser());
            clearTaskListVo.setCreateUserName(name);
            clearTaskListVo.setDependenceDisplayVO(jobService.convertToDisplayVO(tClearTaskRecord.getDependence()));
            list.add(clearTaskListVo);
        }
        PageVo<ClearTaskListVo> result = new PageVo<>();
        result.setPageData(list);
        result.setTotalCount(query.getTotalCount());
        return new ResultVo(0, result);
    }

    /**
     * 为list添加条件字段的方法
     *
     * @param clearTaskQueryVo
     * @return
     */
    private List<Condition> innerAddListCondition(ClearTaskQueryVo clearTaskQueryVo) {
        List<Condition> conditions = new ArrayList<>();
        //添加条件字段
        String name = clearTaskQueryVo.getName();
        String inItemName = clearTaskQueryVo.getInItemName();
        String outItemName = clearTaskQueryVo.getOutItemName();
        if (name != null) {
            conditions.add(T_CLEAR_TASK.NAME.like("%" + name + "%"));
        }
        if (inItemName != null) {
            conditions.add(T_CLEAR_TASK.IN_ITEM_NAME.like("%" + inItemName + "%"));
        }
        if (outItemName != null) {
            conditions.add(T_CLEAR_TASK.OUT_ITEM_NAME.like("%" + outItemName + "%"));
        }
        return conditions;
    }

    /**
     * 数据整理任务详情查询
     *
     * @param id
     * @return
     */
    @Override
    public ResultVo<ClearTaskDetailVo> clearTaskById(BigDecimal id) {
        TClearTaskRecord tClearTaskRecord = clearTaskDao.findById(id);
        if (tClearTaskRecord == null) {
            return new ResultVo<>(ErrorCode.NotExists.getErrorCode(), null);
        }
        ClearTaskDetailVo clearTaskClearTaskVo = (ClearTaskDetailVo) VoReTraversalUtil.traversalTwo(tClearTaskRecord, ClearTaskDetailVo.class);
        //查询创建者名字
        String name = usersDao.getNameByUserId(tClearTaskRecord.getCreateUser());
        clearTaskClearTaskVo.setCreateUserName(name);
        clearTaskClearTaskVo.setDependenceDisplayVO(jobService.convertToDisplayVO(tClearTaskRecord.getDependence()));
        return new ResultVo<>(0, clearTaskClearTaskVo);
    }

    /**
     * 更新定时任务最近执行信息
     *
     * @param clearTaskUpdateVo
     * @return
     */
    @Override
    public void updateNearData(ClearTaskUpdateVo clearTaskUpdateVo) {
        TClearTaskRecord tClearTaskRecord = clearTaskDao.findById(clearTaskUpdateVo.getId());
        //调用方法设置值
        tClearTaskRecord = (TClearTaskRecord) VoReTraversalUtil.traversalTwo(clearTaskUpdateVo, TClearTaskRecord.class);
        //插入流程整合任务表中
        clearTaskDao.update(tClearTaskRecord);
    }

    /**
     * 立即执行的接口
     *
     * @param taskId
     * @return
     */
    @Override
    public ResultVo nowExecute(BigDecimal taskId) {
        TClearTaskRecord taskRecord = clearTaskDao.findById(taskId);
        if (taskRecord == null || taskRecord.getRecordId() == null) {
            return new ResultVo(ErrorCode.ParamError.getErrorCode(), "找不到对应任务信息或者流程信息!");
        }
        BigDecimal recordId = taskRecord.getRecordId();
        TClearRecordRecord recordRecord = clearRecordDao.findById(recordId);
        if (recordRecord == null || recordRecord.getHandleCode() == null || recordRecord.getHandleCode().equals("")) {
            return new ResultVo(ErrorCode.ParamError.getErrorCode(), "找不到对应的流程信息或者流程中无执行json串!");
        }
        String handleCode = recordRecord.getHandleCode();
        AsyncTaskConfigVo asyncTaskConfigVo = new AsyncTaskConfigVo();
        asyncTaskConfigVo.setDependence(taskRecord.getDependence());
        ClearTaskSubmitVo clearTaskSubmitVo = new ClearTaskSubmitVo();
        //判断是不是自定义算法
        JSONObject handleCodeObject = JSONObject.parseObject(handleCode);
        JSONArray frontend = handleCodeObject.getJSONArray("frontend");
        JSONObject object = frontend.getJSONObject(0);
        Object filePath = object.get("filePath");
        if (!StringUtils.isEmpty(filePath)) {
            //自定义算法
            String steps = handleCodeObject.getString("steps");
            JSONObject stepsJsonObject = JSON.parseObject(steps);
            String outItemName = taskRecord.getOutItemName();
            clearTaskSubmitVo = getClearTaskSubmitVo(stepsJsonObject, frontend, taskId, outItemName);
        } else {
            ClearTaskDetailVo taskDetailVo = (ClearTaskDetailVo) VoReTraversalUtil.traversalTwo(taskRecord, ClearTaskDetailVo.class);
            //封装asyncTaskConfigVo
            asyncTaskConfigVo.setTaskId(taskDetailVo.getId());
            asyncTaskConfigVo.setPreProcessProcessor(new ClearTaskPreProcessor());
            asyncTaskConfigVo.setTopic(KAFAKA_TOPIC_CLEAR);
            //将handleCode转为json对象
            JSONObject jsonStringOne = JSON.parseObject(handleCode);
            String steps = jsonStringOne.getString("steps");
            JSONObject jsonObject = JSON.parseObject(steps);
            //构建"target_table":"test2","overwrite":"true","dbName":"default"格式
            if (taskDetailVo != null) {
                jsonObject.put("target_table", taskDetailVo.getOutItemName());
                jsonObject.put("overwrite", "true");
                jsonObject.put("dbName", "default");
            }
            JSONObject taskParams = new JSONObject();
            taskParams.put("config", Base64.encodeBase64String(jsonObject.toJSONString().getBytes()).replaceAll("\r\n", ""));
            asyncTaskConfigVo.setTaskParams(taskParams);
        }
        //构建job信息
        AsyncTaskExecuteServiceImpl asyncTaskExecuteService = new AsyncTaskExecuteServiceImpl();
        try {
            if (!StringUtils.isEmpty(filePath)) {
                //自定义算法
                asyncTaskExecuteService.execute(clearTaskSubmitVo, true);
            } else {
                asyncTaskExecuteService.execute(asyncTaskConfigVo, true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ResultVo(0, "success!");
    }

    @Override
    public void clearTaskFinished(ClearTaskFinishedResponseVO response) {
        try {
            BigDecimal taskId = new BigDecimal(response.getTaskId());
            ClearTaskLogUpdateVo updateVo = new ClearTaskLogUpdateVo();
            ClearTaskUpdateVo clearTaskUpdateVo = new ClearTaskUpdateVo();
            updateVo.setTaskId(taskId);
            if (StringUtil.isNotEmpty(response.getLogId())) {
                updateVo.setId(new BigDecimal(response.getLogId()));
            }
            clearTaskUpdateVo.setId(taskId);
            Timestamp currentTime = new Timestamp(System.currentTimeMillis());
            updateVo.setEndTime(currentTime);
            clearTaskUpdateVo.setNearEndTime(currentTime);
            //获取任务信息
            TClearTaskRecord taskRecord = clearTaskDao.findById(taskId);
            if (taskRecord == null) {
                return;
            }
            if (response.getErrorMsg() != null) {
                updateVo.setTaskLog(response.getErrorMsg());
                updateVo.setResult(TaskResult.FAIL.getValue());
                clearTaskUpdateVo.setNearResult(TaskResult.FAIL.getValue());
                //发送短信或者邮箱
                if (taskRecord != null) {
                    sendEmailAndNote(taskRecord.getName(), taskRecord.getEmail(), taskRecord.getPhone(), "失败", currentTime);
                }
            } else {
                try {
                    updateVo.setResult(TaskResult.SUCCESS.getValue());
                    updateVo.setTaskLog("执行成功！");
                    clearTaskUpdateVo.setNearResult(TaskResult.SUCCESS.getValue());
                    //判断当前表（元数据条目）是否有列，没有则增加
                    BigDecimal outItemId = taskRecord.getOutItemId();
                    //查询当前条目的列信息
                    TMetadataDetailRecord[] records = detailDao.getByItemId(outItemId);
                    if (records == null || records.length == 0) {
                        //获取返回列信息
                        List<ClearTaskColVo> colVos = response.getTableStruct();
                        //循环添加列信息
                        //准备参数，在仓库创建表以及分析表
                        CreateHiveTableVo createHiveTableVo = new CreateHiveTableVo();
                        createHiveTableVo.setTableName(taskRecord.getOutItemName());
                        //别名暂时使用表名
                        createHiveTableVo.setDisplayName(taskRecord.getOutItemName());
                        createHiveTableVo.setCreated_uuid(taskRecord.getUpdateUser().toString());
                        List<CreateHiveColVo> analyzeColVos = new ArrayList<>();
                        //定义自增index
                        int index = 1;
                        for (ClearTaskColVo item : colVos) {
                            DetailAddVo detailAddVo = new DetailAddVo();
                            detailAddVo.setColComment("未知");
                            detailAddVo.setColDisplayname(item.getColumnName());
                            detailAddVo.setColName(item.getColumnName());
                            String datatype = item.getDatatype();
                            //将datatype转为对应码值
                            Integer colType = innerTypeChange(datatype);
                            detailAddVo.setColType(colType);
                            detailAddVo.setIndex(index);
                            detailAddVo.setMetadataItemId(outItemId);
                            detailService.add(detailAddVo, "0");
                            index++;

                            //准备添加分析表用的列
                            CreateHiveColVo colVo = new CreateHiveColVo();
                            colVo.setColName(item.getColumnName());
                            String colTypeValue = item.getDatatype();
                            colVo.setDbType(colTypeValue);
                            colVo.setColDisplayName(item.getColumnName());
                            analyzeColVos.add(colVo);
                        }
                        createHiveTableVo.setColumns(analyzeColVos);
                        //创建分析表
                        String muUrl = idmanagerBaseUrl + REST_FOR_CREATE_TABLE + "?force=false";
                        String patch = HttpClientUtil.doPostByJson(muUrl, JSON.toJSONString(createHiveTableVo));
                        if (patch.equals("fail")) {
                            logger.info("---添加分析表失败--");
                        }
                    } else {
                        jobService.refreshHiveTable(taskRecord.getOutItemName());
                        jobService.clearChartCache(taskRecord.getOutItemName());
                    }
                    //发送短信或者邮箱
                    sendEmailAndNote(taskRecord.getName(), taskRecord.getEmail(), taskRecord.getPhone(), "成功", currentTime);
                } catch (Exception e) {
                    e.printStackTrace();
                    updateVo.setResult(TaskResult.FAIL.getValue());
                    updateVo.setTaskLog("Response can't parse to json!");
                    clearTaskUpdateVo.setNearResult(TaskResult.FAIL.getValue());
                    //发送短信或者邮箱
                    sendEmailAndNote(taskRecord.getName(), taskRecord.getEmail(), taskRecord.getPhone(), "失败", currentTime);
                }
            }
            logService.updateOrSave(updateVo, "0");
            updateNearData(clearTaskUpdateVo);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Integer innerTypeChange(String datatype) {
        if (datatype.equalsIgnoreCase("tinyint")
                || datatype.equalsIgnoreCase("smallint")
                || datatype.equalsIgnoreCase("int")
                || datatype.equalsIgnoreCase("float")
                || datatype.equalsIgnoreCase("bigint")
                || datatype.equalsIgnoreCase("double")
                || datatype.equalsIgnoreCase("decimal")
                || datatype.equalsIgnoreCase("integer")) {
            return 302;
        } else {
            return 301;
        }
    }

    @Override
    public void sendEmailAndNote(String taskName, String emails, String phones, String result, Timestamp currentTime) {
        if (taskName == null) {
            taskName = "";
        }
        //邮件发送
        if (StringUtil.isNotEmpty(emails)) {
            String subject = "【成都金控征信有限公司-大数据基础平台消息提醒】";
            String html = "[金控征信大数据基础平台]整合任务(" + taskName + ")执行完毕，完成时间(" + currentTime + "),结果(" + result + ")。";
            //发送
            try {
                String[] emailArr = emails.split(",");
                for (String email : emailArr) {
                    EmailUtil.sendHtmlMail(email, subject, html);
                }
            } catch (Exception e) {
                e.printStackTrace();
                logger.error(taskName + "邮件发送失败！");
            }
        }
        if (StringUtil.isNotEmpty(phones)) {
            String[] phoneArr = phones.split(",");
            for (String phone : phoneArr) {
                smsService.sendClearJobNotice(phone, taskName, currentTime.toString(), result);
            }
        }
    }
}
