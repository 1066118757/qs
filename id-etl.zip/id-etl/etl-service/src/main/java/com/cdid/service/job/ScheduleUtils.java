package com.cdid.service.job;

import com.cdid.api.job.vo.ScheduleJobEntity;
import com.cdid.asynctask.AsyncTaskExecuteServiceImpl;
import org.quartz.*;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;

/**
 * 定时任务工具类
 */
@Component
public class ScheduleUtils {
    public final static String JOB_CONFIG = "requestVo";
    public final static String CLEAR_TASK_SUBMIT = "clearTaskSubmitVo";
    public final static String LEARNING_MODEL_DEPLOY = "learning_model_deploy";

    @Resource
    private Scheduler scheduler;

    /**
     * 获取触发器key
     */
    public TriggerKey getTriggerKey(BigDecimal jobId) {
        return TriggerKey.triggerKey(jobId.toEngineeringString());
    }
    
    /**
     * 获取jobKey
     */
    public JobKey getJobKey(BigDecimal jobId) {
        return JobKey.jobKey(jobId.toEngineeringString());
    }

    /**
     * 获取表达式触发器
     */
    public List<CronTrigger> getCronTrigger(BigDecimal jobId) {
        try {
            return (List<CronTrigger>)scheduler.getTriggersOfJob(getJobKey(jobId));
        } catch (SchedulerException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 创建定时任务
     */
    public void createScheduleJob(ScheduleJobEntity scheduleJob) {
        try {
        	//构建job信息
            JobDetail jobDetail = JobBuilder.newJob(AsyncTaskExecuteServiceImpl.class).withIdentity(getJobKey(scheduleJob.getJobId())).build();

            //表达式调度构建器
            Set<CronTrigger> triggers = new HashSet<>();
            Set<String> cronExpressions = scheduleJob.getCronExpressions();
            Integer priority = scheduleJob.getPriority();
            priority = priority == null ? 0 : priority;
            Iterator<String> it = cronExpressions.iterator();
            while (it.hasNext()) {
                String cron = it.next();
                CronScheduleBuilder scheduleBuilder = CronScheduleBuilder.cronSchedule(cron)
                        .withMisfireHandlingInstructionDoNothing();
                //按新的cronExpression表达式构建一个新的trigger
                CronTrigger trigger = TriggerBuilder.newTrigger().withIdentity(getTriggerKey(scheduleJob.getJobId())).withSchedule(scheduleBuilder).withPriority(priority).build();
                triggers.add(trigger);
            }

            //放入参数，运行时的方法可以获取
            jobDetail.getJobDataMap().put(JOB_CONFIG,scheduleJob.getAsyncTaskConfigVo());
            jobDetail.getJobDataMap().put(CLEAR_TASK_SUBMIT,scheduleJob.getClearTaskSubmitVo());
            jobDetail.getJobDataMap().put(LEARNING_MODEL_DEPLOY,scheduleJob.getLearningModelDeployId());
            scheduler.scheduleJob(jobDetail, triggers,true);
        } catch (SchedulerException e) {
            e.printStackTrace();
        }
    }

    public void schedule(Class<? extends org.quartz.Job> jobClass,String jobKey,ScheduleBuilder scheduleBuilder,Date startAt){
        JobDetail jobDetail = JobBuilder.newJob(jobClass).withIdentity(new JobKey(jobKey)).build();
        String triggerKey="trigger"+jobKey;
        Trigger trigger=TriggerBuilder.newTrigger().withIdentity(new TriggerKey(triggerKey)).startAt(startAt).withSchedule(scheduleBuilder).build();
        try {
            scheduler.scheduleJob(jobDetail,trigger);
        } catch (SchedulerException e) {
            e.printStackTrace();
        }


    }

    /**
     * 暂停任务
     */
    public void pauseJob(BigDecimal jobId) {
        try {
            scheduler.pauseJob(getJobKey(jobId));
        } catch (SchedulerException e) {
            e.printStackTrace();
        }
    }

    /**
     * 恢复任务
     */
    public void resumeJob(BigDecimal jobId) {
        try {
            scheduler.resumeJob(getJobKey(jobId));
        } catch (SchedulerException e) {
            e.printStackTrace();
        }
    }

    /**
     * 删除定时任务
     */
    public void deleteScheduleJob(BigDecimal jobId) {
        try {
            scheduler.deleteJob(getJobKey(jobId));
        } catch (SchedulerException e) {
            e.printStackTrace();
        }
    }
}
