
package com.cdid.service.oozie.graph;


import com.cdid.service.oozie.command.Parameter;
import org.dom4j.Element;

import java.util.LinkedList;
import java.util.List;

/**
 * Program node in Oozie workflow graph
 */
public class OozieProgramNode extends OozieNode {

	/** Input Parameters of the program */
	private List<Parameter> params = new LinkedList<>();

	private String workPath="";

	private String personalConfig;

	private String oozJobId="";

	private String programType;

	private String programPath;

	private String data;

	public OozieProgramNode() {
	}

	public List<Parameter> getParams() {
		return params;
	}

	public void addParam(Parameter param) {
		params.add(param);
	}

	public String getPersonalConfig() {
		return personalConfig;
	}

	public void setPersonalConfig(String personalConfig) {
		this.personalConfig = personalConfig;
	}

	public String getOozJobId() {
		return oozJobId;
	}

	public void setOozJobId(String oozJobId) {
		this.oozJobId = oozJobId;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getProgramType() {
		return programType;
	}

	public void setProgramType(String programType) {
		this.programType = programType;
	}

	public void setParams(List<Parameter> params) {
		this.params = params;
	}

	public String getProgramPath() {
		return programPath;
	}

	public void setProgramPath(String programPath) {
		this.programPath = programPath;
	}

	/**
	 * Generate a XML String for the node
	 */
	@Override
	public String toXML() {
		StringBuffer sb = new StringBuffer(500);
		sb.append("<widget type='program'>\n");
		genXML(sb);
		return sb.toString();
	}
	public void genXML(StringBuffer sb){
		sb.append("  <id>" + id + "</id>\n");
		sb.append("  <moduleId>" + moduleId + "</moduleId>\n");
		sb.append("  <alias>"+alias+"</alias>\n");
		sb.append("  <oozJob>" + oozJobId + "</oozJob>\n");
		sb.append("  <x>" + x + "</x>\n");
		sb.append("  <y>" + y + "</y>\n");
		sb.append("  <workPath>"+workPath+"</workPath>\n");
		sb.append("  <programType>"+programType+"</programType>\n");
		sb.append("  <programPath>"+programPath+"</programPath>\n");
		sb.append("  <personalConfig>"+personalConfig+"</personalConfig>\n");
		sb.append("  <data>"+data+"</data>\n");
		for (Parameter param : params)
			sb.append("  <param>" + param.toXML() + "</param>\n");
		sb.append("</widget>\n");
	}
	public String getWorkPath() {
		return workPath;
	}

	public void setWorkPath(String workPath) {
		this.workPath = workPath;
	}

	public static OozieProgramNode valueOf(Element xml_node){
		List<Element> childNodes = xml_node.elements();
		OozieProgramNode node = new OozieProgramNode();
		for( Element child : childNodes){
			String value = child.getText();
			String name = child.getName();
			if ("id".equals(name)){
				node.setId(value);
			}else if ("moduleId".equals(name)){
				node.setModuleId(value);
			} else if ( "oozJob".equals(name)){
				node.setOozJobId( value );
			} else if ("x".equals(name)){
				node.setX((int) Float.parseFloat(value));
			} else if ("y".equals(name)){
				node.setY((int) Float.parseFloat(value));
			}else if ("param".equals(name)){
				node.addParam(Parameter.valueOf(child));
			}else if("workPath".equals(name)){
				node.setWorkPath(value);
			} else if("personalConfig".equals(name)){
				node.setPersonalConfig(value);
			}else if("programPath".equals(name)){
				node.setProgramPath(value);
			}else if("programType".equals(name)){
				node.setProgramType(value);
			}else if("alias".equals(name)){
				node.setAlias(value);
			}else if("data".equals(name)){
				node.setData(value);
			}
		}
		return node;
	}

}
