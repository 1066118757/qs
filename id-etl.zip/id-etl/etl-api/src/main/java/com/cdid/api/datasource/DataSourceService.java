package com.cdid.api.datasource;

import com.cdid.api.datasource.vo.*;
import com.cdid.common.vo.JDBCVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResponseVo;
import com.cdid.common.vo.ResultVo;

import java.math.BigDecimal;
import java.util.List;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/02 14:59 
 */
public interface DataSourceService {

    ResultVo<BigDecimal> add(DataSourceAddVo dataSourceAddVo,String userId) throws Exception;

    ResultVo<String> delete(BigDecimal id,String userId) throws Exception;

    ResultVo<String> update(DataSourceUpdateVo dataSourceUpdateVo,String userId) throws Exception;

    ResultVo<String> updateInfo(DataSourceUpdateVo dataSourceUpdateVo,String userId) throws Exception;

    ResultVo<PageVo<DataSourceListVo>> list(DataSourceQueryVo dataSourceQueryVo,String userId,Integer page,Integer size) throws Exception;

    ResultVo<DataSourceDetailVo> findById(BigDecimal id) throws Exception;

    ResultVo<ResponseVo> connectionTest(JDBCVo jdbcVo, String userId);

    ResultVo<List<TablesVo>> queryTableName(JDBCVo jdbcVo);

    ResultVo<List<TablesVo>> queryDistTableName();

    ResultVo<List<TablesVo>> queryDistTableName(String userId);

    ResultVo<List<TableAndFieldVo>> queryTableFilelds(JDBCVo jdbcVo);

    ResultVo<List<TableAndFieldVo>> queryDistTableFilelds(String tableName);

}
