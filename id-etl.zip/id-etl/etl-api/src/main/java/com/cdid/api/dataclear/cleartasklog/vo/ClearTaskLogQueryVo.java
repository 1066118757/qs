package com.cdid.api.dataclear.cleartasklog.vo;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/12/13
 */
@ApiModel(value = "清理任务日志查询对象")
public class ClearTaskLogQueryVo {
    /*@ApiModelProperty(value="id",example="id")
    private BigDecimal id;
    @ApiModelProperty(value="任务id",example="任务id")
    private BigDecimal taskId;
    @ApiModelProperty(value="开始时间",example="开始时间")
    private Timestamp startTime;
    @ApiModelProperty(value="结束时间",example="结束时间")
    private Timestamp endTime;
    @ApiModelProperty(value="任务执行结果，参考码表10",example="任务执行结果，参考码表10")
    private Integer result;
    private BigDecimal createUser;*/

    @ApiModelProperty(value="任务id",example="任务id")
    private BigDecimal taskId;

    public BigDecimal getTaskId() {
        return taskId;
    }

    public void setTaskId(BigDecimal taskId) {
        this.taskId = taskId;
    }
}
