package com.cdid.api.datasource.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.util.Map;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/07 16:39 
 */
@ApiModel("webService连接属性")
public class WebServiceVo {


    private BigDecimal dataSourceId;

    @ApiModelProperty(value="请求方式",example="get")
    private String requestMethod;
    @ApiModelProperty(value="请求地址",example="http://baidu.com")
    private String requestUrl;
//    @ApiModelProperty(value="Content-Type",example="application/json")
//    private String contentType;
    @ApiModelProperty(value="hearder")
    private String headers;
    @ApiModelProperty(value="请求参数",example="json格式")
    private String body;

    public String getRequestMethod() {
        return requestMethod;
    }

    public void setRequestMethod(String requestMethod) {
        this.requestMethod = requestMethod;
    }

    public String getRequestUrl() {
        return requestUrl;
    }

    public void setRequestUrl(String requestUrl) {
        this.requestUrl = requestUrl;
    }

//    public String getContentType() {
//        return contentType;
//    }
//
//    public void setContentType(String contentType) {
//        this.contentType = contentType;
//    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getHeaders() {
        return headers;
    }

    public void setHeaders(String headers) {
        this.headers = headers;
    }

    public BigDecimal getDataSourceId() {
        return dataSourceId;
    }

    public void setDataSourceId(BigDecimal dataSourceId) {
        this.dataSourceId = dataSourceId;
    }
}
