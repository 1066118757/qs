package com.cdid.api.dataclear.cleartask.vo;

import com.cdid.api.jupyter.vo.TaskRequestVo;

import java.math.BigDecimal;

public class ClearTaskBaseConfigVo extends TaskRequestVo {

    private String distJdbcUrl;

    private String distUserName;

    private String distPassword;

    private Integer distDbType;

    private String distSchema;

    private String distTable;

    //导入模式
    private Integer importMode;

    private Integer syncStrategy;

    //字段映射关系
    //封装了操作表以及规则实例化的代码
    private String handleCode;
    //目标表名
    private ClearTaskDetailVo clearTaskDetailVo;

    public ClearTaskDetailVo getClearTaskDetailVo() {
        return clearTaskDetailVo;
    }

    public void setClearTaskDetailVo(ClearTaskDetailVo clearTaskDetailVo) {
        this.clearTaskDetailVo = clearTaskDetailVo;
    }

    //private ConcurrentLinkedQueue<String> codeQueue;

    private BigDecimal scheduleLogId;

    public String getDistSchema() {
        return distSchema;
    }

    public void setDistSchema(String distSchema) {
        this.distSchema = distSchema;
    }

    public String getDistTable() {
        return distTable;
    }

    public void setDistTable(String distTable) {
        this.distTable = distTable;
    }

    public Integer getImportMode() {
        return importMode;
    }

    public void setImportMode(Integer importMode) {
        this.importMode = importMode;
    }

    public String getDistJdbcUrl() {
        return distJdbcUrl;
    }

    public void setDistJdbcUrl(String distJdbcUrl) {
        this.distJdbcUrl = distJdbcUrl;
    }

    public String getDistUserName() {
        return distUserName;
    }

    public void setDistUserName(String distUserName) {
        this.distUserName = distUserName;
    }

    public String getDistPassword() {
        return distPassword;
    }

    public void setDistPassword(String distPassword) {
        this.distPassword = distPassword;
    }

    public Integer getDistDbType() {
        return distDbType;
    }

    public void setDistDbType(Integer distDbType) {
        this.distDbType = distDbType;
    }

    public BigDecimal getScheduleLogId() {
        return scheduleLogId;
    }

    public void setScheduleLogId(BigDecimal scheduleLogId) {
        this.scheduleLogId = scheduleLogId;
    }

    public Integer getSyncStrategy() {
        return syncStrategy;
    }

    public void setSyncStrategy(Integer syncStrategy) {
        this.syncStrategy = syncStrategy;
    }

    public String getHandleCode() {
        return handleCode;
    }

    public void setHandleCode(String handleCode) {
        this.handleCode = handleCode;
    }
}
