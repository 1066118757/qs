package com.cdid.api.datasource;

import com.cdid.api.datasource.vo.TableAndFieldVo;
import com.cdid.api.datasource.vo.TablesVo;
import com.cdid.common.vo.JDBCVo;
import com.cdid.common.vo.ResultVo;

import java.util.List;

/**
 *  @author         ouzhicheng  
 *  @version        V1.0   
 *  @date           2017/12/06 15:59 
 */
public interface JDBCService {
    /**
     * 连接测试
     * @param jdbcVo
     * @return
     */
    ResultVo<Boolean> connectTest(JDBCVo jdbcVo);

    /**
     * 查询数据库表名
     * @param jdbcVo
     * @return
     */
    ResultVo<List<TablesVo>> queryTableName(JDBCVo jdbcVo);

    /**
     * 查询数据库指定表字段名
     * @param jdbcVo
     * @return
     */
    ResultVo<List<TableAndFieldVo>> queryTableFilelds(JDBCVo jdbcVo);
}
