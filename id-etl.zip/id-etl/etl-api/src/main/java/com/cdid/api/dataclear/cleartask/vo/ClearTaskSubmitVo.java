package com.cdid.api.dataclear.cleartask.vo;


import java.math.BigDecimal;

/**
 * @author OuZhiCheng
 * @create 创建时间：2018/2/27
 */
public class ClearTaskSubmitVo {
    private String codeType;
    private String args;
    private String filePath;
    private String mainClass;

    private BigDecimal taskId;

    private String dependence;

    public BigDecimal getTaskId() {
        return taskId;
    }

    public void setTaskId(BigDecimal taskId) {
        this.taskId = taskId;
    }

    public String getCodeType() {
        return codeType;
    }

    public void setCodeType(String codeType) {
        this.codeType = codeType;
    }

    public String getArgs() {
        return args;
    }

    public void setArgs(String args) {
        this.args = args;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getMainClass() {
        return mainClass;
    }

    public void setMainClass(String mainClass) {
        this.mainClass = mainClass;
    }

    public String getDependence() {
        return dependence;
    }

    public void setDependence(String dependence) {
        this.dependence = dependence;
    }
}
