package com.cdid.api.dataclear.ruleinstance;

import com.cdid.api.dataclear.ruleinstance.vo.*;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author OuZhiCheng
 */
public interface RuleInstanceService {
    /**
     * 规则实例化详情添加
     *
     * @param ruleInstanceAddVos
     * @param userId
     * @return
     */

    ResultVo<Object> add(List<RuleInstanceAddVo> ruleInstanceAddVos, String userId);

    /**
     * 规则实例化详情更新
     *
     * @param ruleInstanceUpdateVos
     * @param userId
     * @return
     */
    ResultVo<Object> update(List<RuleInstanceUpdateVo> ruleInstanceUpdateVos, String userId);

    /**
     * 规则实例化详情删除
     *
     * @param id
     * @return
     */
    ResultVo<Object> delete(BigDecimal id);

    /**
     * 规则实例化详情查询
     *
     * @param ruleInstanceQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    ResultVo<PageVo<List<RuleInstanceListVo>>> list(RuleInstanceQueryVo ruleInstanceQueryVo, String userId, Integer page, Integer size);

    /**
     * 规则实例化详情查询详情
     *
     * @param id
     * @return
     */
    ResultVo<RuleInstanceDetailVo> ruleInstanceById(BigDecimal id);

    /**
     * 通过整理记录id查询其规则实例化列表信息
     * @param recordId
     * @param userId
     * @return
     */
    List<RuleInstanceListVo> listByRecordId(BigDecimal recordId, String userId);
}
