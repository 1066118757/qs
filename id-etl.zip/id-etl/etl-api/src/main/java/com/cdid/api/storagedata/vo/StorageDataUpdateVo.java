package com.cdid.api.storagedata.vo;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * @Author Froid_Li
 * @Email 269504518@qq.com
 * @Date 2017/11/24  13:31
 */
@ApiModel(value = "更新存储数据对象")
public class StorageDataUpdateVo {
    @ApiModelProperty(name = "id", value = "存储数据id", required = true)

    private BigDecimal id;
    private String name;
    private String uploadUserId;
    private Timestamp uploadTime;
    private String introduction;
    private Integer type;


    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUploadUserId() {
        return uploadUserId;
    }

    public void setUploadUserId(String uploadUserId) {
        this.uploadUserId = uploadUserId;
    }

    public Timestamp getUploadTime() {
        return uploadTime;
    }

    public void setUploadTime(Timestamp uploadTime) {
        this.uploadTime = uploadTime;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }


    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }
}
