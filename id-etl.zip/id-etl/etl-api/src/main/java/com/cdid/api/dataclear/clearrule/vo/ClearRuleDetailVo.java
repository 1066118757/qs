package com.cdid.api.dataclear.clearrule.vo;


import com.cdid.api.dataclear.ruleparam.vo.RuleParamListVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/12/13
 */
@ApiModel(value = "清理规则详情对象")
public class ClearRuleDetailVo {
    @ApiModelProperty(value="id",example="id")
    private BigDecimal id;
    @ApiModelProperty(value="规则名",example="规则名")
    private String name;
    @ApiModelProperty(value="概述",example="概述")
    private String summary;
    @ApiModelProperty(value="规则类型",example="规则类型")
    private Integer ruleType;
    @ApiModelProperty(value="脚本类型",example="脚本类型")
    private Integer scriptType;
    @ApiModelProperty(value="脚本代码",example="脚本代码")
    private String scriptCode;
    @ApiModelProperty(value="规则状态",example="规则状态 1:代表启用,0:代表禁用")
    private Integer state;
    @ApiModelProperty(value="自定义算法文件路径",example="自定义算法文件路径")
    private String filePath;
    @ApiModelProperty(value="自定义算法主函数",example="自定义算法主函数")
    private String mainClass;
    private Integer status;
    private Timestamp createTime;
    private String createUser;
    private String createUserName;
    private Timestamp updateTime;
    private String updateUser;

    @ApiModelProperty(value="规则参数集合",example="规则参数集合")
    List<RuleParamListVo> ruleParamListVos;

    public List<RuleParamListVo> getRuleParamListVos() {
        return ruleParamListVos;
    }

    public void setRuleParamListVos(List<RuleParamListVo> ruleParamListVos) {
        this.ruleParamListVos = ruleParamListVos;
    }

    public String getCreateUserName() {
        return createUserName;
    }

    public void setCreateUserName(String createUserName) {
        this.createUserName = createUserName;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Timestamp getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Timestamp updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public Integer getRuleType() {
        return ruleType;
    }

    public void setRuleType(Integer ruleType) {
        this.ruleType = ruleType;
    }

    public Integer getScriptType() {
        return scriptType;
    }

    public void setScriptType(Integer scriptType) {
        this.scriptType = scriptType;
    }

    public String getScriptCode() {
        return scriptCode;
    }

    public void setScriptCode(String scriptCode) {
        this.scriptCode = scriptCode;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getMainClass() {
        return mainClass;
    }

    public void setMainClass(String mainClass) {
        this.mainClass = mainClass;
    }
}
