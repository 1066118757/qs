package com.cdid.api.storagedata.vo;


import io.swagger.annotations.ApiModel;

import java.math.BigDecimal;

/**
 * @Author Froid_Li
 * @Email 269504518@qq.com
 * @Date 2017/11/27  11:49
 */
@ApiModel(value = "添加存储数据对象")

public class StorageDataAddVo {
    //    private BigDecimal id;
    private String name;
    //    private BigDecimal uploadUserId;
//    private Timestamp uploadTime;
    private String introduction;
    //    private BigDecimal fileId;
    private Integer type;
//    private String filePath;
    private String userId;

    private Boolean isPublic;

    private BigDecimal groupId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Boolean getIsPublic() {
        return isPublic;
    }

    public void setIsPublic(Boolean isPublic) {
        this.isPublic = isPublic;
    }

    public BigDecimal getGroupId() {
        return groupId;
    }

    public void setGroupId(BigDecimal groupId) {
        this.groupId = groupId;
    }
}
