package com.cdid.api.version.vo;


import io.swagger.annotations.ApiModel;

import java.math.BigDecimal;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/11/24
 */
@ApiModel(value = "更新版本信息对象")
public class VersionUpdateVo {
    private BigDecimal id;
    private String no;
    private String name;
    private String description;
    private String logo;
    private String image;
    private Integer state;
//    private Long createUser;
//    private Timestamp createTime;
//    private Long updateUser;
//    private Timestamp updateTime;
//    private Short flag;

    private String iconImage;

    public String getIconImage() {
        return iconImage;
    }

    public void setIconImage(String iconImage) {
        this.iconImage = iconImage;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getNo() {
        return no;
    }

    public void setNo(String no) {
        this.no = no;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
