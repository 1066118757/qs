package com.cdid.api.dataimport.vo;

import java.util.List;

public class FileJobConfigVo extends JobBaseConfigVo {

    private List<List<String>> data;

    private String redisKey;

    private String redisHost;

    private String redisPort;

    private String redisIndex;

    public List<List<String>> getData() {
        return data;
    }

    public void setData(List<List<String>> data) {
        this.data = data;
    }

    public String getRedisKey() {
        return redisKey;
    }

    public void setRedisKey(String redisKey) {
        this.redisKey = redisKey;
    }

    public String getRedisHost() {
        return redisHost;
    }

    public void setRedisHost(String redisHost) {
        this.redisHost = redisHost;
    }

    public String getRedisPort() {
        return redisPort;
    }

    public void setRedisPort(String redisPort) {
        this.redisPort = redisPort;
    }

    public String getRedisIndex() {
        return redisIndex;
    }

    public void setRedisIndex(String redisIndex) {
        this.redisIndex = redisIndex;
    }
}
