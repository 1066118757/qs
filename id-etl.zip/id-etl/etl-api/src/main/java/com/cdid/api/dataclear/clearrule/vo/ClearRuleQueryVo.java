package com.cdid.api.dataclear.clearrule.vo;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/12/13
 */
@ApiModel(value = "清理规则查询对象")
public class ClearRuleQueryVo {

    @ApiModelProperty(value="规则名",example="规则名")
    private String name;
    @ApiModelProperty(value="规则状态",example="规则状态 1:代表启用,0:代表禁用")
    private Integer state;
    @ApiModelProperty(value="规则类型",example="规则类型")
    private Integer ruleType;
    @ApiModelProperty(value="概述",example="概述")
    private String summary;
    @ApiModelProperty(value="脚本类型",example="脚本类型")
    private Integer scriptType;
    @ApiModelProperty(value="脚本代码",example="脚本代码")
    private String scriptCode;

    /*@ApiModelProperty(value="id",example="id")
    private BigDecimal id;
    private Integer status;
    private Timestamp createTime;
    private BigDecimal createUser;
    private Timestamp updateTime;
    private BigDecimal updateUser;
*/

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public Integer getRuleType() {
        return ruleType;
    }

    public void setRuleType(Integer ruleType) {
        this.ruleType = ruleType;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public Integer getScriptType() {
        return scriptType;
    }

    public void setScriptType(Integer scriptType) {
        this.scriptType = scriptType;
    }

    public String getScriptCode() {
        return scriptCode;
    }

    public void setScriptCode(String scriptCode) {
        this.scriptCode = scriptCode;
    }
}
