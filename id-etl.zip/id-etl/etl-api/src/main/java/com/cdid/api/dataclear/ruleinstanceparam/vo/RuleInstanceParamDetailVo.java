package com.cdid.api.dataclear.ruleinstanceparam.vo;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/12/13
 */
@ApiModel(value = "规则实例化的参数详情对象")
public class RuleInstanceParamDetailVo {
    @ApiModelProperty(value="id",example="id")
    private BigDecimal id;
    @ApiModelProperty(value="参数名",example="参数名")
    private String name;
    @ApiModelProperty(value="对应规则id",example="对应规则id")
    private BigDecimal clearRuleId;
    @ApiModelProperty(value="对应规则实例化id",example="对应规则实例化id")
    private BigDecimal ruleInstanceId;
    @ApiModelProperty(value="参数类型 参考码表13",example="参数类型 参考码表13")
    private Integer type;
    @ApiModelProperty(value="参数获取类型 参考码表12",example="参数获取类型 参考码表12")
    private Integer getType;
    @ApiModelProperty(value="参数所在规则表达式位置",example="参数所在规则表达式位置")
    private String index;
    @ApiModelProperty(value="绑定列id",example="绑定列id")
    private BigDecimal bindColId;
    @ApiModelProperty(value="绑定值",example="绑定值")
    private String bindData;
    private Integer status;
    private Timestamp createTime;
    private String createUser;
    private Timestamp updateTime;
    private String updateUser;
    private String createUserName;

    public String getCreateUserName() {
        return createUserName;
    }

    public void setCreateUserName(String createUserName) {
        this.createUserName = createUserName;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getClearRuleId() {
        return clearRuleId;
    }

    public void setClearRuleId(BigDecimal clearRuleId) {
        this.clearRuleId = clearRuleId;
    }

    public BigDecimal getRuleInstanceId() {
        return ruleInstanceId;
    }

    public void setRuleInstanceId(BigDecimal ruleInstanceId) {
        this.ruleInstanceId = ruleInstanceId;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getGetType() {
        return getType;
    }

    public void setGetType(Integer getType) {
        this.getType = getType;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public BigDecimal getBindColId() {
        return bindColId;
    }

    public void setBindColId(BigDecimal bindColId) {
        this.bindColId = bindColId;
    }

    public String getBindData() {
        return bindData;
    }

    public void setBindData(String bindData) {
        this.bindData = bindData;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Timestamp getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Timestamp updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }
}
