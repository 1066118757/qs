package com.cdid.api.dataclear.clearrecord.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "数据清洗预览参数接受")
public class PreviewVo{

    @ApiModelProperty(value="数据清洗执行json串",example="{\"tableName\":\"test\",\"\"limit\":\"100\",script\":{\"steps\" :[]}}")
    private String handleCode;

    public String getHandleCode() {
        return handleCode;
    }

    public void setHandleCode(String handleCode) {
        this.handleCode = handleCode;
    }
}
