package com.cdid.api.metadata.themeitem.vo;


import io.swagger.annotations.ApiModel;

import java.math.BigDecimal;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/11/24
 */
@ApiModel(value = "添加主题条目对象")
public class ThemeItemAddVo {
    //private BigDecimal id;
    private BigDecimal themeId;
    private String name;
    //private Integer state;
    //private Timestamp auditTime;
    //private Short status;
    //private BigDecimal createUser;
    //private Timestamp createTime;
    //private BigDecimal updateUser;
    //private Timestamp updateTime;


    public BigDecimal getThemeId() {
        return themeId;
    }

    public void setThemeId(BigDecimal themeId) {
        this.themeId = themeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
