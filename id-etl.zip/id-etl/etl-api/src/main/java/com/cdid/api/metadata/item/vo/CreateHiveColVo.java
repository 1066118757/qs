package com.cdid.api.metadata.item.vo;


/**
 * @author OuZhiCheng
 * @create 创建时间：2017/12/20
 */
public class CreateHiveColVo {
    //字段名
    private String colName;
    //字段类型,如VARCHAR
    private String dbType;
    //字段别名
    private String colDisplayName;
    //传0即可
    private Integer colAnalyzeType=0;
    //传""即可
    private String colExp="";
    //传0即可
    private Integer colDataType=0;

    public String getColName() {
        return colName;
    }

    public void setColName(String colName) {
        this.colName = colName;
    }

    public String getDbType() {
        return dbType;
    }

    public void setDbType(String dbType) {
        this.dbType = dbType;
    }

    public String getColDisplayName() {
        return colDisplayName;
    }

    public void setColDisplayName(String colDisplayName) {
        this.colDisplayName = colDisplayName;
    }

    public Integer getColAnalyzeType() {
        return colAnalyzeType;
    }

    public void setColAnalyzeType(Integer colAnalyzeType) {
        this.colAnalyzeType = colAnalyzeType;
    }

    public String getColExp() {
        return colExp;
    }

    public void setColExp(String colExp) {
        this.colExp = colExp;
    }

    public Integer getColDataType() {
        return colDataType;
    }

    public void setColDataType(Integer colDataType) {
        this.colDataType = colDataType;
    }
}
