package com.cdid.api.job;

import com.alibaba.fastjson.JSONObject;
import com.cdid.api.asynctask.vo.AsyncTaskConfigVo;
import com.cdid.api.common.IdNameVO;
import com.cdid.api.dataimport.vo.JobBaseConfigVo;
import com.cdid.api.job.vo.*;
import com.cdid.api.jupyter.vo.DependenceDisplayVO;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;

import java.math.BigDecimal;
import java.util.List;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/02 15:23 
 */
public interface JobService {

    //立即执行引接任务
    ResultVo<Boolean> promptlyRun(BigDecimal jobId);
    //添加引接任务
    ResultVo<String> add(JobAddVo jobAddVo,String userId) throws Exception;
    //删除引接任务
    ResultVo<String> delete(BigDecimal id,String userId) throws Exception;
    //更新引接任务
    ResultVo<String> update(JobUpdateVo jobUpdateVo,String userId,String accessToken) throws Exception;
    //更新引接任务基本信息
    ResultVo<String> updateInfo(JobUpdateVo jobUpdateVo,String userId) throws Exception;
    //引接任务列表
    ResultVo<PageVo<JobListVo>> list(JobQueryVo dataSourceQueryVo,String userId,Integer page,Integer size) throws Exception;
    //引接任务详情
    ResultVo<JobDetailVo> findById(BigDecimal id) throws Exception;

    JobBaseConfigVo getJobConfigVo(BigDecimal id,Integer type) throws Exception;

    AsyncTaskConfigVo getAsyncTaskConfigVo(BigDecimal id, Integer type) throws Exception;

    String getCornStr(BigDecimal jobId,Integer syncStrategy) throws Exception;

    DependenceDisplayVO convertToDisplayVO(String dependence);

    //任务历史统计列表
    ResultVo<PageVo<StatisticsJobListVo>> statisticsList(StatisticsJobQueryVo statisticsJobQueryVo,Integer page,Integer size);
    //任务历史统计汇总记录
    ResultVo<StatisticsJobInfoVo> statisticsInfo(StatisticsJobQueryVo statisticsJobQueryVo);

    //获取最后一次同步情况
    ResultVo<Integer> getlastSyncResult(BigDecimal jobId);
    //数据库迁移
    ResultVo<DbMoveResVo> dbmove(DbMoveVo dbMoveVo,String userId) throws Exception;
    //数据库迁移new
    ResultVo<DbMoveResVo> dbmoveNew(DbMoveVo dbMoveVo,String userId) throws Exception;
    //数据库迁移结果
    ResultVo<List<DbMoveRedisVo>> dbmoveResult(BigDecimal id);
    //获取表对应关系
    ResultVo<List<MappingVo>> getTableMapping(BigDecimal jobId) throws Exception;
    //获取列对应关系
    ResultVo<TableMappingVo> getTablefieldMapping(BigDecimal jobId,String table) throws Exception;


    List<IdNameVO> findSelectableDependenceJob(String name, String type);

    void jobFinishedCallBack(JobFinishedResponseVO resp);

    void refreshHiveTable(String tableName);

    void clearChartCache(String tableName);
}
