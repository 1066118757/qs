package com.cdid.api.common;


/**
 * @Author Froid_Li
 * @Email 269504518@qq.com
 * @Date 2017/11/24  11:56
 */
public interface IDGeneratorService<T> {
    T id();
}
