package com.cdid.api.jobconf;

import com.cdid.api.jobconf.vo.*;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;

import java.math.BigDecimal;
import java.util.List;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/02 15:23 
 */
public interface JobConfService {

    ResultVo<String> add(JobConfAddVo jobConfAddVo,String userId) throws Exception;

    ResultVo<String> batchAdd(List<JobConfAddVo> jobConfAddVos,String userId) throws Exception;

    ResultVo<String> delete(List<BigDecimal> ids) throws Exception;

    ResultVo<String> deleteByRefId(BigDecimal refId) throws Exception;

    ResultVo<String> update(JobConfUpdateVo jobConfUpdateVo,String userId) throws Exception;

    ResultVo<PageVo<JobConfListVo>> list(JobConfQueryVo dataSourceQueryVo) throws Exception;

    ResultVo<JobConfDetailVo> findById(BigDecimal id) throws Exception;

    List<JobConfDetailVo> findByRefId(BigDecimal refId,Integer ... type) throws Exception;
}
