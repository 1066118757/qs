package com.cdid.api.dataclear.ruleinstanceparam;

import com.cdid.api.dataclear.ruleinstanceparam.vo.*;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author OuZhiCheng
 */
public interface RuleInstanceParamService {
    /**
     * 规则实例化参数详情添加
     *
     * @param ruleInstanceParamAddVos
     * @param userId
     * @return
     */

    ResultVo<Object> add(List<RuleInstanceParamAddVo> ruleInstanceParamAddVos, String userId);

    /**
     * 规则实例化参数详情更新
     *
     * @param ruleInstanceParamUpdateVo
     * @param userId
     * @return
     */
    ResultVo<Object> update(RuleInstanceParamUpdateVo ruleInstanceParamUpdateVo, String userId);

    /**
     * 规则实例化参数详情删除
     *
     * @param id
     * @return
     */
    ResultVo<Object> delete(BigDecimal id);

    /**
     * 规则实例化参数详情查询
     *
     * @param ruleInstanceParamQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    ResultVo<PageVo<List<RuleInstanceParamListVo>>> list(RuleInstanceParamQueryVo ruleInstanceParamQueryVo, String userId, Integer page, Integer size);

    /**
     * 规则实例化参数详情查询详情
     *
     * @param id
     * @return
     */
    ResultVo<RuleInstanceParamDetailVo> ruleInstanceParamById(BigDecimal id);

    /**
     * 规则实例化参数详情删除-依据规则实例化id
     * @param ruleInstanceId
     * @return
     */
    ResultVo<Object> deleteByInstanceId(BigDecimal ruleInstanceId);

    /**
     * 通过规则实例化id查询其参数列表信息
     * @param ruleInstanceId
     * @param userId
     * @return
     */
    List<RuleInstanceParamListVo> listByRuleInstanceId(BigDecimal ruleInstanceId, String userId);
}
