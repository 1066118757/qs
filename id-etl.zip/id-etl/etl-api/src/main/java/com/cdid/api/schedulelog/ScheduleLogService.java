package com.cdid.api.schedulelog;

import com.cdid.api.schedulelog.vo.ScheduleLogAddVo;
import com.cdid.api.schedulelog.vo.ScheduleLogDetailVo;
import com.cdid.api.schedulelog.vo.ScheduleLogListVo;
import com.cdid.api.schedulelog.vo.ScheduleLogQueryVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;

import java.math.BigDecimal;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/02 15:23 
 */
public interface ScheduleLogService {

    ResultVo<BigDecimal> saveOrUpdate(ScheduleLogAddVo scheduleLogAddVo) throws Exception;

    ResultVo<PageVo<ScheduleLogListVo>> list(ScheduleLogQueryVo scheduleLogQueryVo,Integer page,Integer size) throws Exception;

    ResultVo<ScheduleLogDetailVo> findById(BigDecimal id) throws Exception;

    Boolean jobIsRunning(BigDecimal jobId);

    void deleteByJobId(BigDecimal jobId);

}
