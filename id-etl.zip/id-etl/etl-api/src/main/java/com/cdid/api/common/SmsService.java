package com.cdid.api.common;


import com.cdid.common.vo.ResultVo;

/**
 * @Author Froid_Li
 * @Email 269504518@qq.com
 * @Date 2017/12/12  14:55
 */

public interface SmsService {

    /**
     * 短信验证通知
     * @param phoneNumber
     * @return
     */
     ResultVo<String> sendVerifyCode(String phoneNumber);


    /**
     *  数据引接任务完成通知
     * @param phoneNumber
     * @param jobName
     * @param endTime
     * @param jobResult
     * @param count
     * @return
     */
     ResultVo<String> sendETLJobNotice(String phoneNumber, String jobName, String endTime, String jobResult, String count);


    /**
     *  数据整合任务完成通知
     * @param phoneNumber
     * @param jobName
     * @param endTime
     * @param jobResult
     * @return
     */
      ResultVo<String> sendClearJobNotice(String phoneNumber, String jobName, String endTime, String jobResult);




}


