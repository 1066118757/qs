package com.cdid.api.jobconf.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/02 15:38 
 */
@ApiModel("配置列表对象")
public class JobConfListVo {

    private BigDecimal id;
    @ApiModelProperty(value="key",example="用户名")
    private String key;
    @ApiModelProperty(value="value",example="root")
    private String value;
    @ApiModelProperty(value="关联id",example="1906177435238400")
    private BigDecimal refId;
    /**
     * 类型 701:数据源配置,702:任务配置,703:消息提醒机制,704:字段映射
     */
    @ApiModelProperty(value="类型 701:数据源配置,702:任务配置,703:消息提醒机制,704:字段映射",example="702")
    private Integer type;
    /**
     * 状态
     */
    @ApiModelProperty(value="状态 1:启用,2:禁用",example="1")
    private Integer state;
//    private Short status;
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Timestamp createTime;
    private String createUser;
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Timestamp updateTime;
    private String updateUser;

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public BigDecimal getRefId() {
        return refId;
    }

    public void setRefId(BigDecimal refId) {
        this.refId = refId;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Timestamp getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Timestamp updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }
}
