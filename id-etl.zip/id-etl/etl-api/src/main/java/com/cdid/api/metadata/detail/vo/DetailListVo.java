package com.cdid.api.metadata.detail.vo;


import io.swagger.annotations.ApiModel;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/11/24
 */
@ApiModel(value = "列表查询元数据详情对象")
public class DetailListVo {
    private BigDecimal id;
    private BigDecimal metadataItemId;
    private String colDisplayname;
    private Integer colType;
    private String colComment;
    private String colName;
    private Integer state;
    private Timestamp auditTime;
    private Short status;
    private String createUser;
    private Timestamp createTime;
    private String updateUser;
    private Timestamp updateTime;
    private Integer index;
    private String createUserName;

    public String getCreateUserName() {
        return createUserName;
    }

    public void setCreateUserName(String createUserName) {
        this.createUserName = createUserName;
    }

    public Integer getIndex() {
        return index;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }

    public Timestamp getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(Timestamp auditTime) {
        this.auditTime = auditTime;
    }

    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public Timestamp getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Timestamp updateTime) {
        this.updateTime = updateTime;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public BigDecimal getMetadataItemId() {
        return metadataItemId;
    }

    public void setMetadataItemId(BigDecimal metadataItemId) {
        this.metadataItemId = metadataItemId;
    }

    public String getColDisplayname() {
        return colDisplayname;
    }

    public void setColDisplayname(String colDisplayname) {
        this.colDisplayname = colDisplayname;
    }

    public Integer getColType() {
        return colType;
    }

    public void setColType(Integer colType) {
        this.colType = colType;
    }

    public String getColComment() {
        return colComment;
    }

    public void setColComment(String colComment) {
        this.colComment = colComment;
    }

    public String getColName() {
        return colName;
    }

    public void setColName(String colName) {
        this.colName = colName;
    }
}
