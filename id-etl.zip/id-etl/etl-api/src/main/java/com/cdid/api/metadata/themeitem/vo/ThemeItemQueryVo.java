package com.cdid.api.metadata.themeitem.vo;


import io.swagger.annotations.ApiModel;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/11/24
 */
@ApiModel(value = "存储主题条目搜索条件对象")
public class ThemeItemQueryVo {
    /*private BigDecimal id;
    private Integer state;
    private Timestamp auditTime;
    private Short status;
    private BigDecimal createUser;
    private Timestamp createTime;
    private BigDecimal updateUser;
    private Timestamp updateTime;*/

    private BigDecimal themeId;
    private String name;

    public BigDecimal getThemeId() {
        return themeId;
    }

    public void setThemeId(BigDecimal themeId) {
        this.themeId = themeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
