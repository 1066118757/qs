package com.cdid.api.dataclear.ruleparam;

import com.cdid.api.dataclear.ruleparam.vo.*;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author OuZhiCheng
 */
public interface RuleParamService {
    /**
     * 规则参数详情添加
     *
     * @param ruleParamAddVos
     * @param userId
     * @return
     */

    ResultVo<Object> add(List<RuleParamAddVo> ruleParamAddVos, String userId);

    /**
     * 规则参数详情更新
     *
     * @param ruleParamUpdateVo
     * @param userId
     * @return
     */
    ResultVo<Object> update(RuleParamUpdateVo ruleParamUpdateVo, String userId);

    /**
     * 规则参数详情删除
     *
     * @param id
     * @return
     */
    ResultVo<Object> delete(BigDecimal id);

    /**
     * 规则参数详情查询
     *
     * @param ruleParamQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    ResultVo<PageVo<List<RuleParamListVo>>> list(RuleParamQueryVo ruleParamQueryVo, String userId, Integer page, Integer size);

    /**
     * 规则参数详情查询详情
     *
     * @param id
     * @return
     */
    ResultVo<RuleParamDetailVo> ruleParamById(BigDecimal id);

    /**
     * 规则参数详情删除-依据规则id
     * @param ruleId
     * @return
     */
    ResultVo<Object> deleteByRuleId(BigDecimal ruleId);

    /**
     * 通过规则id查询其参数列表信息
     * @param ruleId
     * @param userId
     * @return
     */
    List<RuleParamListVo> listByRuleId(BigDecimal ruleId, String userId);
}
