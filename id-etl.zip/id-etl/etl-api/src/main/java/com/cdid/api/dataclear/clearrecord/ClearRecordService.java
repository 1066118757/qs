package com.cdid.api.dataclear.clearrecord;

import com.cdid.api.dataclear.clearrecord.vo.*;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author OuZhiCheng
 */
public interface ClearRecordService {
    /**
     * 数据整理记录详情添加
     *
     * @param clearRecordAddVo
     * @param userId
     * @return
     */

    ResultVo<Object> add(ClearRecordAddVo clearRecordAddVo, String userId);

    /**
     * 数据整理记录详情更新
     *
     * @param clearRecordUpdateVo
     * @param userId
     * @return
     */
    ResultVo<Object> update(ClearRecordUpdateVo clearRecordUpdateVo, String userId);

    /**
     * 数据整理记录详情删除
     *
     * @param id
     * @return
     */
    ResultVo<Object> delete(BigDecimal id);

    /**
     * 数据整理记录详情查询
     *
     * @param clearRecordQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    ResultVo<PageVo<List<ClearRecordListVo>>> list(ClearRecordQueryVo clearRecordQueryVo, String userId, Integer page, Integer size);

    /**
     * 数据整理记录详情查询详情
     *
     * @param id
     * @return
     */
    ResultVo<ClearRecordDetailVo> clearRecordById(BigDecimal id);

    /**
     * 清洗结果预览
     * @param handleCode
     * @return
     */
    ResultVo clearResultPreview(String handleCode);

    /**
     * 通过redisKey从Redis查询数据的方法
     * @param redisKey
     * @return
     */
    ResultVo getRedisData(String redisKey);
}
