package com.cdid.api.metadata.themeitem;

import com.cdid.api.metadata.themeitem.vo.*;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;

import java.math.BigDecimal;
import java.util.List;

/**
 *
 * @author OuZhiCheng
 * @create 创建时间：2017/11/24
 *
 * 元数据主题条目
 */
public interface ThemeItemService {
    /**
     * 元数据主题条目添加
     * @param themeItemAddVo
     * @param userId
     * @return
     */
    ResultVo<Object> add(ThemeItemAddVo themeItemAddVo, String userId);

    /**
     * 元数据主题条目更新
     * @param themeItemUpdateVo
     * @param userId
     * @return
     */
    ResultVo<Object> update(ThemeItemUpdateVo themeItemUpdateVo, String userId);

    /**
     * 元数据主题条目删除
     * @param id
     * @return
     */
    ResultVo<Object> delete(BigDecimal id);

    /**
     * 元数据主题条目查询
     * @param themeItemQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    ResultVo<PageVo<List<ThemeItemListVo>>> list(ThemeItemQueryVo themeItemQueryVo, String userId, Integer page, Integer size);


    /**
     * 元数据主题条目查询详情
     * @param id
     * @return
     */
    ResultVo<ThemeItemDetailVo> detailById(BigDecimal id);

}
