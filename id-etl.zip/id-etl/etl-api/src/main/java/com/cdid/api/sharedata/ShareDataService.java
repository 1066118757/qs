package com.cdid.api.sharedata;

import io.swagger.models.auth.In;

import java.util.List;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2018/1/11 13:46  
 */
public interface ShareDataService {

    String getCsvDataByTableName(String tableName ,Integer limit,String authorization);

    String getDataByTableName(String tableName);

    String getResultData(String tableName,String priKey) throws Exception;

    String getPrivateKey(String userId);

    String getToken();
}
