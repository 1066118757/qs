package com.cdid.api.asynctask;

import com.cdid.api.asynctask.vo.AsyncTaskConfigVo;
import com.cdid.api.dataclear.cleartask.vo.ClearTaskSubmitVo;

public interface AsyncTaskExecuteService {

    void execute(AsyncTaskConfigVo configVo,boolean isHand) throws Exception ;

    void execute(ClearTaskSubmitVo clearTaskSubmitVo,boolean isHand) throws Exception ;

    void execute(String learningModelDeployId,boolean isHand) throws Exception ;
}
