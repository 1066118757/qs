package com.cdid.api.job.vo;

import com.cdid.api.asynctask.vo.AsyncTaskConfigVo;
import com.cdid.api.dataclear.cleartask.vo.ClearTaskSubmitVo;
import com.cdid.api.jupyter.vo.TaskRequestVo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

/**
 * 定时器
 */
public class ScheduleJobEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 任务调度参数key
     */
//    public static final String JOB_PARAM_KEY = "JOB_PARAM_KEY";

    /**
     * 任务id
     */
    private BigDecimal jobId;


    private TaskRequestVo taskRequestVo;

    private AsyncTaskConfigVo asyncTaskConfigVo;

    //自定义算法提交的参数对象
    private ClearTaskSubmitVo clearTaskSubmitVo;

    private String learningModelDeployId;

    private Integer priority=0;

    /**
     * cron表达式
     */
    private Set<String> cronExpressions = new HashSet<>();

    /**
     * 设置：任务id
     *
     * @param jobId 任务id
     */
    public void setJobId(BigDecimal jobId) {
        this.jobId = jobId;
    }

    /**
     * 获取：任务id
     *
     * @return BigDecimal
     */
    public BigDecimal getJobId() {
        return jobId;
    }

    public Set<String> getCronExpressions() {
        return cronExpressions;
    }

    public void setCronExpressions(Set<String> cronExpressions) {
        this.cronExpressions = cronExpressions;
    }

    public TaskRequestVo getTaskRequestVo() {
        return taskRequestVo;
    }

    public void setTaskRequestVo(TaskRequestVo taskRequestVo) {
        this.taskRequestVo = taskRequestVo;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    public AsyncTaskConfigVo getAsyncTaskConfigVo() {
        return asyncTaskConfigVo;
    }

    public void setAsyncTaskConfigVo(AsyncTaskConfigVo asyncTaskConfigVo) {
        this.asyncTaskConfigVo = asyncTaskConfigVo;
    }

    public ClearTaskSubmitVo getClearTaskSubmitVo() {
        return clearTaskSubmitVo;
    }

    public void setClearTaskSubmitVo(ClearTaskSubmitVo clearTaskSubmitVo) {
        this.clearTaskSubmitVo = clearTaskSubmitVo;
    }

    public String getLearningModelDeployId() {
        return learningModelDeployId;
    }

    public void setLearningModelDeployId(String learningModelDeployId) {
        this.learningModelDeployId = learningModelDeployId;
    }
}
