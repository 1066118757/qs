package com.cdid.api.job.vo;

import com.cdid.api.datasource.vo.DataSourceAddVo;
import com.cdid.api.jobconf.vo.JobConfAddVo;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/02 15:24 
 */
@ApiModel("引接任务添加对象")
public class JobAddVo {

    private BigDecimal id;

    /**
     * 名称
     */
    @ApiModelProperty(value="名称",example="任务名称")
    private String name;
    /**
     * 目标表来源 1：新建目标表 2：已有目标表
     */
    @ApiModelProperty(value="目标表来源 1：新建目标表 2：已有目标表",example="1")
    private Short distTableSource;
    /**
     * 目标表
     */
    @ApiModelProperty(value="目标表",example="t_user")
    private String distTable;
    /**
     * 逻辑分区id
     */
    @ApiModelProperty(value="逻辑分区id",example="1")
    private BigDecimal logicPartitionId;
    /**
     * 导入方式 1:全覆盖,2:按列覆盖,3:按列合并更新
     */
    @ApiModelProperty(value="导入方式 1:全覆盖,2:按列覆盖,3:按列合并更新",example="1")
    private Integer importMode;
    /**
     * 同步策略 1:定时,2:频率
     */
    @ApiModelProperty(value="同步策略 1:定时,2:频率",example="1")
    private Integer syncStrategy;
    /**
     * 优先级
     */
    @ApiModelProperty(value="优先级",example="1")
    private Integer priority;
    /**
     * 状态
     */
    @ApiModelProperty(value="状态 1:启用；2:禁用",example="1")
    private Integer state;
    /**
     * 最近一次执行状态
     */
    @ApiModelProperty(value="最近一次执行状态 1:成功 2:失败",example="1")
    private Integer latestScheduleState;
    /**
     * 最近一执行成功行数
     */
    @ApiModelProperty(value="最近一次执行成功行数",example="100")
    private Long latestSuccessRows;
    /**
     * 最近一执行成功时间
     */
    @ApiModelProperty(value="最近一次执行成功时间",example="2015-08-12 13:11:00")
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Timestamp latestScheduleTime;
    /**
     * 最近一执行日志
     */
    @ApiModelProperty(value="最近一次执行日志",example="log")
    private String latestScheduleLog;
    /**
     * 数据源id
     */
    @ApiModelProperty(value="数据源id",example="1905686402170880")
    private BigDecimal dataSourceId;
    @ApiModelProperty(value="引接任务配置")
    private List<JobConfAddVo> confs;
    @ApiModelProperty(value="引接任务关联数据源对象")
    private DataSourceAddVo dataSourceAddVo;
    @ApiModelProperty(value="文件类型的redisKey")
    private String redisKey;

    @ApiModelProperty(value="依赖任务")
    private String dependence;

    public String getRedisKey() {
        return redisKey;
    }

    public void setRedisKey(String redisKey) {
        this.redisKey = redisKey;
    }

    public DataSourceAddVo getDataSourceAddVo() {
        return dataSourceAddVo;
    }

    public void setDataSourceAddVo(DataSourceAddVo dataSourceAddVo) {
        this.dataSourceAddVo = dataSourceAddVo;
    }

    public List<JobConfAddVo> getConfs() {
        return confs;
    }

    public void setConfs(List<JobConfAddVo> confs) {
        this.confs = confs;
    }

    //    private Short status;

//    private Timestamp createTime;
//    private BigDecimal createUser;
//    private Timestamp updateTime;
//    private BigDecimal updateUser;


    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Short getDistTableSource() {
        return distTableSource;
    }

    public void setDistTableSource(Short distTableSource) {
        this.distTableSource = distTableSource;
    }

    public String getDistTable() {
        return distTable;
    }

    public void setDistTable(String distTable) {
        this.distTable = distTable;
    }

    public BigDecimal getLogicPartitionId() {
        return logicPartitionId;
    }

    public void setLogicPartitionId(BigDecimal logicPartitionId) {
        this.logicPartitionId = logicPartitionId;
    }

    public Integer getImportMode() {
        return importMode;
    }

    public void setImportMode(Integer importMode) {
        this.importMode = importMode;
    }

    public Integer getSyncStrategy() {
        return syncStrategy;
    }

    public void setSyncStrategy(Integer syncStrategy) {
        this.syncStrategy = syncStrategy;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public Integer getLatestScheduleState() {
        return latestScheduleState;
    }

    public void setLatestScheduleState(Integer latestScheduleState) {
        this.latestScheduleState = latestScheduleState;
    }

    public Long getLatestSuccessRows() {
        return latestSuccessRows;
    }

    public void setLatestSuccessRows(Long latestSuccessRows) {
        this.latestSuccessRows = latestSuccessRows;
    }

    public Timestamp getLatestScheduleTime() {
        return latestScheduleTime;
    }

    public void setLatestScheduleTime(Timestamp latestScheduleTime) {
        this.latestScheduleTime = latestScheduleTime;
    }

    public String getLatestScheduleLog() {
        return latestScheduleLog;
    }

    public void setLatestScheduleLog(String latestScheduleLog) {
        this.latestScheduleLog = latestScheduleLog;
    }

    public BigDecimal getDataSourceId() {
        return dataSourceId;
    }

    public void setDataSourceId(BigDecimal dataSourceId) {
        this.dataSourceId = dataSourceId;
    }

    public String getDependence() {
        return dependence;
    }

    public void setDependence(String dependence) {
        this.dependence = dependence;
    }
}
