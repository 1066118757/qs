package com.cdid.api.jupyter.vo;

import com.cdid.api.jupyter.TaskPreProcessProcessor;
import com.cdid.api.jupyter.defaultimpl.DefaultTaskPreProcessor;

import java.math.BigDecimal;

public class TaskRequestVo {

    private BigDecimal taskId;

    private TaskPreProcessProcessor preProcessProcessor=new DefaultTaskPreProcessor();

    public BigDecimal getTaskId() {
        return taskId;
    }

    public void setTaskId(BigDecimal taskId) {
        this.taskId = taskId;
    }

    public TaskPreProcessProcessor getPreProcessProcessor() {
        return preProcessProcessor;
    }

    public void setPreProcessProcessor(TaskPreProcessProcessor preProcessProcessor) {
        this.preProcessProcessor = preProcessProcessor;
    }

}
