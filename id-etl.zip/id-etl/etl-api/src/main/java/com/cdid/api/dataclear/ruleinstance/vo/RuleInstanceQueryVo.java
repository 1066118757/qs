package com.cdid.api.dataclear.ruleinstance.vo;


import io.swagger.annotations.ApiModel;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/12/13
 */
@ApiModel(value = "规则实例化查询对象")
public class RuleInstanceQueryVo {
    /*@ApiModelProperty(value="id",example="id")
    private BigDecimal id;
    @ApiModelProperty(value="清洗记录id",example="清洗记录id")
    private BigDecimal clearRecordId;
    @ApiModelProperty(value="操作表对应的元数据条目详情id，列对应元数据条目详情",example="操作表对应的元数据条目详情id，列对应元数据条目详情")
    private BigDecimal metadataDetailId;
    @ApiModelProperty(value="表达式",example="表达式")
    private String expression;
    @ApiModelProperty(value="清洗规则id",example="清洗规则id")
    private BigDecimal clearRuleId;
    private Integer status;
    private Timestamp createTime;
    private BigDecimal createUser;
    private Timestamp updateTime;
    private BigDecimal updateUser;*/

}
