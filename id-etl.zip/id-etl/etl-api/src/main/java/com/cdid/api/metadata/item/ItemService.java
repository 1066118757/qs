package com.cdid.api.metadata.item;

import com.cdid.api.metadata.item.vo.*;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;

import java.math.BigDecimal;
import java.util.List;

/**
 *
 * @author OuZhiCheng
 * @create 创建时间：2017/11/24
 *
 * 元数据条目
 */
public interface ItemService {
    /**
     * 元数据条目添加
     * @param itemAddVo
     * @param userId
     * @return
     */
    ResultVo<Object> add(ItemAddVo itemAddVo, String userId);

    /**
     * 元数据条目更新
     * @param itemUpdateVo
     * @param userId
     * @return
     */
    ResultVo<Object> update(ItemUpdateVo itemUpdateVo, String userId);

    /**
     * 元数据条目删除
     * @param id
     * @return
     */
    ResultVo<Object> delete(BigDecimal id,String accessToken);

    /**
     * 元数据条目查询
     * @param itemQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    ResultVo<PageVo<List<ItemListVo>>> list(ItemQueryVo itemQueryVo,boolean isAdmin, String userId, Integer page, Integer size);

    /**
     * 元数据条目查询详情
     * @param id
     * @return
     */
    ResultVo<ItemDetailVo> detailById(BigDecimal id);

    /**
     * 元数据条目添加(批量添加详情)
     * @param itemAddAllsVo
     * @param userId
     * @return
     */
    ResultVo<Object> addAlls(ItemAddAllsVo itemAddAllsVo, String userId,boolean isISI);

    /**
     * 元数据条目更新(批量编辑详情)
     * @param itemUpdateAllsVo
     * @param userId
     * @return
     */
    ResultVo<Object> updateAlls(ItemAddAllsVo itemUpdateAllsVo, String userId,String accessToken);

    boolean isShareTable(String tableName);
}
