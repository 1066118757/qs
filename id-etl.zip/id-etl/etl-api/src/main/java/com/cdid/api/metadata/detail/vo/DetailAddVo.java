package com.cdid.api.metadata.detail.vo;


import io.swagger.annotations.ApiModel;

import java.math.BigDecimal;

@ApiModel(value = "添加元数据详情对象")
public class DetailAddVo {

    private BigDecimal metadataItemId;
    private String colDisplayname;
    private Integer colType;
    private String colComment;
    private String colName;
    private Integer index;


    public Integer getIndex() {
        return index;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }

    public BigDecimal getMetadataItemId() {
        return metadataItemId;
    }

    public void setMetadataItemId(BigDecimal metadataItemId) {
        this.metadataItemId = metadataItemId;
    }

    public String getColDisplayname() {
        return colDisplayname;
    }

    public void setColDisplayname(String colDisplayname) {
        this.colDisplayname = colDisplayname;
    }

    public Integer getColType() {
        return colType;
    }

    public void setColType(Integer colType) {
        this.colType = colType;
    }

    public String getColComment() {
        return colComment;
    }

    public void setColComment(String colComment) {
        this.colComment = colComment;
    }

    public String getColName() {
        return colName;
    }

    public void setColName(String colName) {
        this.colName = colName;
    }
}
