package com.cdid.api.job.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/28 10:50  
 */
@ApiModel("数据库迁移对象")
public class DbMoveVo {

    @ApiModelProperty(value="任务名称")
    private String name;
    @ApiModelProperty(value="数据源id")
    private BigDecimal dataSourceId;

    @ApiModelProperty(value="逻辑分区条目id")
    private BigDecimal logicPartitionId;

    @ApiModelProperty(value="表数据类型 201:数据结构 202:数据字典 默认201",example="201")
    private Integer metadataType = 201;

    @ApiModelProperty(value="优先级",example="1")
    private Integer priority;

    @ApiModelProperty(value="数据表,不传则迁移该数据源下的所有表",example="['table1','table2']")
    private List<String> tableNames;

    public List<String> getTableNames() {
        return tableNames;
    }

    public void setTableNames(List<String> tableNames) {
        this.tableNames = tableNames;
    }

    public BigDecimal getDataSourceId() {
        return dataSourceId;
    }

    public void setDataSourceId(BigDecimal dataSourceId) {
        this.dataSourceId = dataSourceId;
    }

    public BigDecimal getLogicPartitionId() {
        return logicPartitionId;
    }

    public void setLogicPartitionId(BigDecimal logicPartitionId) {
        this.logicPartitionId = logicPartitionId;
    }

    public Integer getMetadataType() {
        return metadataType;
    }

    public void setMetadataType(Integer metadataType) {
        this.metadataType = metadataType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }
}
