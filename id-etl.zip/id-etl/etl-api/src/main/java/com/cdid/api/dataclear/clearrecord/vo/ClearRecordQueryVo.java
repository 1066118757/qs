package com.cdid.api.dataclear.clearrecord.vo;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/12/13
 */
@ApiModel(value = "清理记录查询对象")
public class ClearRecordQueryVo {

    @ApiModelProperty(value="记录名",example="记录名")
    private String name;
    /*@ApiModelProperty(value="id",example="id")
    private BigDecimal id;
    @ApiModelProperty(value="标签,参考码表 14",example="标签,参考码表 14")
    private Integer[] labels;
    @ApiModelProperty(value="操作表对应的条目id，表对应元数据条目",example="操作表对应的条目id，表对应元数据条目")
    private BigDecimal metadataItemId;
    private Integer status;
    private Timestamp createTime;
    private BigDecimal createUser;
    private Timestamp updateTime;
    private BigDecimal updateUser;

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer[] getLabels() {
        return labels;
    }

    public void setLabels(Integer[] labels) {
        this.labels = labels;
    }

    public BigDecimal getMetadataItemId() {
        return metadataItemId;
    }

    public void setMetadataItemId(BigDecimal metadataItemId) {
        this.metadataItemId = metadataItemId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public BigDecimal getCreateUser() {
        return createUser;
    }

    public void setCreateUser(BigDecimal createUser) {
        this.createUser = createUser;
    }

    public Timestamp getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Timestamp updateTime) {
        this.updateTime = updateTime;
    }

    public BigDecimal getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(BigDecimal updateUser) {
        this.updateUser = updateUser;
    }*/

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
