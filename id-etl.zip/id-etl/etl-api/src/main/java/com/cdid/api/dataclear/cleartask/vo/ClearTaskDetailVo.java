package com.cdid.api.dataclear.cleartask.vo;


import com.cdid.api.jupyter.vo.DependenceDisplayVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.sql.Timestamp;

@ApiModel(value = "清理任务详情对象")
public class ClearTaskDetailVo {
    @ApiModelProperty(value="id",example="id")
    private BigDecimal id;
    @ApiModelProperty(value="整合记录id",example="整合记录id")
    private BigDecimal recordId;
    @ApiModelProperty(value="任务名",example="任务名")
    private String name;
    @ApiModelProperty(value="输入表id",example="输入表id")
    private BigDecimal inItemId;
    @ApiModelProperty(value="输入表名",example="输入表名")
    private String inItemName;
    @ApiModelProperty(value="输出表所在主题条目id",example="输出表所在主题条目id")
    private BigDecimal outThemeItemId;
    @ApiModelProperty(value="输出表名",example="输出表名")
    private String outItemName;
    @ApiModelProperty(value="输出表类型",example="输出表类型")
    private Integer outItemType;
    @ApiModelProperty(value="输出表用途",example="输出表用途")
    private String outItemPurpose;
    @ApiModelProperty(value="输出表id,对应元数据条目id",example="输出表id,对应元数据条目id")
    private BigDecimal outItemId;
    @ApiModelProperty(value="定时任务cron表达式",example="定时任务cron表达式")
    private String cronCode;
    @ApiModelProperty(value="最近一次开始时间",example="最近一次开始时间")
    private Timestamp nearStartTime;
    @ApiModelProperty(value="最近一次结束时间",example="最近一次结束时间")
    private Timestamp nearEndTime;
    @ApiModelProperty(value="最近一次任务执行结果，参考码表10",example="最近一次任务执行结果，参考码表10")
    private Integer nearResult;
    @ApiModelProperty(value="任务执行方式，参考码表11",example="任务执行方式，参考码表11")
    private Integer type;
    @ApiModelProperty(value="短信提醒，true 开启 false 关闭",example="短信提醒，true 开启 false 关闭")
    private Boolean isNote;
    @ApiModelProperty(value="邮件提醒，true 开启 false 关闭",example="邮件提醒，true 开启 false 关闭")
    private Boolean isEmail;
    private Integer status;
    private Timestamp createTime;
    private String createUser;
    private Timestamp updateTime;
    private String updateUser;
    private String createUserName;

    @ApiModelProperty(value="接收电子邮件的email地址",example="接收电子邮件的email地址")
    private String email;
    @ApiModelProperty(value="接收短信的电话号码",example="接收短信的电话号码")
    private String phone;
    @ApiModelProperty(value="任务优先级（定时）",example="任务优先级（定时），默认0")
    private Integer priority;

    private String dependence;

    private DependenceDisplayVO dependenceDisplayVO;

    public String getCreateUserName() {
        return createUserName;
    }

    public void setCreateUserName(String createUserName) {
        this.createUserName = createUserName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public BigDecimal getRecordId() {
        return recordId;
    }

    public void setRecordId(BigDecimal recordId) {
        this.recordId = recordId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getInItemId() {
        return inItemId;
    }

    public void setInItemId(BigDecimal inItemId) {
        this.inItemId = inItemId;
    }

    public String getInItemName() {
        return inItemName;
    }

    public void setInItemName(String inItemName) {
        this.inItemName = inItemName;
    }

    public BigDecimal getOutThemeItemId() {
        return outThemeItemId;
    }

    public void setOutThemeItemId(BigDecimal outThemeItemId) {
        this.outThemeItemId = outThemeItemId;
    }

    public String getOutItemName() {
        return outItemName;
    }

    public void setOutItemName(String outItemName) {
        this.outItemName = outItemName;
    }

    public Integer getOutItemType() {
        return outItemType;
    }

    public void setOutItemType(Integer outItemType) {
        this.outItemType = outItemType;
    }

    public String getOutItemPurpose() {
        return outItemPurpose;
    }

    public void setOutItemPurpose(String outItemPurpose) {
        this.outItemPurpose = outItemPurpose;
    }

    public BigDecimal getOutItemId() {
        return outItemId;
    }

    public void setOutItemId(BigDecimal outItemId) {
        this.outItemId = outItemId;
    }

    public String getCronCode() {
        return cronCode;
    }

    public void setCronCode(String cronCode) {
        this.cronCode = cronCode;
    }

    public Timestamp getNearStartTime() {
        return nearStartTime;
    }

    public void setNearStartTime(Timestamp nearStartTime) {
        this.nearStartTime = nearStartTime;
    }

    public Timestamp getNearEndTime() {
        return nearEndTime;
    }

    public void setNearEndTime(Timestamp nearEndTime) {
        this.nearEndTime = nearEndTime;
    }

    public Integer getNearResult() {
        return nearResult;
    }

    public void setNearResult(Integer nearResult) {
        this.nearResult = nearResult;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Boolean getIsNote() {
        return isNote;
    }

    public void setIsNote(Boolean note) {
        isNote = note;
    }

    public Boolean getIsEmail() {
        return isEmail;
    }

    public void setIsEmail(Boolean email) {
        isEmail = email;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Timestamp getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Timestamp updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public String getDependence() {
        return dependence;
    }

    public void setDependence(String dependence) {
        this.dependence = dependence;
    }

    public DependenceDisplayVO getDependenceDisplayVO() {
        return dependenceDisplayVO;
    }

    public void setDependenceDisplayVO(DependenceDisplayVO dependenceDisplayVO) {
        this.dependenceDisplayVO = dependenceDisplayVO;
    }
}
