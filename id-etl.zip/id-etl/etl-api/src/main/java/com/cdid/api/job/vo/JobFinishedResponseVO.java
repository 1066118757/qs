package com.cdid.api.job.vo;

import java.math.BigDecimal;

public class JobFinishedResponseVO {

    private String taskId;

    private Boolean success;

    private String errorMsg;

    private String logId;

    private String srcTable;

    private String targetTable;

    private Long successRows;

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public String getLogId() {
        return logId;
    }

    public void setLogId(String logId) {
        this.logId = logId;
    }

    public String getSrcTable() {
        return srcTable;
    }

    public void setSrcTable(String srcTable) {
        this.srcTable = srcTable;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public Long getSuccessRows() {
        return successRows;
    }

    public void setSuccessRows(Long successRows) {
        this.successRows = successRows;
    }

    public String getTargetTable() {
        return targetTable;
    }

    public void setTargetTable(String targetTable) {
        this.targetTable = targetTable;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }
}
