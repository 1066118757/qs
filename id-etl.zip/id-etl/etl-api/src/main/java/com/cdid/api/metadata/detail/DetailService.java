package com.cdid.api.metadata.detail;

import com.cdid.api.metadata.detail.vo.*;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author OuZhiCheng
 */
public interface DetailService {
    /**
     * 元数据条目详情添加
     *
     * @param detailAddVo
     * @param userId
     * @return
     */

    ResultVo<Object> add(DetailAddVo detailAddVo, String userId);

    /**
     * 元数据条目详情更新
     *
     * @param detailUpdateVo
     * @param userId
     * @return
     */
    ResultVo<Object> update(DetailUpdateVo detailUpdateVo, String userId);

    /**
     * 元数据条目详情删除
     *
     * @param id
     * @return
     */
    ResultVo<Object> delete(BigDecimal id);

    /**
     * 元数据条目详情查询
     *
     * @param detailQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    ResultVo<PageVo<List<DetailListVo>>> list(DetailQueryVo detailQueryVo, String userId, Integer page, Integer size);

    /**
     * 元数据条目详情查询详情
     *
     * @param id
     * @return
     */
    ResultVo<DetailDetailVo> detailById(BigDecimal id);

    /**
     * 下载元数据模板
     *
     * @param type
     * @return
     */
    ResultVo<MetaTemplateVo> downloadTemplate(Integer type);

    /**
     * 导出数据结构
     *
     * @param fileType
     * @return
     */
    ResultVo<MetaTemplateVo> exportDataStructure(BigDecimal metadataItemId, Integer fileType);
}
