package com.cdid.api.dataclear.cleartasklog.vo;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/12/13
 */
@ApiModel(value = "清理任务日志添加对象")
public class ClearTaskLogAddVo {
    @ApiModelProperty(value="id",example="id")
    private BigDecimal id;
    @ApiModelProperty(value="任务id",example="任务id")
    private BigDecimal taskId;
    @ApiModelProperty(value="开始时间",example="开始时间")
    private Timestamp startTime;
    @ApiModelProperty(value="结束时间",example="结束时间")
    private Timestamp endTime;
    @ApiModelProperty(value="任务执行结果，参考码表10",example="任务执行结果，参考码表10")
    private Integer result;
    @ApiModelProperty(value="执行成功列数目",example="执行成功列数目")
    private Long successRows;
    @ApiModelProperty(value="任务日志文本",example="任务日志文本")
    private String taskLog;

    public Long getSuccessRows() {
        return successRows;
    }

    public void setSuccessRows(Long successRows) {
        this.successRows = successRows;
    }

    public String getTaskLog() {
        return taskLog;
    }

    public void setTaskLog(String taskLog) {
        this.taskLog = taskLog;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public BigDecimal getTaskId() {
        return taskId;
    }

    public void setTaskId(BigDecimal taskId) {
        this.taskId = taskId;
    }

    public Timestamp getStartTime() {
        return startTime;
    }

    public void setStartTime(Timestamp startTime) {
        this.startTime = startTime;
    }

    public Timestamp getEndTime() {
        return endTime;
    }

    public void setEndTime(Timestamp endTime) {
        this.endTime = endTime;
    }

    public Integer getResult() {
        return result;
    }

    public void setResult(Integer result) {
        this.result = result;
    }
}
