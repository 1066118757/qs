package com.cdid.api.datastorage.vo;

import io.swagger.annotations.ApiModel;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/13 16:32  
 */
@ApiModel("执行sql对象")
public class ExecuteSqlVo {
    private String tableName;
    private String sql;


    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getSql() {
        return sql;
    }

    public void setSql(String sql) {
        this.sql = sql;
    }
}
