package com.cdid.api.asynctask;

import com.cdid.api.asynctask.vo.AsyncTaskConfigVo;
import com.cdid.api.jupyter.vo.TaskRequestVo;

public interface AsyncTaskPreProcessProcessor {

    void preProcess(AsyncTaskConfigVo configVo) throws Exception;
}
