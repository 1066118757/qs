package com.cdid.api.operate.operatelog.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * @author LQL
 * @createAt 2017/11/27
 */

/**
 * 数据审核日志查询条件
 */
@ApiModel("存储日志搜索条件对象")
public class OperateLogQueryVo {
    private BigDecimal id;
    private String operatorId;
    @ApiModelProperty(value="操作者名字",example="张三")
    private String operatorName;
    private String operateTable;
    private Timestamp operateTimeStart;
    private Timestamp operateTimeEnd;
    private Integer actionId;
    @ApiModelProperty(value="结果：0 成功 -1 失败",example="结果：0 成功 -1 失败")
    private Integer result;
    @ApiModelProperty(value="是否系统操作 1：系统操作 0：非系统操作",example="是否系统操作 1：系统操作 0：非系统操作")
    private Integer flag;

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(String operatorId) {
        this.operatorId = operatorId;
    }

    public String getOperateTable() {
        return operateTable;
    }

    public void setOperateTable(String operateTable) {
        this.operateTable = operateTable;
    }

    public Timestamp getOperateTimeStart() {
        return operateTimeStart;
    }

    public void setOperateTimeStart(Timestamp operateTimeStart) {
        this.operateTimeStart = operateTimeStart;
    }

    public Timestamp getOperateTimeEnd() {
        return operateTimeEnd;
    }

    public void setOperateTimeEnd(Timestamp operateTimeEnd) {
        this.operateTimeEnd = operateTimeEnd;
    }

    public Integer getActionId() {
        return actionId;
    }

    public void setActionId(Integer actionId) {
        this.actionId = actionId;
    }

    public Integer getResult() {
        return result;
    }

    public void setResult(Integer result) {
        this.result = result;
    }
}
