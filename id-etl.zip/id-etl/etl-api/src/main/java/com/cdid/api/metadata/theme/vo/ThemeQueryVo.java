package com.cdid.api.metadata.theme.vo;


import io.swagger.annotations.ApiModel;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/11/24
 */
@ApiModel(value = "存储主题搜索条件对象")
public class ThemeQueryVo {
    /*private BigDecimal id;
    private String remark;
    private Integer state;
    private Timestamp auditTime;
    private Short status;
    private BigDecimal createUser;
    private Timestamp createTime;
    private BigDecimal updateUser;
    private Timestamp updateTime;*/
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
