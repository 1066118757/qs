package com.cdid.api.operate.operateaction.vo;

/**
 * @Author LQL
 * @CreateAt 2017/11/28
 */

import io.swagger.annotations.ApiModel;


@ApiModel("日志操作描述添加对象")
public class OperateActionAddVo {
    private Integer id;

    private String actionDesc;

    private Integer scope;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getActionDesc() {
        return actionDesc;
    }

    public void setActionDesc(String actionDesc) {
        this.actionDesc = actionDesc;
    }

    public Integer getScope() {
        return scope;
    }

    public void setScope(Integer scope) {
        this.scope = scope;
    }
}
