package com.cdid.api.job.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/02 21:36 
 */
@ApiModel("引接任务统计列表对象")
public class StatisticsJobListVo {
    private BigDecimal id;
    @ApiModelProperty(value="引接任务名称",example="任务名称1")
    private String name;
    @ApiModelProperty(value="数据源名称",example="数据源名称")
    private String dataSourceName;
    @ApiModelProperty(value="任务状态 1：启用 2：禁用",example="1")
    private Integer state;
    private String createUser;

    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Timestamp scheduleStartTime;
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Timestamp scheduleEndTime;
    @ApiModelProperty(value="任务执行状态 1：成功 2：失败",example="1")
    private Integer scheduleState;
    @ApiModelProperty(value="成功行数",example="100")
    private Long successRows;
    @ApiModelProperty(value="任务日志",example="任务日志")
    private String scheduleLog;
    @ApiModelProperty(value="来源表")
    private String srcTableName;
    @ApiModelProperty(value="目标")
    private String distTableName;

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDataSourceName() {
        return dataSourceName;
    }

    public void setDataSourceName(String dataSourceName) {
        this.dataSourceName = dataSourceName;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Timestamp getScheduleStartTime() {
        return scheduleStartTime;
    }

    public void setScheduleStartTime(Timestamp scheduleStartTime) {
        this.scheduleStartTime = scheduleStartTime;
    }

    public Timestamp getScheduleEndTime() {
        return scheduleEndTime;
    }

    public void setScheduleEndTime(Timestamp scheduleEndTime) {
        this.scheduleEndTime = scheduleEndTime;
    }

    public Integer getScheduleState() {
        return scheduleState;
    }

    public void setScheduleState(Integer scheduleState) {
        this.scheduleState = scheduleState;
    }

    public Long getSuccessRows() {
        return successRows;
    }

    public void setSuccessRows(Long successRows) {
        this.successRows = successRows;
    }

    public String getScheduleLog() {
        return scheduleLog;
    }

    public void setScheduleLog(String scheduleLog) {
        this.scheduleLog = scheduleLog;
    }

    public String getSrcTableName() {
        return srcTableName;
    }

    public void setSrcTableName(String srcTableName) {
        this.srcTableName = srcTableName;
    }

    public String getDistTableName() {
        return distTableName;
    }

    public void setDistTableName(String distTableName) {
        this.distTableName = distTableName;
    }
}
