package com.cdid.api.job.vo;

import java.util.ArrayList;
import java.util.List;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2018/1/2 16:36  
 */
public class UploadResVo {

    private String dataKey;

    private List<String> header = new ArrayList<>();

    public String getDataKey() {
        return dataKey;
    }

    public void setDataKey(String dataKey) {
        this.dataKey = dataKey;
    }

    public List<String> getHeader() {
        return header;
    }

    public void setHeader(List<String> header) {
        this.header = header;
    }
}
