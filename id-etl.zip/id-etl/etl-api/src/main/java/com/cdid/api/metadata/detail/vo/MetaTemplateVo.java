package com.cdid.api.metadata.detail.vo;


import java.math.BigDecimal;

/**
 * @Author Froid_Li
 * @Email 269504518@qq.com
 * @Date 2017/11/29  10:56
 */
public class MetaTemplateVo {
    private BigDecimal fileId;

    private String path;

    private String name;

    private String fileType;

    private byte[] data = null;

    public BigDecimal getFileId() {
        return fileId;
    }

    public void setFileId(BigDecimal fileId) {
        this.fileId = fileId;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }


    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }
}
