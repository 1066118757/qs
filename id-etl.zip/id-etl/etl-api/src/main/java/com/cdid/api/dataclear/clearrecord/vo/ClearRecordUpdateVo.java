package com.cdid.api.dataclear.clearrecord.vo;


import com.cdid.api.dataclear.ruleinstance.vo.RuleInstanceAddVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/12/13
 */
@ApiModel(value = "清理记录更新对象")
public class ClearRecordUpdateVo {
    @ApiModelProperty(value="id",example="id")
    private BigDecimal id;
    @ApiModelProperty(value="记录名",example="记录名")
    private String name;
    @ApiModelProperty(value="标签,参考码表 14",example="标签,参考码表 14")
    private Integer[] labels;
    @ApiModelProperty(value="操作表对应的条目id，表对应元数据条目",example="操作表对应的条目id，表对应元数据条目")
    private BigDecimal metadataItemId;

    @ApiModelProperty(value="规则实例化集合",example="规则实例化集合")
    private List<RuleInstanceAddVo> ruleInstanceAddVos;

    @ApiModelProperty(value="封装了操作表以及规则实例化信息的json串",example="封装了操作表以及规则实例化信息的json串")
    private String handleCode;

    public String getHandleCode() {
        return handleCode;
    }

    public void setHandleCode(String handleCode) {
        this.handleCode = handleCode;
    }

    public List<RuleInstanceAddVo> getRuleInstanceAddVos() {
        return ruleInstanceAddVos;
    }

    public void setRuleInstanceAddVos(List<RuleInstanceAddVo> ruleInstanceAddVos) {
        this.ruleInstanceAddVos = ruleInstanceAddVos;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer[] getLabels() {
        return labels;
    }

    public void setLabels(Integer[] labels) {
        this.labels = labels;
    }

    public BigDecimal getMetadataItemId() {
        return metadataItemId;
    }

    public void setMetadataItemId(BigDecimal metadataItemId) {
        this.metadataItemId = metadataItemId;
    }

}
