package com.cdid.api.file.vo;


import com.cdid.api.metadata.detail.vo.DetailPassVo;
import io.swagger.annotations.ApiModel;

import java.math.BigDecimal;
import java.util.List;

/**
 * @Author Froid_Li
 * @Email 269504518@qq.com
 * @Date 2017/11/28  15:47
 */
@ApiModel(value = "文件上传解析返回对象")

public class FileParseRespVo {

    private BigDecimal fileId;
    private List<DetailPassVo> voList;

    public List<DetailPassVo> getVoList() {
        return voList;
    }

    public void setVoList(List<DetailPassVo> voList) {
        this.voList = voList;
    }

    public BigDecimal getFileId() {
        return fileId;
    }

    public void setFileId(BigDecimal fileId) {
        this.fileId = fileId;
    }
}
