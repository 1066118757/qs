package com.cdid.api.dataclear.clearrecord.vo;

public class PreviewReturnVo {

    private String column;
    private String data;

    public String getColumn() {
        return column;
    }

    public void setColumn(String column) {
        this.column = column;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
