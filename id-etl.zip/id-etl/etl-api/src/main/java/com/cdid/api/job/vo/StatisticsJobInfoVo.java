package com.cdid.api.job.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/03 20:19 
 */
@ApiModel("引接任务统计信息对象")
public class StatisticsJobInfoVo {
    @ApiModelProperty(value="总次数",example="0")
    private Integer totalTime;
    @ApiModelProperty(value="成功次数",example="0")
    private BigDecimal successTime;
    @ApiModelProperty(value="正在运行的个数",example="0")
    private BigDecimal runningTime;
    @ApiModelProperty(value="失败次数",example="0")
    private BigDecimal failTime;
    @ApiModelProperty(value="同步数据量总数",example="0")
    private BigDecimal totalDataCount;

    public Integer getTotalTime() {
        return totalTime;
    }

    public void setTotalTime(Integer totalTime) {
        this.totalTime = totalTime;
    }

    public BigDecimal getSuccessTime() {
        return successTime;
    }

    public void setSuccessTime(BigDecimal successTime) {
        this.successTime = successTime;
    }

    public BigDecimal getRunningTime() {
        return runningTime;
    }

    public void setRunningTime(BigDecimal runningTime) {
        this.runningTime = runningTime;
    }

    public BigDecimal getFailTime() {
        return failTime;
    }

    public void setFailTime(BigDecimal failTime) {
        this.failTime = failTime;
    }

    public BigDecimal getTotalDataCount() {
        return totalDataCount;
    }

    public void setTotalDataCount(BigDecimal totalDataCount) {
        this.totalDataCount = totalDataCount;
    }
}
