package com.cdid.api.dict;

import com.cdid.api.dict.vo.DictValueVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * @Author Froid_Li
 * @Email 269504518@qq.com
 * @Date 2017/8/31  17:26
 */
public interface DictService {
    /**
     * @param ids
     * @param pageNo
     * @param pageSize
     * @return
     */
    ResultVo<PageVo> detail(List<Integer> ids, Integer pageNo, Integer pageSize);

    ResultVo<List<DictValueVo>> findValue(Integer id, Short key);

    List<DictValueVo> getMappingByTypeId(Integer typeId);

    ResultVo<Boolean> add(Integer typeId, String value, BigDecimal userId);

    String getValueByMappingId(Integer mappingId);

    List<String> getValuesByMappingIds(Integer[] mappingIdArr);

    List<String> getValuesByKeys(Integer[] mappingIdArr);

    Map<Integer,String> get(Integer[] mappingIdArr);

    Map<Integer,String> getByTypeId(Integer typeId);

    Map<Integer,String> getByTypeIdList(List<Integer> typeIdList);

    void initDict();
}
