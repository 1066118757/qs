package com.cdid.api.dataclear.ruleinstance.vo;


import com.cdid.api.dataclear.ruleinstanceparam.vo.RuleInstanceParamAddVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/12/13
 */
@ApiModel(value = "规则实例化添加对象")
public class RuleInstanceAddVo {

    @ApiModelProperty(value="id",example="id")
    private BigDecimal id;
    @ApiModelProperty(value="清洗记录id",example="清洗记录id")
    private BigDecimal clearRecordId;
    @ApiModelProperty(value="操作表对应的元数据条目详情id，列对应元数据条目详情",example="操作表对应的元数据条目详情id，列对应元数据条目详情")
    private BigDecimal metadataDetailId;
    @ApiModelProperty(value="表达式",example="表达式")
    private String expression;
    @ApiModelProperty(value="清洗规则id",example="清洗规则id")
    private BigDecimal clearRuleId;

    @ApiModelProperty(value="清洗规则实例化参数集合",example="清洗规则实例化参数集合")
    private List<RuleInstanceParamAddVo> ruleInstanceParamAddVos;

    public List<RuleInstanceParamAddVo> getRuleInstanceParamAddVos() {
        return ruleInstanceParamAddVos;
    }

    public void setRuleInstanceParamAddVos(List<RuleInstanceParamAddVo> ruleInstanceParamAddVos) {
        this.ruleInstanceParamAddVos = ruleInstanceParamAddVos;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public BigDecimal getClearRecordId() {
        return clearRecordId;
    }

    public void setClearRecordId(BigDecimal clearRecordId) {
        this.clearRecordId = clearRecordId;
    }

    public BigDecimal getMetadataDetailId() {
        return metadataDetailId;
    }

    public void setMetadataDetailId(BigDecimal metadataDetailId) {
        this.metadataDetailId = metadataDetailId;
    }

    public String getExpression() {
        return expression;
    }

    public void setExpression(String expression) {
        this.expression = expression;
    }

    public BigDecimal getClearRuleId() {
        return clearRuleId;
    }

    public void setClearRuleId(BigDecimal clearRuleId) {
        this.clearRuleId = clearRuleId;
    }

}
