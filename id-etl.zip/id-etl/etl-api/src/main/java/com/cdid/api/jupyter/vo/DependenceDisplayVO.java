package com.cdid.api.jupyter.vo;

import com.cdid.api.common.IdNameVO;

import java.util.ArrayList;
import java.util.List;

public class DependenceDisplayVO {

    private List<IdNameVO> etlJobs=new ArrayList<>();

    private List<IdNameVO> clearJobs=new ArrayList<>();

    public DependenceDisplayVO() {
    }

    public DependenceDisplayVO(List<IdNameVO> clearJobs, List<IdNameVO> etlJobs) {
        this.clearJobs = clearJobs;
        this.etlJobs = etlJobs;
    }

    public List<IdNameVO> getClearJobs() {
        return clearJobs;
    }

    public void setClearJobs(List<IdNameVO> clearJobs) {
        this.clearJobs = clearJobs;
    }

    public List<IdNameVO> getEtlJobs() {
        return etlJobs;
    }

    public void setEtlJobs(List<IdNameVO> etlJobs) {
        this.etlJobs = etlJobs;
    }
}
