package com.cdid.api.storagedata.vo;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @Author Froid_Li
 * @Email 269504518@qq.com
 * @Date 2017/11/24  13:51
 */
@ApiModel(value = "存储数据搜索条件对象")

public class StorageDataQueryVo {
    @ApiModelProperty(name = "type", value = "数据类别,0代表图像，1代表视频", required = true)
    private Integer type;
    private String name;
    private String uploadUserId;

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUploadUserId() {
        return uploadUserId;
    }

    public void setUploadUserId(String uploadUserId) {
        this.uploadUserId = uploadUserId;
    }
}
