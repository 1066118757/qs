package com.cdid.api.common;


import java.util.List;
import java.util.Map;

/**
 * Froid_Li
 * 269504518@qq.com
 * 2017/12/27  20:31
 */
public interface RedisService {
    boolean delete(String redisKey);

    boolean hdel(String redisKey);

    String get(String redisKey);

    boolean exists(String redisKey);

    boolean put(String redisKey, String value);

    boolean hmput(String redisKey, Map<String, String> value);

    boolean mPut(String redisKey, String mapKey, String value);

    String mGet(String redisKey, String mapKey);

    List<String> hmGet(String redisKey, String... mapKey);

    Map<String, String> hmGetAll(String redisKey);

    boolean put(String redisKey, String value, long expireSeconds);

    List<String> keys(String pattern);

    Long getExpireTime(String key);

    void batchDelete(String... keys);

    void incr(String key);

    void decr(String key);

    void batchDelete(int dbIndex,String... keys);
}
