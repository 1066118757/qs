package com.cdid.api.operate.operatelog;


import com.cdid.api.operate.operatelog.vo.OperateLogAddVo;
import com.cdid.api.operate.operatelog.vo.OperateLogListVo;
import com.cdid.api.operate.operatelog.vo.OperateLogQueryVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;

import java.util.List;

public interface OperateLogService {

    /**
     * 添加操作日志
     * @param operateLogVo
     * @return
     */
    ResultVo<Object> add(OperateLogAddVo operateLogVo);

    /**
     * 分页查询操作日志
     *
     * @param operateLogQueryVo
     * @param pageNo
     * @param pageSize
     * @return
     */
    ResultVo<PageVo<List<OperateLogListVo>>> list(OperateLogQueryVo operateLogQueryVo, Integer pageNo, Integer pageSize);

}
