package com.cdid.api.metadata.item.vo;


import io.swagger.annotations.ApiModel;

import java.math.BigDecimal;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/11/24
 */
@ApiModel(value = "添加元数据条目对象")
public class ItemAddVo {
    private BigDecimal themeItemId;
    private String name;
    private Integer type;
    private String purpose;
    private Integer sourceType;

    public Integer getSourceType() {
        return sourceType;
    }

    public void setSourceType(Integer sourceType) {
        this.sourceType = sourceType;
    }

    public BigDecimal getThemeItemId() {
        return themeItemId;
    }

    public void setThemeItemId(BigDecimal themeItemId) {
        this.themeItemId = themeItemId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }
}
