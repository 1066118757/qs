package com.cdid.api.common;


public class TokenVo {
    private String userId;
    private Long expiredTime;
    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setExpiredTime(Long expiredTime) {
        this.expiredTime = expiredTime;
    }

    public String getUserId() {
        return userId;
    }

    public Long getExpiredTime() {
        return expiredTime;
    }

}
