package com.cdid.api.operate.operatelog.vo;

import io.swagger.annotations.ApiModel;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * @author LQL
 * @createAt 2017/11/27
 */
@ApiModel(value = "日志操作对象")
public class OperateLogDetailVo {
    private BigDecimal id;
    private String operatorId;
    private String operateTable;
    private Timestamp operateTime;
    private Integer actionId;
    private Integer result;
    private String operatorName;

    public String getOperatorName() {
        return operatorName;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }
    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(String operatorId) {
        this.operatorId = operatorId;
    }

    public String getOperateTable() {
        return operateTable;
    }

    public void setOperateTable(String operateTable) {
        this.operateTable = operateTable;
    }

    public Timestamp getOperateTime() {
        return operateTime;
    }

    public void setOperateTime(Timestamp operateTime) {
        this.operateTime = operateTime;
    }

    public Integer getActionId() {
        return actionId;
    }

    public void setActionId(Integer actionId) {
        this.actionId = actionId;
    }

    public Integer getResult() {
        return result;
    }

    public void setResult(Integer result) {
        this.result = result;
    }
}
