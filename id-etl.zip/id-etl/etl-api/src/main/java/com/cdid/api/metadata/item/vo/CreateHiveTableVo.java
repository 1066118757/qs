package com.cdid.api.metadata.item.vo;


import java.util.List;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/12/20
 */
public class CreateHiveTableVo {
    //数据库名,默认default
    private String schema="default";
    //表名
    private String tableName;
    //表别名
    private String displayName;
    //创建人
    private String created_uuid;
    //传0即可
    private Number tableType=0;
    //表的列集合
    private List<CreateHiveColVo> columns;

    public String getSchema() {
        return schema;
    }

    public void setSchema(String schema) {
        this.schema = schema;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getCreated_uuid() {
        return created_uuid;
    }

    public void setCreated_uuid(String created_uuid) {
        this.created_uuid = created_uuid;
    }

    public Number getTableType() {
        return tableType;
    }

    public void setTableType(Number tableType) {
        this.tableType = tableType;
    }

    public List<CreateHiveColVo> getColumns() {
        return columns;
    }

    public void setColumns(List<CreateHiveColVo> columns) {
        this.columns = columns;
    }
}
