package com.cdid.api.schedulelog.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/02 15:47 
 */
@ApiModel("任务日志列表对象")
public class ScheduleLogListVo {

    private BigDecimal id;
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Timestamp scheduleStarttime;
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Timestamp scheduleEndtime;
    private Integer scheduleState;
    private Long successRows;
    private String scheduleLog;
    private BigDecimal jobId;

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public Timestamp getScheduleStarttime() {
        return scheduleStarttime;
    }

    public void setScheduleStarttime(Timestamp scheduleStarttime) {
        this.scheduleStarttime = scheduleStarttime;
    }

    public Timestamp getScheduleEndtime() {
        return scheduleEndtime;
    }

    public void setScheduleEndtime(Timestamp scheduleEndtime) {
        this.scheduleEndtime = scheduleEndtime;
    }

    public Integer getScheduleState() {
        return scheduleState;
    }

    public void setScheduleState(Integer scheduleState) {
        this.scheduleState = scheduleState;
    }

    public Long getSuccessRows() {
        return successRows;
    }

    public void setSuccessRows(Long successRows) {
        this.successRows = successRows;
    }

    public String getScheduleLog() {
        return scheduleLog;
    }

    public void setScheduleLog(String scheduleLog) {
        this.scheduleLog = scheduleLog;
    }

    public BigDecimal getJobId() {
        return jobId;
    }

    public void setJobId(BigDecimal jobId) {
        this.jobId = jobId;
    }
}
