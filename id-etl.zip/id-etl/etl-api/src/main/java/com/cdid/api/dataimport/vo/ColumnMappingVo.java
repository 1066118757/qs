package com.cdid.api.dataimport.vo;

public class ColumnMappingVo {

    private String source;

    private String dist;

    private String distDataType;

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDist() {
        return dist;
    }

    public void setDist(String dist) {
        this.dist = dist;
    }

    public String getDistDataType() {
        return distDataType;
    }

    public void setDistDataType(String distDataType) {
        this.distDataType = distDataType;
    }
}
