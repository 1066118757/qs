package com.cdid.api.file.vo;


import java.math.BigDecimal;

/**
 * @Author Froid_Li
 * @Email 269504518@qq.com
 * @Date 2017/12/14  16:21
 */
public class FileUploadRespVo {
    private BigDecimal fileId;

    private String filePath;

    private String name;

    private String fileType;

    public BigDecimal getFileId() {
        return fileId;
    }

    public void setFileId(BigDecimal fileId) {
        this.fileId = fileId;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }
}
