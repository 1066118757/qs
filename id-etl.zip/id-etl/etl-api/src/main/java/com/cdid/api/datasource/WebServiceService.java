package com.cdid.api.datasource;

import com.cdid.api.datasource.vo.WebServiceVo;
import com.cdid.common.vo.ResponseVo;
import com.cdid.common.vo.ResultVo;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/06 15:59 
 */
public interface WebServiceService {
    /**
     * 连接测试
     * @return
     */
    ResultVo<ResponseVo> connectTest(WebServiceVo webServiceVo);

    ResultVo<ResponseVo> getResponse(WebServiceVo webServiceVo);

}
