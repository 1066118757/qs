package com.cdid.api.dataimport.websocket;

import com.cdid.api.dataimport.websocket.vo.WebSocketConfigVo;
import com.neovisionaries.ws.client.WebSocket;
import com.neovisionaries.ws.client.WebSocketException;

import java.io.IOException;

public interface WebSocketService {

    WebSocket connect(WebSocketConfigVo configVo) throws IOException, WebSocketException;
}
