package com.cdid.api.metadata.theme.vo;


import io.swagger.annotations.ApiModel;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/11/24
 */
@ApiModel(value = "添加主题对象")
public class ThemeAddVo {
    //private BigDecimal id;
    private String name;
    private String remark;
/*    private Integer state;
    private Timestamp auditTime;
    private Short status;
    private BigDecimal createUser;
    private Timestamp createTime;
    private BigDecimal updateUser;
    private Timestamp updateTime;*/

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
