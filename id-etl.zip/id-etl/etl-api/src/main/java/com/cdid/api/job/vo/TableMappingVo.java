package com.cdid.api.job.vo;

import io.swagger.annotations.ApiModel;

import java.util.List;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/28 21:39  
 */
@ApiModel("映射对象")
public class TableMappingVo {
    private String srcTable;
    private String disTable;

    private List<MappingVo> mappingVoList;

    public String getSrcTable() {
        return srcTable;
    }

    public void setSrcTable(String srcTable) {
        this.srcTable = srcTable;
    }

    public String getDisTable() {
        return disTable;
    }

    public void setDisTable(String disTable) {
        this.disTable = disTable;
    }

    public List<MappingVo> getMappingVoList() {
        return mappingVoList;
    }

    public void setMappingVoList(List<MappingVo> mappingVoList) {
        this.mappingVoList = mappingVoList;
    }
}
