package com.cdid.api.datastorage.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/13 11:09  
 */
@ApiModel("逻辑分区查询对象")
public class LogicQueryVo {
    @ApiModelProperty(value="名称",example="名称")
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
