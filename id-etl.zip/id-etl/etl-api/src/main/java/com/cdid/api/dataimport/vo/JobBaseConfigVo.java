package com.cdid.api.dataimport.vo;

import com.cdid.api.jupyter.vo.TaskRequestVo;

import java.math.BigDecimal;
import java.util.List;

public class JobBaseConfigVo extends TaskRequestVo {

    private BigDecimal dbMoveJobId;

    private int dbMoveTableCount;

    private String distJdbcUrl;

    private String distDataBase;

    private String distUserName;

    private String distPassword;

    private Integer distDbType;

    private String distSchema;

    private String distTable;

    //导入模式
    private Integer importMode;

    private Integer syncStrategy;

    //字段映射关系
    private List<ColumnMappingVo> columnMappingVoList;

    private String columnMapping;

    private Integer priority;

    private BigDecimal scheduleLogId;

    //短信提醒
    private String smsReminding;

    //邮箱提醒
    private String emailReminding;

    private String dependence;

    public String getSmsReminding() {
        return smsReminding;
    }

    public void setSmsReminding(String smsReminding) {
        this.smsReminding = smsReminding;
    }

    public String getEmailReminding() {
        return emailReminding;
    }

    public void setEmailReminding(String emailReminding) {
        this.emailReminding = emailReminding;
    }

    public String getDistSchema() {
        return distSchema;
    }

    public void setDistSchema(String distSchema) {
        this.distSchema = distSchema;
    }

    public String getDistTable() {
        return distTable;
    }

    public void setDistTable(String distTable) {
        this.distTable = distTable;
    }

    public Integer getImportMode() {
        return importMode;
    }

    public void setImportMode(Integer importMode) {
        this.importMode = importMode;
    }

    public List<ColumnMappingVo> getColumnMappingVoList() {
        return columnMappingVoList;
    }

    public void setColumnMappingVoList(List<ColumnMappingVo> columnMappingVoList) {
        this.columnMappingVoList = columnMappingVoList;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    public String getDistJdbcUrl() {
        return distJdbcUrl;
    }

    public void setDistJdbcUrl(String distJdbcUrl) {
        this.distJdbcUrl = distJdbcUrl;
    }

    public String getDistUserName() {
        return distUserName;
    }

    public void setDistUserName(String distUserName) {
        this.distUserName = distUserName;
    }

    public String getDistPassword() {
        return distPassword;
    }

    public void setDistPassword(String distPassword) {
        this.distPassword = distPassword;
    }

    public Integer getDistDbType() {
        return distDbType;
    }

    public void setDistDbType(Integer distDbType) {
        this.distDbType = distDbType;
    }

    public BigDecimal getScheduleLogId() {
        return scheduleLogId;
    }

    public void setScheduleLogId(BigDecimal scheduleLogId) {
        this.scheduleLogId = scheduleLogId;
    }

    public Integer getSyncStrategy() {
        return syncStrategy;
    }

    public void setSyncStrategy(Integer syncStrategy) {
        this.syncStrategy = syncStrategy;
    }

    public BigDecimal getDbMoveJobId() {
        return dbMoveJobId;
    }

    public void setDbMoveJobId(BigDecimal dbMoveJobId) {
        this.dbMoveJobId = dbMoveJobId;
    }

    public int getDbMoveTableCount() {
        return dbMoveTableCount;
    }

    public void setDbMoveTableCount(int dbMoveTableCount) {
        this.dbMoveTableCount = dbMoveTableCount;
    }

    public String getColumnMapping() {
        return columnMapping;
    }

    public void setColumnMapping(String columnMapping) {
        this.columnMapping = columnMapping;
    }

    public String getDistDataBase() {
        return distDataBase;
    }

    public void setDistDataBase(String distDataBase) {
        this.distDataBase = distDataBase;
    }

    public String getDependence() {
        return dependence;
    }

    public void setDependence(String dependence) {
        this.dependence = dependence;
    }
}
