package com.cdid.api.metadata.item.vo;


import io.swagger.annotations.ApiModel;

import java.math.BigDecimal;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/11/24
 */
@ApiModel(value = "更新元数据条目对象")
public class ItemUpdateVo {
    private BigDecimal id;
    private BigDecimal themeItemId;
    private String name;
    private Integer type;
    private String purpose;
    private Integer state;
    /*private Timestamp auditTime;
    private Short status;
    private BigDecimal createUser;
    private Timestamp createTime;
    private BigDecimal updateUser;
    private Timestamp updateTime;*/

    private Integer sourceType;

    public Integer getSourceType() {
        return sourceType;
    }

    public void setSourceType(Integer sourceType) {
        this.sourceType = sourceType;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public BigDecimal getThemeItemId() {
        return themeItemId;
    }

    public void setThemeItemId(BigDecimal themeItemId) {
        this.themeItemId = themeItemId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }
}
