package com.cdid.api.datastorage.vo;

import com.cdid.api.dataimport.vo.ColumnMappingVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.util.List;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/13 15:56  
 */
@ApiModel("分享或加载数据对象")
public class LoadOrShareVo {
    @ApiModelProperty(value="源表名称",example="1")
    private String distTableName;

    @ApiModelProperty(value="目标表名称",example="1")
    private String srcTableName;
    @ApiModelProperty(value="逻辑分区条目id",example="1")
    private BigDecimal logicPartitionId;
    @ApiModelProperty(value="目标表来源 1:新建 2:已有目标表 默认1",example="1")
    private Integer distTableSource = 1;
    @ApiModelProperty(value="表数据类型 201:数据结构 202:数据字典 默认201",example="1")
    private Integer metadataType = 201;
    private List<ColumnMappingVo> columnMappingVoList;

    @ApiModelProperty(value="sql")
    private String sql;

    public String getSrcTableName() {
        return srcTableName;
    }

    public void setSrcTableName(String srcTableName) {
        this.srcTableName = srcTableName;
    }

    public String getDistTableName() {
        return distTableName;
    }

    public void setDistTableName(String distTableName) {
        this.distTableName = distTableName;
    }

    public List<ColumnMappingVo> getColumnMappingVoList() {
        return columnMappingVoList;
    }

    public void setColumnMappingVoList(List<ColumnMappingVo> columnMappingVoList) {
        this.columnMappingVoList = columnMappingVoList;
    }

    public Integer getDistTableSource() {
        return distTableSource;
    }

    public void setDistTableSource(Integer distTableSource) {
        this.distTableSource = distTableSource;
    }

    public Integer getMetadataType() {
        return metadataType;
    }

    public void setMetadataType(Integer metadataType) {
        this.metadataType = metadataType;
    }

    public BigDecimal getLogicPartitionId() {
        return logicPartitionId;
    }

    public void setLogicPartitionId(BigDecimal logicPartitionId) {
        this.logicPartitionId = logicPartitionId;
    }

    public String getSql() {
        return sql;
    }

    public void setSql(String sql) {
        this.sql = sql;
    }
}
