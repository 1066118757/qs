package com.cdid.api.operate.operateaction;

import com.cdid.api.operate.operateaction.vo.OperateActionAddVo;
import com.cdid.api.operate.operateaction.vo.OperateActionQueryVo;
import com.cdid.api.operate.operateaction.vo.OperateActionVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;

import java.math.BigDecimal;
import java.util.List;

/**
 * @Author LQL
 * @CreateAt 2017/11/28
 */
public interface OperateActionService {
    /**
     * 添加日志操作描述
     *
     * @param operateActionAddVo
     * @return
     */
    ResultVo<Object> add(OperateActionAddVo operateActionAddVo);

    /**
     * 更新日志操作描述
     * @param operateActionVo
     * @return
     */
    ResultVo<Object> update(OperateActionVo operateActionVo);

    /**
     * 查询操作日志描述
     * @param id
     * @return
     */
    ResultVo<OperateActionVo> detailById(BigDecimal id);

    /**
     * 删除操作日志描述
     * @param id
     * @return
     */
    ResultVo<Object> delete(BigDecimal id);


    /**
     * 操作日志列表查询
     * @param operateActionQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    ResultVo<PageVo<List<OperateActionVo>>> list(OperateActionQueryVo operateActionQueryVo, String userId, Integer page, Integer size);
}
