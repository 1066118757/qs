package com.cdid.api.metadata.item.vo;


/**
 * @author OuZhiCheng
 * @create 创建时间：2017/11/24
 */
public class ExistDataQueryVo {
    private String schema;
    private String tableName;

    public String getSchema() {
        return schema;
    }

    public void setSchema(String schema) {
        this.schema = schema;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
}
