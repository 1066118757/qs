package com.cdid.api.jobconf.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/02 15:38 
 */
@ApiModel("配置查询对象")
public class JobConfQueryVo {

    private BigDecimal id;
    @ApiModelProperty(value="key",example="用户名")
    private String key;
    @ApiModelProperty(value="value",example="root")
    private String value;
    @ApiModelProperty(value="关联id",example="1906177435238400")
    private BigDecimal refId;
    /**
     * 类型 701:数据源配置,702:任务配置,703:消息提醒机制,704:字段映射
     */
    @ApiModelProperty(value="类型 701:数据源配置,702:任务配置,703:消息提醒机制,704:字段映射",example="702")
    private Integer type;
    /**
     * 状态
     */
    @ApiModelProperty(value="状态 1:启用,2:禁用",example="1")
    private Integer state;
//    private Short status;
//    private Timestamp createTime;
//    private BigDecimal createUser;
//    private Timestamp updateTime;
//    private BigDecimal updateUser;

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public BigDecimal getRefId() {
        return refId;
    }

    public void setRefId(BigDecimal refId) {
        this.refId = refId;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

}
