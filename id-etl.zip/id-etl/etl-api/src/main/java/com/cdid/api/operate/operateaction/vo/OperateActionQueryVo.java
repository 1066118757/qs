package com.cdid.api.operate.operateaction.vo;

import io.swagger.annotations.ApiModel;

@ApiModel(value = "日志查询对象")
public class OperateActionQueryVo {
    private Integer id;

    private String actionDesc;

    private Integer scope;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getActionDesc() {
        return actionDesc;
    }

    public void setActionDesc(String actionDesc) {
        this.actionDesc = actionDesc;
    }

    public Integer getScope() {
        return scope;
    }

    public void setScope(Integer scope) {
        this.scope = scope;
    }
}
