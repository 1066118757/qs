package com.cdid.api.dataclear.cleartask;

import com.cdid.api.dataclear.cleartask.vo.*;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

/**
 * @author OuZhiCheng
 */
public interface ClearTaskService {
    /**
     * 数据整理任务详情添加
     *
     * @param clearTaskAddVo
     * @param userId
     * @return
     */

    ResultVo<Object> add(ClearTaskAddVo clearTaskAddVo, String userId);

    /**
     * 数据整理任务详情更新
     *
     * @param clearTaskUpdateVo
     * @param userId
     * @return
     */
    ResultVo<Object> update(ClearTaskUpdateVo clearTaskUpdateVo, String userId);

    /**
     * 数据整理任务详情删除
     *
     * @param id
     * @return
     */
    ResultVo<Object> delete(BigDecimal id);

    /**
     * 数据整理任务详情查询
     *
     * @param clearTaskQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    ResultVo<PageVo<List<ClearTaskListVo>>> list(ClearTaskQueryVo clearTaskQueryVo, String userId, Integer page, Integer size);

    /**
     * 数据整理任务详情查询详情
     *
     * @param id
     * @return
     */
    ResultVo<ClearTaskDetailVo> clearTaskById(BigDecimal id);

    /**
     * 获取定时任务实体类的方法
     * @param taskDetailVo
     * @param handleCode
     * @return
     */
    public ResultVo getScheduleJobEntity(ClearTaskDetailVo taskDetailVo,String handleCode);

    /**
     * 项目启动init获取定时任务实体类的方法
     * @param taskDetailVo
     * @param handleCode
     * @return
     */
    public ResultVo initGetScheduleJobEntity(ClearTaskDetailVo taskDetailVo,String handleCode) throws Exception;

    /**
     * 更新定时任务最近执行信息
     * @param clearTaskUpdateVo
     * @return
     */
    void updateNearData(ClearTaskUpdateVo clearTaskUpdateVo);

    /**
     * 立即执行的接口
     * @param taskId
     * @return
     */
    ResultVo nowExecute(BigDecimal taskId);

    void clearTaskFinished(ClearTaskFinishedResponseVO response);

    void sendEmailAndNote(String taskName, String emails, String phones, String result, Timestamp currentTime);
}
