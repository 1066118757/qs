package com.cdid.api.asynctask.vo;

import com.alibaba.fastjson.JSONObject;
import com.cdid.api.jupyter.TaskPreProcessProcessor;

import java.math.BigDecimal;

public class AsyncTaskConfigVo {

    private BigDecimal taskId;

    private TaskPreProcessProcessor preProcessProcessor;

    private JSONObject taskParams;

    private String topic;

    private String dependence;

    public BigDecimal getTaskId() {
        return taskId;
    }

    public void setTaskId(BigDecimal taskId) {
        this.taskId = taskId;
    }

    public TaskPreProcessProcessor getPreProcessProcessor() {
        return preProcessProcessor;
    }

    public void setPreProcessProcessor(TaskPreProcessProcessor preProcessProcessor) {
        this.preProcessProcessor = preProcessProcessor;
    }

    public JSONObject getTaskParams() {
        return taskParams;
    }

    public void setTaskParams(JSONObject taskParams) {
        this.taskParams = taskParams;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getDependence() {
        return dependence;
    }

    public void setDependence(String dependence) {
        this.dependence = dependence;
    }
}
