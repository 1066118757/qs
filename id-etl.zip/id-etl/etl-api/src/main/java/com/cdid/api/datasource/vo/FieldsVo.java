package com.cdid.api.datasource.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/02 15:01 
 */
@ApiModel("数据库指定表字段集合")
public class FieldsVo {
    @ApiModelProperty(value="字段名",example="连接的数据库表字段名")
    private String FieldName;
    @ApiModelProperty(value="字段类型",example="int")
    private String FieldType;
    @ApiModelProperty(value="hbase库列族",example="String")
    private String colFamily;

    public String getFieldName() {
        return FieldName;
    }

    public void setFieldName(String fieldName) {
        FieldName = fieldName;
    }

    public String getFieldType() {
        return FieldType;
    }

    public void setFieldType(String fieldType) {
        FieldType = fieldType;
    }

    public String getColFamily() {
        return colFamily;
    }

    public void setColFamily(String colFamily) {
        this.colFamily = colFamily;
    }

    @Override
    public boolean equals(Object obj) {
        FieldsVo fieldsVo = (FieldsVo)obj;
        return fieldsVo.FieldName.equals(this.FieldName);
    }
}
