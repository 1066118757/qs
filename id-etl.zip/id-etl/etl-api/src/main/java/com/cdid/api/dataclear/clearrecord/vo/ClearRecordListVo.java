package com.cdid.api.dataclear.clearrecord.vo;


import com.cdid.api.dataclear.ruleinstance.vo.RuleInstanceListVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/12/13
 */
@ApiModel(value = "清理记录列表对象")
public class ClearRecordListVo {
    @ApiModelProperty(value="id",example="id")
    private BigDecimal id;
    @ApiModelProperty(value="记录名",example="记录名")
    private String name;
    @ApiModelProperty(value="标签,参考码表 14",example="标签,参考码表 14")
    private Integer[] labels;
    @ApiModelProperty(value="操作表对应的条目id，表对应元数据条目",example="操作表对应的条目id，表对应元数据条目")
    private BigDecimal metadataItemId;
    private Integer status;
    private Timestamp createTime;
    private String createUser;
    private Timestamp updateTime;
    private String updateUser;

    @ApiModelProperty(value="规则实例化集合",example="规则实例化集合")
    private List<RuleInstanceListVo> ruleInstanceListVos;

    @ApiModelProperty(value="封装了操作表以及规则实例化信息的json串",example="封装了操作表以及规则实例化信息的json串")
    private String handleCode;
    @ApiModelProperty(value="操作表名",example="操作表名")
    private String tableName;

    private String createUserName;

    public String getCreateUserName() {
        return createUserName;
    }

    public void setCreateUserName(String createUserName) {
        this.createUserName = createUserName;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getHandleCode() {
        return handleCode;
    }

    public void setHandleCode(String handleCode) {
        this.handleCode = handleCode;
    }

    public List<RuleInstanceListVo> getRuleInstanceListVos() {
        return ruleInstanceListVos;
    }

    public void setRuleInstanceListVos(List<RuleInstanceListVo> ruleInstanceListVos) {
        this.ruleInstanceListVos = ruleInstanceListVos;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer[] getLabels() {
        return labels;
    }

    public void setLabels(Integer[] labels) {
        this.labels = labels;
    }

    public BigDecimal getMetadataItemId() {
        return metadataItemId;
    }

    public void setMetadataItemId(BigDecimal metadataItemId) {
        this.metadataItemId = metadataItemId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Timestamp getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Timestamp updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }
}
