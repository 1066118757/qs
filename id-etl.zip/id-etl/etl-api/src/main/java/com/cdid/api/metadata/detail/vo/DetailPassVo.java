package com.cdid.api.metadata.detail.vo;


import com.cdid.utils.csv.annotation.CsvField;
import com.cdid.utils.excel.annotation.ExcelField;

import java.util.HashMap;
import java.util.Map;

/**
 * @Author Froid_Li
 * @Email 269504518@qq.com
 * @Date 2017/11/28  15:02
 */
public class DetailPassVo {

    @CsvField(title = "序号")
    @ExcelField(title = "序号")
    private String index;
    @ExcelField(title = "字段名")
    @CsvField(title = "字段名")
    private String colDisplayName;

    @ExcelField(title = "字段类型(数值/文本)")
    @CsvField(title = "字段类型(数值/文本)")
    private String colType;
    @CsvField(title = "字段含义")
    @ExcelField(title = "字段含义")
    private String colComment;

    @CsvField(title = "原始字段")
    @ExcelField(title = "原始字段")
    private String colName;

    public DetailPassVo() {
    }

    public DetailPassVo(String index, String colDisplayName, String colType, String colComment, String colName) {
        this.index = index;
        this.colName = colName;
        this.colType = colType;
        this.colComment = colComment;
        this.colDisplayName = colDisplayName;
    }

    public String getColDisplayName() {
        return colDisplayName;
    }

    public void setColDisplayName(String colDisplayName) {
        this.colDisplayName = colDisplayName;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public String getColType() {
        return colType;
    }

    public void setColType(String colType) {
        this.colType = colType;
    }

    public String getColComment() {
        return colComment;
    }

    public void setColComment(String colComment) {
        this.colComment = colComment;
    }

    public String getColName() {
        return colName;
    }

    public void setColName(String colName) {
        this.colName = colName;
    }


    public Map<String, String> csvMap() {
        Map<String, String> columnMapping = new HashMap<String, String>();
        columnMapping.put("序号", "index");
        columnMapping.put("字段名", "colDisplayname");
        columnMapping.put("字段类型(数值/文本)", "colType");
        columnMapping.put("字段含义", "colComment");
        columnMapping.put("原始字段", "colName");
        return columnMapping;
    }
}
