package com.cdid.api.metadata.detail.vo;


import io.swagger.annotations.ApiModel;

import java.math.BigDecimal;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/11/24
 */
@ApiModel(value = "更新元数据详情对象")
public class DetailUpdateVo {
    private BigDecimal id;
    private BigDecimal metadataItemId;
    private String colDisplayname;
    private Integer colType;
    private String colComment;
    private String colName;
    private Integer state;
    private Integer index;


    /*private Timestamp auditTime;
    private Short status;
    private BigDecimal createUser;
    private Timestamp createTime;
    private BigDecimal updateUser;
    private Timestamp updateTime;*/

    public Integer getIndex() {
        return index;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }
    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public BigDecimal getMetadataItemId() {
        return metadataItemId;
    }

    public void setMetadataItemId(BigDecimal metadataItemId) {
        this.metadataItemId = metadataItemId;
    }

    public String getColDisplayname() {
        return colDisplayname;
    }

    public void setColDisplayname(String colDisplayname) {
        this.colDisplayname = colDisplayname;
    }

    public Integer getColType() {
        return colType;
    }

    public void setColType(Integer colType) {
        this.colType = colType;
    }

    public String getColComment() {
        return colComment;
    }

    public void setColComment(String colComment) {
        this.colComment = colComment;
    }

    public String getColName() {
        return colName;
    }

    public void setColName(String colName) {
        this.colName = colName;
    }
}
