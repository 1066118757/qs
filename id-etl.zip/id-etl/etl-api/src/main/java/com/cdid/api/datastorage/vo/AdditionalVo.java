package com.cdid.api.datastorage.vo;

import com.cdid.api.dataimport.vo.ColumnMappingVo;
import io.swagger.annotations.ApiModel;

import java.util.List;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/13 14:18  
 */
@ApiModel("追加数据")
public class AdditionalVo {
    private String tableName;
    private String redisKey;
    private List<ColumnMappingVo> columnMappingVoList;

    public String getRedisKey() {
        return redisKey;
    }

    public void setRedisKey(String redisKey) {
        this.redisKey = redisKey;
    }

    public List<ColumnMappingVo> getColumnMappingVoList() {
        return columnMappingVoList;
    }

    public void setColumnMappingVoList(List<ColumnMappingVo> columnMappingVoList) {
        this.columnMappingVoList = columnMappingVoList;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
}
