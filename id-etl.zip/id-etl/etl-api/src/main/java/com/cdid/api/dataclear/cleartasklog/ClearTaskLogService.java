package com.cdid.api.dataclear.cleartasklog;

import com.cdid.api.dataclear.cleartasklog.vo.*;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author OuZhiCheng
 */
public interface ClearTaskLogService {
    /**
     * 数据整理任务日志详情添加
     *
     * @param clearTaskLogAddVo
     * @param userId
     * @return
     */

    ResultVo<Object> add(ClearTaskLogAddVo clearTaskLogAddVo, String userId);

    /**
     * 数据整理任务日志详情更新
     *
     * @param clearTaskLogUpdateVo
     * @param userId
     * @return
     */
    ResultVo<Object> update(ClearTaskLogUpdateVo clearTaskLogUpdateVo, String userId);

    /**
     * 数据整理任务日志详情删除
     *
     * @param id
     * @return
     */
    ResultVo<Object> delete(BigDecimal id);

    /**
     * 数据整理任务日志详情查询
     *
     * @param clearTaskLogQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    ResultVo<PageVo<List<ClearTaskLogListVo>>> list(ClearTaskLogQueryVo clearTaskLogQueryVo, String userId, Integer page, Integer size);

    /**
     * 数据整理任务日志详情查询详情
     *
     * @param id
     * @return
     */
    ResultVo<ClearTaskLogDetailVo> clearTaskLogById(BigDecimal id);

    /**
     * 数据整理任务日志依据是否有id更新或者保存
     * @param clearTaskLogUpdateVo
     * @param userId
     * @return
     */
    ResultVo<BigDecimal> updateOrSave(ClearTaskLogUpdateVo clearTaskLogUpdateVo, String userId);

    /**
     * 判断当前任务是否正在执行
     * @param taskId
     * @return
     */
    Boolean taskIsRunning(BigDecimal taskId);

    /**
     * 通过taskId查询最近一次的logId
     * @param taskId
     * @return
     */
    BigDecimal lastLogIdByTaskId(BigDecimal taskId);


    void taskScheduleFail(BigDecimal taskId,String errorMessage);
}
