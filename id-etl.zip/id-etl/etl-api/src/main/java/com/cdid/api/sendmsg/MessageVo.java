package com.cdid.api.sendmsg;

import java.util.List;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2018/3/1 15:06  
 */
public class MessageVo {
    private String name;
    private String finishTime;
    private String result;
    private List<String> email;
    private List<String> phone;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFinishTime() {
        return finishTime;
    }

    public void setFinishTime(String finishTime) {
        this.finishTime = finishTime;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public List<String> getEmail() {
        return email;
    }

    public void setEmail(List<String> email) {
        this.email = email;
    }

    public List<String> getPhone() {
        return phone;
    }

    public void setPhone(List<String> phone) {
        this.phone = phone;
    }
}
