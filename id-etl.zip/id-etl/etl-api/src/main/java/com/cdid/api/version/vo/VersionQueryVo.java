package com.cdid.api.version.vo;


import io.swagger.annotations.ApiModel;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/11/24
 */
@ApiModel(value = "版本信息查询对象")
public class VersionQueryVo {
    //private BigDecimal id;
    private String no;
    private String name;
    //private String description;
    //private String logo;
    //private String image;
    private Integer state;
//    private Long createUser;
//    private Timestamp createTime;
//    private Long updateUser;
//    private Timestamp updateTime;
//    private Short flag;


    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getNo() {
        return no;
    }

    public void setNo(String no) {
        this.no = no;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
