package com.cdid.api.storagedata.vo;


import io.swagger.annotations.ApiModel;

import java.math.BigDecimal;

/**
 * @Author Froid_Li
 * @Email 269504518@qq.com
 * @Date 2017/12/14  16:14
 */
@ApiModel(value = "图片视频上传返回对象")

public class StorageDataUploadVo {
    private BigDecimal fileId;
    private BigDecimal id;

    public BigDecimal getFileId() {
        return fileId;
    }

    public void setFileId(BigDecimal fileId) {
        this.fileId = fileId;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }
}
