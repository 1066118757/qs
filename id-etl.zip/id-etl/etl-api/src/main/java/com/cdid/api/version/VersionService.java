package com.cdid.api.version;

import com.cdid.api.version.vo.*;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;

import java.math.BigDecimal;
import java.util.List;

/**
 * @Author OZC
 * @CreateAt 2018/07/09
 */
public interface VersionService {
    /**
     * 添加版本信息
     *
     * @param versionAddVo
     * @return
     */
    ResultVo<Object> add(VersionAddVo versionAddVo,String  userId);

    /**
     * 更新版本信息
     * @param versionVo
     * @return
     */
    ResultVo<Object> update(VersionUpdateVo versionVo,String  userId);

    /**
     * 查询操作日志描述
     * @param id
     * @return
     */
    ResultVo<VersionDetailVo> detailById(BigDecimal id);

    /**
     * 获取当前启用版本信息
     * @return
     */
    ResultVo<VersionDetailVo> getCurrentInfo();

    /**
     * 删除操作日志描述
     * @param id
     * @return
     */
    ResultVo<Object> delete(BigDecimal id);


    /**
     * 操作日志列表查询
     * @param versionQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    ResultVo<PageVo<List<VersionListVo>>> list(VersionQueryVo versionQueryVo, String userId, Integer page, Integer size);
}
