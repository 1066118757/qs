package com.cdid.api.datastorage;

import com.cdid.api.datastorage.vo.*;
import com.cdid.api.metadata.item.vo.ItemListVo;
import com.cdid.api.metadata.item.vo.ItemQueryVo;
import com.cdid.api.metadata.theme.vo.ThemeListVo;
import com.cdid.api.metadata.themeitem.vo.ThemeItemDataStorageListVo;
import com.cdid.api.metadata.themeitem.vo.ThemeItemListVo;
import com.cdid.api.metadata.themeitem.vo.ThemeItemQueryVo;
import com.cdid.api.schedulelog.vo.ScheduleLogAddVo;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;
import org.apache.hadoop.yarn.webapp.hamlet.Hamlet;

import java.math.BigDecimal;
import java.util.List;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/13 11:03  
 */
public interface DataStorageService {

    /**
     * 逻辑分区列表
     * @param logicQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    ResultVo<PageVo<List<ThemeListVo>>> findLogicList(LogicQueryVo logicQueryVo,String userId, int page, int size);

    /**
     * 逻辑分区下的所有表
     * @param logicItemQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    ResultVo<PageVo<List<ItemListVo>>> findLogicItemList(LogicItemQueryVo logicItemQueryVo,String userId, int page, int size);

    ResultVo<Object> findListData(BigDecimal itemId, int page, int size);

    /**
     * 数据追加
     * @param additionalVo
     * @return
     */
    ResultVo<String> additional(AdditionalVo additionalVo);

    /**
     * 获取文件数据
     * @param redisKey
     * @return
     */
    ResultVo<List<List<String>>> findFileData(String redisKey);


    /**
     * 加载，分享
     * @param loadOrShareVo
     * @param userId
     * @return
     */
    ResultVo<String> loadOrShare(LoadOrShareVo loadOrShareVo,String userId) throws Exception;

    ResultVo<Boolean> executeSql(ExecuteSqlVo executeSqlVo);

    /**
     * 获取同步记录
     * @param redisKey
     * @return
     */
    ResultVo<ScheduleLogAddVo> getResult(String redisKey);
}
