package com.cdid.api.dataclear.cleartask.vo;


/**
 * @author OuZhiCheng
 * @create 创建时间：2017/12/13
 */
public class ClearTaskColVo {

    private String columnName;
    private String datatype;
    private Boolean nullable;

    public String getColumnName() {
        return columnName;
    }

    public void setColumnName(String columnName) {
        this.columnName = columnName;
    }

    public String getDatatype() {
        return datatype;
    }

    public void setDatatype(String datatype) {
        this.datatype = datatype;
    }

    public Boolean getNullable() {
        return nullable;
    }

    public void setNullable(Boolean nullable) {
        this.nullable = nullable;
    }
}
