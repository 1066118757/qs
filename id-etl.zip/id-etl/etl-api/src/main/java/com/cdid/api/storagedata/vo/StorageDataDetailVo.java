package com.cdid.api.storagedata.vo;


import io.swagger.annotations.ApiModel;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * @Author Froid_Li
 * @Email 269504518@qq.com
 * @Date 2017/11/25  22:27
 */
@ApiModel(value = "存储数据详情对象")
public class StorageDataDetailVo {

    private BigDecimal fileId;
    private String name;
    private String introduction;
    private String uploadUserId;
    private Timestamp uploadTime;
    private String filePath;
    private String uploadUserName;

    public String getUploadUserName() {
        return uploadUserName;
    }

    public void setUploadUserName(String uploadUserName) {
        this.uploadUserName = uploadUserName;
    }

    public BigDecimal getFileId() {
        return fileId;
    }

    public void setFileId(BigDecimal fileId) {
        this.fileId = fileId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getUploadUserId() {
        return uploadUserId;
    }

    public void setUploadUserId(String uploadUserId) {
        this.uploadUserId = uploadUserId;
    }

    public Timestamp getUploadTime() {
        return uploadTime;
    }

    public void setUploadTime(Timestamp uploadTime) {
        this.uploadTime = uploadTime;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
}
