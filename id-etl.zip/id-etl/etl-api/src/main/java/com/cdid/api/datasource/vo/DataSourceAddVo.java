package com.cdid.api.datasource.vo;

import com.cdid.api.jobconf.vo.JobConfAddVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import net.bytebuddy.agent.builder.AgentBuilder;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/02 15:01 
 */
@ApiModel("数据源添加对象")
public class DataSourceAddVo {

//    private BigDecimal id;
    /**
     * 名称
     */
    @ApiModelProperty(value="名称",example="数据源名称")
    private String name;
    /**
     * 描述
     */
    @ApiModelProperty(value="描述",example="数据源描述")
    private String remark;
    /**
     * 类型
     */
    @ApiModelProperty(value="类型 码表6",example="601")
    private Integer type;
    /**
     * 状态
     */
    @ApiModelProperty(value="状态 1：启用 2：禁用",example="1")
    private Integer state;
    /**
     * 最近连接日志
     */
    @ApiModelProperty(value="最近连接日志",example="最近连接日志")
    private String latestConnectLog;

    @ApiModelProperty(value="数据源配置")
    private List<JobConfAddVo> confs = new ArrayList<>();

    public List<JobConfAddVo> getConfs() {
        return confs;
    }

    public void setConfs(List<JobConfAddVo> confs) {
        this.confs = confs;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getLatestConnectLog() {
        return latestConnectLog;
    }

    public void setLatestConnectLog(String latestConnectLog) {
        this.latestConnectLog = latestConnectLog;
    }
}
