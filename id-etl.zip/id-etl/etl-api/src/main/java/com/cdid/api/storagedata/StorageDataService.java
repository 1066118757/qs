package com.cdid.api.storagedata;


import com.cdid.api.file.vo.FileUploadRespVo;
import com.cdid.api.file.vo.FileVo;
import com.cdid.api.storagedata.vo.*;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;

import java.math.BigDecimal;
import java.util.List;

/**
 * @Author Froid_Li
 * @Email 269504518@qq.com
 * @Date 2017/11/24  13:28
 */
public interface StorageDataService {
    /**
     * @param storageDataAddVo
     * @return
     */
    ResultVo<List<FileUploadRespVo>> add(StorageDataAddVo storageDataAddVo, List<FileVo> fileVoList)throws Exception;

    /**
     * @param id
     * @return
     */
    ResultVo<Object> delete(BigDecimal id)throws Exception ;

    /**
     * @param storageDataUpdateVo
     * @return
     */
    ResultVo<Object> update(StorageDataUpdateVo storageDataUpdateVo);

    /**
     * @param storageDataQueryVo
     * @param pageNo
     * @param pageSize
     * @return
     */
    ResultVo<PageVo<StorageDataListVo>> list(StorageDataQueryVo storageDataQueryVo, Integer pageNo, Integer pageSize);

    /**
     * @param id
     * @return
     */
    ResultVo<StorageDataDetailVo> detailById(BigDecimal id);
}
