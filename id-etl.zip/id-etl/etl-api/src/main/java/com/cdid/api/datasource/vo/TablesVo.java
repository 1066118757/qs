package com.cdid.api.datasource.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/02 15:01 
 */
@ApiModel("数据库表集合")
public class TablesVo {
    @ApiModelProperty(value="表名",example="连接的数据库表名")
    private String tableName;

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
}
