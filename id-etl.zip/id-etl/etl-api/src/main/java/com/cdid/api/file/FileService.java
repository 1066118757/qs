package com.cdid.api.file;


import com.cdid.api.file.vo.FileParseRespVo;
import com.cdid.api.file.vo.FileUploadRespVo;
import com.cdid.api.file.vo.FileVo;
import com.cdid.common.vo.ResultVo;

import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.util.List;

/**
 * @Author Froid_Li
 * @Email 269504518@qq.com
 * @Date 2017/11/28  15:42
 */
public interface FileService {
    /**
     * @param fileVoList
     * @return
     */
    ResultVo<List<FileParseRespVo>> parseFile(List<FileVo> fileVoList);


    /**
     * @param fileVoList
     * @return
     */
    ResultVo<List<FileUploadRespVo>> saveFile(List<FileVo> fileVoList) throws Exception;

    /**
     * @param fileId
     * @return
     * @throws Exception
     */
    ResultVo<FileVo> getFile(BigDecimal fileId) throws Exception;

    /**
     * @param fileId
     * @return
     * @throws Exception
     */
    ResultVo<String> deleteFile(BigDecimal fileId) throws Exception;

    void writeHdfsFileToOutputStream(String hdfsPath, OutputStream os) throws Exception;

    /**
     * @param filePath
     * @return
     */
    byte[] read(String filePath) throws IOException;

    String uploadToHDFS(String localFilePath) throws IOException;

    void uploadToHDFS(String localFilePath,String hdfsPath) throws IOException;

    boolean deleteFromHDFS(String hdfsPath);
}
