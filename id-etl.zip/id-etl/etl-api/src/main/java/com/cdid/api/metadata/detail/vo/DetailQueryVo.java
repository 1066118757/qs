package com.cdid.api.metadata.detail.vo;


import io.swagger.annotations.ApiModel;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/11/24
 */
@ApiModel(value = "存储元数据详情搜索条件对象")
public class DetailQueryVo {
    private BigDecimal metadataItemId;
    /*private String colDisplayname;
    private Integer colType;
    private String colComment;
    private String colName;
    private Integer state;
    private Timestamp auditTime;
    private Short status;
    private BigDecimal createUser;
    private Timestamp createTime;
    private BigDecimal updateUser;
    private Timestamp updateTime;*/

    public BigDecimal getMetadataItemId() {
        return metadataItemId;
    }

    public void setMetadataItemId(BigDecimal metadataItemId) {
        this.metadataItemId = metadataItemId;
    }
}
