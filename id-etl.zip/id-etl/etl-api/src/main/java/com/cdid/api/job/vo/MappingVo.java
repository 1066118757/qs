package com.cdid.api.job.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/28 17:19  
 */
@ApiModel("映射对象")
public class MappingVo {
    private String source;

    private String dist;

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDist() {
        return dist;
    }

    public void setDist(String dist) {
        this.dist = dist;
    }
}
