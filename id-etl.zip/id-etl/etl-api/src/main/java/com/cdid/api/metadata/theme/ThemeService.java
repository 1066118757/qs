package com.cdid.api.metadata.theme;

import com.cdid.api.metadata.theme.vo.*;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;

import java.math.BigDecimal;
import java.util.List;

/**
 *
 * @author OuZhiCheng
 * @create 创建时间：2017/11/24
 *
 * 元数据主题
 */
public interface ThemeService {
    /**
     * 元数据主题添加
     * @param themeAddVo
     * @param userId
     * @return
     */
    ResultVo<Object> add(ThemeAddVo themeAddVo, String userId);

    /**
     * 元数据主题更新
     * @param themeUpdateVo
     * @param userId
     * @return
     */
    ResultVo<Object> update(ThemeUpdateVo themeUpdateVo, String userId);

    /**
     * 元数据主题删除
     * @param id
     * @return
     */
    ResultVo<Object> delete(BigDecimal id);

    /**
     * 元数据主题查询
     * @param themeQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    ResultVo<PageVo<List<ThemeListVo>>> list(ThemeQueryVo themeQueryVo, String userId, Integer page, Integer size);

    /**
     * 元数据主题查询详情
     * @param id
     * @return
     */
    ResultVo<ThemeDetailVo> detailById(BigDecimal id);

    /**
     * 查询全部元数据主题信息
     * @param userId
     * @return
     */
    ResultVo<List<ThemeAllListVo>> listAlls(String from,String userId);

    /**
     * 查询逻辑分区列表
     * @return
     */
    ResultVo<List<ThemeMenuVo>> listMenu();
}
