package com.cdid.api.dict.vo;


/**
 * @Author Froid_Li
 * @Email 269504518@qq.com
 * @Date 2017/9/1  00:17
 */
public class DictValueVo {
    private Integer id;
    private String typeName;
    private Short key;
    private String value;
    private Integer mappingId;


    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Short getKey() {
        return key;
    }

    public void setKey(Short key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public Integer getMappingId() {
        return mappingId;
    }

    public void setMappingId(Integer mappingId) {
        this.mappingId = mappingId;
    }
}
