package com.cdid.api.jupyter.vo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class DependenceVO {

    private List<BigDecimal>  etlJobs=new ArrayList<>();

    private List<BigDecimal> clearJobs=new ArrayList<>();

    public List<BigDecimal> getClearJobs() {
        return clearJobs;
    }

    public void setClearJobs(List<BigDecimal> clearJobs) {
        this.clearJobs = clearJobs;
    }

    public List<BigDecimal> getEtlJobs() {
        return etlJobs;
    }

    public void setEtlJobs(List<BigDecimal> etlJobs) {
        this.etlJobs = etlJobs;
    }
}
