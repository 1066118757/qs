package com.cdid.api.common;


import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;

/**
 * Froid_Li
 * 2018/1/4  10:49
 */
public interface TokenService {

    String getUserId(HttpServletRequest request) throws Exception;

    public String getToken(HttpServletRequest request);
}
