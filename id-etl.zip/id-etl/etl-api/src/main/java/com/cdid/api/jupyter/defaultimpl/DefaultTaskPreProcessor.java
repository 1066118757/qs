package com.cdid.api.jupyter.defaultimpl;

import com.cdid.api.asynctask.vo.AsyncTaskConfigVo;
import com.cdid.api.jupyter.TaskPreProcessProcessor;
import com.cdid.api.jupyter.vo.TaskRequestVo;

public class DefaultTaskPreProcessor implements TaskPreProcessProcessor{

    @Override
    public void preProcess(AsyncTaskConfigVo configVo,boolean isHand) throws Exception {
    }
}
