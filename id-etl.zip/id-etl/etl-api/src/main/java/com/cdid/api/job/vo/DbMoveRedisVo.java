package com.cdid.api.job.vo;

import com.cdid.api.schedulelog.vo.ScheduleLogAddVo;

import java.math.BigDecimal;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/29 11:14  
 */
public class DbMoveRedisVo {
    private ScheduleLogAddVo scheduleLogAddVo;

    private int tableCount;

    private String srcTable;

    private String disTable;

    private BigDecimal dbMoveJobId;

    public ScheduleLogAddVo getScheduleLogAddVo() {
        return scheduleLogAddVo;
    }

    public void setScheduleLogAddVo(ScheduleLogAddVo scheduleLogAddVo) {
        this.scheduleLogAddVo = scheduleLogAddVo;
    }

    public String getSrcTable() {
        return srcTable;
    }

    public void setSrcTable(String srcTable) {
        this.srcTable = srcTable;
    }

    public String getDisTable() {
        return disTable;
    }

    public void setDisTable(String disTable) {
        this.disTable = disTable;
    }

    public BigDecimal getDbMoveJobId() {
        return dbMoveJobId;
    }

    public void setDbMoveJobId(BigDecimal dbMoveJobId) {
        this.dbMoveJobId = dbMoveJobId;
    }

    public int getTableCount() {
        return tableCount;
    }

    public void setTableCount(int tableCount) {
        this.tableCount = tableCount;
    }
}
