package com.cdid.api.dataclear.clearrule;

import com.cdid.api.dataclear.clearrule.vo.*;
import com.cdid.common.vo.PageVo;
import com.cdid.common.vo.ResultVo;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author OuZhiCheng
 */
public interface ClearRuleService {
    /**
     * 数据整理规则详情添加
     *
     * @param clearRuleAddVo
     * @param userId
     * @return
     */

    ResultVo<Object> add(ClearRuleAddVo clearRuleAddVo, String userId);

    /**
     * 数据整理规则详情更新
     *
     * @param clearRuleUpdateVo
     * @param userId
     * @return
     */
    ResultVo<Object> update(ClearRuleUpdateVo clearRuleUpdateVo, String userId);

    /**
     * 数据整理规则详情删除
     *
     * @param id
     * @return
     */
    ResultVo<Object> delete(BigDecimal id);

    /**
     * 数据整理规则详情查询
     *
     * @param clearRuleQueryVo
     * @param userId
     * @param page
     * @param size
     * @return
     */
    ResultVo<PageVo<List<ClearRuleListVo>>> list(ClearRuleQueryVo clearRuleQueryVo, String userId, Integer page, Integer size);

    /**
     * 数据整理规则详情查询详情
     *
     * @param id
     * @return
     */
    ResultVo<ClearRuleDetailVo> clearRuleById(BigDecimal id);
}
