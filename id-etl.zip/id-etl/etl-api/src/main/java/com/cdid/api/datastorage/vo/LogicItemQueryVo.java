package com.cdid.api.datastorage.vo;

import io.swagger.annotations.ApiModel;

import java.math.BigDecimal;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/13 11:42  
 */
@ApiModel("逻辑分区条目查询对象")
public class LogicItemQueryVo {

    private BigDecimal themeId;

    private String name;

    public BigDecimal getThemeId() {
        return themeId;
    }

    public void setThemeId(BigDecimal themeId) {
        this.themeId = themeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
