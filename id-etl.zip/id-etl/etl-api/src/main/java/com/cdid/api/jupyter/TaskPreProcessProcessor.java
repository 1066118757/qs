package com.cdid.api.jupyter;

import com.cdid.api.asynctask.vo.AsyncTaskConfigVo;
public interface TaskPreProcessProcessor {

    void preProcess(AsyncTaskConfigVo configVo,boolean isHand) throws Exception;
}
