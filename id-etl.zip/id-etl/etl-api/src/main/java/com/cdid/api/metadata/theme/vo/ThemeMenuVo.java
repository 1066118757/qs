package com.cdid.api.metadata.theme.vo;


import io.swagger.annotations.ApiModel;

import java.math.BigDecimal;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/11/24
 */
@ApiModel(value = "主题菜单对象")
public class ThemeMenuVo {
    private BigDecimal id;
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }
}
