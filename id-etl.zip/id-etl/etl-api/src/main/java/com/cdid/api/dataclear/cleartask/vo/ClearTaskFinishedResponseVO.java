package com.cdid.api.dataclear.cleartask.vo;

import java.util.ArrayList;
import java.util.List;

public class ClearTaskFinishedResponseVO {

    private String taskId;

    private String errorMsg;

    private String logId;

    List<ClearTaskColVo> tableStruct=new ArrayList<>();


    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public String getLogId() {
        return logId;
    }

    public void setLogId(String logId) {
        this.logId = logId;
    }

    public List<ClearTaskColVo> getTableStruct() {
        return tableStruct;
    }

    public void setTableStruct(List<ClearTaskColVo> tableStruct) {
        this.tableStruct = tableStruct;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }
}
