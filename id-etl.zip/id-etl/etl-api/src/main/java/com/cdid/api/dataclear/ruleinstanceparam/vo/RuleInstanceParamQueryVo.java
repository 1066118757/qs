package com.cdid.api.dataclear.ruleinstanceparam.vo;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/12/13
 */
@ApiModel(value = "规则实例化的参数查询对象")
public class RuleInstanceParamQueryVo {

    @ApiModelProperty(value="对应规则id",example="对应规则id")
    private BigDecimal clearRuleId;
    @ApiModelProperty(value="对应规则实例化id",example="对应规则实例化id")
    private BigDecimal ruleInstanceId;

    /*@ApiModelProperty(value="id",example="id")
    private BigDecimal id;
    @ApiModelProperty(value="参数名",example="参数名")
    private String name;
    @ApiModelProperty(value="参数类型 参考码表13",example="参数类型 参考码表13")
    private Integer type;
    @ApiModelProperty(value="参数获取类型 参考码表12",example="参数获取类型 参考码表12")
    private Integer getType;
    @ApiModelProperty(value="参数所在规则表达式位置",example="参数所在规则表达式位置")
    private String index;
    @ApiModelProperty(value="绑定列id",example="绑定列id")
    private BigDecimal bindColId;
    @ApiModelProperty(value="绑定值",example="绑定值")
    private String bindData;
    private Integer status;
    private Timestamp createTime;
    private BigDecimal createUser;
    private Timestamp updateTime;
    private BigDecimal updateUser;*/

    public BigDecimal getClearRuleId() {
        return clearRuleId;
    }

    public void setClearRuleId(BigDecimal clearRuleId) {
        this.clearRuleId = clearRuleId;
    }

    public BigDecimal getRuleInstanceId() {
        return ruleInstanceId;
    }

    public void setRuleInstanceId(BigDecimal ruleInstanceId) {
        this.ruleInstanceId = ruleInstanceId;
    }
}
