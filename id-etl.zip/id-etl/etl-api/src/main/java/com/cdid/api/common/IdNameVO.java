package com.cdid.api.common;

import java.math.BigDecimal;

public class IdNameVO {

    private BigDecimal id;

    private String name;

    public IdNameVO() {
    }

    public IdNameVO(BigDecimal id, String name) {
        this.id = id;
        this.name = name;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
