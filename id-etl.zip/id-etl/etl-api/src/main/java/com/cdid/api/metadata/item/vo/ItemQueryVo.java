package com.cdid.api.metadata.item.vo;


import io.swagger.annotations.ApiModel;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/11/24
 */
@ApiModel(value = "存储元数据条目搜索条件对象")
public class ItemQueryVo {
    private BigDecimal themeItemId;
    private String name;
    private Integer type;
    private Integer sourceType;

    public BigDecimal getThemeItemId() {
        return themeItemId;
    }

    public void setThemeItemId(BigDecimal themeItemId) {
        this.themeItemId = themeItemId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getSourceType() {
        return sourceType;
    }

    public void setSourceType(Integer sourceType) {
        this.sourceType = sourceType;
    }
}
