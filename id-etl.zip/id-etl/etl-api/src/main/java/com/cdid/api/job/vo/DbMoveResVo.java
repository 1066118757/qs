package com.cdid.api.job.vo;

import io.swagger.annotations.ApiModel;

import java.math.BigDecimal;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/29 16:49  
 */
@ApiModel("数据库迁移响应对象")
public class DbMoveResVo {
    public DbMoveResVo(){}
    public DbMoveResVo(BigDecimal jobId, int tableCount) {
        this.jobId = jobId;
        this.tableCount = tableCount;
    }

    private BigDecimal jobId;

    private int tableCount;

    public BigDecimal getJobId() {
        return jobId;
    }

    public void setJobId(BigDecimal jobId) {
        this.jobId = jobId;
    }

    public int getTableCount() {
        return tableCount;
    }

    public void setTableCount(int tableCount) {
        this.tableCount = tableCount;
    }
}
