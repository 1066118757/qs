package com.cdid.utils.cron;

import com.alibaba.fastjson.JSON;
import com.cdid.utils.cron.CronTab;
import com.cdid.utils.jdbc.ConfKey;
import com.cronutils.builder.CronBuilder;
import com.cronutils.model.CronType;
import com.cronutils.model.definition.CronDefinitionBuilder;
import com.cronutils.model.field.expression.QuestionMark;
import org.apache.commons.lang3.StringUtils;

import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import static com.cronutils.model.field.expression.FieldExpressionFactory.*;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/06 17:57 
 */
public class CronUtil {

    public static final String EVERY = "EVERY";

    /**
     * 根据时间戳获取定时的cron表达式
     *
     * @param time
     * @return
     * @throws Exception
     */
    public static String toCronString(long time) throws Exception {
//        21 31 14 8 12 ? 2017
        Date date = new Date(time);
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int year = cal.get(Calendar.YEAR);//获取年份
        int month = cal.get(Calendar.MONTH) + 1;//获取月份
        int day = cal.get(Calendar.DATE);//获取日
        int hour = cal.get(Calendar.HOUR_OF_DAY);//小时
        int minute = cal.get(Calendar.MINUTE);//分
        int second = cal.get(Calendar.SECOND);//秒
        CronTab cronTab = new CronTab(year, null, month, day, hour, minute, second);
        String cronString = CronUtil.toCronString(cronTab);
        return cronString;
    }

    public static String toCronString(CronTab crontab) throws Exception {
        //0 32 17 6 12 ? 2017
        Integer year = crontab.getYear();
        String yearType = crontab.getYearType();
        Integer week = crontab.getWeek();
        String weekType = crontab.getWeekType();
        Integer month = crontab.getMonth();
        String monthType = crontab.getMonthType();
        Integer day = crontab.getDay();
        String dayType = crontab.getDayType();
        Integer hour = crontab.getHour();
        String hourType = crontab.getHourType();
        Integer miunte = crontab.getMinute();
        String miunteType = crontab.getMinuteType();
        Integer second = crontab.getSecond();
        String secondType = crontab.getSecondType();
        CronBuilder cronBuilder = CronBuilder.cron(CronDefinitionBuilder.instanceDefinitionFor(CronType.QUARTZ));
        cronBuilder.withYear(year == null ? always() : EVERY.equals(yearType) ? every(year) : on(year));

        if(week == null) {
            cronBuilder.withDoW( QuestionMark.questionMark());
            cronBuilder.withMonth(month == null ? always() : EVERY.equals(monthType) ? every(month) : on(month));
            cronBuilder.withDoM(day == null ? always() : EVERY.equals(dayType) ? every(day) : on(day));
        }else if(week<=7 && week >= 1){
            cronBuilder.withDoW(on(getWeek(week)));
            cronBuilder.withMonth(always());
            cronBuilder.withDoM(QuestionMark.questionMark());
        }else {
            return null;
        }


        com.cronutils.model.Cron cron = cronBuilder
                .withHour(hour == null ? always() : EVERY.equals(hourType) ? every(hour) : on(hour))
                .withMinute(miunte == null ? always() : EVERY.equals(miunteType) ? every(miunte) : on(miunte))
                .withSecond(second == null ? always() : EVERY.equals(secondType) ? every(second) : on(second))
                .instance();
        // Obtain the string expression
        String cronAsString = cron.asString();
        return cronAsString;
    }

    public static int getWeek(int week){
        if(week < 7){
            return week + 1;
        }else {
            return 1;
        }
    }


    /**
     * 根据同步策略，time获取cron
     *
     * @param syncStrategy
     * @param confMap
     * @return
     * @throws Exception
     */
    public static String getCronString(Integer syncStrategy, Map<String,String> confMap) throws Exception {
        String cronString = null;
        String time = null;
        switch (syncStrategy) {
            case 1:
                //定时
                time = confMap.get(ConfKey.SYNCSTRATEGY_TIMING);
                long longTime = Long.parseLong(time);
                cronString = toCronString(longTime);
                break;
            case 2:
                //频率
                time = confMap.get(ConfKey.SYNCSTRATEGY_FREQUENCY);
                CronTab cronTab = JSON.parseObject(time, CronTab.class);
                cronString = toCronString(cronTab);
                break;
            default:
                break;
        }
        return cronString;
    }
    /**
     * 根据同步策略，time获取cron
     *
     * @param syncStrategy
     * @param time
     * @return
     * @throws Exception
     */
    public static String getCronString(Integer syncStrategy, String time) throws Exception {
        String cronString = null;
        switch (syncStrategy) {
            case 1:
                //定时
                long longTime = Long.parseLong(time);
                cronString = toCronString(longTime);
                break;
            case 2:
                //频率
                CronTab cronTab = JSON.parseObject(time, CronTab.class);
                cronString = toCronString(cronTab);
                break;
            default:
                break;
        }
        return cronString;
    }

}

