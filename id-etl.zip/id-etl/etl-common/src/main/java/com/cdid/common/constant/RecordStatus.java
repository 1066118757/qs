package com.cdid.common.constant;

public enum RecordStatus {

    Effective((short)1),Deleted((short)2);

    private short status;

    RecordStatus(short status) {
        this.status = status;
    }

    public short getStatus() {
        return status;
    }
}
