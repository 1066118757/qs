package com.cdid.common.dict;


public enum ScriptType {
    //java
    JAVA(901),
    //python
    PYTHON(902),
    //R
    R(903)
    ;

    private int value;
    ScriptType(int value) {
        this.value = value;
    }
    public int getValue() {
        return value;
    }
}
