package com.cdid.common.dict;


public enum ItemSourceType {
    //管理员
    MANAGER(1501),
    //数据清洗
    DATA_CLEAR(1502),
    //视图
    VIEW(1503),
    //中科院文献数据
    ISI(1504)
    ;

    private int value;
    ItemSourceType(int value) {
        this.value = value;
    }
    public int getValue() {
        return value;
    }
}
