package com.cdid.utils.jdbc;


/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/07 14:16 
 */
public final class ConfKey {
    public static final String DATABASE_NAME = "数据库名";
    public static final String SERVER_IP = "服务器";
    public static final String PORT = "端口号";
    public static final String USER_NAME = "用户名";
    public static final String USER_PWD = "密码";

    public static final String METADATA_TYPE = "表数据类型";

    public static final String REQUEST_METHOD = "请求方式";
    public static final String REQUEST_URL = "URL";
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String BODY = "body";
    public static final String DATAPATH = "dataPath";
    public static final String HEADERS = "headers";
    public static final String RESPCONTENTTYPE = "RespContentType";

    //同步策略
    public static final String SYNCSTRATEGY_TIMING = "定时";
    public static final String SYNCSTRATEGY_FREQUENCY = "频率";
    public static final String SOURCE_TABLE = "来源表";

    public static final String FIELD_MAPPING = "字段映射";

    //短信提醒
    public static final String SMS_REMINDING = "短信提醒";
    //邮箱提醒
    public static final String EMAIL_REMINDING = "邮箱提醒";

    public static final String DBMOVE_TABLE_COUNT = "dbmoveTableCount";
}
