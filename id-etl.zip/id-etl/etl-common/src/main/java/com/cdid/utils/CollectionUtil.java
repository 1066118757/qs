package com.cdid.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class CollectionUtil {

    public static String mkString(List<?> list, String separator){
        StringBuilder listStr=new StringBuilder();
        boolean isFirst=true;
        for(Object obj:list){
            if(obj!=null){
                if(!isFirst){
                    listStr.append(separator);
                }
                listStr.append(obj.toString());
                isFirst=false;
            }
        }
    return listStr.toString();
    }

    public static void main(String[] args) {
        List<Integer> list1=new ArrayList<>();
        list1.addAll(Arrays.asList(1,2,3,4));
        List<Integer> list12=list1.stream().filter(c -> c!=2).map(a -> a*2).collect(Collectors.toList());
        System.out.println(list12);
        List<Integer> list2=new ArrayList<>();
        list2.addAll(Arrays.asList(3,4,7,8));
        list1.removeAll(list2);
        //System.out.println(list1);
    }
}
