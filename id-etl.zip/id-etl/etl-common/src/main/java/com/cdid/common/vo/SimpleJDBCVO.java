package com.cdid.common.vo;

import com.cdid.config.PropertyUtil;

public class SimpleJDBCVO {

    private String driver;

    private String url;

    private String username;

    private String password;

    public SimpleJDBCVO() {
    }

    public SimpleJDBCVO(String driver, String password, String url, String username) {
        this.driver = driver;
        this.password = password;
        this.url = url;
        this.username = username;
    }

    public String getDriver() {
        return driver;
    }

    public void setDriver(String driver) {
        this.driver = driver;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public static SimpleJDBCVO getCurrentEnvHiveJDBCVO(){
        SimpleJDBCVO vo=new SimpleJDBCVO();
        String hiveIP=PropertyUtil.getMergedProperty("dist.ip");
        String hivePort=PropertyUtil.getMergedProperty("dist.port");
        String userName=PropertyUtil.getMergedProperty("dist.username");
        String password=PropertyUtil.getProperty("dist.password");
        String jdbcUrl="jdbc:hive2://"+hiveIP+":"+hivePort;
        vo.setDriver("org.apache.hive.jdbc.HiveDriver");
        vo.setUrl(jdbcUrl);
        vo.setUsername(userName);
        vo.setPassword(password);
        return vo;
    }
}
