package com.cdid.common.dict;


public enum DataSourceType {
    //mysql
    MYSQL(601),
    //oracle
    ORACLE(602),
    //sql server
    SQL_SERVER(603),
    //info bright
    INFO_BRIGHT(604),
    //postgre sql
    POSTGRE_SQL(605),
    HBASE(606),
    MONGODB(607),
    WEBSERVICE(608),
    EXCEL(609),
    TXT(610),
    CSV(611),
    XML(612),
    HIVE(613),
    ;

    private int value;
    DataSourceType(int value) {
        this.value = value;
    }
    public int getValue() {
        return value;
    }
}
