package com.cdid.common.dict;


public enum JobState {
    Running(1),Success(2),Fail(3);

    private int value;

    JobState(int value){
        this.value=value;
    }

    public int getValue() {
        return value;
    }
}
