package com.cdid.utils.excel.exceptions;

/**
 * author : Crab2Died</br>
 * date : 2017/5/24  10:28</br>
 */
public class TimeMatchFormatException extends Exception {
	
	private static final long serialVersionUID = 206910143412957809L;

	public TimeMatchFormatException(String message) {
        super(message);
    }

}
