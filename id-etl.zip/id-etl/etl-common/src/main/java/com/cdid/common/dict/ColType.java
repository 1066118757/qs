package com.cdid.common.dict;


public enum ColType {
    //文本
    TEXT(301),
    //数值
    NUMBER(302),
    ;

    private int value;
    ColType(int value) {
        this.value = value;
    }
    public int getValue() {
        return value;
    }
}
