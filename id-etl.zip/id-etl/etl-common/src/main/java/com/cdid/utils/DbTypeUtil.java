package com.cdid.utils;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/14 16:12  
 */
public class DbTypeUtil {

    public static String getDbByType(Integer type){

        switch (type){
            case 601: return "mysql";
            case 602: return "oracle";
            case 603: return "sqlserver";
            case 604: return "infobright";
            case 605: return "postgresql";
            case 606: return "hbase";
            case 607: return "mongodb";
            case 613: return "hive";
            default: return null;
        }
    }
    public static Integer getTypeByDb(String db){
        switch (db){
            case "mysql": return 601;
            case "oracle": return 602;
            case "sqlserver": return 603;
            case "infobright": return 604;
            case "postgresql": return 605;
            case "hbase": return 606;
            case "mongodb": return 607;
            case "hive": return 613;
            default: return null;
        }
    }
}
