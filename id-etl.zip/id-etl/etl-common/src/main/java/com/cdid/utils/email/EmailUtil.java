package com.cdid.utils.email;

import com.cdid.common.constant.ErrorCode;
import com.cdid.common.vo.ResultVo;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.UnsupportedEncodingException;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

/**
 * @Author Froid_Li
 * @Email 269504518@qq.com
 * @Date 2017/12/13  11:20
 */
@Component
public class EmailUtil {
    private static final String HOST = "smtp.163.com";
    private static final Integer PORT = 25;
    private static final String USERNAME = "jkzxdata@163.com";
    private static final String PASSWORD = "jkzx33445566";
//    private static final String PASSWORD = "jkzx123456";
    private static final String EMAILFORM = "jkzxdata@163.com";
    private static JavaMailSenderImpl mailSender = createMailSender();

    /**
     * 邮件发送器
     *
     * @return 配置好的工具
     */
    private static JavaMailSenderImpl createMailSender() {
        JavaMailSenderImpl sender = new JavaMailSenderImpl();
        sender.setHost(HOST);
        sender.setPort(PORT);
        sender.setUsername(USERNAME);
        sender.setPassword(PASSWORD);
        sender.setDefaultEncoding("Utf-8");
        Properties p = new Properties();
        p.setProperty("mail.smtp.timeout", "100000");
        p.setProperty("mail.smtp.auth", "true");
        p.setProperty("mail.smtp.starttls.enable", "true");
        sender.setJavaMailProperties(p);
        return sender;
    }

    /**
     * 发送邮件
     *
     * @param to      接受人
     * @param subject 主题
     * @param content 内容
     * @throws MessagingException           异常
     * @throws UnsupportedEncodingException 异常
     */
    public static ResultVo<String> sendHtmlMail(String to, String subject, String content) throws MessagingException, UnsupportedEncodingException {
        try {
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            // 设置utf-8或GBK编码，否则邮件会有乱码
            MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            messageHelper.setFrom(EMAILFORM, "1");
            messageHelper.setTo(to);
            messageHelper.setSubject(subject);
            messageHelper.setText(content, true);
            mailSender.send(mimeMessage);
            return new ResultVo<>(0, "success");

        } catch (Exception e) {
            e.printStackTrace();
            return new ResultVo<>(ErrorCode.UnknownError.getErrorCode(), "邮件发送失败");
        }
    }

    /**
     * 发送邮件
     *
     * @param mailMap 收件人与邮件内容集合
     * @throws MessagingException 异常
     */
    public static ResultVo<String> sendHtmlMail(Map<String, String> mailMap) throws MessagingException {
        try {
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            // 设置utf-8编码
            MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            messageHelper.setFrom(EMAILFORM);
            Iterator<String> iterator = mailMap.keySet().iterator();
            while (iterator.hasNext()) {
                messageHelper.setTo(iterator.next());
                //messageHelper.setSubject(subject);
                messageHelper.setText(mailMap.get(iterator.next()), true);
                mailSender.send(mimeMessage);
            }
            return new ResultVo<>(0, "success");

        } catch (Exception e) {
            return new ResultVo<>(ErrorCode.UnknownError.getErrorCode(), "邮件发送失败");
        }

    }
}