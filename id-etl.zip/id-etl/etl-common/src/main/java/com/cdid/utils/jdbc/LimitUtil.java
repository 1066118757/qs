package com.cdid.utils.jdbc;

/**
 * Oracle分页查询语句生成类 为ibatis实现分页设计
 *
 * @author qiulongjie
 *
 */
public class LimitUtil {

     public static String creatLimitSql(int page, int size, String querySql) {
         int offset = (page-1)*size;
         int max = page*size;
         String sql = "select * from (select t.*, ROWNUM RM from ( "+querySql+" ) t where ROWNUM<=" + max
                 + " ) where RM> " + offset;
         return sql;
     }
 }