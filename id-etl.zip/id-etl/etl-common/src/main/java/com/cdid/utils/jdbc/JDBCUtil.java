package com.cdid.utils.jdbc;

import com.cdid.common.constant.ErrorCode;
import com.cdid.common.dict.DataSourceType;
import com.cdid.common.vo.JDBCVo;
import com.cdid.common.vo.ResultVo;
import com.cdid.utils.StringUtil;
import org.apache.log4j.Logger;

import java.io.BufferedReader;
import java.io.Reader;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class JDBCUtil {

    private static final Logger logger=Logger.getLogger(JDBCUtil.class);


    private static Connection connection = null;
    /**
     * 数据库连接测试
     * @param jdbcVo
     * @return
     */
    public static ResultVo<Boolean> connectionTest(JDBCVo jdbcVo){
        //初始化连接为null
        Connection connectionTest = null;
        //连接是否成功的标识符，默认fasle
        Boolean flag=false;
        String msg = null;
        try{
            String userName = jdbcVo.getUserName();
            String password = jdbcVo.getPassword();
            //依据type获取不同驱动名以及url
            Map map = getDriverAndUrl(jdbcVo);
            String driver = (String)map.get("driver");
            String jdbcUrl = (String)map.get("jdbcUrl");
            //加载驱动
            Class.forName(driver);
            connectionTest = DriverManager.getConnection(jdbcUrl, userName, password);
            if (connectionTest!=null){
                flag=true;
                //关闭连接
                releaseConn(connectionTest,null,null);
            }
        }catch(Exception e){
            e.printStackTrace();
            String exceptionMsg = e.getMessage();
            if(exceptionMsg.contains("password")){
                msg = "用户名或密码错误";
            }else {
                msg = e.getMessage();
            }
        }
        Integer errcode = flag ? 0: ErrorCode.UnknownError.getErrorCode();
        return new ResultVo<>(errcode,flag,msg);
    }
    //获取数据库连接
    public static Connection getConnection(JDBCVo jdbcVo){
        try{
            String userName = jdbcVo.getUserName();
            String password = jdbcVo.getPassword();
            //依据type获取不同驱动名以及url
            Map map = getDriverAndUrl(jdbcVo);
            String driver = (String)map.get("driver");
            String jdbcUrl = (String)map.get("jdbcUrl");
            if (connection == null || connection.isClosed()){
                //加载驱动
                Class.forName(driver);
                connection = DriverManager.getConnection(jdbcUrl, userName, password);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return connection;
    }

    /*private static Connection getConnection(){
        try{
            if(connection == null || connection.isClosed()){
                connection = dataSource.getConnection();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return connection;
    }*/


    /**
     * 执行更新操作
     *
     * @param sql
     *            sql语句
     * @param params
     *            执行参数
     * @return 执行结果
     * @throws SQLException
     */
    public static boolean updateByPreparedStatement(String sql, List<?> params,JDBCVo jdbcVo)
            throws SQLException {
        boolean flag = false;
        int result = -1;// 表示当用户执行添加删除和修改的时候所影响数据库的行数
        Connection connection = null;
        PreparedStatement pstmt = null;

        try{
            connection = getConnection(jdbcVo);
            pstmt = connection.prepareStatement(sql);
            int index = 1;
            // 填充sql语句中的占位符
            if (params != null && !params.isEmpty()) {
                for (int i = 0; i < params.size(); i++) {
                    pstmt.setObject(index++, params.get(i));
                }
            }
            result = pstmt.executeUpdate();
            flag = result > 0 ? true : false;
        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            releaseConn(connection,pstmt,null);
        }
        return flag;
    }


    public static List<Map<String, Object>> findResult(String sql,JDBCVo jdbcVo){
        return findResult(sql, null,jdbcVo);
    }

    /**
     * 执行查询操作
     *
     * @param sql
     *            sql语句
     * @param params
     *            执行参数
     * @return
     * @throws SQLException
     */
    public static List<Map<String, Object>> findResult(String sql, List<?> params,JDBCVo jdbcVo) {
        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        int index = 1;
        Connection connection = null;
        PreparedStatement pstmt = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection(jdbcVo);
            pstmt = connection.prepareStatement(sql);
            if (params != null && !params.isEmpty()) {
                for (int i = 0; i < params.size(); i++) {
                    pstmt.setObject(index++, params.get(i));
                }
            }
            resultSet = pstmt.executeQuery();
            ResultSetMetaData metaData = resultSet.getMetaData();
            int cols_len = metaData.getColumnCount();
            while (resultSet.next()) {
                Map<String, Object> map = new HashMap<String, Object>();
                for (int i = 0; i < cols_len; i++) {
                    String cols_name = metaData.getColumnName(i + 1);
                    Object cols_value;
                    if (cols_name.equals("PROJECT_DETAIL")){
                        Clob clob = resultSet.getClob(cols_name);
                        cols_value = ClobToString(clob);
                    }else {
                        cols_value = resultSet.getObject(cols_name);
                    }
                    if (cols_value == null) {
                        cols_value = "";
                    }
                    //对PROJECT_DETAIL clob类型进行处理
                   /*if (cols_name.equals("PROJECT_DETAIL")){
                        cols_value = ClobToString((Clob) cols_value);
                   }*/
                    map.put(cols_name, cols_value);
                }
                list.add(map);
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            releaseConn(connection,pstmt,resultSet);
        }
        return list;
    }

    /**
     * 释放资源
     */
    public static void releaseConn(Connection connection,Statement pstmt,ResultSet resultSet) {
        if (resultSet != null) {
            try {
                resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (pstmt != null) {
            try {
                pstmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }


    /**
     * 将字Clob转成String类型
     * @param sc
     * @return
     * @throws Exception
     */
    public static String ClobToString(Clob sc) throws Exception {
        if (sc==null){
            return null;
        }
        String reString = "";
        Reader is = sc.getCharacterStream();// 得到流
        BufferedReader br = new BufferedReader(is);
        String s = br.readLine();
        StringBuffer sb = new StringBuffer();
        while (s != null) {// 执行循环将字符串全部取出付值给StringBuffer由StringBuffer转成STRING
            sb.append(s);
            s = br.readLine();
        }
        reString = sb.toString();
        return reString;
    }

    public static Map getDriverAndUrl(JDBCVo jdbcVo){
        String driver=null;
        String jdbcUrl=null;
        Integer type = jdbcVo.getType();
        String databaseName = jdbcVo.getDatabaseName();
        String port = jdbcVo.getPort();
        String url = jdbcVo.getUrl();
        //mysql--infobright
        if (type==DataSourceType.MYSQL.getValue()
                ||type==DataSourceType.INFO_BRIGHT.getValue()){
            driver="com.mysql.jdbc.Driver";
            jdbcUrl="jdbc:mysql://"+url+":"+port+"/"+databaseName;
        }
        //oracle
        if (type==DataSourceType.ORACLE.getValue()){
            driver="oracle.jdbc.OracleDriver";
            jdbcUrl="jdbc:oracle:thin:@"+url+":"+port+":"+databaseName;
        }
        //postgres sql
        if (type==DataSourceType.POSTGRE_SQL.getValue()){
            driver="org.postgresql.Driver";
            jdbcUrl="jdbc:postgresql://"+url+":"+port+"/"+databaseName;
        }
        //sqlServer
        if (type==DataSourceType.SQL_SERVER.getValue()){
            driver="com.microsoft.sqlserver.jdbc.SQLServerDriver";
            jdbcUrl="jdbc:sqlserver://"+url+":"+port+";DatabaseName="+databaseName;
        }
        //hive
        if (type==DataSourceType.HIVE.getValue()){
            driver="org.apache.hive.jdbc.HiveDriver";
            //bc:hive://ip:10000/default
            jdbcUrl="jdbc:hive2://"+url+":"+port+"/"+databaseName;
        }
        //mongodb
        if (type==DataSourceType.MONGODB.getValue()){
            driver="mongodb.jdbc.MongoDriver";
            //jdbc:mongo://ds029847.mongolab.com:29847/tpch
            jdbcUrl="jdbc:mongo://"+url+":"+port+"/"+databaseName;
        }
        //habse
        if (type==DataSourceType.HBASE.getValue()){
            driver="org.apache.phoenix.jdbc.PhoenixDriver";
            //"jdbc:phoenix:master:2181"
            jdbcUrl="jdbc:phoenix:"+url+":"+port+"/"+databaseName;
            if(StringUtil.isEmpty(databaseName)){
                jdbcUrl="jdbc:phoenix:"+url+":"+port;
            }
        }
        Map map=new HashMap();
        map.put("driver",driver);
        map.put("jdbcUrl",jdbcUrl);
        return map;
    }

    public static  Connection getConnection(String driverClass,String jdbcUrl,String userName,String password){
        try{
            if (connection == null || connection.isClosed()){
                Class.forName(driverClass);
                if(jdbcUrl.contains("phoenix")){
                    connection=DriverManager.getConnection(jdbcUrl);
                }
                connection = DriverManager.getConnection(jdbcUrl, userName, password);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return connection;
    }

    public static  void executeUpdate(String sql,String driverClass,String jdbcUrl,String userName,String password) throws SQLException {
        Connection connection=null;
        Statement stmt=null;
        try{
            connection=getConnection(driverClass,jdbcUrl,userName,password);
            stmt=connection.createStatement();
            stmt.executeUpdate(sql);
        }finally {
            releaseConn(connection,stmt,null);
        }
    }

    public static void executeBatch(List<String> sqls,String driverClass,String jdbcUrl,String userName,String password ) {
        Connection connection=null;
        Statement stmt=null;
        try {
            connection = getConnection(driverClass, jdbcUrl, userName, password);
            stmt = connection.createStatement();
            for (String sql : sqls) {
                try {
                    stmt.execute(sql);
                } catch (SQLException e) {
                    e.printStackTrace();
                    logger.error(e.getMessage(), e);
                }
            }
        }catch(Exception e){
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }finally {
            releaseConn(connection,stmt,null);
        }
    }
}
