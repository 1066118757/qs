package com.cdid.common.dict.dicttype;

/**
 * Created by wx on 2017/8/30.
 */
public enum DictType {

    COL_TYPE(3),//列类型
    DATASOURCE_TYPE(6),//数据源类型
    CONF_TYPE(7),//数据源类型
    RULE_TYPE(8),//规则类型
    SCRIPT_TYPE(9),//脚本类型
    TASK_RESULT(10),//任务执行结果
    CLEAR_TYPE(11),//整合任务执行方式
    ITEM_SOURCE_TYPE(15),//条目来源类型
    ;

    private int value;
    DictType(int value) {
        this.value = value;
    }
    public int getValue() {
        return value;
    }

}
