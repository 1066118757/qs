package com.cdid.common.dict;


public enum ConfType {
    //数据源配置
    DATASOURCE(701),
    //引接任务配置
    JOB(702),
    //消息提醒机制
    MESSAGE(703),
    //字段映射
    FIELD(704)
    ;

    private int value;
    ConfType(int value) {
        this.value = value;
    }
    public int getValue() {
        return value;
    }
}
