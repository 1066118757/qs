package com.cdid.common.dict;


public enum TaskResult {
    //执行中
    RUNNING(1001),
    //成功
    SUCCESS(1002),
    //失败
    FAIL(1003),
    //未执行
    NO_EXECUTE(1004),
    //正在提交
    SUBMITING(1005),
    //已提交
    SUBMITED(1006)
    ;

    private int value;
    TaskResult(int value) {
        this.value = value;
    }
    public int getValue() {
        return value;
    }
}
