package com.cdid.common.dict;


public enum ClearType {
    //定时任务
    CRONTAB(1101)
    ;

    private int value;
    ClearType(int value) {
        this.value = value;
    }
    public int getValue() {
        return value;
    }
}
