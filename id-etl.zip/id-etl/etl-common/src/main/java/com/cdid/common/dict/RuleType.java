package com.cdid.common.dict;


public enum RuleType {
    //更新值
    UPDATE_VALUES(801),
    //数据清洗
    DATA_CLEAR(802),
    //数据筛选
    DATA_FILTER(803),
    //列操作
    COL_HAND(804),
    //其他
    OTHER(805),
    //自定义
    USER_DEFINED(806),
    ;

    private int value;
    RuleType(int value) {
        this.value = value;
    }
    public int getValue() {
        return value;
    }
}
