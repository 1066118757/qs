package com.cdid.utils;


import com.cdid.utils.csv.util.ExportCSV;
import com.cdid.utils.csv.util.ImportCSV;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;



public class CsvUtils {


    /*----------------------------------------读取CSV操作基于Map映射---------------------------------------------*/
    /*  一. 操作流程 ：                                                                                          */
    /*      1) 读取表头信息,与给出的Map映射匹配                                                                   */
    /*      2) 读取表头下面的数据内容, 按行读取, 并映射至java对象                                                   */
    /*  二. 参数说明                                                                                             */
    /*      *) csvPath          =>      目标CSV路径                                                              */
    /*      *) beanClass        =>      java映射对象类                                                           */
    /*      *) fieldDelimiter   =>      CSV文件分隔符                                                            */
    /*      *) columnMapping    =>      Map映射                                                                 */
    public <T> List<T> readCsv2Objects(String csvPath, char fieldDelimiter, Class<T> beanClass,
                                       Map<String, String> columnMapping) {
        List<T> result = new ArrayList<>();
        try {
            result = ImportCSV.parseCsvFileToBeans(csvPath, fieldDelimiter, beanClass, columnMapping);
            return result;
        } catch (Exception e) {
            System.out.print(e.getMessage());
            return result;
        }

    }

    /*----------------------------------------基于模板、注解导出CSV-----------------------------------------------*/
    /*  一. 操作流程 ：                                                                                          */
    /*      1) 初始化模板                                                                                        */
    /*      2) 读取映射                                                                                          */
    /*      3) 写入数据                                                                                          */
    /*  二. 参数说明                                                                                             */
    /*      *) csvFilePath      =>      写入CSV路径                                                              */
    /*      *) beans            =>      java映射对象类                                                           */

    public <T> void writeObjects2Csv(String csvFilePath, List<T> beans) {
        try {
            ExportCSV.writeBeanToCsvFile(csvFilePath, beans);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public <T> void writeObjects2Csv(String csvFilePath, List<T> beans, String charset) {
        try {
            ExportCSV.writeBeanToCsvFile(csvFilePath, beans, charset);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * 解析csv文件 到一个list中 每个单元个为一个String类型记录，每一行为一个list。 再将所有的行放到一个总list中
     * @param filePath 文件路径
     * @param fieldDelimiter 每行的每列分割符
     * @param startLine 开始行
     * @return
     * @throws IOException
     */
    public List<List<String>> readCSVFile(String filePath,String fieldDelimiter,Integer startLine,String charset) throws IOException {
       return readCSVFile(new FileInputStream(filePath),fieldDelimiter,startLine,charset);
    }

    public List<List<String>> readCSVFile(InputStream is, String fieldDelimiter, Integer startLine,String charset) throws IOException {
        InputStreamReader fr = null;
        BufferedReader br = null;
        fr = new InputStreamReader(is,charset);
        br = new BufferedReader(fr);
        String rec = null;// 一行
        String str;// 一个单元格
        List<List<String>> listFile = new ArrayList<List<String>>();
        try {
            //行数计数
            int lineNo=0;
            //列数基准
            int baseNo=0;
            //非法数据数
            int count=0;
            // 读取一行
            while ((rec = br.readLine()) != null) {
                //自增1
//                lineNo++;
                //当到达起始位置，开始取值
                if (lineNo>=startLine){
                    //依据fieldDelimiter分割
                    String[] split = rec.split(fieldDelimiter);
                    //将起始行的列数作为基准，接下来的数量只要不等于起始行列数，认定为非法数据，不读取
                    if (lineNo==startLine){
                        baseNo=split.length;
                    }
                    //只有列数与基准相等的数据认定为有效数据
                    List<String> cells = Arrays.asList(split);
                    if (baseNo==split.length){
                        listFile.add(cells);
                    }else {
                        List<String> cells_ = new ArrayList<>();
                        cells_.addAll(cells);

                        for(int i = split.length ; i<baseNo;i++){
                            cells_.add("");
                        }
                        listFile.add(cells_);

                        count++;
                    }
                }
                //自增1
                lineNo++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (fr != null) {
                fr.close();
            }
            if (br != null) {
                br.close();
            }
        }
        return listFile;
    }


}
