package com.cdid.common.vo;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/21 11:55  
 */
public class ResponseVo {

    private String contentType;

    private String data;

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
