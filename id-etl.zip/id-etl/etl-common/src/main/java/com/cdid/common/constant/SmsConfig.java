package com.cdid.common.constant;


/**
 * @Author Froid_Li
 * @Email 269504518@qq.com
 * @Date 2017/12/12  15:31
 */
public class SmsConfig {
    // 账号appid
    public static final Integer APPID = 1400054758;

    //账号appkey
    public static final String APPKEY = "b0286609b3a1ccd4ceb15cdf70d727e0";

    //模板ID
    public static final Integer VERIFYTMPLID = 65719;

    public static final Integer jOBTMPID = 78458;
    public static final Integer ETLJOBTMPID = 78459;


    public static final Integer CACHEEXPIRETIME = 60;
}
