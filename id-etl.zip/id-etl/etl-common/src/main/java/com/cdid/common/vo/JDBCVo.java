package com.cdid.common.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.util.Map;

@ApiModel("JDBC连接属性")
public class JDBCVo{
    @ApiModelProperty(value="数据源Id",example="数据源名Id")
    private BigDecimal dataSourceId;
    //数据源名
    @ApiModelProperty(value="数据源名",example="数据源名")
    private String dataSourceName;
    //数据库名
    @ApiModelProperty(value="数据库名",example="数据库名")
    private String databaseName;
    //数据库地址
    @ApiModelProperty(value="数据库地址",example="数据库地址")
    private String url;
    //用户名
    @ApiModelProperty(value="用户名",example="用户名")
    private String userName;
    //密码
    @ApiModelProperty(value="密码",example="密码")
    private String password;
    //端口号
    @ApiModelProperty(value="端口号",example="端口号")
    private String port;
    //数据库类型
    @ApiModelProperty(value="数据库类型",example="数据库类型")
    private Integer type;
    //数据库表名
    @ApiModelProperty(value="数据库表名",example="数据库表名")
    private String tableName;


    @ApiModelProperty(value="webservice请求方式",example="get")
    private String requestMethod;
    @ApiModelProperty(value="webservice请求地址",example="http://baidu.com")
    private String requestUrl;
//    @ApiModelProperty(value="webservice  Content-Type",example="application/json")
//
//    private String contentType;
    @ApiModelProperty(value="webservice  hearder")
    private String headers;
    @ApiModelProperty(value="webservice请求参数",example="json格式")
    private String body;

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getDataSourceName() {
        return dataSourceName;
    }

    public void setDataSourceName(String dataSourceName) {
        this.dataSourceName = dataSourceName;
    }

    public String getDatabaseName() {
        return databaseName;
    }

    public void setDatabaseName(String databaseName) {
        this.databaseName = databaseName;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public BigDecimal getDataSourceId() {
        return dataSourceId;
    }

    public void setDataSourceId(BigDecimal dataSourceId) {
        this.dataSourceId = dataSourceId;
    }

    public String getRequestMethod() {
        return requestMethod;
    }

    public void setRequestMethod(String requestMethod) {
        this.requestMethod = requestMethod;
    }

    public String getRequestUrl() {
        return requestUrl;
    }

    public void setRequestUrl(String requestUrl) {
        this.requestUrl = requestUrl;
    }

//    public String getContentType() {
//        return contentType;
//    }
//
//    public void setContentType(String contentType) {
//        this.contentType = contentType;
//    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getHeaders() {
        return headers;
    }

    public void setHeaders(String headers) {
        this.headers = headers;
    }
}
