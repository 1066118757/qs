package com.cdid.dao.oozie;

import com.cdid.common.vo.PageVo;
import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.Group;
import com.cdid.jooq.tables.MGroupUser;
import com.cdid.jooq.tables.records.GroupRecord;
import com.cdid.jooq.tables.records.MGroupUserRecord;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.jooq.Record2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

@Repository
public class GroupUserDao extends BaseDaoImpl<MGroupUserRecord,BigDecimal> {

    @Autowired
    DSLContext dsl;
    @Override
    public Configuration getConfiguration() {
         return dsl.configuration();
    }

    public GroupUserDao() {
        super(MGroupUser.M_GROUP_USER);
    }

}
