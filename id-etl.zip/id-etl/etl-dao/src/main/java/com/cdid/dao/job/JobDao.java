package com.cdid.dao.job;


import com.cdid.common.constant.RecordStatus;
import com.cdid.common.dict.DataSourceType;
import com.cdid.common.dict.JobState;
import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.records.TJobRecord;
import com.cdid.utils.StringUtil;
import org.jooq.*;
import org.jooq.impl.DSL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.*;

import static com.cdid.jooq.tables.TDataSource.T_DATA_SOURCE;
import static com.cdid.jooq.tables.TJob.T_JOB;
import static com.cdid.jooq.tables.TJobConf.T_JOB_CONF;
import static com.cdid.jooq.tables.TScheduleLog.T_SCHEDULE_LOG;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/02 14:49 
 */
@Repository
public class JobDao extends BaseDaoImpl<TJobRecord, BigDecimal> {
    @Autowired
    DSLContext dsl;

    public JobDao() {
        super(T_JOB);
    }

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }

    public void updateStatus(BigDecimal id,String userId,Short status){

        dsl.update(T_JOB)
                .set(T_JOB.STATUS, status)
                .set(T_JOB.UPDATE_TIME, new Timestamp(System.currentTimeMillis()))
                .set(T_JOB.UPDATE_USER, userId)
                .where(T_JOB.ID.eq(id)).execute();
    }

    public Integer getDataSourceType(BigDecimal id){
        Integer type = dsl.select(T_DATA_SOURCE.TYPE).from(T_JOB).innerJoin(T_DATA_SOURCE).on(T_DATA_SOURCE.ID.eq(T_JOB.DATA_SOURCE_ID)).where(T_JOB.ID.eq(id)).fetchAny().value1();
        return type;
    }

    public PageVo<Record10<Timestamp, Timestamp, String, Integer, Long, String, BigDecimal, String, Integer, String>> statisticsList(List<Condition> conditions, OffsetPagingVo offsetPagingVo, Collection<SortField<?>> sortFields){
        Result<Record10<Timestamp, Timestamp, String, Integer, Long, String, BigDecimal, String, Integer, String>> fetch = dsl.select(
                T_SCHEDULE_LOG.SCHEDULE_STARTTIME.as("startLogTime"),
                T_SCHEDULE_LOG.SCHEDULE_ENDTIME.as("endLogTime"),
                T_SCHEDULE_LOG.SCHEDULE_LOG.as("scheduleLog"),
                T_SCHEDULE_LOG.SCHEDULE_STATE.as("scheduleState"),
                T_SCHEDULE_LOG.SUCCESS_ROWS.as("successRows"),
                T_JOB.NAME.as("jobName"),
                T_JOB.ID.as("jobId"),
                T_JOB.CREATE_USER.as("createUser"),
                T_JOB.STATE.as("state"),
                T_DATA_SOURCE.NAME.as("dataSourceName")
        ).from(T_SCHEDULE_LOG)
                .leftJoin(T_JOB).on(T_JOB.ID.eq(T_SCHEDULE_LOG.JOB_ID))
                .leftJoin(T_DATA_SOURCE).on(T_DATA_SOURCE.ID.eq(T_JOB.DATA_SOURCE_ID))
                .where(conditions)
                .orderBy(sortFields)
                .limit(offsetPagingVo.getOffset(), offsetPagingVo.getSize())
                .fetch();

        Integer totalCount = dsl.selectCount().from(T_SCHEDULE_LOG)
                .leftJoin(T_JOB).on(T_JOB.ID.eq(T_SCHEDULE_LOG.JOB_ID))
                .leftJoin(T_DATA_SOURCE).on(T_DATA_SOURCE.ID.eq(T_JOB.DATA_SOURCE_ID))
                .where(conditions).fetchAny().value1();

        PageVo<Record10<Timestamp, Timestamp, String, Integer, Long, String, BigDecimal, String, Integer, String>> pageVo = new PageVo<>();
        pageVo.setPageData(fetch);
        pageVo.setTotalCount(totalCount);
        return pageVo;
    }

    public Map<String,Object> statisticsInfo(List<Condition> conditions){


        Record5<Integer, BigDecimal, BigDecimal, BigDecimal, BigDecimal> record5 = dsl.select(
                T_SCHEDULE_LOG.ID.count().as("totalTime"),
                DSL.when(T_SCHEDULE_LOG.SCHEDULE_STATE.eq(JobState.Success.getValue()), 1).otherwise(0).sum().as("successTime"),
                DSL.when(T_SCHEDULE_LOG.SCHEDULE_STATE.eq(JobState.Fail.getValue()), 1).otherwise(0).sum().as("failTime"),
                DSL.when(T_SCHEDULE_LOG.SCHEDULE_STATE.eq(JobState.Running.getValue()), 1).otherwise(0).sum().as("runningTime"),
                T_SCHEDULE_LOG.SUCCESS_ROWS.sum().as("totalDataCount")
        ).from(T_SCHEDULE_LOG)
                .leftJoin(T_JOB).on(T_JOB.ID.eq(T_SCHEDULE_LOG.JOB_ID))
                .leftJoin(T_DATA_SOURCE).on(T_DATA_SOURCE.ID.eq(T_JOB.DATA_SOURCE_ID))
                .where(conditions).fetchAny();


        Map<String,Object> data = new HashMap<>();
        data.put("totalTime",record5.value1() == null ? Integer.valueOf(0) : record5.value1());
        data.put("successTime",record5.value2() == null ? BigDecimal.ZERO : record5.value2());
        data.put("failTime",record5.value3() == null ? BigDecimal.ZERO : record5.value3());
        data.put("runningTime",record5.value4() == null ? BigDecimal.ZERO : record5.value4());
        data.put("totalDataCount",record5.value5() == null ? BigDecimal.ZERO : record5.value5());
        return data;
    }

    public  Map<BigDecimal, Result<Record>> findAllConfig(BigDecimal jobId){
        short status = RecordStatus.Effective.getStatus();
        Integer state = 1;
        List<Condition> conditions = new ArrayList<>();
        if(jobId != null){
            conditions.add(T_JOB.ID.eq(jobId));
        }
        conditions.add(T_JOB.STATUS.eq(status));
        conditions.add(T_JOB.STATE.eq(state));
        conditions.add(T_JOB_CONF.STATUS.eq(status));
        conditions.add(T_DATA_SOURCE.STATUS.eq(status));
        conditions.add(T_DATA_SOURCE.STATE.eq(state));
        Map<BigDecimal, Result<Record>> bigDecimalResultMap = dsl.select().from(T_DATA_SOURCE)
                .innerJoin(T_JOB).on(T_JOB.DATA_SOURCE_ID.eq(T_DATA_SOURCE.ID))
                .leftJoin(T_JOB_CONF).on(T_JOB_CONF.REF_ID.eq(T_JOB.ID)).or(T_JOB_CONF.REF_ID.eq(T_DATA_SOURCE.ID))
                .where(conditions)
                .fetchGroups(T_JOB.ID);
        return bigDecimalResultMap;
    }
    public Result<Record2<BigDecimal, Integer>> findAll(){
        short status = RecordStatus.Effective.getStatus();
        Integer state = 1;
        List<Condition> conditions = new ArrayList<>();
        conditions.add(T_JOB.STATUS.eq(status));
        conditions.add(T_JOB.STATE.eq(state));
        conditions.add(T_JOB.SYNC_STRATEGY.eq(2).or(T_JOB.SYNC_STRATEGY.eq(1).and(T_JOB.LATEST_SCHEDULE_TIME.isNull())));
        conditions.add(T_DATA_SOURCE.STATUS.eq(status));
        conditions.add(T_DATA_SOURCE.STATE.eq(state));
        //过滤掉文件数据源的任务
        conditions.add(T_DATA_SOURCE.TYPE.notIn(
                DataSourceType.CSV.getValue(),
                DataSourceType.EXCEL.getValue(),
                DataSourceType.TXT.getValue(),
                DataSourceType.XML.getValue()));
        ResultQuery<Record2<BigDecimal, Integer>> query=dsl.select(T_JOB.ID.as("jobId"), T_DATA_SOURCE.TYPE.as("dbType")).from(T_JOB).innerJoin(T_DATA_SOURCE).on(T_JOB.DATA_SOURCE_ID.eq(T_DATA_SOURCE.ID))
                .where(conditions);
        System.out.println(query.getSQL());
        return query.fetch();
    }

    public List<Record2<BigDecimal,String>> findIdNameByIds(Collection<BigDecimal> idList){
       return dsl.select(T_JOB.ID,T_JOB.NAME).from(T_JOB).where(T_JOB.ID.in(idList)).fetch();
    }

    public List<Record2<BigDecimal,String>> findSelectableDependenceJob(String name){
        List<Condition> conditionList=new ArrayList<>();
        if(StringUtil.isNotEmpty(name)){
            conditionList.add(T_JOB.NAME.like("%"+name+"%"));
        }
        conditionList.add(T_JOB.ID.in(dsl.select(T_JOB_CONF.REF_ID).from(T_JOB_CONF).where(T_JOB_CONF.KEY.eq("频率"),T_JOB_CONF.VALUE.like("%\"day\":1%"))));
        return dsl.select(T_JOB.ID,T_JOB.NAME).from(T_JOB).where(conditionList).fetch();
    }
}
