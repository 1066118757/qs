package com.cdid.dao.oozie;


import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.TOozieJob;
import com.cdid.jooq.tables.Users;
import com.cdid.jooq.tables.records.TOozieJobRecord;
import org.jooq.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public class OozieJobDao extends BaseDaoImpl<TOozieJobRecord,BigDecimal> {

    @Autowired
    private DSLContext dsl;

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }

    public OozieJobDao() {
        super(TOozieJob.T_OOZIE_JOB);
    }

    public List<Record2<String,Integer>> statisticsByStatus(List<Condition> conditionList){
        return dsl.select(TOozieJob.T_OOZIE_JOB.LATEST_STATUS,TOozieJob.T_OOZIE_JOB.ID.count())
                .from(TOozieJob.T_OOZIE_JOB)
                .where(conditionList).groupBy(TOozieJob.T_OOZIE_JOB.LATEST_STATUS).fetch();
    }

    public List<Record3<String,String,Integer>> statisticsByCreateUser(List<Condition> conditionList){
        return dsl.select(TOozieJob.T_OOZIE_JOB.CREATE_USER,Users.USERS.FIRST_NAME,TOozieJob.T_OOZIE_JOB.ID.count())
                .from(TOozieJob.T_OOZIE_JOB)
                .innerJoin(Users.USERS).on(Users.USERS.GUID.eq(TOozieJob.T_OOZIE_JOB.CREATE_USER))
                .where(conditionList).groupBy(TOozieJob.T_OOZIE_JOB.CREATE_USER,Users.USERS.FIRST_NAME).fetch();
    }

}
