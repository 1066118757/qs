package com.cdid.dao.jobconf;


import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.records.TJobConfRecord;
import org.jooq.Condition;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.jooq.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static com.cdid.jooq.tables.TJobConf.T_JOB_CONF;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/02 14:49 
 */
@Repository
public class JobConfDao extends BaseDaoImpl<TJobConfRecord, BigDecimal> {
    @Autowired
    DSLContext dsl;

    public JobConfDao() {
        super(T_JOB_CONF);
    }

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }

    public void deleteByRefId(BigDecimal refId){
        dsl.deleteFrom(T_JOB_CONF).where(T_JOB_CONF.REF_ID.eq(refId)).execute();
    }

    public Result<TJobConfRecord> findByRefId(BigDecimal refId,Integer ... type){
        List<Condition> conditions = new ArrayList<>();
        conditions.add(T_JOB_CONF.REF_ID.eq(refId));
        if(type != null && type.length > 0){
            conditions.add(T_JOB_CONF.TYPE.in(type));
        }
        Result<TJobConfRecord> records = dsl.selectFrom(T_JOB_CONF).where(conditions).fetch();
        return records;
    }
}
