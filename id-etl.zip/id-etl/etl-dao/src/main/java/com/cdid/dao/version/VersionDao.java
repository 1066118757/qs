package com.cdid.dao.version;

import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.TVersion;
import com.cdid.jooq.tables.records.TVersionRecord;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

/**
 * @Author OZC
 * @CreateAt 2018/07/09
 */

@Repository
public class VersionDao extends BaseDaoImpl<TVersionRecord, BigDecimal> {
    @Autowired
    private DSLContext dsl;

    @Override
    public Configuration getConfiguration() { return dsl.configuration(); }

    public VersionDao() {
        super(TVersion.T_VERSION);
    }

    /**
     * 修改除id外的其他记录state为0
     * @param id
     */
    public void changeState(BigDecimal id){
        dsl.update(TVersion.T_VERSION).set(TVersion.T_VERSION.STATE,0).where(TVersion.T_VERSION.ID.notEqual(id)).execute();
    }
}
