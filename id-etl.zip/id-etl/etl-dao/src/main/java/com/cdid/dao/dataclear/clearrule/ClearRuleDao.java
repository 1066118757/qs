package com.cdid.dao.dataclear.clearrule;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/12/13
 */
import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.records.TClearRuleRecord;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

import static com.cdid.jooq.tables.TClearRule.T_CLEAR_RULE;

@Repository
public class ClearRuleDao extends BaseDaoImpl<TClearRuleRecord, BigDecimal> {
    @Autowired
    DSLContext dsl;

    public ClearRuleDao() {
        super(T_CLEAR_RULE);
    }

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }

}

