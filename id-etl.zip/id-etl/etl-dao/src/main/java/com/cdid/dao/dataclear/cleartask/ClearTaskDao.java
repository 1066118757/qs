package com.cdid.dao.dataclear.cleartask;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/12/13
 */
import com.cdid.common.constant.RecordStatus;
import com.cdid.dao.BaseDaoImpl;
import com.cdid.common.dict.ClearType;
import com.cdid.jooq.tables.records.TClearTaskRecord;
import com.cdid.utils.StringUtil;
import org.jooq.Condition;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.jooq.Record2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static com.cdid.jooq.tables.TClearTask.T_CLEAR_TASK;

@Repository
public class ClearTaskDao extends BaseDaoImpl<TClearTaskRecord, BigDecimal> {
    @Autowired
    DSLContext dsl;

    public ClearTaskDao() {
        super(T_CLEAR_TASK);
    }

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }

    public TClearTaskRecord[] findAll(){
        int status = RecordStatus.Effective.getStatus();
        TClearTaskRecord[] tClearTaskRecords = dsl.selectFrom(T_CLEAR_TASK)
                .where(T_CLEAR_TASK.TYPE.eq(ClearType.CRONTAB.getValue()),T_CLEAR_TASK.STATUS.eq(status))
                .fetchArray();
        return tClearTaskRecords;
    }

    public List<Record2<BigDecimal,String>> findIdNameByIds(Collection<BigDecimal> idList){
        return dsl.select(T_CLEAR_TASK.ID,T_CLEAR_TASK.NAME).from(T_CLEAR_TASK).where(T_CLEAR_TASK.ID.in(idList)).fetch();
    }

    public List<Record2<BigDecimal,String>> findSelectableDependenceJob(String name){
        List<Condition> conditionList=new ArrayList<>();
        if(StringUtil.isNotEmpty(name)){
            conditionList.add(T_CLEAR_TASK.NAME.like("%"+name+"%"));
        }
        conditionList.add(T_CLEAR_TASK.CRON_CODE.like("%\"day\":1%"));
        return dsl.select(T_CLEAR_TASK.ID,T_CLEAR_TASK.NAME).from(T_CLEAR_TASK).where(conditionList).fetch();
    }
}

