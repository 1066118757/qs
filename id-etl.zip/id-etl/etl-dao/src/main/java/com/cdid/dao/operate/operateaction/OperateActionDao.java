package com.cdid.dao.operate.operateaction;

import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.TOperateAction;
import com.cdid.jooq.tables.records.TOperateActionRecord;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

/**
 * @Author LQL
 * @CreateAt 2017/11/28
 */

/**
 * 日志操作描述
 */
@Repository
public class OperateActionDao extends BaseDaoImpl<TOperateActionRecord, BigDecimal> {
    @Autowired
    private DSLContext dsl;

    @Override
    public Configuration getConfiguration() { return dsl.configuration(); }

    public OperateActionDao() {
        super(TOperateAction.T_OPERATE_ACTION);
    }

}
