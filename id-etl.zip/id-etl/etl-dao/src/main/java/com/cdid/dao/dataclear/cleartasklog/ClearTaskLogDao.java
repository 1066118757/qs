package com.cdid.dao.dataclear.cleartasklog;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/12/13
 */
import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.records.TClearTaskLogRecord;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.jooq.Field;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.Timestamp;

import static com.cdid.jooq.tables.TClearTaskLog.T_CLEAR_TASK_LOG;

@Repository
public class ClearTaskLogDao extends BaseDaoImpl<TClearTaskLogRecord, BigDecimal> {
    @Autowired
    DSLContext dsl;

    public ClearTaskLogDao() {
        super(T_CLEAR_TASK_LOG);
    }

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }

    public TClearTaskLogRecord findTaskLatestLog(BigDecimal taskId) {
        Field<Timestamp> maxStartTime = dsl.select(T_CLEAR_TASK_LOG.START_TIME.max()).from(T_CLEAR_TASK_LOG).where(T_CLEAR_TASK_LOG.TASK_ID.eq(taskId)).asField();
        return dsl.selectFrom(T_CLEAR_TASK_LOG)
                .where(T_CLEAR_TASK_LOG.START_TIME.eq(maxStartTime), T_CLEAR_TASK_LOG.TASK_ID.eq(taskId)).fetchAny();
    }

    public void deleteByTaskId(BigDecimal taskId) {
        dsl.delete(T_CLEAR_TASK_LOG).where(T_CLEAR_TASK_LOG.TASK_ID.eq(taskId)).execute();
    }

}

