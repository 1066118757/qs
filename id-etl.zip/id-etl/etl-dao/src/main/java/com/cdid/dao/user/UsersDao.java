package com.cdid.dao.user;

import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.MGroupUser;
import com.cdid.jooq.tables.Users;
import com.cdid.jooq.tables.records.UsersRecord;
import org.jooq.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class UsersDao extends BaseDaoImpl<UsersRecord,BigDecimal> {

    @Autowired
    DSLContext dsl;

    public UsersDao() {
        super(Users.USERS);
    }

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }

    /**
     * 通过userId查询名字
     * @param userId
     * @return
     */
    public String getNameByUserId(String userId){
        String name="";
        Record1<String> fetchAny = dsl.select(Users.USERS.FIRST_NAME).from(Users.USERS).where(Users.USERS.GUID.eq(userId)).fetchAny();
        if (fetchAny!=null && fetchAny.size()>0){
            name=fetchAny.value1();
        }
        return name;
    }

    /**
     *  通过userId查询名字
     * @param userIds
     * @return
     */
    public Map<String, Result<Record2<String,String>>> getNameByUserIds(String ... userIds){
        Map<String, Result<Record2<String, String>>> stringResultMap = dsl.select(Users.USERS.FIRST_NAME, Users.USERS.GUID).from(Users.USERS).where(Users.USERS.GUID.in(userIds))
                .fetchGroups(Users.USERS.GUID);
        return stringResultMap;
    }

    /**
     * 通过名称模糊查询ids
     * @param name
     * @return
     */
    public String[] getIdsByName(String name){
        String[] ids = dsl.select(Users.USERS.GUID).from(Users.USERS)
                .where(Users.USERS.FIRST_NAME.like("%" + name + "%")).fetchArray(Users.USERS.GUID);
        return ids;
    }


    public UsersRecord findByGuId(String guid){
        return dsl.selectFrom(Users.USERS).where(Users.USERS.GUID.eq(guid)).fetchAny();
    }

    public boolean updatePriKeyAndPubKey(String guid,String publicKey,String privateKey){
        return dsl.update(Users.USERS).set(Users.USERS.PUBLIC_KEY, publicKey).set(Users.USERS.PRIVATE_KEY, privateKey)
                .where(Users.USERS.GUID.eq(guid)).execute() > 0;
    }

    public PageVo<Record2<String,String>>  findGroupUserByPage(String groupId,OffsetPagingVo offsetPagingVo){
        Condition condition=Users.USERS.GUID.in(dsl.select(MGroupUser.M_GROUP_USER.USER_ID).from(MGroupUser.M_GROUP_USER).where(MGroupUser.M_GROUP_USER.GROUP_ID.eq(groupId)));
        List<Record2<String,String>> content= dsl.select(Users.USERS.GUID,Users.USERS.FIRST_NAME).where(condition).orderBy(Users.USERS.FIRST_NAME.asc()).limit(offsetPagingVo.getOffset(),offsetPagingVo.getSize()).fetch();
        Integer total=dsl.selectCount().from(Users.USERS).where(condition).fetchAny().value1();
        return new PageVo<>(total,content);
    }

    public Map<String,String> getUserIdNameMap(Collection<String> userIds){
        List<Record2<String,String>> users=dsl.select(Users.USERS.GUID,Users.USERS.FIRST_NAME).from(Users.USERS).where(Users.USERS.GUID.in(userIds)).fetch();
        Map<String,String> userIdNameMap=new HashMap<>();
        for(Record2<String,String> record:users){
            userIdNameMap.put(record.value1(),record.value2());
        }
        return  userIdNameMap;
    }


}
