package com.cdid.dao.file;


import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.TFile;
import com.cdid.jooq.tables.records.TFileRecord;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

/**
 * @Author Froid_Li
 * @Email 269504518@qq.com
 * @Date 2017/11/24  17:22
 */
@Repository
public class FileDao extends BaseDaoImpl<TFileRecord, BigDecimal> {
    @Autowired
    DSLContext dsl;

    public FileDao() {
        super(TFile.T_FILE);
    }

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }
}
