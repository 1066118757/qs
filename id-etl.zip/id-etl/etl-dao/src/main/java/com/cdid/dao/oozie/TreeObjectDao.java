package com.cdid.dao.oozie;

import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.*;
import com.cdid.jooq.tables.records.TTreeObjectRecord;
import org.jooq.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

@Repository
public class TreeObjectDao extends BaseDaoImpl<TTreeObjectRecord,BigDecimal> {

    @Autowired
    DSLContext dsl;
    @Override
    public Configuration getConfiguration() {
         return dsl.configuration();
    }

    public TreeObjectDao() {
        super(TTreeObject.T_TREE_OBJECT);
    }

    public  List<org.jooq.Record9<BigDecimal, String, BigDecimal, String, Timestamp, String, Boolean, String, String>> queryProgramTree(List<Condition> conditionList, OffsetPagingVo offsetPagingVo){
        return dsl.select(TTreeObject.T_TREE_OBJECT.ID,
                TTreeObject.T_TREE_OBJECT.NAME,
                TProgram.T_PROGRAM.ID,
                TProgram.T_PROGRAM.NAME,
                TProgram.T_PROGRAM.CREATE_TIME,
                Users.USERS.FIRST_NAME,
                TProgram.T_PROGRAM.DOWNLOADABLE,
                TProgram.T_PROGRAM.PROGRAMTYPE,
                TProgram.T_PROGRAM.DESCRIPTION)
                .from(TTreeObject.T_TREE_OBJECT)
                .leftJoin(TProgram.T_PROGRAM).on(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID.eq(TProgram.T_PROGRAM.ID))
                .leftJoin(Users.USERS).on(TProgram.T_PROGRAM.OWNER.eq(Users.USERS.GUID))
                .where(conditionList)
                .orderBy(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID.nvl2(1,0).asc(),TTreeObject.T_TREE_OBJECT.NAME.asc())
                .limit(offsetPagingVo.getOffset(),offsetPagingVo.getSize()).fetch();
    }

    public PageVo<Record9<BigDecimal, String, BigDecimal, String, Timestamp, String, Boolean, String, String>> queryPrograms(List<Condition> conditionList, OffsetPagingVo offsetPagingVo){
        List<Record9<BigDecimal, String, BigDecimal, String, Timestamp, String, Boolean, String, String>> content = dsl.select(
                TTreeObject.T_TREE_OBJECT.ID,
                TTreeObject.T_TREE_OBJECT.NAME,
                TProgram.T_PROGRAM.ID,
                TProgram.T_PROGRAM.NAME,
                TProgram.T_PROGRAM.CREATE_TIME,
                Users.USERS.FIRST_NAME,
                TProgram.T_PROGRAM.DOWNLOADABLE,
                TProgram.T_PROGRAM.PROGRAMTYPE,
                TProgram.T_PROGRAM.DESCRIPTION)
                .from(TTreeObject.T_TREE_OBJECT)
                .innerJoin(TProgram.T_PROGRAM).on(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID.eq(TProgram.T_PROGRAM.ID))
                .leftJoin(Users.USERS).on(TProgram.T_PROGRAM.OWNER.eq(Users.USERS.GUID))
                .where(conditionList)
                .orderBy(TTreeObject.T_TREE_OBJECT.NAME.asc())
                .limit(offsetPagingVo.getOffset(),offsetPagingVo.getSize()).fetch();
        int total=dsl.selectCount().from(TTreeObject.T_TREE_OBJECT)
                .innerJoin(TProgram.T_PROGRAM)
                .on(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID.eq(TProgram.T_PROGRAM.ID))
                .where(conditionList).fetchAny().value1();
        return new PageVo<>(total,content);
    }


    public List<org.jooq.Record8<BigDecimal, String, BigDecimal, String, String, String,String,Timestamp>> queryFileTree(List<Condition> conditionList,OffsetPagingVo offsetPagingVo){
       return   dsl.select(TTreeObject.T_TREE_OBJECT.ID,
                TTreeObject.T_TREE_OBJECT.NAME,
                TStorageData.T_STORAGE_DATA.ID,
                TStorageData.T_STORAGE_DATA.NAME,
                TFile.T_FILE.PATH,
                TFile.T_FILE.FILE_TYPE,
               Users.USERS.FIRST_NAME,
               TStorageData.T_STORAGE_DATA.CREATE_TIME)
               .from(TTreeObject.T_TREE_OBJECT)
                .leftJoin(TStorageData.T_STORAGE_DATA).on(TStorageData.T_STORAGE_DATA.ID.eq(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID))
                .leftJoin(TFile.T_FILE).on(TStorageData.T_STORAGE_DATA.FILE_ID.eq(TFile.T_FILE.ID))
               .leftJoin(Users.USERS).on(TStorageData.T_STORAGE_DATA.CREATE_USER.eq(Users.USERS.GUID))
               .where(conditionList)
                .orderBy(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID.nvl2(1,0).asc(),TTreeObject.T_TREE_OBJECT.NAME.asc())
               .limit(offsetPagingVo.getOffset(),offsetPagingVo.getSize()).fetch();
    }

    public PageVo<Record8<BigDecimal, String, BigDecimal, String, String, String,String,Timestamp>> queryFiles(List<Condition> conditionList,OffsetPagingVo offsetPagingVo){
        List<Record8<BigDecimal, String, BigDecimal, String, String, String,String,Timestamp>>  content= dsl.select(TTreeObject.T_TREE_OBJECT.ID,
                TTreeObject.T_TREE_OBJECT.NAME,
                TStorageData.T_STORAGE_DATA.ID,
                TStorageData.T_STORAGE_DATA.NAME,
                TFile.T_FILE.PATH,
                TFile.T_FILE.FILE_TYPE,
                Users.USERS.FIRST_NAME,
                TStorageData.T_STORAGE_DATA.CREATE_TIME)
                .from(TTreeObject.T_TREE_OBJECT)
                .innerJoin(TStorageData.T_STORAGE_DATA).on(TStorageData.T_STORAGE_DATA.ID.eq(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID))
                .innerJoin(TFile.T_FILE).on(TStorageData.T_STORAGE_DATA.FILE_ID.eq(TFile.T_FILE.ID))
                .leftJoin(Users.USERS).on(TStorageData.T_STORAGE_DATA.CREATE_USER.eq(Users.USERS.GUID))
                .where(conditionList)
                .orderBy(TTreeObject.T_TREE_OBJECT.NAME.asc())
                .limit(offsetPagingVo.getOffset(),offsetPagingVo.getSize()).fetch();
        int total=dsl.selectCount().from(TTreeObject.T_TREE_OBJECT)
                .innerJoin(TStorageData.T_STORAGE_DATA)
                .on(TStorageData.T_STORAGE_DATA.ID.eq(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID))
                .innerJoin(TFile.T_FILE).on(TStorageData.T_STORAGE_DATA.FILE_ID.eq(TFile.T_FILE.ID))
                .where(conditionList).fetchAny().value1();
        return new PageVo<>(total,content);
    }

    public List<org.jooq.Record6<BigDecimal, String, BigDecimal, String, Timestamp, String>> queryTableTree(List<Condition> conditionList, OffsetPagingVo offsetPagingVo){
        return dsl.select(TTreeObject.T_TREE_OBJECT.ID,
                TTreeObject.T_TREE_OBJECT.NAME,
                TMetadataItem.T_METADATA_ITEM.ID,
                TMetadataItem.T_METADATA_ITEM.NAME,
                TMetadataItem.T_METADATA_ITEM.CREATE_TIME,
                Users.USERS.FIRST_NAME)
                .from(TTreeObject.T_TREE_OBJECT)
                .leftJoin(TMetadataItem.T_METADATA_ITEM).on(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID.eq(TMetadataItem.T_METADATA_ITEM.ID))
                .leftJoin(Users.USERS).on(TMetadataItem.T_METADATA_ITEM.CREATE_USER.eq(Users.USERS.GUID))
                .where(conditionList)
                .orderBy(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID.nvl2(1,0).asc(),TTreeObject.T_TREE_OBJECT.NAME.asc())
                .limit(offsetPagingVo.getOffset(),offsetPagingVo.getSize()).fetch();
    }

    public PageVo<Record6<BigDecimal, String, BigDecimal, String, Timestamp, String>> queryTables(List<Condition> conditionList, OffsetPagingVo offsetPagingVo){
        List<Record6<BigDecimal, String, BigDecimal, String, Timestamp, String>> content = dsl.select(TTreeObject.T_TREE_OBJECT.ID,
                TTreeObject.T_TREE_OBJECT.NAME,
                TMetadataItem.T_METADATA_ITEM.ID,
                TMetadataItem.T_METADATA_ITEM.NAME,
                TMetadataItem.T_METADATA_ITEM.CREATE_TIME,
                Users.USERS.FIRST_NAME)
                .from(TTreeObject.T_TREE_OBJECT)
                .innerJoin(TMetadataItem.T_METADATA_ITEM).on(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID.eq(TMetadataItem.T_METADATA_ITEM.ID))
                .leftJoin(Users.USERS).on(TMetadataItem.T_METADATA_ITEM.CREATE_USER.eq(Users.USERS.GUID))
                .where(conditionList)
                .orderBy(TTreeObject.T_TREE_OBJECT.NAME.asc())
                .limit(offsetPagingVo.getOffset(),offsetPagingVo.getSize()).fetch();
        int total=dsl.selectCount().from(TTreeObject.T_TREE_OBJECT)
                .innerJoin(TMetadataItem.T_METADATA_ITEM).on(TTreeObject.T_TREE_OBJECT.SOURCE_OBJECT_ID.eq(TMetadataItem.T_METADATA_ITEM.ID))
                .where(conditionList).fetchAny().value1();
        return new PageVo<>(total,content);
    }


    public Integer queryTotalByCondition(List<Condition> conditionList){
       return  dsl.selectCount().from(TTreeObject.T_TREE_OBJECT).where(conditionList).fetchAny().value1();
    }


}
