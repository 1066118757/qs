package com.cdid.dao.metadata.themeitem;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/11/24
 */
import com.cdid.common.constant.RecordStatus;
import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.records.TMetadataThemeItemRecord;
import org.jooq.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import static com.cdid.jooq.tables.TMetadataThemeItem.T_METADATA_THEME_ITEM;
import static com.cdid.jooq.tables.TMetadataTheme.T_METADATA_THEME;

@Repository
public class ThemeItemDao extends BaseDaoImpl<TMetadataThemeItemRecord, BigDecimal> {
    @Autowired
    DSLContext dsl;

    public ThemeItemDao() {
        super(T_METADATA_THEME_ITEM);
    }

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }

    public void deleteByThemeId(BigDecimal themeId){
        dsl.delete(T_METADATA_THEME_ITEM).where(T_METADATA_THEME_ITEM.THEME_ID.eq(themeId)).execute();
    }


    public PageVo<Record> listByPage(List<Condition> conditions, OffsetPagingVo offsetPagingVo, Collection<SortField<?>> sortFields) {
        PageVo<Record> pageVo = new PageVo<>();
        Record[] records = dsl.select().from(T_METADATA_THEME_ITEM).leftJoin(T_METADATA_THEME).on(T_METADATA_THEME_ITEM.THEME_ID.eq(T_METADATA_THEME.ID))
                .where(conditions).orderBy(sortFields).limit(offsetPagingVo.getOffset(), offsetPagingVo.getSize()).fetchArray();

        ArrayList<Record> arrayList = new ArrayList<>(Arrays.asList(records));
        Integer count = dsl.selectCount().from(T_METADATA_THEME_ITEM).leftJoin(T_METADATA_THEME).on(T_METADATA_THEME_ITEM.THEME_ID.eq(T_METADATA_THEME.ID))
                .where(conditions).fetchAny().value1();
        pageVo.setPageData(arrayList);

        pageVo.setTotalCount(count);

        return pageVo;
    }

    public Result<Record2<BigDecimal, String>> listMenu(){
        Result<Record2<BigDecimal, String>> fetch =
                dsl.select(T_METADATA_THEME_ITEM.ID.as("id"),
                        T_METADATA_THEME_ITEM.NAME.as("name"))
                        .from(T_METADATA_THEME_ITEM)
                        .where(T_METADATA_THEME_ITEM.STATUS.eq(RecordStatus.Effective.getStatus()))
                        .fetch();

        return fetch;
    }
}

