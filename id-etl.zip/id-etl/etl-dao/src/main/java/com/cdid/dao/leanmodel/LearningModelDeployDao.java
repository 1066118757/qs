package com.cdid.dao.leanmodel;


import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.records.LearningModelDeployRecord;
import com.cdid.jooq.tables.records.TDataSourceRecord;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.jooq.Record2;
import org.jooq.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import static com.cdid.jooq.tables.LearningModelDeploy.LEARNING_MODEL_DEPLOY;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/02 14:49 
 */
@Repository
public class LearningModelDeployDao extends BaseDaoImpl<LearningModelDeployRecord, String> {
    @Autowired
    DSLContext dsl;

    public LearningModelDeployDao() {
        super(LEARNING_MODEL_DEPLOY);
    }

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }

    public Result<Record2<String, String>> getAll(){
        return dsl.select(LEARNING_MODEL_DEPLOY.ID, LEARNING_MODEL_DEPLOY.SCHEDULE_CONFIG).from(LEARNING_MODEL_DEPLOY).where(LEARNING_MODEL_DEPLOY.SCHEDULE_CONFIG.isNotNull().and(LEARNING_MODEL_DEPLOY.SCHEDULE_CONFIG.ne(""))).fetch();
    }

}
