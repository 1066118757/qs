package com.cdid.dao.metadata.item;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/11/24
 */
import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.AnalyzeMapInfo;
import com.cdid.jooq.tables.records.AnalyzeMapInfoRecord;
import com.cdid.jooq.tables.records.TMetadataItemRecord;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.jooq.Record1;
import org.jooq.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

import static com.cdid.jooq.tables.TMetadataItem.T_METADATA_ITEM;
import static com.cdid.jooq.tables.TMetadataThemeItem.T_METADATA_THEME_ITEM;

@Repository
public class AnalyzeTableDao extends BaseDaoImpl<AnalyzeMapInfoRecord, BigDecimal> {
    @Autowired
    DSLContext dsl;

    public AnalyzeTableDao() {
        super(AnalyzeMapInfo.ANALYZE_MAP_INFO);
    }

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }


}

