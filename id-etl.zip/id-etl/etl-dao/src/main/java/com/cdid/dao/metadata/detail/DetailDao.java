package com.cdid.dao.metadata.detail;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/11/24
 */
import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.records.TMetadataDetailRecord;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

import static com.cdid.jooq.tables.TMetadataDetail.T_METADATA_DETAIL;

@Repository
public class DetailDao extends BaseDaoImpl<TMetadataDetailRecord, BigDecimal> {
    @Autowired
    DSLContext dsl;

    public DetailDao() {
        super(T_METADATA_DETAIL);
    }

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }

    public void deleteByItemId(BigDecimal itemId){
        dsl.delete(T_METADATA_DETAIL).where(T_METADATA_DETAIL.METADATA_ITEM_ID.eq(itemId)).execute();
    }

    public TMetadataDetailRecord[] getByItemId(BigDecimal itemId){
        TMetadataDetailRecord[] tMetadataDetailRecords = dsl.selectFrom(T_METADATA_DETAIL).where(T_METADATA_DETAIL.METADATA_ITEM_ID.eq(itemId)).fetchArray();
        return tMetadataDetailRecords;
    }
}

