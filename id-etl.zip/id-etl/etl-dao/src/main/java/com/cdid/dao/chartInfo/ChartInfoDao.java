package com.cdid.dao.chartInfo;


import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.records.ChartInfoRecord;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

import static com.cdid.jooq.tables.ChartInfo.CHART_INFO;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/02 14:49 
 */
@Repository
public class ChartInfoDao extends BaseDaoImpl<ChartInfoRecord, BigDecimal> {
    @Autowired
    DSLContext dsl;

    public ChartInfoDao() {
        super(CHART_INFO);
    }

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }

}
