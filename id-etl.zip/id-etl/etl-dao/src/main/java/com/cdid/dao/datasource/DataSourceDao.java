package com.cdid.dao.datasource;


import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.records.TDataSourceRecord;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import static com.cdid.jooq.tables.TDataSource.T_DATA_SOURCE;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/02 14:49 
 */
@Repository
public class DataSourceDao extends BaseDaoImpl<TDataSourceRecord, BigDecimal> {
    @Autowired
    DSLContext dsl;

    public DataSourceDao() {
        super(T_DATA_SOURCE);
    }

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }

    public void updateStatus(BigDecimal id,String userId,Short status){

        dsl.update(T_DATA_SOURCE)
                .set(T_DATA_SOURCE.STATUS, status)
                .set(T_DATA_SOURCE.UPDATE_TIME, new Timestamp(System.currentTimeMillis()))
                .set(T_DATA_SOURCE.UPDATE_USER, userId)
                .where(T_DATA_SOURCE.ID.eq(id)).execute();
    }

    public List<BigDecimal> findIdsByType(Integer type){
        List<BigDecimal> ids = dsl.select(T_DATA_SOURCE.ID).from(T_DATA_SOURCE).where(T_DATA_SOURCE.TYPE.eq(type)).fetch().getValues(T_DATA_SOURCE.ID);
        return ids;
    }
    public List<BigDecimal> findIdsByIds(String name){
        List<BigDecimal> ids = dsl.select(T_DATA_SOURCE.ID).from(T_DATA_SOURCE).where(T_DATA_SOURCE.NAME.like("%" +name+ "%")).fetch().getValues(T_DATA_SOURCE.ID);
        return ids;
    }
}
