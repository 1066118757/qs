package com.cdid.dao.dict;


import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.CDictMapping;
import com.cdid.jooq.tables.records.CDictMappingRecord;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.jooq.Record3;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

import static com.cdid.jooq.tables.CDictMapping.C_DICT_MAPPING;

/**
 * @Author Froid_Li
 * @Email 269504518@qq.com
 * @Date 2017/8/31  17:10
 */

@Repository
public class DictMappingDao extends BaseDaoImpl<CDictMappingRecord, BigDecimal> {
    @Autowired
    DSLContext dsl;

    public DictMappingDao() {
        super(CDictMapping.C_DICT_MAPPING);
    }

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }


    /**
     * @param typeId
     * @return
     */
    public Record3<Integer, Integer, Short> findNextRecord(Integer typeId) {
        return dsl.select(C_DICT_MAPPING.ID, C_DICT_MAPPING.TYPE_ID, C_DICT_MAPPING.KEY.max())
                .from(C_DICT_MAPPING).where(C_DICT_MAPPING.TYPE_ID.eq(typeId))
                .groupBy(C_DICT_MAPPING.ID).orderBy(C_DICT_MAPPING.KEY.desc()).limit(1).fetchOne();

    }
}
