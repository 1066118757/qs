package com.cdid.dao.schedulelog;


import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.records.TScheduleLogRecord;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.jooq.Field;
import org.jooq.ResultQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.Timestamp;

import static com.cdid.jooq.tables.TScheduleLog.T_SCHEDULE_LOG;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/02 14:49 
 */
@Repository
public class SchedulelogDao extends BaseDaoImpl<TScheduleLogRecord, BigDecimal> {
    @Autowired
    DSLContext dsl;

    public SchedulelogDao() {
        super(T_SCHEDULE_LOG);
    }

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }

    public TScheduleLogRecord findJobLatestLog(BigDecimal jobId) {
        Field<Timestamp> maxStartTime = dsl.select(T_SCHEDULE_LOG.SCHEDULE_STARTTIME.max()).from(T_SCHEDULE_LOG).where(T_SCHEDULE_LOG.JOB_ID.eq(jobId)).asField();
        return dsl.selectFrom(T_SCHEDULE_LOG)
                .where(T_SCHEDULE_LOG.SCHEDULE_STARTTIME.eq(maxStartTime), T_SCHEDULE_LOG.JOB_ID.eq(jobId)).fetchAny();
    }

    public void deleteByJobId(BigDecimal jobId){
        dsl.delete(T_SCHEDULE_LOG).where(T_SCHEDULE_LOG.JOB_ID.eq(jobId))
                .execute();
    }
}
