package com.cdid.dao.oozie;


import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.TOozieJob;
import com.cdid.jooq.tables.TOozieJobLog;
import com.cdid.jooq.tables.records.TOozieJobLogRecord;
import com.cdid.jooq.tables.records.TOozieJobRecord;
import org.jooq.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public class OozieJobLogDao extends BaseDaoImpl<TOozieJobLogRecord,BigDecimal> {

    @Autowired
    private DSLContext dsl;

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }

    public OozieJobLogDao() {
        super(TOozieJobLog.T_OOZIE_JOB_LOG);
    }

    public List<Record2<String,Integer>> statisticsByStatus(List<Condition> conditionList){
       return  dsl.select(TOozieJobLog.T_OOZIE_JOB_LOG.STATUS,TOozieJobLog.T_OOZIE_JOB_LOG.ID.count())
                .from(TOozieJobLog.T_OOZIE_JOB_LOG)
                .innerJoin(TOozieJob.T_OOZIE_JOB).on(TOozieJobLog.T_OOZIE_JOB_LOG.JOB_ID.eq(TOozieJob.T_OOZIE_JOB.ID))
                .where(conditionList).groupBy(TOozieJobLog.T_OOZIE_JOB_LOG.STATUS).fetch();
    }
}
