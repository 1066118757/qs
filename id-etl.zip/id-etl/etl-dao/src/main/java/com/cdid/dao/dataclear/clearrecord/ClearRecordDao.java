package com.cdid.dao.dataclear.clearrecord;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/12/13
 */
import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.records.TClearRecordRecord;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

import static com.cdid.jooq.tables.TClearRecord.T_CLEAR_RECORD;

@Repository
public class ClearRecordDao extends BaseDaoImpl<TClearRecordRecord, BigDecimal> {
    @Autowired
    DSLContext dsl;

    public ClearRecordDao() {
        super(T_CLEAR_RECORD);
    }

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }

}

