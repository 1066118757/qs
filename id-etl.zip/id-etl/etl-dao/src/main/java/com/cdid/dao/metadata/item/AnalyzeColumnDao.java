package com.cdid.dao.metadata.item;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/11/24
 */
import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.AnalyzeMapDetail;
import com.cdid.jooq.tables.AnalyzeMapInfo;
import com.cdid.jooq.tables.records.AnalyzeMapDetailRecord;
import com.cdid.jooq.tables.records.AnalyzeMapInfoRecord;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

@Repository
public class AnalyzeColumnDao extends BaseDaoImpl<AnalyzeMapDetailRecord, BigDecimal> {
    @Autowired
    DSLContext dsl;

    public AnalyzeColumnDao() {
        super(AnalyzeMapDetail.ANALYZE_MAP_DETAIL);
    }

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }


}

