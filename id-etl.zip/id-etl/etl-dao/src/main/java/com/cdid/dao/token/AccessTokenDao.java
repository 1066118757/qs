package com.cdid.dao.token;

import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.AccessTokens;
import com.cdid.jooq.tables.TStorageData;
import com.cdid.jooq.tables.records.AccessTokensRecord;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

@Repository
public class AccessTokenDao extends BaseDaoImpl<AccessTokensRecord,BigDecimal> {

    @Autowired
    DSLContext dsl;

    public AccessTokenDao() {
        super(AccessTokens.ACCESS_TOKENS);
    }

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }


}
