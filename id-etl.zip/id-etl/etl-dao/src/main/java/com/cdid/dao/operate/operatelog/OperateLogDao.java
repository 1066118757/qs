package com.cdid.dao.operate.operatelog;

import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.records.TOperateLogRecord;
import org.jooq.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.cdid.jooq.tables.TOperateLog.T_OPERATE_LOG;
import static com.cdid.jooq.tables.TOperateAction.T_OPERATE_ACTION;
import static com.cdid.jooq.tables.Users.USERS;

@Repository
public class OperateLogDao extends BaseDaoImpl<TOperateLogRecord, BigDecimal> {
    @Autowired
    private DSLContext dsl;

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }

    public OperateLogDao() {
        super(T_OPERATE_LOG);
    }

    /**
     * 关联查询日志信息
     * @param conditions
     * @param sortFields
     * @param pageNo
     * @param pageSize
     * @return
     */
    public Map<String, Object> list(List<Condition> conditions, Collection<SortField<?>> sortFields, Integer pageNo, Integer pageSize) {
        Map<String, Object> resultMap = new HashMap<>();
        Record[] records = dsl.select(
                T_OPERATE_LOG.ID.as("log_id"),
                T_OPERATE_LOG.OPERATE_TIME.as("log_operate_time"),
                T_OPERATE_LOG.ACTION_ID.as("log_action_id"),
                T_OPERATE_LOG.OPERATE_TABLE.as("log_operate_table"),
                T_OPERATE_LOG.OPERATOR_ID.as("log_operator_id"),
                T_OPERATE_LOG.RESULT.as("log_result"),
                T_OPERATE_ACTION.ACTION_DESC.as("action_desc"),
                USERS.FIRST_NAME.as("operator_name"),
                USERS.SCOPE.as("operator_type"),
                USERS.LOGIN_ACCOUNT.as("operator_account")
        )
                .from(T_OPERATE_LOG)
                .leftJoin(T_OPERATE_ACTION).on(T_OPERATE_LOG.ACTION_ID.eq(T_OPERATE_ACTION.ID))
                .leftJoin(USERS).on(T_OPERATE_LOG.OPERATOR_ID.eq(USERS.GUID))
                .where(conditions)
                .orderBy(sortFields)
                .limit(pageSize)
                .offset((pageNo - 1) * pageSize)
                .fetchArray();
        Integer total = dsl.selectCount()
                .from(T_OPERATE_LOG)
                .leftJoin(T_OPERATE_ACTION).on(T_OPERATE_LOG.ACTION_ID.eq(T_OPERATE_ACTION.ID))
                .leftJoin(USERS).on(T_OPERATE_LOG.OPERATOR_ID.eq(USERS.GUID))
                .where(conditions)
                .fetchAny().value1();
        resultMap.put("data", records);
        resultMap.put("total", total);
        return resultMap;
    }
}
