package com.cdid.dao.metadata.item;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/11/24
 */
import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.records.TMetadataItemRecord;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.jooq.Record1;
import org.jooq.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

import static com.cdid.jooq.tables.TMetadataItem.T_METADATA_ITEM;
import static com.cdid.jooq.tables.TMetadataThemeItem.T_METADATA_THEME_ITEM;

@Repository
public class ItemDao extends BaseDaoImpl<TMetadataItemRecord, BigDecimal> {
    @Autowired
    DSLContext dsl;

    public ItemDao() {
        super(T_METADATA_ITEM);
    }

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }

    /**
     * 依据表名查询信息
     * @param tableName
     * @return
     */
    public TMetadataItemRecord[] getInfoByTableName(String tableName){
        TMetadataItemRecord[] tMetadataItemRecords = dsl.selectFrom(T_METADATA_ITEM).where(T_METADATA_ITEM.NAME.eq(tableName)).fetchArray();
        return tMetadataItemRecords;
    }


    public BigDecimal fetchIdByThemeItemIdAndName(BigDecimal themeItemId,String name){
        Record1<BigDecimal> record = dsl.select(T_METADATA_ITEM.ID).from(T_METADATA_ITEM)
                .where(T_METADATA_ITEM.THEME_ITEM_ID.eq(themeItemId))
                .and(T_METADATA_ITEM.NAME.eq(name)).fetchAny();
        if(record == null){
            return null;
        }
        return record.value1();
    }

    public String fetchCreateUserByName(String name){
        Record1<String> record = dsl.select(T_METADATA_ITEM.CREATE_USER).from(T_METADATA_ITEM)
                .where(T_METADATA_ITEM.NAME.eq(name)).fetchAny();
        if(record == null){
            return null;
        }
        return record.value1();
    }
    public Result<TMetadataItemRecord> fetchAll(String userId){
        return dsl.selectFrom(T_METADATA_ITEM)
                .where(T_METADATA_ITEM.CREATE_USER.eq(userId)).fetch();
    }

    public boolean isShare(String tableName){

        return dsl.select(T_METADATA_ITEM.ID).from(T_METADATA_ITEM)
                .leftJoin(T_METADATA_THEME_ITEM).on(T_METADATA_THEME_ITEM.ID.eq(T_METADATA_ITEM.THEME_ITEM_ID))
                .where(T_METADATA_ITEM.NAME.eq(tableName))
                .and(T_METADATA_THEME_ITEM.THEME_ID.eq(BigDecimal.valueOf(100L)))
                .fetch().size() > 0;
    }

    public TMetadataItemRecord findByName(String tableName){
        TMetadataItemRecord tMetadataItemRecord = dsl.selectFrom(T_METADATA_ITEM).where(T_METADATA_ITEM.NAME.eq(tableName)).fetchAny();
        return tMetadataItemRecord;
    }
}

