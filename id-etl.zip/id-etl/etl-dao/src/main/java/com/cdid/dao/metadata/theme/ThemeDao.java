package com.cdid.dao.metadata.theme;

/**
 * @author OuZhiCheng
 * @create 创建时间：2017/11/24
 */
import com.cdid.common.constant.RecordStatus;
import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.records.TMetadataThemeRecord;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.jooq.Record2;
import org.jooq.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

import static com.cdid.jooq.tables.TMetadataTheme.T_METADATA_THEME;
@Repository
public class ThemeDao extends BaseDaoImpl<TMetadataThemeRecord, BigDecimal> {
    @Autowired
    DSLContext dsl;

    public ThemeDao() {
        super(T_METADATA_THEME);
    }

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }


    public Result<Record2<BigDecimal, String>> listMenu(){
        Result<Record2<BigDecimal, String>> fetch =
                dsl.select(T_METADATA_THEME.ID.as("id"),
                        T_METADATA_THEME.NAME.as("name"))
                .from(T_METADATA_THEME)
                .where(T_METADATA_THEME.STATUS.eq(RecordStatus.Effective.getStatus()))
                .fetch();

        return fetch;
    }

    public TMetadataThemeRecord[] getInfoByName(String name){
        TMetadataThemeRecord[] tMetadataThemeRecords = dsl.selectFrom(T_METADATA_THEME).where(T_METADATA_THEME.NAME.eq(name)).fetchArray();
        return tMetadataThemeRecords;
    }
}

