package com.cdid.dao.dict;


import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.CDictType;
import com.cdid.jooq.tables.records.CDictTypeRecord;
import org.jooq.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.cdid.jooq.tables.CDictMapping.C_DICT_MAPPING;
import static com.cdid.jooq.tables.CDictType.C_DICT_TYPE;

/**
 * @Author Froid_Li
 * @Email 269504518@qq.com
 * @Date 2017/8/31  17:16
 */
@Repository
public class DictTypeDao extends BaseDaoImpl<CDictTypeRecord, BigDecimal> {

    private static Logger logger = LoggerFactory.getLogger(DictTypeDao.class);
    @Autowired
    DSLContext dsl;

    public DictTypeDao() {
        super(CDictType.C_DICT_TYPE);
    }

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }

    public List<Map> findByTypeIds(List<Integer> typeIds, OffsetPagingVo offsetPagingVo) {
        logger.info("typeIds: " + typeIds);
        Record5[] r5 = dsl.select(C_DICT_TYPE.ID.as("typeId"), C_DICT_MAPPING.ID, C_DICT_TYPE.TYPE_NAME,
                 C_DICT_MAPPING.KEY, C_DICT_MAPPING.VALUE)
                .from(C_DICT_TYPE)
                .innerJoin(C_DICT_MAPPING).on(C_DICT_TYPE.ID.eq(C_DICT_MAPPING.TYPE_ID)).where(C_DICT_TYPE.ID.in(typeIds))
                .orderBy(C_DICT_TYPE.ID.asc()).limit(offsetPagingVo.getOffset(), offsetPagingVo.getSize())
                .fetchArray();

        List<Map> resultList = new ArrayList();

        for (Record5 rc5 : r5) {
            Map map = new HashMap<>();
            map.put("typeId", rc5.getValue(0));
            map.put("id", rc5.getValue(1));
            map.put("typeName", rc5.getValue(2));
            map.put("key", rc5.getValue(3));
            map.put("value", rc5.getValue(4));
            resultList.add(map);
        }


        return resultList;
    }

    public List<Map> findValue(Integer id, Short key) {
        List<Condition> conditions = new ArrayList<>();
        if (!StringUtils.isEmpty(id)) {
            conditions.add(C_DICT_TYPE.ID.eq(id));
        }
        if (!StringUtils.isEmpty(key)) {
            conditions.add(C_DICT_MAPPING.KEY.eq(key));
        }

        Record4[] r4 = dsl.select(C_DICT_MAPPING.TYPE_ID, C_DICT_TYPE.TYPE_NAME, C_DICT_MAPPING.KEY, C_DICT_MAPPING.VALUE).from(C_DICT_TYPE)
                .innerJoin(C_DICT_MAPPING).on(C_DICT_TYPE.ID.eq(C_DICT_MAPPING.TYPE_ID)).where(conditions).orderBy(C_DICT_MAPPING.KEY.asc()).fetchArray();
        List<Map> resultList = new ArrayList();
        for (Record4 rc4 : r4) {
            System.out.println(rc4.getValue(0));
            System.out.println(rc4.getValue(1));
            System.out.println(rc4.getValue(2));
            System.out.println(rc4.getValue(3));

            Map map = new HashMap<>();
            map.put("id", rc4.getValue(0));
            map.put("typeName", rc4.getValue(1));
            map.put("key", rc4.getValue(2));
            map.put("value", rc4.getValue(3));
            resultList.add(map);
        }

        return resultList;
    }

    public List<Map> findAll() {

        Record4[] r4 = dsl.select(C_DICT_TYPE.ID, C_DICT_TYPE.TYPE_NAME, C_DICT_MAPPING.ID.as("mappingId"), C_DICT_MAPPING.VALUE).from(C_DICT_TYPE)
                .innerJoin(C_DICT_MAPPING).on(C_DICT_TYPE.ID.eq(C_DICT_MAPPING.TYPE_ID)).orderBy(C_DICT_MAPPING.KEY.asc()).fetchArray();
        List<Map> resultList = new ArrayList();
        for (Record4 rc4 : r4) {
            Map map = new HashMap<>();
            map.put("id", rc4.getValue(0));
            map.put("typeName", rc4.getValue(1));
            map.put("mappingId", rc4.getValue(2));
            map.put("value", rc4.getValue(3));
            resultList.add(map);
        }

        return resultList;
    }


}
