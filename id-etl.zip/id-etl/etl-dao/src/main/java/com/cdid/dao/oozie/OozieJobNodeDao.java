package com.cdid.dao.oozie;

import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.MOoziejobNode;
import com.cdid.jooq.tables.TOozieShare;
import com.cdid.jooq.tables.records.MOoziejobNodeRecord;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

@Repository
public class OozieJobNodeDao extends BaseDaoImpl<MOoziejobNodeRecord,BigDecimal> {

    @Autowired
    DSLContext dsl;
    @Override
    public Configuration getConfiguration() {
         return dsl.configuration();
    }

    public OozieJobNodeDao() {
        super(MOoziejobNode.M_OOZIEJOB_NODE);
    }
}
