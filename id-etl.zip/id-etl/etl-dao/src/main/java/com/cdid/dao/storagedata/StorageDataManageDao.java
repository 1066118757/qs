package com.cdid.dao.storagedata;


import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.TStorageData;
import com.cdid.jooq.tables.records.TStorageDataRecord;
import org.jooq.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.List;

import static com.cdid.jooq.tables.TFile.T_FILE;
import static com.cdid.jooq.tables.TStorageData.T_STORAGE_DATA;
import static com.cdid.jooq.tables.Users.USERS;

/**
 * @Author Froid_Li
 * @Email 269504518@qq.com
 * @Date 2017/11/24  13:37
 */
@Repository
public class StorageDataManageDao extends BaseDaoImpl<TStorageDataRecord, BigDecimal> {
    @Autowired
    DSLContext dsl;

    public StorageDataManageDao() {
        super(TStorageData.T_STORAGE_DATA);
    }

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }

    /**
     * @param conditions
     * @param offsetPagingVo
     * @param sortFields
     * @return
     */
    public PageVo<Record10<BigDecimal, String, String, Integer, BigDecimal, Timestamp, String, String, String,Boolean>> fetchPage(List<Condition> conditions, OffsetPagingVo offsetPagingVo, Collection<SortField<?>> sortFields) {
        PageVo<Record10<BigDecimal, String, String, Integer, BigDecimal, Timestamp, String, String, String,Boolean>> pageVo = new PageVo<>();
        Result<Record10<BigDecimal, String, String, Integer, BigDecimal, Timestamp, String, String, String,Boolean>> fetch = dsl.select(
                T_STORAGE_DATA.ID.as("id"),
                T_STORAGE_DATA.NAME.as("name"),
                T_STORAGE_DATA.INTRODUCTION.as("introduction"),
                T_STORAGE_DATA.TYPE.as("type"),
                T_STORAGE_DATA.FILE_ID.as("fileId"),
                T_STORAGE_DATA.UPLOAD_TIME.as("uploadTime"),
                T_STORAGE_DATA.UPLOAD_USER_ID.as("uploadUserId"),
                USERS.FIRST_NAME.as("uploadUserName"),
                T_FILE.PATH.as("filePath"),
                T_STORAGE_DATA.IS_PUBLIC
        ).from(T_STORAGE_DATA)
                .innerJoin(T_FILE)
                .on(T_STORAGE_DATA.FILE_ID.eq(T_FILE.ID))
                .innerJoin(USERS)
                .on(T_STORAGE_DATA.UPLOAD_USER_ID.eq(USERS.GUID))
                .where(conditions).orderBy(sortFields)
                .limit(offsetPagingVo.getOffset(), offsetPagingVo.getSize())
                .fetch();

        Integer total = dsl.selectCount().from(T_STORAGE_DATA)
                .innerJoin(T_FILE)
                .on(T_FILE.ID.eq(T_STORAGE_DATA.FILE_ID))
                .where(conditions).fetchAny().value1();
        pageVo.setPageData(fetch);
        pageVo.setTotalCount(total);
        return pageVo;
    }

    /**
     * @param id
     * @return
     */
    public Record7<BigDecimal, String, String, String, Timestamp, String,String> detailById(BigDecimal id) {
        Record7<BigDecimal, String, String, String, Timestamp, String,String> result = dsl.select(
                T_STORAGE_DATA.FILE_ID,
                T_STORAGE_DATA.NAME,
                T_STORAGE_DATA.INTRODUCTION,
                T_STORAGE_DATA.UPLOAD_USER_ID,
                T_STORAGE_DATA.UPLOAD_TIME,
                T_FILE.PATH,
                USERS.FIRST_NAME.as("uploadUserName")
        ).from(T_STORAGE_DATA)
                .innerJoin(T_FILE)
                .on(T_STORAGE_DATA.FILE_ID.eq(T_FILE.ID))
                .innerJoin(USERS)
                .on(T_STORAGE_DATA.UPLOAD_USER_ID.eq(USERS.GUID))
                .fetchAny();
        return result;

    }


}
