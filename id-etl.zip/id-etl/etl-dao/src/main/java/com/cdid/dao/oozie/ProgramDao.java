package com.cdid.dao.oozie;


import com.cdid.common.vo.OffsetPagingVo;
import com.cdid.common.vo.PageVo;
import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.TProgram;
import com.cdid.jooq.tables.Users;
import com.cdid.jooq.tables.records.TProgramRecord;
import org.jooq.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.List;

@Repository
public class ProgramDao extends BaseDaoImpl<TProgramRecord,BigDecimal> {

    @Autowired
    private DSLContext dsl;

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }

    public ProgramDao() {
        super(TProgram.T_PROGRAM);
    }

    public PageVo<Record7<BigDecimal,String,Boolean,Boolean,String,String,Timestamp>> findByPage(List<Condition> conditionList, OffsetPagingVo pagingVo, Collection<SortField<?>> sortFields){
        List<Record7<BigDecimal,String,Boolean,Boolean,String,String,Timestamp>> content=dsl.select(TProgram.T_PROGRAM.ID,
                TProgram.T_PROGRAM.NAME,
                TProgram.T_PROGRAM.IS_PUBLIC,
                TProgram.T_PROGRAM.DOWNLOADABLE,
                TProgram.T_PROGRAM.PROGRAMTYPE,
                Users.USERS.FIRST_NAME,
                TProgram.T_PROGRAM.CREATE_TIME).from(TProgram.T_PROGRAM)
                .leftJoin(Users.USERS).on(TProgram.T_PROGRAM.OWNER.eq(Users.USERS.GUID))
                .where(conditionList)
                .orderBy(sortFields)
                .limit(pagingVo.getOffset(),pagingVo.getSize())
                .fetch();
        Integer totalCount=dsl.selectCount().from(TProgram.T_PROGRAM).where(conditionList).fetchAny().value1();
        return new PageVo(totalCount,content);
    }
}
