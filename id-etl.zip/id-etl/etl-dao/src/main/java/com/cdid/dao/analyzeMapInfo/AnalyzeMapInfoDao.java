package com.cdid.dao.analyzeMapInfo;


import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.records.AnalyzeMapInfoRecord;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.jooq.Record1;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static com.cdid.jooq.tables.AnalyzeMapInfo.ANALYZE_MAP_INFO;

/**
 *  @author         jamie  
 *  @version        V1.0   
 *  @date           2017/12/02 14:49 
 */
@Repository
public class AnalyzeMapInfoDao extends BaseDaoImpl<AnalyzeMapInfoRecord, BigDecimal> {
    @Autowired
    DSLContext dsl;

    public AnalyzeMapInfoDao() {
        super(ANALYZE_MAP_INFO);
    }

    @Override
    public Configuration getConfiguration() {
        return dsl.configuration();
    }

    public List<String> getUuidBySchemaAndTableName(String schema, String tableName){
        List<String> list=new ArrayList<>();
        Record1<String>[] fetchArray = dsl.select(ANALYZE_MAP_INFO.ANALYZE_MAP_INFO_UUID)
                .from(ANALYZE_MAP_INFO)
                .where(ANALYZE_MAP_INFO.SCHEMA.eq(schema))
                .and(ANALYZE_MAP_INFO.TABLE_NAME.eq(tableName))
                .fetchArray();
        for (Record1 item:fetchArray) {
            list.add((String)item.value1());
        }
        return list;
    }
}
