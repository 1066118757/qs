package com.cdid.dao.oozie;

import com.cdid.dao.BaseDaoImpl;
import com.cdid.jooq.tables.Group;
import com.cdid.jooq.tables.TOozieShare;
import com.cdid.jooq.tables.records.GroupRecord;
import com.cdid.jooq.tables.records.TOozieShareRecord;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

@Repository
public class GroupDao extends BaseDaoImpl<GroupRecord,String> {

    @Autowired
    DSLContext dsl;
    @Override
    public Configuration getConfiguration() {
         return dsl.configuration();
    }

    public GroupDao() {
        super(Group.GROUP);
    }
}
