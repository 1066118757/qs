1. 软件环境：
    + SpringBoot
    + Jooq
    + Postgres
    + Gradle啊飒飒的
